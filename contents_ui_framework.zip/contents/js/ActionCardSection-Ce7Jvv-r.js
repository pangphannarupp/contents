import{L as t}from"./AccountCardSection-DXixqG3L.js";import{d as r,o as s,j as n,l as e,a,u as l,F as i}from"../vendors/vendor-ah_eQdvw.js";const d={class:"guide-section"},c={style:{background:"#f4f5f8",padding:"20px","border-radius":"12px",display:"grid","grid-template-columns":"1fr 1fr",gap:"10px"}},p={class:"variant-group"},u={class:"variant-group"},g={class:"variant-group"},b={class:"variant-group"},f=r({__name:"ActionCardSection",setup(v){return(C,o)=>(s(),n(i,null,[e("div",d,[o[8]||(o[8]=e("h2",null,"4. PPActionCard Colors",-1)),e("div",c,[e("div",p,[o[0]||(o[0]=e("h3",null,"Pink Badge",-1)),a(l(t),{title:"Approval",subtitle:"Pending",badgeCount:"5",badgeColor:"pink"}),o[1]||(o[1]=e("pre",{class:"code-block"},[e("code",null,`<PPActionCard 
  title="Approval" 
  badgeColor="pink" 
/>`)],-1))]),e("div",u,[o[2]||(o[2]=e("h3",null,"Orange Badge",-1)),a(l(t),{title:"Payment",subtitle:"Due",badgeCount:"2",badgeColor:"orange"}),o[3]||(o[3]=e("pre",{class:"code-block"},[e("code",null,`<PPActionCard 
  title="Payment" 
  badgeColor="orange" 
/>`)],-1))]),e("div",g,[o[4]||(o[4]=e("h3",null,"Teal Badge",-1)),a(l(t),{title:"Transfer",subtitle:"Done",badgeCount:"1",badgeColor:"teal"}),o[5]||(o[5]=e("pre",{class:"code-block"},[e("code",null,`<PPActionCard 
  title="Transfer" 
  badgeColor="teal" 
/>`)],-1))]),e("div",b,[o[6]||(o[6]=e("h3",null,"Blue Badge",-1)),a(l(t),{title:"Send",badgeColor:"blue"}),o[7]||(o[7]=e("pre",{class:"code-block"},[e("code",null,`<PPActionCard 
  title="Send" 
  badgeColor="blue" 
/>`)],-1))])]),o[9]||(o[9]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[10]||(o[10]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>4. PPActionCard Colors</h2>
        <div style="background: #f4f5f8; padding: 20px; border-radius: 12px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
          
          <div class="variant-group">
            <h3>Pink Badge</h3>
            <PPActionCard title="Approval" subtitle="Pending" badgeCount="5" badgeColor="pink" />
            <pre class="code-block"><code>&lt;PPActionCard 
  title="Approval" 
  badgeColor="pink" 
/&gt;</code></pre>
          </div>

          <div class="variant-group">
            <h3>Orange Badge</h3>
            <PPActionCard title="Payment" subtitle="Due" badgeCount="2" badgeColor="orange" />
            <pre class="code-block"><code>&lt;PPActionCard 
  title="Payment" 
  badgeColor="orange" 
/&gt;</code></pre>
          </div>

          <div class="variant-group">
            <h3>Teal Badge</h3>
            <PPActionCard title="Transfer" subtitle="Done" badgeCount="1" badgeColor="teal" />
            <pre class="code-block"><code>&lt;PPActionCard 
  title="Transfer" 
  badgeColor="teal" 
/&gt;</code></pre>
          </div>

          <div class="variant-group">
            <h3>Blue Badge</h3>
            <PPActionCard title="Send" badgeColor="blue" />
            <pre class="code-block"><code>&lt;PPActionCard 
  title="Send" 
  badgeColor="blue" 
/&gt;</code></pre>
          </div>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPActionCard } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{f as _};
