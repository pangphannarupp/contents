import{m as e}from"../main.js";const o=r=>{const t=[];for(let a=0;a<r;a+=1)t.push(e.image.avatarGitHub());return t};export{o as f};
