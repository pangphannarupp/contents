import{P as r,bO as g}from"./AccountCardSection-DXixqG3L.js";import{d as v,o as y,j as b,l as o,a as s,w as l,A as p,u as i,F as P,p as c}from"../vendors/vendor-ah_eQdvw.js";import{_ as T}from"./App-D7rwXoHs.js";const h={class:"component-section"},w={class:"demo-box"},x={class:"demo-content"},k={style:{display:"flex",gap:"12px","flex-wrap":"wrap"}},B=v({__name:"WebToastSection",setup(C){const a=c(!1),u=c("info"),m=c("top-right"),f=c(""),n=(d,t)=>{a.value=!1,setTimeout(()=>{u.value=d,m.value=t,f.value=`This is a ${d} toast displayed at ${t}.`,a.value=!0},100)};return(d,t)=>(y(),b(P,null,[o("div",h,[t[11]||(t[11]=o("h2",null,"Web Toast",-1)),t[12]||(t[12]=o("p",null,"A desktop-friendly toast component that can be positioned at various corners of the screen.",-1)),o("div",w,[t[9]||(t[9]=o("h3",null,"Basic Toast",-1)),o("div",x,[o("div",k,[s(i(r),{onClick:t[0]||(t[0]=e=>n("info","top-right")),style:{color:"white"}},{default:l(()=>[...t[5]||(t[5]=[p("Info (Top Right)",-1)])]),_:1}),s(i(r),{onClick:t[1]||(t[1]=e=>n("success","bottom-right")),style:{"--pp-primary-variant":"#4caf50",color:"white"}},{default:l(()=>[...t[6]||(t[6]=[p("Success (Bottom Right)",-1)])]),_:1}),s(i(r),{onClick:t[2]||(t[2]=e=>n("error","top-center")),style:{"--pp-primary-variant":"#f44336",color:"white"}},{default:l(()=>[...t[7]||(t[7]=[p("Error (Top Center)",-1)])]),_:1}),s(i(r),{onClick:t[3]||(t[3]=e=>n("warning","bottom-left")),style:{"--pp-primary-variant":"#ff9800",color:"white"}},{default:l(()=>[...t[8]||(t[8]=[p("Warning (Bottom Left)",-1)])]),_:1})]),s(i(g),{modelValue:a.value,"onUpdate:modelValue":t[4]||(t[4]=e=>a.value=e),type:u.value,position:m.value,title:"Notification",message:f.value},null,8,["modelValue","type","position","message"])]),t[10]||(t[10]=o("pre",{class:"code-block"},[o("code",null,`<PPWebToast 
  v-model="isVisible"
  type="success|error|warning|info"
  position="top-right|top-left|bottom-right|bottom-left|top-center|bottom-center"
  title="Notification"
  message="This is a toast message."
/>`)],-1))]),t[13]||(t[13]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[14]||(t[14]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="component-section">
    <h2>Web Toast</h2>
    <p>A desktop-friendly toast component that can be positioned at various corners of the screen.</p>

    <div class="demo-box">
      <h3>Basic Toast</h3>
      <div class="demo-content">
        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
          <PPButton @click="showToast('info', 'top-right')" style="color: white;">Info (Top Right)</PPButton>
          <PPButton @click="showToast('success', 'bottom-right')" style="--pp-primary-variant: #4caf50; color: white;">Success (Bottom Right)</PPButton>
          <PPButton @click="showToast('error', 'top-center')" style="--pp-primary-variant: #f44336; color: white;">Error (Top Center)</PPButton>
          <PPButton @click="showToast('warning', 'bottom-left')" style="--pp-primary-variant: #ff9800; color: white;">Warning (Bottom Left)</PPButton>
        </div>

        <PPWebToast 
          v-model="toastVisible"
          :type="toastType"
          :position="toastPosition"
          title="Notification"
          :message="toastMessage"
        />
      </div>
      <pre class="code-block"><code>&lt;PPWebToast 
  v-model="isVisible"
  type="success|error|warning|info"
  position="top-right|top-left|bottom-right|bottom-left|top-center|bottom-center"
  title="Notification"
  message="This is a toast message."
/&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPButton, PPWebToast } from '@phanna/ui-framework';

const toastVisible = ref(false);
const toastType = ref('info');
const toastPosition = ref('top-right');
const toastMessage = ref('');

const showToast = (type: string, position: string) => {
  toastVisible.value = false;
  
  setTimeout(() => {
    toastType.value = type;
    toastPosition.value = position;
    toastMessage.value = \`This is a \${type} toast displayed at \${position}.\`;
    toastVisible.value = true;
  }, 100);
};
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 4px;
}
</style>
`)])],-1))],64))}}),$=T(B,[["__scopeId","data-v-18619409"]]);export{$ as W};
