import{aW as o}from"./AccountCardSection-DXixqG3L.js";import{d as c,o as d,j as u,l,a,u as i,F as m,p as n}from"../vendors/vendor-ah_eQdvw.js";const p={class:"guide-section"},g={class:"variant-group"},h={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"16px"}},v={class:"variant-group"},S={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"16px"}},V=c({__name:"SwitchSection",setup(b){const s=n(!1),P=n(!0),r=n(!1);return(f,e)=>(d(),u(m,null,[l("div",p,[e[9]||(e[9]=l("h2",null,"Switches",-1)),e[10]||(e[10]=l("p",{class:"guide-desc"},"A toggle switch component supporting multiple platform styles and Material Design 3.",-1)),l("div",g,[e[5]||(e[5]=l("h3",null,"Standard Styles",-1)),l("div",h,[a(i(o),{modelValue:s.value,"onUpdate:modelValue":e[0]||(e[0]=t=>s.value=t),label:"Standard Toggle"},null,8,["modelValue"]),a(i(o),{modelValue:s.value,"onUpdate:modelValue":e[1]||(e[1]=t=>s.value=t),label:"iOS Mode Toggle",mode:"ios",color:"secondary"},null,8,["modelValue"]),a(i(o),{modelValue:P.value,"onUpdate:modelValue":e[2]||(e[2]=t=>P.value=t),label:"Disabled Toggle",disabled:!0},null,8,["modelValue"])]),e[6]||(e[6]=l("pre",{class:"code-block"},[l("code",null,`<template>
  <PPSwitch v-model="switchVal1" label="Standard Toggle" />
  <PPSwitch v-model="switchVal1" label="iOS Mode Toggle" mode="ios" color="secondary" />
  <PPSwitch v-model="switchVal2" label="Disabled Toggle" :disabled="true" />
</template>

<script setup>
import { ref } from 'vue';
const switchVal1 = ref(false);
const switchVal2 = ref(true);
<\/script>`)],-1))]),l("div",v,[e[7]||(e[7]=l("h3",null,"Material 3 & Icon Styles",-1)),l("div",S,[a(i(o),{modelValue:r.value,"onUpdate:modelValue":e[3]||(e[3]=t=>r.value=t),label:"Material 3 Toggle",variant:"m3"},null,8,["modelValue"]),a(i(o),{modelValue:r.value,"onUpdate:modelValue":e[4]||(e[4]=t=>r.value=t),label:"Icon Toggle",variant:"icon",color:"success"},null,8,["modelValue"])]),e[8]||(e[8]=l("pre",{class:"code-block"},[l("code",null,`<template>
  <PPSwitch v-model="switchVal3" label="Material 3 Toggle" variant="m3" />
  <PPSwitch v-model="switchVal3" label="Icon Toggle" variant="icon" color="success" />
</template>

<script setup>
import { ref } from 'vue';
const switchVal3 = ref(false);
<\/script>`)],-1))]),e[11]||(e[11]=l("div",{class:"variant-group"},[l("h3",null,"Customizing CSS"),l("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),l("pre",{class:"code-block"},[l("code",null,`/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[12]||(e[12]=l("div",{class:"variant-group",style:{"margin-top":"40px"}},[l("h3",null,"Full Page Source Code"),l("p",{class:"custom-guide"},"Complete source code for this section."),l("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[l("code",null,`<template>
<div class="guide-section">
        <h2>Switches</h2>
        <p class="guide-desc">A toggle switch component supporting multiple platform styles and Material Design 3.</p>

        <div class="variant-group">
          <h3>Standard Styles</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 16px;">
            <PPSwitch v-model="switchVal1" label="Standard Toggle" />
            <PPSwitch v-model="switchVal1" label="iOS Mode Toggle" mode="ios" color="secondary" />
            <PPSwitch v-model="switchVal2" label="Disabled Toggle" :disabled="true" />
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPSwitch v-model="switchVal1" label="Standard Toggle" /&gt;
  &lt;PPSwitch v-model="switchVal1" label="iOS Mode Toggle" mode="ios" color="secondary" /&gt;
  &lt;PPSwitch v-model="switchVal2" label="Disabled Toggle" :disabled="true" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
const switchVal1 = ref(false);
const switchVal2 = ref(true);
&lt;/script&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Material 3 & Icon Styles</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 16px;">
            <PPSwitch v-model="switchVal3" label="Material 3 Toggle" variant="m3" />
            <PPSwitch v-model="switchVal3" label="Icon Toggle" variant="icon" color="success" />
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPSwitch v-model="switchVal3" label="Material 3 Toggle" variant="m3" /&gt;
  &lt;PPSwitch v-model="switchVal3" label="Icon Toggle" variant="icon" color="success" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
const switchVal3 = ref(false);
&lt;/script&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const switchVal1 = ref(false);

const switchVal2 = ref(true);

const switchVal3 = ref(false);



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{V as _};
