import{_ as t}from"./BottomNavScreen-B5Qg60E9.js";import{_ as o}from"./HamburgerDrawerScreen-DGm-ypG3.js";import{_ as r}from"./TabbedScreen-CkaIdnlQ.js";import{_ as n}from"./CardLayoutScreen-DND-gL8L.js";import{_ as i}from"./GridLayoutScreen-DUaEsOtO.js";import{_ as d}from"./FullScreenHeroScreen-ByLvtJqd.js";import{_ as l}from"./ListFabScreen-B_MLKjR4.js";import{_ as c}from"./CarouselLayoutScreen-CghH03mc.js";import{_ as u}from"./BackdropScreen-B9eNHlR_.js";import{_ as p}from"./MasterDetailScreen-GC23Byt1.js";import{_ as m}from"./ProfileSettingsScreen-Du9CEMhW.js";import{_ as g}from"./ChatMessagingScreen-rvmS3IUw.js";import{_ as v}from"./DashboardAnalyticsScreen-mz38tGe5.js";import{_ as y}from"./MapCentricScreen-z968uXzR.js";import{_ as b}from"./WizardFormScreen-C_N0LcWY.js";import{_ as f}from"./EcommerceProductScreen-B-aU6uTQ.js";import{_ as h}from"./MediaPlayerScreen-CuOWHwA1.js";import{_ as S}from"./CalendarAgendaScreen-D7ar3tJx.js";import{_ as k}from"./SocialFeedScreen-C9K1k9d2.js";import{_}from"./WalletFinancialScreen-B1cLwzh0.js";import{_ as A}from"./FoodDeliveryScreen-C-7eJhDl.js";import{_ as L}from"./FitnessTrackerScreen-C5MP82Yl.js";import{_ as w}from"./SmartHomeDashboardScreen-CkVtVgMo.js";import{_ as F}from"./DatingSwipeScreen-Cv8lOHUP.js";import{_ as C}from"./PodcastPlayerScreen-BGlh9FU3.js";import{d as D,o as P,j as $,l as e,a,F as M}from"../vendors/vendor-ah_eQdvw.js";import{_ as B}from"./App-D7rwXoHs.js";const z={class:"guide-section"},H={class:"section-content"},T={class:"variant-group"},W={class:"component-demo",style:{background:"transparent"}},I={class:"variant-group"},N={class:"component-demo",style:{background:"transparent"}},x={class:"variant-group"},E={class:"component-demo",style:{background:"transparent"}},U={class:"variant-group"},G={class:"component-demo",style:{background:"transparent"}},O={class:"variant-group"},V={class:"component-demo",style:{background:"transparent"}},j={class:"variant-group"},q={class:"component-demo",style:{background:"transparent"}},R={class:"variant-group"},Y={class:"component-demo",style:{background:"transparent"}},J={class:"variant-group"},K={class:"component-demo",style:{background:"transparent"}},Q={class:"variant-group"},X={class:"component-demo",style:{background:"transparent"}},Z={class:"variant-group"},ee={class:"component-demo",style:{background:"transparent"}},se={class:"variant-group"},ae={class:"component-demo",style:{background:"transparent"}},te={class:"variant-group"},oe={class:"component-demo",style:{background:"transparent"}},re={class:"variant-group"},ne={class:"component-demo",style:{background:"transparent"}},ie={class:"variant-group"},de={class:"component-demo",style:{background:"transparent"}},le={class:"variant-group"},ce={class:"component-demo",style:{background:"transparent"}},ue={class:"variant-group"},pe={class:"component-demo",style:{background:"transparent"}},me={class:"variant-group"},ge={class:"component-demo",style:{background:"transparent"}},ve={class:"variant-group"},ye={class:"component-demo",style:{background:"transparent"}},be={class:"variant-group"},fe={class:"component-demo",style:{background:"transparent"}},he={class:"variant-group"},Se={class:"component-demo",style:{background:"transparent"}},ke={class:"variant-group"},_e={class:"component-demo",style:{background:"transparent"}},Ae={class:"variant-group"},Le={class:"component-demo",style:{background:"transparent"}},we={class:"variant-group"},Fe={class:"component-demo",style:{background:"transparent"}},Ce={class:"variant-group"},De={class:"component-demo",style:{background:"transparent"}},Pe={class:"variant-group"},$e={class:"component-demo",style:{background:"transparent"}},Me=D({__name:"LayoutPatternsSection",setup(Be){return(ze,s)=>(P(),$(M,null,[e("div",z,[s[50]||(s[50]=e("div",{class:"section-header"},[e("h2",null,"Mobile Layout Patterns"),e("p",null,"A collection of standard mobile layout patterns built using the UI framework's components.")],-1)),e("div",H,[e("div",T,[s[0]||(s[0]=e("h3",null,"1. Bottom Navigation Layout",-1)),s[1]||(s[1]=e("p",{class:"guide-desc"},"A classic layout featuring a persistent bottom navigation bar for top-level destinations.",-1)),e("div",W,[a(t)])]),e("div",I,[s[2]||(s[2]=e("h3",null,"2. Hamburger Drawer Layout",-1)),s[3]||(s[3]=e("p",{class:"guide-desc"},"A layout utilizing a sidebar navigation drawer triggered from the app bar.",-1)),e("div",N,[a(o)])]),e("div",x,[s[4]||(s[4]=e("h3",null,"3. Tabbed Layout",-1)),s[5]||(s[5]=e("p",{class:"guide-desc"},"Using tabs below the header to organize content into distinct categories.",-1)),e("div",E,[a(r)])]),e("div",U,[s[6]||(s[6]=e("h3",null,"4. Card Layout",-1)),s[7]||(s[7]=e("p",{class:"guide-desc"},"A vertical feed focused on large, visually distinct cards, perfect for news or social media.",-1)),e("div",G,[a(n)])]),e("div",O,[s[8]||(s[8]=e("h3",null,"5. Grid Layout",-1)),s[9]||(s[9]=e("p",{class:"guide-desc"},"A grid or masonry style layout suitable for image galleries or dashboards.",-1)),e("div",V,[a(i)])]),e("div",j,[s[10]||(s[10]=e("h3",null,"6. Full Screen Hero",-1)),s[11]||(s[11]=e("p",{class:"guide-desc"},"An immersive layout dominated by a background visual, often used for onboarding.",-1)),e("div",q,[a(d)])]),e("div",R,[s[12]||(s[12]=e("h3",null,"7. List with FAB",-1)),s[13]||(s[13]=e("p",{class:"guide-desc"},"A standard list view with a primary Floating Action Button (FAB) in the corner.",-1)),e("div",Y,[a(l)])]),e("div",J,[s[14]||(s[14]=e("h3",null,"8. Carousel Layout",-1)),s[15]||(s[15]=e("p",{class:"guide-desc"},"Combining a horizontal scrolling carousel for featured items with a vertical list.",-1)),e("div",K,[a(c)])]),e("div",Q,[s[16]||(s[16]=e("h3",null,"9. Backdrop Layout",-1)),s[17]||(s[17]=e("p",{class:"guide-desc"},"A material pattern with a background filter/control layer and a foreground content layer.",-1)),e("div",X,[a(u)])]),e("div",Z,[s[18]||(s[18]=e("h3",null,"10. Master Detail Layout",-1)),s[19]||(s[19]=e("p",{class:"guide-desc"},"A split-pane layout ideal for larger viewports or tablets, showing a list alongside details.",-1)),e("div",ee,[a(p)])]),e("div",se,[s[20]||(s[20]=e("h3",null,"11. Profile & Settings Layout",-1)),s[21]||(s[21]=e("p",{class:"guide-desc"},"A layout featuring an avatar header and grouped list sections for settings and preferences.",-1)),e("div",ae,[a(m)])]),e("div",te,[s[22]||(s[22]=e("h3",null,"12. Chat / Messaging Layout",-1)),s[23]||(s[23]=e("p",{class:"guide-desc"},"A conversational interface with a scrollable message history and sticky bottom input.",-1)),e("div",oe,[a(g)])]),e("div",re,[s[24]||(s[24]=e("h3",null,"13. Dashboard / Analytics Layout",-1)),s[25]||(s[25]=e("p",{class:"guide-desc"},"A data-heavy layout with summary metric cards, charts, and a recent activity feed.",-1)),e("div",ne,[a(v)])]),e("div",ie,[s[26]||(s[26]=e("h3",null,"14. Map-centric Layout",-1)),s[27]||(s[27]=e("p",{class:"guide-desc"},"A full-screen map interface with a floating search bar and a bottom details sheet.",-1)),e("div",de,[a(y)])]),e("div",le,[s[28]||(s[28]=e("h3",null,"15. Wizard / Stepped Form Layout",-1)),s[29]||(s[29]=e("p",{class:"guide-desc"},"A multi-step form layout with a progress bar and sticky bottom action buttons.",-1)),e("div",ce,[a(b)])]),e("div",ue,[s[30]||(s[30]=e("h3",null,"16. E-commerce Product Layout",-1)),s[31]||(s[31]=e("p",{class:"guide-desc"},"A classic shopping layout featuring a large image gallery, product details, and a sticky Add to Cart button.",-1)),e("div",pe,[a(f)])]),e("div",me,[s[32]||(s[32]=e("h3",null,"17. Media Player Layout",-1)),s[33]||(s[33]=e("p",{class:"guide-desc"},"An immersive playback layout with large album art, scrubber, and playback controls.",-1)),e("div",ge,[a(h)])]),e("div",ve,[s[34]||(s[34]=e("h3",null,"18. Calendar / Agenda Layout",-1)),s[35]||(s[35]=e("p",{class:"guide-desc"},"A productivity layout featuring a horizontal date selector and vertical time-blocked agenda.",-1)),e("div",ye,[a(S)])]),e("div",be,[s[36]||(s[36]=e("h3",null,"19. Immersive Social Feed",-1)),s[37]||(s[37]=e("p",{class:"guide-desc"},"A full-screen vertical snapping layout with floating right-side action buttons.",-1)),e("div",fe,[a(k)])]),e("div",he,[s[38]||(s[38]=e("h3",null,"20. Wallet / Financial Layout",-1)),s[39]||(s[39]=e("p",{class:"guide-desc"},"A fintech layout with a prominent top balance card, quick actions, and recent transactions list.",-1)),e("div",Se,[a(_)])]),e("div",ke,[s[40]||(s[40]=e("h3",null,"21. Food Delivery / Restaurant Menu Layout",-1)),s[41]||(s[41]=e("p",{class:"guide-desc"},"A delivery app layout with a hero image, horizontal sticky categories, vertical menu items, and a floating View Cart button.",-1)),e("div",_e,[a(A)])]),e("div",Ae,[s[42]||(s[42]=e("h3",null,"22. Fitness / Workout Tracker Layout",-1)),s[43]||(s[43]=e("p",{class:"guide-desc"},"A health layout with a circular progress ring, daily stat summaries, and an activity timeline.",-1)),e("div",Le,[a(L)])]),e("div",we,[s[44]||(s[44]=e("h3",null,"23. Smart Home IoT Dashboard",-1)),s[45]||(s[45]=e("p",{class:"guide-desc"},"A grid-based layout for controlling devices with status summaries and toggleable cards.",-1)),e("div",Fe,[a(w)])]),e("div",Ce,[s[46]||(s[46]=e("h3",null,"24. Dating / Swiping Layout",-1)),s[47]||(s[47]=e("p",{class:"guide-desc"},"A full-screen stacked card layout with prominent photos, details overlays, and circular action buttons.",-1)),e("div",De,[a(F)])]),e("div",Pe,[s[48]||(s[48]=e("h3",null,"25. Podcast / Audiobook Player Layout",-1)),s[49]||(s[49]=e("p",{class:"guide-desc"},"A spoken-word media layout featuring a prominent cover, 15s skips, speed controls, and a sleep timer.",-1)),e("div",$e,[a(C)])])]),s[51]||(s[51]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),s[52]||(s[52]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <div class="section-header">
      <h2>Mobile Layout Patterns</h2>
      <p>A collection of standard mobile layout patterns built using the UI framework's components.</p>
    </div>

    <div class="section-content">
      
      <div class="variant-group">
        <h3>1. Bottom Navigation Layout</h3>
        <p class="guide-desc">A classic layout featuring a persistent bottom navigation bar for top-level destinations.</p>
        <div class="component-demo" style="background: transparent;">
          <BottomNavScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>2. Hamburger Drawer Layout</h3>
        <p class="guide-desc">A layout utilizing a sidebar navigation drawer triggered from the app bar.</p>
        <div class="component-demo" style="background: transparent;">
          <HamburgerDrawerScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>3. Tabbed Layout</h3>
        <p class="guide-desc">Using tabs below the header to organize content into distinct categories.</p>
        <div class="component-demo" style="background: transparent;">
          <TabbedScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>4. Card Layout</h3>
        <p class="guide-desc">A vertical feed focused on large, visually distinct cards, perfect for news or social media.</p>
        <div class="component-demo" style="background: transparent;">
          <CardLayoutScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>5. Grid Layout</h3>
        <p class="guide-desc">A grid or masonry style layout suitable for image galleries or dashboards.</p>
        <div class="component-demo" style="background: transparent;">
          <GridLayoutScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>6. Full Screen Hero</h3>
        <p class="guide-desc">An immersive layout dominated by a background visual, often used for onboarding.</p>
        <div class="component-demo" style="background: transparent;">
          <FullScreenHeroScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>7. List with FAB</h3>
        <p class="guide-desc">A standard list view with a primary Floating Action Button (FAB) in the corner.</p>
        <div class="component-demo" style="background: transparent;">
          <ListFabScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>8. Carousel Layout</h3>
        <p class="guide-desc">Combining a horizontal scrolling carousel for featured items with a vertical list.</p>
        <div class="component-demo" style="background: transparent;">
          <CarouselLayoutScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>9. Backdrop Layout</h3>
        <p class="guide-desc">A material pattern with a background filter/control layer and a foreground content layer.</p>
        <div class="component-demo" style="background: transparent;">
          <BackdropScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>10. Master Detail Layout</h3>
        <p class="guide-desc">A split-pane layout ideal for larger viewports or tablets, showing a list alongside details.</p>
        <div class="component-demo" style="background: transparent;">
          <MasterDetailScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>11. Profile & Settings Layout</h3>
        <p class="guide-desc">A layout featuring an avatar header and grouped list sections for settings and preferences.</p>
        <div class="component-demo" style="background: transparent;">
          <ProfileSettingsScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>12. Chat / Messaging Layout</h3>
        <p class="guide-desc">A conversational interface with a scrollable message history and sticky bottom input.</p>
        <div class="component-demo" style="background: transparent;">
          <ChatMessagingScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>13. Dashboard / Analytics Layout</h3>
        <p class="guide-desc">A data-heavy layout with summary metric cards, charts, and a recent activity feed.</p>
        <div class="component-demo" style="background: transparent;">
          <DashboardAnalyticsScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>14. Map-centric Layout</h3>
        <p class="guide-desc">A full-screen map interface with a floating search bar and a bottom details sheet.</p>
        <div class="component-demo" style="background: transparent;">
          <MapCentricScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>15. Wizard / Stepped Form Layout</h3>
        <p class="guide-desc">A multi-step form layout with a progress bar and sticky bottom action buttons.</p>
        <div class="component-demo" style="background: transparent;">
          <WizardFormScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>16. E-commerce Product Layout</h3>
        <p class="guide-desc">A classic shopping layout featuring a large image gallery, product details, and a sticky Add to Cart button.</p>
        <div class="component-demo" style="background: transparent;">
          <EcommerceProductScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>17. Media Player Layout</h3>
        <p class="guide-desc">An immersive playback layout with large album art, scrubber, and playback controls.</p>
        <div class="component-demo" style="background: transparent;">
          <MediaPlayerScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>18. Calendar / Agenda Layout</h3>
        <p class="guide-desc">A productivity layout featuring a horizontal date selector and vertical time-blocked agenda.</p>
        <div class="component-demo" style="background: transparent;">
          <CalendarAgendaScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>19. Immersive Social Feed</h3>
        <p class="guide-desc">A full-screen vertical snapping layout with floating right-side action buttons.</p>
        <div class="component-demo" style="background: transparent;">
          <SocialFeedScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>20. Wallet / Financial Layout</h3>
        <p class="guide-desc">A fintech layout with a prominent top balance card, quick actions, and recent transactions list.</p>
        <div class="component-demo" style="background: transparent;">
          <WalletFinancialScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>21. Food Delivery / Restaurant Menu Layout</h3>
        <p class="guide-desc">A delivery app layout with a hero image, horizontal sticky categories, vertical menu items, and a floating View Cart button.</p>
        <div class="component-demo" style="background: transparent;">
          <FoodDeliveryScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>22. Fitness / Workout Tracker Layout</h3>
        <p class="guide-desc">A health layout with a circular progress ring, daily stat summaries, and an activity timeline.</p>
        <div class="component-demo" style="background: transparent;">
          <FitnessTrackerScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>23. Smart Home IoT Dashboard</h3>
        <p class="guide-desc">A grid-based layout for controlling devices with status summaries and toggleable cards.</p>
        <div class="component-demo" style="background: transparent;">
          <SmartHomeDashboardScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>24. Dating / Swiping Layout</h3>
        <p class="guide-desc">A full-screen stacked card layout with prominent photos, details overlays, and circular action buttons.</p>
        <div class="component-demo" style="background: transparent;">
          <DatingSwipeScreen />
        </div>
      </div>

      <div class="variant-group">
        <h3>25. Podcast / Audiobook Player Layout</h3>
        <p class="guide-desc">A spoken-word media layout featuring a prominent cover, 15s skips, speed controls, and a sleep timer.</p>
        <div class="component-demo" style="background: transparent;">
          <PodcastPlayerScreen />
        </div>
      </div>

    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import BottomNavScreen from './screens/BottomNavScreen.vue';
import HamburgerDrawerScreen from './screens/HamburgerDrawerScreen.vue';
import TabbedScreen from './screens/TabbedScreen.vue';
import CardLayoutScreen from './screens/CardLayoutScreen.vue';
import GridLayoutScreen from './screens/GridLayoutScreen.vue';
import FullScreenHeroScreen from './screens/FullScreenHeroScreen.vue';
import ListFabScreen from './screens/ListFabScreen.vue';
import CarouselLayoutScreen from './screens/CarouselLayoutScreen.vue';
import BackdropScreen from './screens/BackdropScreen.vue';
import MasterDetailScreen from './screens/MasterDetailScreen.vue';
import ProfileSettingsScreen from './screens/ProfileSettingsScreen.vue';
import ChatMessagingScreen from './screens/ChatMessagingScreen.vue';
import DashboardAnalyticsScreen from './screens/DashboardAnalyticsScreen.vue';
import MapCentricScreen from './screens/MapCentricScreen.vue';
import WizardFormScreen from './screens/WizardFormScreen.vue';
import EcommerceProductScreen from './screens/EcommerceProductScreen.vue';
import MediaPlayerScreen from './screens/MediaPlayerScreen.vue';
import CalendarAgendaScreen from './screens/CalendarAgendaScreen.vue';
import SocialFeedScreen from './screens/SocialFeedScreen.vue';
import WalletFinancialScreen from './screens/WalletFinancialScreen.vue';
import FoodDeliveryScreen from './screens/FoodDeliveryScreen.vue';
import FitnessTrackerScreen from './screens/FitnessTrackerScreen.vue';
import SmartHomeDashboardScreen from './screens/SmartHomeDashboardScreen.vue';
import DatingSwipeScreen from './screens/DatingSwipeScreen.vue';
import PodcastPlayerScreen from './screens/PodcastPlayerScreen.vue';
<\/script>

<style scoped>
/* Inherits global guide styles */
</style>
`)])],-1))],64))}}),is=B(Me,[["__scopeId","data-v-7305fe81"]]);export{is as L};
