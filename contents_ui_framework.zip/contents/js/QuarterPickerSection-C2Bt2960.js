import{bf as b,bg as f}from"./AccountCardSection-DXixqG3L.js";import{d as x,o as s,j as p,l as e,a as i,u as c,A as d,y as u,k as y,F as k,p as m}from"../vendors/vendor-ah_eQdvw.js";import{_ as P}from"./App-D7rwXoHs.js";const Q={class:"component-section"},h={style:{"margin-top":"40px"}},S={class:"demo-box",style:{padding:"40px",background:"#f8fafc","border-radius":"12px",display:"flex","flex-direction":"column","align-items":"center",gap:"20px"}},w={style:{width:"300px","box-shadow":"0 4px 12px rgba(0,0,0,0.1)","border-radius":"12px",overflow:"hidden"}},q={key:0,style:{"font-size":"14px",color:"#64748b"}},C={class:"variant-group"},z={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},A=x({__name:"QuarterPickerSection",setup(V){const a=m(null),t=m(null),v=l=>{t.value=l};return(l,r)=>{var o,n;return s(),p(k,null,[e("div",Q,[r[8]||(r[8]=e("h2",null,"Quarter Picker",-1)),r[9]||(r[9]=e("p",null,"A specialized calendar component for selecting financial or calendar quarters (Q1-Q4) within a given year.",-1)),e("div",h,[r[2]||(r[2]=e("h3",null,"Basic Quarter Picker (PPQuarterPicker)",-1)),r[3]||(r[3]=e("p",null,"A simple inline quarter picker, similar to the month and year pickers.",-1)),e("div",S,[e("div",w,[i(c(b),{onQuarterSelected:v})]),t.value?(s(),p("p",q,[r[1]||(r[1]=d("Selected: ",-1)),e("strong",null,u((o=t.value)==null?void 0:o.year)+" - Q"+u((n=t.value)==null?void 0:n.quarter),1)])):y("",!0)]),r[4]||(r[4]=e("div",{style:{"margin-top":"16px"}},[e("pre",{class:"code-block"},[e("code",null,`<template>
  <PPQuarterPicker @quarter-selected="onSelect" />
</template>

<script setup>
const onSelect = (selection) => {
  console.log(selection.year, selection.quarter);
};
<\/script>`)])],-1))]),e("div",C,[r[5]||(r[5]=e("h3",null,"Input Wrapper",-1)),r[6]||(r[6]=e("p",{class:"custom-guide"},[e("strong",null,"Component:"),d(),e("code",null,"<PPQuarterPickerInput>")],-1)),e("div",z,[i(c(f),{modelValue:a.value,"onUpdate:modelValue":r[0]||(r[0]=g=>a.value=g)},null,8,["modelValue"])]),r[7]||(r[7]=e("pre",{class:"code-block"},[e("code",null,'<PPQuarterPickerInput v-model="quarter" />')],-1))]),r[10]||(r[10]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-danger-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),r[11]||(r[11]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Quarter Picker</h2>
    <p>A specialized calendar component for selecting financial or calendar quarters (Q1-Q4) within a given year.</p>

    <!-- Basic Quarter Picker -->
    <div style="margin-top: 40px;">
      <h3>Basic Quarter Picker (PPQuarterPicker)</h3>
      <p>A simple inline quarter picker, similar to the month and year pickers.</p>
      
      <div class="demo-box" style="padding: 40px; background: #f8fafc; border-radius: 12px; display: flex; flex-direction: column; align-items: center; gap: 20px;">
        <div style="width: 300px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-radius: 12px; overflow: hidden;">
          <PPQuarterPicker 
            @quarter-selected="onQuarterSelected" 
          />
        </div>
        <p v-if="selectedQuarter" style="font-size: 14px; color: #64748b;">Selected: <strong>{{ selectedQuarter?.year }} - Q{{ selectedQuarter?.quarter }}</strong></p>
      </div>

      <div style="margin-top: 16px;">
        <pre class="code-block"><code>&lt;template&gt;
  &lt;PPQuarterPicker @quarter-selected="onSelect" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
const onSelect = (selection) =&gt; {
  console.log(selection.year, selection.quarter);
};
&lt;/script&gt;</code></pre>
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-danger-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
const quarterModel = ref(null);
import { PPQuarterPicker , PPQuarterPickerInput } from '@phanna/ui-framework';

const selectedQuarter = ref<{ year: number, quarter: number } | null>(null);

const onQuarterSelected = (selection: { year: number, quarter: number }) => {
  selectedQuarter.value = selection;
};
<\/script>

<style scoped>
.component-section {
  max-width: 800px;
}
.demo-box {
  border: 1px solid #e2e8f0;
}
h2 {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 8px;
}
h3 {
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 8px;
}
p {
  color: #64748b;
  margin-bottom: 16px;
  line-height: 1.5;
}
.code-block {
  background: #1e293b;
  color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  font-size: 14px;
}
</style>
`)])],-1))],64)}}}),O=P(A,[["__scopeId","data-v-80ef0e12"]]);export{O as Q};
