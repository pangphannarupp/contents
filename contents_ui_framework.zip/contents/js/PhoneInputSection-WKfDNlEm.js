import{bb as d}from"./AccountCardSection-DXixqG3L.js";import{d as i,o as m,j as c,l,a as t,u as a,y as u,A as s,F as v,p as r}from"../vendors/vendor-ah_eQdvw.js";import{_ as g}from"./App-D7rwXoHs.js";const f={class:"guide-section"},h={class:"demo-box"},P={style:{"margin-top":"16px","font-family":"monospace"}},y={class:"demo-box"},x={style:{"margin-top":"16px","font-family":"monospace"}},b={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"16px"}},V={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"16px"}},I=i({__name:"PhoneInputSection",setup(S){const o=r(""),p=r("");return(U,e)=>(m(),c(v,null,[l("div",f,[e[11]||(e[11]=l("h2",null,"Phone Input",-1)),e[12]||(e[12]=l("p",null,"A specialized input component for telephone numbers with country code support.",-1)),e[13]||(e[13]=l("h3",null,"Basic Usage",-1)),l("div",h,[t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[0]||(e[0]=n=>o.value=n),placeholder:"Enter phone number"},null,8,["modelValue"]),l("div",P,"Value: "+u(o.value),1)]),e[14]||(e[14]=l("pre",{class:"code-block"},[l("code",null,'<PPPhoneInput v-model="phone" placeholder="Enter phone number" />')],-1)),e[15]||(e[15]=l("h3",{style:{"margin-top":"24px"}},"Formatted Input",-1)),e[16]||(e[16]=l("p",{class:"guide-desc"},[s("Use the "),l("code",null,"format"),s(" prop to automatically format the number as the user types (e.g. "),l("code",null,"### ### ###"),s(" or "),l("code",null,"### ### ####"),s(").")],-1)),l("div",y,[t(a(d),{modelValue:p.value,"onUpdate:modelValue":e[1]||(e[1]=n=>p.value=n),format:"### ### ###",placeholder:"e.g. 012 345 678"},null,8,["modelValue"]),l("div",x,"Value: "+u(p.value),1)]),e[17]||(e[17]=l("pre",{class:"code-block"},[l("code",null,'<PPPhoneInput v-model="phone" format="### ### ###" />')],-1)),e[18]||(e[18]=l("h3",{style:{"margin-top":"24px"}},"Variants",-1)),l("div",b,[t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[2]||(e[2]=n=>o.value=n),variant:"outline",placeholder:"Outline (Default)"},null,8,["modelValue"]),t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[3]||(e[3]=n=>o.value=n),variant:"filled",placeholder:"Filled"},null,8,["modelValue"]),t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[4]||(e[4]=n=>o.value=n),variant:"underlined",placeholder:"Underlined"},null,8,["modelValue"])]),e[19]||(e[19]=l("h3",{style:{"margin-top":"24px"}},"Sizes & Shapes",-1)),l("div",V,[t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[5]||(e[5]=n=>o.value=n),size:"sm",placeholder:"Small (sm)"},null,8,["modelValue"]),t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[6]||(e[6]=n=>o.value=n),size:"md",placeholder:"Medium (md) - Default"},null,8,["modelValue"]),t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[7]||(e[7]=n=>o.value=n),size:"lg",placeholder:"Large (lg)"},null,8,["modelValue"]),e[10]||(e[10]=l("div",{style:{"margin-top":"8px"}},null,-1)),t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[8]||(e[8]=n=>o.value=n),rounded:"",placeholder:"Rounded Pill Style"},null,8,["modelValue"]),t(a(d),{modelValue:o.value,"onUpdate:modelValue":e[9]||(e[9]=n=>o.value=n),variant:"filled",rounded:"",placeholder:"Rounded Filled"},null,8,["modelValue"])]),e[20]||(e[20]=l("pre",{class:"code-block"},[l("code",null,'<PPPhoneInput variant="outline|filled|underlined" size="sm|md|lg" rounded />')],-1)),e[21]||(e[21]=l("div",{class:"variant-group"},[l("h3",null,"Customizing CSS"),l("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),l("pre",{class:"code-block"},[l("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[22]||(e[22]=l("div",{class:"variant-group",style:{"margin-top":"40px"}},[l("h3",null,"Full Page Source Code"),l("p",{class:"custom-guide"},"Complete source code for this section."),l("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[l("code",null,`<template>
  <div class="guide-section">
    <h2>Phone Input</h2>
    <p>A specialized input component for telephone numbers with country code support.</p>

    <h3>Basic Usage</h3>
    <div class="demo-box">
      <PPPhoneInput v-model="phone" placeholder="Enter phone number" />
      <div style="margin-top: 16px; font-family: monospace;">Value: {{ phone }}</div>
    </div>
    <pre class="code-block"><code>&lt;PPPhoneInput v-model="phone" placeholder="Enter phone number" /&gt;</code></pre>

    <h3 style="margin-top: 24px;">Formatted Input</h3>
    <p class="guide-desc">Use the <code>format</code> prop to automatically format the number as the user types (e.g. <code>### ### ###</code> or <code>### ### ####</code>).</p>
    <div class="demo-box">
      <PPPhoneInput v-model="formattedPhone" format="### ### ###" placeholder="e.g. 012 345 678" />
      <div style="margin-top: 16px; font-family: monospace;">Value: {{ formattedPhone }}</div>
    </div>
    <pre class="code-block"><code>&lt;PPPhoneInput v-model="phone" format="### ### ###" /&gt;</code></pre>

    <h3 style="margin-top: 24px;">Variants</h3>
    <div class="demo-box" style="display: flex; flex-direction: column; gap: 16px;">
      <PPPhoneInput v-model="phone" variant="outline" placeholder="Outline (Default)" />
      <PPPhoneInput v-model="phone" variant="filled" placeholder="Filled" />
      <PPPhoneInput v-model="phone" variant="underlined" placeholder="Underlined" />
    </div>
    
    <h3 style="margin-top: 24px;">Sizes & Shapes</h3>
    <div class="demo-box" style="display: flex; flex-direction: column; gap: 16px;">
      <PPPhoneInput v-model="phone" size="sm" placeholder="Small (sm)" />
      <PPPhoneInput v-model="phone" size="md" placeholder="Medium (md) - Default" />
      <PPPhoneInput v-model="phone" size="lg" placeholder="Large (lg)" />
      <div style="margin-top: 8px;"></div>
      <PPPhoneInput v-model="phone" rounded placeholder="Rounded Pill Style" />
      <PPPhoneInput v-model="phone" variant="filled" rounded placeholder="Rounded Filled" />
    </div>
    <pre class="code-block"><code>&lt;PPPhoneInput variant="outline|filled|underlined" size="sm|md|lg" rounded /&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPPhoneInput } from '@phanna/ui-framework';

const phone = ref('');
const formattedPhone = ref('');
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),F=g(I,[["__scopeId","data-v-ac55af3e"]]);export{F as P};
