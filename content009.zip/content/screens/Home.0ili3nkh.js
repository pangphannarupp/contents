import{j as o}from"../main.js";import{p as t}from"./Toolbar.D4ly2Fgf.js";const s=t(o.jsx("path",{d:"M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"}),"Home");export{s as H};
