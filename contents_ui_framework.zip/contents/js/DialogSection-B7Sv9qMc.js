import{P as i,ar as g,as as v,at as C}from"./AccountCardSection-DXixqG3L.js";import{d as P,o as x,j as y,l as o,a as n,w as u,A as c,u as r,L as h,F as b,p}from"../vendors/vendor-ah_eQdvw.js";const w={class:"component-section"},k={class:"demo-box",style:{"margin-top":"32px",display:"flex",gap:"16px","align-items":"center","justify-content":"center",height:"160px",background:"#f8fafc","border-radius":"8px","flex-wrap":"wrap"}},A=P({__name:"DialogSection",setup(B){const l=p(!1),a=p(!1),s=p(!1),d=()=>{console.log("Confirmed!")},f=m=>{console.log("Input value:",m)};return(m,e)=>(x(),y(b,null,[o("div",w,[e[9]||(e[9]=o("h2",null,"Dialogs",-1)),e[10]||(e[10]=o("p",null,"Modal dialogs designed to interrupt the user to prompt for confirmation, display alerts, or request input.",-1)),o("div",k,[n(r(i),{onClick:e[0]||(e[0]=t=>l.value=!0)},{default:u(()=>[...e[6]||(e[6]=[c("Confirm Dialog",-1)])]),_:1}),n(r(i),{variant:"secondary",onClick:e[1]||(e[1]=t=>a.value=!0)},{default:u(()=>[...e[7]||(e[7]=[c("Alert Dialog",-1)])]),_:1}),n(r(i),{variant:"outline",onClick:e[2]||(e[2]=t=>s.value=!0)},{default:u(()=>[...e[8]||(e[8]=[c("Input Dialog",-1)])]),_:1})]),n(r(g),{modelValue:l.value,"onUpdate:modelValue":e[3]||(e[3]=t=>l.value=t),title:"Delete Account?",message:"Are you sure you want to delete your account? This action cannot be undone.",confirmText:"Delete",cancelText:"Cancel",confirmVariant:"outline-danger",onConfirm:d},null,8,["modelValue"]),n(r(v),{modelValue:a.value,"onUpdate:modelValue":e[4]||(e[4]=t=>a.value=t),title:"Update Successful",message:"Your profile has been updated successfully.",buttonText:"Great"},null,8,["modelValue"]),n(r(C),{modelValue:s.value,"onUpdate:modelValue":e[5]||(e[5]=t=>s.value=t),title:"Create Folder",message:"Enter a name for the new folder:",placeholder:"Folder name",confirmText:"Create",cancelText:"Cancel",onConfirm:f},null,8,["modelValue"]),e[11]||(e[11]=h(`<div style="margin-top:40px;"><h3>Usage Example</h3><pre class="code-block" style="background:#1e293b;color:#e2e8f0;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;PPButton @click=&quot;isOpen = true&quot;&gt;Show Confirm&lt;/PPButton&gt;

  &lt;PPConfirm 
    v-model=&quot;isOpen&quot; 
    title=&quot;Are you sure?&quot; 
    message=&quot;This action is irreversible.&quot;
    confirmText=&quot;Yes, Proceed&quot;
    cancelText=&quot;No, Go Back&quot;
    @confirm=&quot;onConfirm&quot;
  /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from &#39;vue&#39;;
import { PPConfirm, PPButton } from &#39;@phanna/ui-framework&#39;;

const isOpen = ref(false);

const onConfirm = () =&gt; {
  console.log(&#39;User confirmed action&#39;);
};
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[12]||(e[12]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="component-section">
    <h2>Dialogs</h2>
    <p>Modal dialogs designed to interrupt the user to prompt for confirmation, display alerts, or request input.</p>

    <!-- Demo Box -->
    <div class="demo-box" style="margin-top: 32px; display: flex; gap: 16px; align-items: center; justify-content: center; height: 160px; background: #f8fafc; border-radius: 8px; flex-wrap: wrap;">
      <PPButton @click="showConfirm = true">Confirm Dialog</PPButton>
      <PPButton variant="secondary" @click="showAlert = true">Alert Dialog</PPButton>
      <PPButton variant="outline" @click="showInput = true">Input Dialog</PPButton>
    </div>

    <!-- Confirm Dialog -->
    <PPConfirm 
      v-model="showConfirm" 
      title="Delete Account?" 
      message="Are you sure you want to delete your account? This action cannot be undone."
      confirmText="Delete"
      cancelText="Cancel"
      confirmVariant="outline-danger"
      @confirm="handleConfirm"
    />

    <!-- Alert Dialog -->
    <PPAlert 
      v-model="showAlert" 
      title="Update Successful" 
      message="Your profile has been updated successfully."
      buttonText="Great"
    />

    <!-- Input Dialog -->
    <PPInputDialog 
      v-model="showInput" 
      title="Create Folder" 
      message="Enter a name for the new folder:"
      placeholder="Folder name"
      confirmText="Create"
      cancelText="Cancel"
      @confirm="handleInputConfirm"
    />

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block" style="background: #1e293b; color: #e2e8f0; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPButton @click="isOpen = true"&gt;Show Confirm&lt;/PPButton&gt;

  &lt;PPConfirm 
    v-model="isOpen" 
    title="Are you sure?" 
    message="This action is irreversible."
    confirmText="Yes, Proceed"
    cancelText="No, Go Back"
    @confirm="onConfirm"
  /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPConfirm, PPButton } from '@phanna/ui-framework';

const isOpen = ref(false);

const onConfirm = () =&gt; {
  console.log('User confirmed action');
};
&lt;/script&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPConfirm, PPAlert, PPInputDialog, PPButton } from '@phanna/ui-framework';

const showConfirm = ref(false);
const showAlert = ref(false);
const showInput = ref(false);

const handleConfirm = () => {
  console.log('Confirmed!');
};

const handleInputConfirm = (value: string) => {
  console.log('Input value:', value);
};
<\/script>
`)])],-1))],64))}});export{A as _};
