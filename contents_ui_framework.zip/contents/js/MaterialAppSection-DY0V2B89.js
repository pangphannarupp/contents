import{d as R,o as p,j as c,l as e,A as g,a as i,w as o,u as a,k as D,E as s,aE as I,a8 as F,aV as W,aB as f,bl as Y,M as u,bn as J,aD as P,am as V,F as k,z as C,y as _,p as n}from"../vendors/vendor-ah_eQdvw.js";import{a0 as w,b as z,c as T,af as L,Z as A,a as v,e as B,aW as h,P as H}from"./AccountCardSection-DXixqG3L.js";import{_ as $}from"./App-D7rwXoHs.js";const K={class:"guide-section"},Z={class:"section-content"},q={class:"variant-group"},G={class:"component-demo",style:{padding:"0"}},Q={style:{height:"600px",width:"100%",border:"1px solid var(--pp-border, #e2e8f0)","border-radius":"12px",overflow:"hidden",position:"relative"}},X={style:{display:"flex","align-items":"center",gap:"8px"}},ee={key:0,style:{background:"var(--pp-primary, #3b82f6)",color:"white",padding:"12px 24px","border-radius":"8px","font-weight":"500","box-shadow":"0 4px 12px rgba(0,0,0,0.15)",display:"flex","align-items":"center",gap:"8px","pointer-events":"auto","white-space":"nowrap"}},te={style:{padding:"24px"}},ae={key:0},ie={key:1},oe={key:2},re={style:{display:"flex","align-items":"center",gap:"16px","margin-top":"24px"}},le={style:{"margin-top":"16px",display:"flex",gap:"12px","flex-wrap":"wrap"}},ne={class:"variant-group",style:{"margin-top":"32px"}},se={class:"component-demo",style:{padding:"0"}},de={style:{height:"600px","max-width":"375px",margin:"0 auto",border:"12px solid #1e293b","border-radius":"36px",overflow:"hidden",position:"relative",background:"#0f172a"}},pe={style:{padding:"24px"}},ce={class:"variant-group",style:{"margin-top":"32px"}},me={class:"component-demo",style:{padding:"0"}},ue={style:{height:"500px",width:"100%",border:"1px solid var(--pp-border, #e2e8f0)","border-radius":"12px",overflow:"hidden",position:"relative"}},ve={style:{display:"flex","align-items":"center",gap:"16px"}},ge={style:{padding:"32px",height:"100%"}},he={style:{display:"flex","justify-content":"space-between","align-items":"center","margin-bottom":"24px"}},be={style:{display:"grid","grid-template-columns":"repeat(3, 1fr)",gap:"24px","margin-bottom":"24px"}},xe={style:{"font-size":"14px",opacity:"0.7","margin-bottom":"8px"}},ye={style:{"font-size":"32px","font-weight":"bold"}},fe=R({__name:"MaterialAppSection",setup(Pe){const l=n(!1),d=n(!0),S=n("home"),m=n("home"),O=n("home"),M=n("dashboard"),b=n(!1),x=n(!0),y=n(!0);function U(){b.value=!0,setTimeout(()=>{b.value=!1},3e3)}const N=[{value:"home",label:"Home",icon:f,activeIcon:W},{value:"search",label:"Search",icon:u,activeIcon:Y},{value:"profile",label:"Profile",icon:P,activeIcon:J}],E=[{groupLabel:"Overview",items:[{id:"home",label:"Home",icon:f},{id:"analytics",label:"Analytics",icon:u}]},{groupLabel:"Settings",items:[{id:"profile",label:"Profile",icon:P}]}],j=[{groupLabel:"Core",items:[{id:"dashboard",label:"Dashboard",icon:f},{id:"users",label:"Users",icon:P}]},{groupLabel:"System",items:[{id:"settings",label:"Settings",icon:u}]}];return(ke,t)=>(p(),c(k,null,[e("div",K,[t[28]||(t[28]=e("div",{class:"section-header"},[e("h2",null,"PPMaterialApp (Scaffold)"),e("p",null,"The master layout container that brings together App Bars, Navigation Drawers, Bottom Navigation, and Floating Action Buttons into a single cohesive structure.")],-1)),e("div",Z,[e("div",q,[t[16]||(t[16]=e("h3",null,"Full Application Layout Demo",-1)),t[17]||(t[17]=e("p",{class:"guide-desc"},[g("A complete dashboard layout using "),e("code",null,"PPMaterialApp"),g(". The layout manages the fixed header, sidebar, and scrollable content area automatically.")],-1)),e("div",G,[e("div",Q,[i(a(B),{theme:l.value?"dark":"light",responsive:!0,"drawer-variant":"mini","drawer-open":d.value,onCloseDrawer:t[3]||(t[3]=r=>d.value=!1),"hide-app-bar-on-scroll":x.value,"hide-bottom-nav-on-scroll":y.value,"fab-position":"center-docked"},{header:o(()=>[i(a(A),{title:"Dashboard",theme:l.value?"dark":"light",variant:"center"},{left:o(()=>[i(a(v),{onClick:t[0]||(t[0]=r=>d.value=!d.value),color:"transparent"},{default:o(()=>[i(a(s),{icon:a(V)},null,8,["icon"])]),_:1})]),right:o(()=>[e("div",X,[i(a(v),{color:"transparent"},{default:o(()=>[i(a(s),{icon:a(u)},null,8,["icon"])]),_:1}),i(a(v),{color:"transparent",badge:!0},{default:o(()=>[i(a(s),{icon:a(I)},null,8,["icon"])]),_:1}),i(a(w),{src:"https://i.pravatar.cc/150?u=a042581f4e29026704d",size:"sm"})])]),_:1},8,["theme"])]),drawer:o(()=>[i(a(L),{modelValue:S.value,"onUpdate:modelValue":t[1]||(t[1]=r=>S.value=r),items:E,theme:l.value?"dark":"light",variant:"flat",collapsed:!d.value},null,8,["modelValue","theme","collapsed"])]),"bottom-nav":o(()=>[i(a(T),{theme:l.value?"dark":"light",items:N,modelValue:m.value,"onUpdate:modelValue":t[2]||(t[2]=r=>m.value=r),variant:"cutout"},null,8,["theme","modelValue"])]),fab:o(()=>[i(a(z),{color:"primary",shape:"rounded",onClick:U},{icon:o(()=>[i(a(s),{icon:a(F)},null,8,["icon"])]),_:1})]),snackbar:o(()=>[b.value?(p(),c("div",ee,[i(a(s),{icon:a(I)},null,8,["icon"]),t[10]||(t[10]=e("span",null,"FAB Clicked! Feature implemented!",-1))])):D("",!0)]),default:o(()=>[e("div",te,[m.value==="home"?(p(),c("div",ae,[...t[11]||(t[11]=[e("h1",{style:{"margin-top":"0"}},"Welcome back!",-1),e("p",null,"This is the Home tab. The Header and Sidebar stay fixed while this content scrolls.",-1),e("div",{style:{height:"800px",background:"repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,0.05) 10px, rgba(0,0,0,0.05) 20px)","border-radius":"8px","margin-top":"24px",padding:"24px"}}," Scroll down to see the FAB stay in place! ",-1)])])):m.value==="search"?(p(),c("div",ie,[...t[12]||(t[12]=[e("h1",{style:{"margin-top":"0"}},"Search",-1),e("p",null,"Find what you're looking for.",-1),e("div",{style:{display:"flex","flex-direction":"column",gap:"16px","margin-top":"24px"}},[e("div",{style:{height:"60px",background:"rgba(0,0,0,0.05)","border-radius":"8px"}}),e("div",{style:{height:"120px",background:"rgba(0,0,0,0.05)","border-radius":"8px"}}),e("div",{style:{height:"120px",background:"rgba(0,0,0,0.05)","border-radius":"8px"}})],-1)])])):m.value==="profile"?(p(),c("div",oe,[t[14]||(t[14]=e("h1",{style:{"margin-top":"0"}},"Your Profile",-1)),t[15]||(t[15]=e("p",null,"Manage your account settings and preferences.",-1)),e("div",re,[i(a(w),{src:"https://i.pravatar.cc/150?u=a042581f4e29026704d",size:"lg"}),t[13]||(t[13]=e("div",null,[e("h3",{style:{margin:"0"}},"Jane Doe"),e("p",{style:{margin:"4px 0 0 0",opacity:"0.7"}},"jane.doe@example.com")],-1))])])):D("",!0)])]),_:1},8,["theme","drawer-open","hide-app-bar-on-scroll","hide-bottom-nav-on-scroll"])])]),e("div",le,[i(a(h),{modelValue:d.value,"onUpdate:modelValue":t[4]||(t[4]=r=>d.value=r),label:"Sidebar",color:"primary"},null,8,["modelValue"]),i(a(h),{modelValue:l.value,"onUpdate:modelValue":t[5]||(t[5]=r=>l.value=r),label:"Dark Theme",color:"primary"},null,8,["modelValue"]),i(a(h),{modelValue:x.value,"onUpdate:modelValue":t[6]||(t[6]=r=>x.value=r),label:"Hide App Bar on Scroll",color:"primary"},null,8,["modelValue"]),i(a(h),{modelValue:y.value,"onUpdate:modelValue":t[7]||(t[7]=r=>y.value=r),label:"Hide Bottom Nav on Scroll",color:"primary"},null,8,["modelValue"])]),t[18]||(t[18]=e("pre",{class:"code-block"},[e("code",null,`<PPMaterialApp theme="light">
  <template #header>
    <PPAppBar title="Dashboard" />
  </template>

  <template #drawer>
    <PPSidebarNavigation :items="items" />
  </template>

  <!-- Main Content goes in the default slot -->
  <div class="content">
    ...
  </div>

  <template #fab>
    <PPFab color="primary">...</PPFab>
  </template>
</PPMaterialApp>`)],-1))]),e("div",ne,[t[20]||(t[20]=e("h3",null,"Mobile App Layout",-1)),t[21]||(t[21]=e("p",{class:"guide-desc"},"A typical mobile layout with an App Bar, Bottom Navigation, and a center-docked FAB. No sidebar is used here.",-1)),e("div",se,[e("div",de,[i(a(B),{theme:"dark","hide-app-bar-on-scroll":!0,"hide-bottom-nav-on-scroll":!0,"fab-position":"center-float"},{header:o(()=>[i(a(A),{title:"Mobile App",theme:"dark",variant:"center"},{left:o(()=>[i(a(v),{color:"transparent"},{default:o(()=>[i(a(s),{icon:a(V)},null,8,["icon"])]),_:1})]),right:o(()=>[i(a(v),{color:"transparent"},{default:o(()=>[i(a(s),{icon:a(u)},null,8,["icon"])]),_:1})]),_:1})]),"bottom-nav":o(()=>[i(a(T),{theme:"dark",items:N,modelValue:O.value,"onUpdate:modelValue":t[8]||(t[8]=r=>O.value=r)},null,8,["modelValue"])]),fab:o(()=>[i(a(z),{color:"primary",shape:"circle",size:"lg"},{icon:o(()=>[i(a(s),{icon:a(F)},null,8,["icon"])]),_:1})]),default:o(()=>[e("div",pe,[(p(),c(k,null,C(10,r=>e("div",{key:r,style:{height:"80px",background:"rgba(255,255,255,0.05)","border-radius":"12px","margin-bottom":"16px",padding:"16px",display:"flex","align-items":"center",gap:"16px"}},[...t[19]||(t[19]=[e("div",{style:{width:"48px",height:"48px","border-radius":"24px",background:"rgba(255,255,255,0.1)"}},null,-1),e("div",{style:{flex:"1"}},[e("div",{style:{height:"12px",width:"60%",background:"rgba(255,255,255,0.1)","border-radius":"4px","margin-bottom":"8px"}}),e("div",{style:{height:"10px",width:"40%",background:"rgba(255,255,255,0.05)","border-radius":"4px"}})],-1)])])),64))])]),_:1})])])]),e("div",ce,[t[26]||(t[26]=e("h3",null,"Desktop Admin Layout",-1)),t[27]||(t[27]=e("p",{class:"guide-desc"},"A classic desktop admin layout with a permanent sidebar, header, and content area. No bottom navigation or FAB.",-1)),e("div",me,[e("div",ue,[i(a(B),{theme:l.value?"dark":"light","drawer-variant":"default","drawer-open":!0},{header:o(()=>[i(a(A),{title:"Admin Portal",theme:l.value?"dark":"light",variant:"default"},{right:o(()=>[e("div",ve,[i(a(H),{variant:"ghost",size:"small"},{default:o(()=>[...t[22]||(t[22]=[g("Help",-1)])]),_:1}),i(a(w),{src:"https://i.pravatar.cc/150?u=admin",size:"sm"})])]),_:1},8,["theme"])]),drawer:o(()=>[i(a(L),{modelValue:M.value,"onUpdate:modelValue":t[9]||(t[9]=r=>M.value=r),items:j,theme:l.value?"dark":"light",variant:"flat"},null,8,["modelValue","theme"])]),default:o(()=>[e("div",ge,[e("div",he,[t[24]||(t[24]=e("h1",{style:{margin:"0"}},"Dashboard Overview",-1)),i(a(H),{color:"primary"},{default:o(()=>[...t[23]||(t[23]=[g("Export Report",-1)])]),_:1})]),e("div",be,[(p(),c(k,null,C(3,r=>e("div",{key:r,style:{height:"120px",background:"var(--pp-surface-alt, rgba(0,0,0,0.02))","border-radius":"12px",border:"1px solid var(--pp-border, #e2e8f0)",padding:"24px"}},[e("div",xe,"Metric "+_(r),1),e("div",ye,_(Math.floor(Math.random()*1e3)),1)])),64))]),t[25]||(t[25]=e("div",{style:{height:"400px",background:"var(--pp-surface-alt, rgba(0,0,0,0.02))","border-radius":"12px",border:"1px solid var(--pp-border, #e2e8f0)"}},null,-1))])]),_:1},8,["theme"])])])])]),t[29]||(t[29]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-surface: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[30]||(t[30]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <div class="section-header">
      <h2>PPMaterialApp (Scaffold)</h2>
      <p>The master layout container that brings together App Bars, Navigation Drawers, Bottom Navigation, and Floating Action Buttons into a single cohesive structure.</p>
    </div>

    <div class="section-content">
      <div class="variant-group">
        <h3>Full Application Layout Demo</h3>
        <p class="guide-desc">A complete dashboard layout using <code>PPMaterialApp</code>. The layout manages the fixed header, sidebar, and scrollable content area automatically.</p>
        
        <div class="component-demo" style="padding: 0;">
          <!-- We put it in a container so it doesn't take over the whole screen in the documentation -->
          <div style="height: 600px; width: 100%; border: 1px solid var(--pp-border, #e2e8f0); border-radius: 12px; overflow: hidden; position: relative;">
            <PPMaterialApp 
              :theme="isDark ? 'dark' : 'light'" 
              :responsive="true"
              drawer-variant="mini"
              :drawer-open="drawerOpen"
              @close-drawer="drawerOpen = false"
              :hide-app-bar-on-scroll="hideAppBarOnScroll"
              :hide-bottom-nav-on-scroll="hideBottomNavOnScroll"
              fab-position="center-docked"
            >
              <template #header>
                <PPAppBar title="Dashboard" :theme="isDark ? 'dark' : 'light'" variant="center">
                  <template #left>
                    <PPIconButton @click="drawerOpen = !drawerOpen" color="transparent">
                      <ion-icon :icon="menuOutline" />
                    </PPIconButton>
                  </template>
                  <template #right>
                    <div style="display: flex; align-items: center; gap: 8px;">
                      <PPIconButton color="transparent">
                        <ion-icon :icon="searchOutline" />
                      </PPIconButton>
                      <PPIconButton color="transparent" :badge="true">
                        <ion-icon :icon="notificationsOutline" />
                      </PPIconButton>
                      <PPAvatar src="https://i.pravatar.cc/150?u=a042581f4e29026704d" size="sm" />
                    </div>
                  </template>
                </PPAppBar>
              </template>

              <!-- DRAWER -->
              <template #drawer>
                <PPSidebarNavigation
                  v-model="activeMenu"
                  :items="sidebarItems"
                  :theme="isDark ? 'dark' : 'light'"
                  variant="flat"
                  :collapsed="!drawerOpen"
                />
              </template>

              <!-- BOTTOM NAV -->
              <template #bottom-nav>
                <PPBottomNav
                  :theme="isDark ? 'dark' : 'light'"
                  :items="bottomNavItems"
                  v-model="activeBottom"
                  variant="cutout"
                />
              </template>

              <!-- FAB -->
              <template #fab>
                <PPFab color="primary" shape="rounded" @click="triggerSnackbar">
                  <template #icon><ion-icon :icon="addOutline" /></template>
                </PPFab>
              </template>

              <!-- SNACKBAR -->
              <template #snackbar>
                <div v-if="showSnackbar" style="background: var(--pp-primary, #3b82f6); color: white; padding: 12px 24px; border-radius: 8px; font-weight: 500; box-shadow: 0 4px 12px rgba(0,0,0,0.15); display: flex; align-items: center; gap: 8px; pointer-events: auto; white-space: nowrap;">
                  <ion-icon :icon="notificationsOutline" />
                  <span>FAB Clicked! Feature implemented!</span>
                </div>
              </template>

              <!-- MAIN CONTENT -->
              <div style="padding: 24px;">
                <div v-if="activeBottom === 'home'">
                  <h1 style="margin-top: 0;">Welcome back!</h1>
                  <p>This is the Home tab. The Header and Sidebar stay fixed while this content scrolls.</p>
                  <div style="height: 800px; background: repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,0.05) 10px, rgba(0,0,0,0.05) 20px); border-radius: 8px; margin-top: 24px; padding: 24px;">
                    Scroll down to see the FAB stay in place!
                  </div>
                </div>

                <div v-else-if="activeBottom === 'search'">
                  <h1 style="margin-top: 0;">Search</h1>
                  <p>Find what you're looking for.</p>
                  <div style="display: flex; flex-direction: column; gap: 16px; margin-top: 24px;">
                    <div style="height: 60px; background: rgba(0,0,0,0.05); border-radius: 8px;"></div>
                    <div style="height: 120px; background: rgba(0,0,0,0.05); border-radius: 8px;"></div>
                    <div style="height: 120px; background: rgba(0,0,0,0.05); border-radius: 8px;"></div>
                  </div>
                </div>

                <div v-else-if="activeBottom === 'profile'">
                  <h1 style="margin-top: 0;">Your Profile</h1>
                  <p>Manage your account settings and preferences.</p>
                  <div style="display: flex; align-items: center; gap: 16px; margin-top: 24px;">
                    <PPAvatar src="https://i.pravatar.cc/150?u=a042581f4e29026704d" size="lg" />
                    <div>
                      <h3 style="margin: 0;">Jane Doe</h3>
                      <p style="margin: 4px 0 0 0; opacity: 0.7;">jane.doe@example.com</p>
                    </div>
                  </div>
                </div>
              </div>
            </PPMaterialApp>
          </div>
        </div>
        
        <div style="margin-top: 16px; display: flex; gap: 12px; flex-wrap: wrap;">
          <PPSwitch v-model="drawerOpen" label="Sidebar" color="primary" />
          <PPSwitch v-model="isDark" label="Dark Theme" color="primary" />
          <PPSwitch v-model="hideAppBarOnScroll" label="Hide App Bar on Scroll" color="primary" />
          <PPSwitch v-model="hideBottomNavOnScroll" label="Hide Bottom Nav on Scroll" color="primary" />
        </div>

        <pre class="code-block"><code>&lt;PPMaterialApp theme="light"&gt;
  &lt;template #header&gt;
    &lt;PPAppBar title="Dashboard" /&gt;
  &lt;/template&gt;

  &lt;template #drawer&gt;
    &lt;PPSidebarNavigation :items="items" /&gt;
  &lt;/template&gt;

  &lt;!-- Main Content goes in the default slot --&gt;
  &lt;div class="content"&gt;
    ...
  &lt;/div&gt;

  &lt;template #fab&gt;
    &lt;PPFab color="primary"&gt;...&lt;/PPFab&gt;
  &lt;/template&gt;
&lt;/PPMaterialApp&gt;</code></pre>
      </div>

      <div class="variant-group" style="margin-top: 32px;">
        <h3>Mobile App Layout</h3>
        <p class="guide-desc">A typical mobile layout with an App Bar, Bottom Navigation, and a center-docked FAB. No sidebar is used here.</p>
        
        <div class="component-demo" style="padding: 0;">
          <div style="height: 600px; max-width: 375px; margin: 0 auto; border: 12px solid #1e293b; border-radius: 36px; overflow: hidden; position: relative; background: #0f172a;">
            <PPMaterialApp 
              theme="dark" 
              :hide-app-bar-on-scroll="true"
              :hide-bottom-nav-on-scroll="true"
              fab-position="center-float"
            >
              <template #header>
                <PPAppBar title="Mobile App" theme="dark" variant="center">
                  <template #left>
                    <PPIconButton color="transparent">
                      <ion-icon :icon="menuOutline" />
                    </PPIconButton>
                  </template>
                  <template #right>
                    <PPIconButton color="transparent">
                      <ion-icon :icon="searchOutline" />
                    </PPIconButton>
                  </template>
                </PPAppBar>
              </template>

              <template #bottom-nav>
                <PPBottomNav
                  theme="dark"
                  :items="bottomNavItems"
                  v-model="activeBottomMobile"
                />
              </template>

              <template #fab>
                <PPFab color="primary" shape="circle" size="lg">
                  <template #icon><ion-icon :icon="addOutline" /></template>
                </PPFab>
              </template>

              <div style="padding: 24px;">
                <div v-for="i in 10" :key="i" style="height: 80px; background: rgba(255,255,255,0.05); border-radius: 12px; margin-bottom: 16px; padding: 16px; display: flex; align-items: center; gap: 16px;">
                  <div style="width: 48px; height: 48px; border-radius: 24px; background: rgba(255,255,255,0.1);"></div>
                  <div style="flex: 1;">
                    <div style="height: 12px; width: 60%; background: rgba(255,255,255,0.1); border-radius: 4px; margin-bottom: 8px;"></div>
                    <div style="height: 10px; width: 40%; background: rgba(255,255,255,0.05); border-radius: 4px;"></div>
                  </div>
                </div>
              </div>
            </PPMaterialApp>
          </div>
        </div>
      </div>

      <div class="variant-group" style="margin-top: 32px;">
        <h3>Desktop Admin Layout</h3>
        <p class="guide-desc">A classic desktop admin layout with a permanent sidebar, header, and content area. No bottom navigation or FAB.</p>
        
        <div class="component-demo" style="padding: 0;">
          <div style="height: 500px; width: 100%; border: 1px solid var(--pp-border, #e2e8f0); border-radius: 12px; overflow: hidden; position: relative;">
            <PPMaterialApp 
              :theme="isDark ? 'dark' : 'light'" 
              drawer-variant="default"
              :drawer-open="true"
            >
              <template #header>
                <PPAppBar title="Admin Portal" :theme="isDark ? 'dark' : 'light'" variant="default">
                  <template #right>
                    <div style="display: flex; align-items: center; gap: 16px;">
                      <PPButton variant="ghost" size="small">Help</PPButton>
                      <PPAvatar src="https://i.pravatar.cc/150?u=admin" size="sm" />
                    </div>
                  </template>
                </PPAppBar>
              </template>

              <template #drawer>
                <PPSidebarNavigation
                  v-model="activeAdminMenu"
                  :items="adminSidebarItems"
                  :theme="isDark ? 'dark' : 'light'"
                  variant="flat"
                />
              </template>

              <div style="padding: 32px; height: 100%;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                  <h1 style="margin: 0;">Dashboard Overview</h1>
                  <PPButton color="primary">Export Report</PPButton>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 24px;">
                  <div v-for="i in 3" :key="i" style="height: 120px; background: var(--pp-surface-alt, rgba(0,0,0,0.02)); border-radius: 12px; border: 1px solid var(--pp-border, #e2e8f0); padding: 24px;">
                    <div style="font-size: 14px; opacity: 0.7; margin-bottom: 8px;">Metric {{ i }}</div>
                    <div style="font-size: 32px; font-weight: bold;">{{ Math.floor(Math.random() * 1000) }}</div>
                  </div>
                </div>

                <div style="height: 400px; background: var(--pp-surface-alt, rgba(0,0,0,0.02)); border-radius: 12px; border: 1px solid var(--pp-border, #e2e8f0);"></div>
              </div>
            </PPMaterialApp>
          </div>
        </div>
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-surface: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { IonIcon } from '@ionic/vue';
import { 
  menuOutline, 
  addOutline,
  homeOutline,
  home,
  searchOutline,
  search,
  personOutline,
  person,
  notificationsOutline
} from 'ionicons/icons';
import { 
  PPMaterialApp, 
  PPAppBar, 
  PPSidebarNavigation, 
  PPBottomNav, 
  PPFab, 
  PPIconButton, 
  PPAvatar,
  PPButton,
  PPSwitch
} from '@phanna/ui-framework';

const isDark = ref(false);
const drawerOpen = ref(true);
const activeMenu = ref('home');
const activeBottom = ref('home');
const activeBottomMobile = ref('home');
const activeAdminMenu = ref('dashboard');
const showSnackbar = ref(false);
const hideAppBarOnScroll = ref(true);
const hideBottomNavOnScroll = ref(true);

function triggerSnackbar() {
  showSnackbar.value = true;
  setTimeout(() => {
    showSnackbar.value = false;
  }, 3000);
}

const bottomNavItems = [
  { value: 'home', label: 'Home', icon: homeOutline, activeIcon: home },
  { value: 'search', label: 'Search', icon: searchOutline, activeIcon: search },
  { value: 'profile', label: 'Profile', icon: personOutline, activeIcon: person }
];

const sidebarItems = [
  {
    groupLabel: 'Overview',
    items: [
      { id: 'home', label: 'Home', icon: homeOutline },
      { id: 'analytics', label: 'Analytics', icon: searchOutline }
    ]
  },
  {
    groupLabel: 'Settings',
    items: [
      { id: 'profile', label: 'Profile', icon: personOutline }
    ]
  }
];

const adminSidebarItems = [
  {
    groupLabel: 'Core',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: homeOutline },
      { id: 'users', label: 'Users', icon: personOutline }
    ]
  },
  {
    groupLabel: 'System',
    items: [
      { id: 'settings', label: 'Settings', icon: searchOutline }
    ]
  }
];

function toggleDrawer() {
  drawerOpen.value = !drawerOpen.value;
}
<\/script>

<style scoped>
/* Scoped styles if needed */
</style>
`)])],-1))],64))}}),Se=$(fe,[["__scopeId","data-v-882c111e"]]);export{Se as M};
