import{e as o,j as e}from"../main.js";const t=o(e.jsx("path",{d:"M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"}),"Home");export{t as H};
//# sourceMappingURL=Home.DltwLliB.js.map
