import{d as x,o as c,j as u,l as e,a as s,w as l,F as m,z as y,y as w,u as i,ay as P,az as O,aA as k,a8 as z,aB as A,aC as R,aD as S,M as b,aE as B,aF as C,E as o,A as t,aG as v,aH as T,aI as M,L as g,aJ as D,aK as F,aL as I,a7 as f,aM as L,aN as U,p as _}from"../vendors/vendor-ah_eQdvw.js";import{a as n,b as N,c as j,e as W,s as V,g as h,i as r,k as H}from"./AccountCardSection-DXixqG3L.js";import{_ as G}from"./App-D7rwXoHs.js";const Q={class:"guide-section"},E={class:"variant-group"},Y={class:"component-demo mobile-demo-wrapper"},$={class:"mock-phone"},J={class:"mobile-header"},K={class:"header-actions"},q={class:"feed-container"},X={class:"post-header"},Z={class:"post-meta"},ee={class:"user-name"},ae={class:"post-actions"},ie={style:{position:"absolute",bottom:"70px",right:"16px"}},se={class:"variant-group",style:{"margin-top":"48px"}},oe={class:"component-demo web-demo-wrapper"},te={class:"dashboard-layout"},le={class:"dashboard-sidebar"},ne={class:"sidebar-nav"},de={class:"active"},re={class:"dashboard-main"},pe={class:"dashboard-content"},ce={class:"chart-card"},ue={class:"chart-placeholder"},me={class:"variant-group",style:{"margin-top":"48px"}},be={class:"component-demo desktop-demo-wrapper"},ve={class:"mail-layout"},ge={class:"pane-folders"},fe={class:"folder-list"},he={class:"active"},xe={class:"pane-list"},ye={class:"list-search"},we={class:"pane-reading"},Pe=x({__name:"AppLayoutsSection",setup(Oe){const p=_("home");return(ke,a)=>(c(),u(m,null,[e("div",Q,[a[29]||(a[29]=e("h2",null,"Application Layout Templates",-1)),a[30]||(a[30]=e("p",null,"These templates demonstrate how to combine various UI framework components to create complex, real-world application layouts for Mobile, Web, and Desktop environments.",-1)),e("div",E,[a[6]||(a[6]=e("h3",null,"Mobile Layout: Social Media Feed",-1)),a[7]||(a[7]=e("p",{class:"custom-guide"},"A classic mobile-first layout featuring a bottom navigation bar, a scrolling feed, a floating action button (FAB), and a top app bar.",-1)),e("div",Y,[e("div",$,[s(i(W),null,{header:l(()=>[e("div",J,[a[1]||(a[1]=e("span",{class:"app-title"},"SocialFeed",-1)),e("div",K,[s(i(n),{icon:i(b),size:"small"},null,8,["icon"]),s(i(n),{icon:i(B),size:"small",badge:""},null,8,["icon"])])])]),footer:l(()=>[s(i(j),{modelValue:p.value,"onUpdate:modelValue":a[0]||(a[0]=d=>p.value=d),items:[{label:"Home",value:"home",icon:i(A)},{label:"Explore",value:"explore",icon:i(R)},{label:"Profile",value:"profile",icon:i(S)}]},null,8,["modelValue","items"])]),default:l(()=>[e("div",q,[(c(),u(m,null,y(3,d=>e("div",{class:"post-card",key:d},[e("div",X,[a[3]||(a[3]=e("div",{class:"avatar"},null,-1)),e("div",Z,[e("span",ee,"User "+w(d),1),a[2]||(a[2]=e("span",{class:"post-time"},"2 hours ago",-1))])]),a[4]||(a[4]=e("div",{class:"post-content"}," This is a sample post in the social media feed to demonstrate the layout. The bottom navigation provides easy access to primary routes, while the FAB handles the primary action. ",-1)),e("div",ae,[s(i(n),{icon:i(P),size:"small"},null,8,["icon"]),s(i(n),{icon:i(O),size:"small"},null,8,["icon"]),s(i(n),{icon:i(k),size:"small"},null,8,["icon"])])])),64)),a[5]||(a[5]=e("div",{style:{height:"80px"}},null,-1))]),e("div",ie,[s(i(N),{icon:i(z),color:"primary"},null,8,["icon"])])]),_:1})])])]),e("div",se,[a[16]||(a[16]=e("h3",null,"Web Layout: Analytics Dashboard",-1)),a[17]||(a[17]=e("p",{class:"custom-guide"},"A responsive web layout with a permanent sidebar navigation, a top header, and a grid-based dashboard.",-1)),e("div",oe,[e("div",te,[e("div",le,[a[12]||(a[12]=e("div",{class:"sidebar-logo"},"AnalyticsPro",-1)),e("ul",ne,[e("li",de,[s(i(o),{icon:i(C)},null,8,["icon"]),a[8]||(a[8]=t(" Overview",-1))]),e("li",null,[s(i(o),{icon:i(v)},null,8,["icon"]),a[9]||(a[9]=t(" Reports",-1))]),e("li",null,[s(i(o),{icon:i(T)},null,8,["icon"]),a[10]||(a[10]=t(" Audience",-1))]),e("li",null,[s(i(o),{icon:i(M)},null,8,["icon"]),a[11]||(a[11]=t(" Settings",-1))])])]),e("div",re,[a[15]||(a[15]=e("div",{class:"dashboard-header"},[e("span",{class:"page-title"},"Overview"),e("div",{class:"user-profile"},[e("div",{class:"avatar-small"}),e("span",null,"Admin User")])],-1)),e("div",pe,[a[14]||(a[14]=g('<div class="stats-grid" data-v-aac627d2><div class="stat-card" data-v-aac627d2><span class="stat-label" data-v-aac627d2>Total Users</span><span class="stat-value" data-v-aac627d2>24,592</span></div><div class="stat-card" data-v-aac627d2><span class="stat-label" data-v-aac627d2>Revenue</span><span class="stat-value" data-v-aac627d2>$12,450</span></div><div class="stat-card" data-v-aac627d2><span class="stat-label" data-v-aac627d2>Bounce Rate</span><span class="stat-value" data-v-aac627d2>42.3%</span></div></div>',1)),e("div",ce,[e("div",ue,[s(i(o),{icon:i(v),style:{"font-size":"64px",color:"#cbd5e1"}},null,8,["icon"]),a[13]||(a[13]=e("span",null,"Interactive Chart Area",-1))])])])])])])]),e("div",me,[a[27]||(a[27]=e("h3",null,"Desktop Layout: Mail Client (3-Pane View)",-1)),a[28]||(a[28]=e("p",{class:"custom-guide"},"A dense, information-rich layout utilizing a 3-pane structure typical of native desktop applications.",-1)),e("div",be,[e("div",ve,[e("div",ge,[a[23]||(a[23]=e("div",{class:"folder-header"},"Mailbox",-1)),e("ul",fe,[e("li",he,[s(i(o),{icon:i(D)},null,8,["icon"]),a[18]||(a[18]=t(" Inbox ",-1)),a[19]||(a[19]=e("span",{class:"badge"},"12",-1))]),e("li",null,[s(i(o),{icon:i(F)},null,8,["icon"]),a[20]||(a[20]=t(" Sent",-1))]),e("li",null,[s(i(o),{icon:i(I)},null,8,["icon"]),a[21]||(a[21]=t(" Drafts",-1))]),e("li",null,[s(i(o),{icon:i(f)},null,8,["icon"]),a[22]||(a[22]=t(" Trash",-1))])])]),e("div",xe,[e("div",ye,[s(i(o),{icon:i(b)},null,8,["icon"]),a[24]||(a[24]=e("input",{type:"text",placeholder:"Search mail..."},null,-1))]),a[25]||(a[25]=g('<div class="message-item active" data-v-aac627d2><div class="msg-sender" data-v-aac627d2>Product Team</div><div class="msg-subject" data-v-aac627d2>Q3 Roadmap Update</div><div class="msg-preview" data-v-aac627d2>Here is the latest update regarding our...</div></div><div class="message-item" data-v-aac627d2><div class="msg-sender" data-v-aac627d2>Design Dept</div><div class="msg-subject" data-v-aac627d2>New UI Assets</div><div class="msg-preview" data-v-aac627d2>Please find attached the latest assets...</div></div>',2))]),e("div",we,[s(i(H),{variant:"classic",collapsible:!0,"model-value":"message"},{default:l(()=>[s(i(V),{title:"Message",id:"message"},{default:l(()=>[s(i(h),{title:"Respond"},{default:l(()=>[s(i(r),{icon:i(L),label:"Reply",size:"large"},null,8,["icon"]),s(i(r),{icon:i(U),label:"Forward",size:"large"},null,8,["icon"])]),_:1}),s(i(h),{title:"Delete"},{default:l(()=>[s(i(r),{icon:i(f),label:"Delete",size:"large"},null,8,["icon"])]),_:1})]),_:1})]),_:1}),a[26]||(a[26]=e("div",{class:"email-content"},[e("h2",{style:{"margin-top":"0","margin-bottom":"8px","font-size":"24px",color:"#0f172a"}},"Q3 Roadmap Update"),e("div",{class:"email-meta"},"From: Product Team <product@example.com>"),e("div",{class:"email-body"},[e("p",null,"Hello everyone,"),e("p",null,"We are excited to share the upcoming milestones for Q3. We will be focusing heavily on optimizing the desktop layouts and improving performance across the board."),e("p",null,[t("Best,"),e("br"),t("Product Team")])])],-1))])])])]),a[31]||(a[31]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),a[32]||(a[32]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Application Layout Templates</h2>
    <p>These templates demonstrate how to combine various UI framework components to create complex, real-world application layouts for Mobile, Web, and Desktop environments.</p>

    <!-- Mobile Layout -->
    <div class="variant-group">
      <h3>Mobile Layout: Social Media Feed</h3>
      <p class="custom-guide">A classic mobile-first layout featuring a bottom navigation bar, a scrolling feed, a floating action button (FAB), and a top app bar.</p>
      
      <div class="component-demo mobile-demo-wrapper">
        <!-- Mock Phone Container -->
        <div class="mock-phone">
          <PPMaterialApp>
            <template #header>
              <div class="mobile-header">
                <span class="app-title">SocialFeed</span>
                <div class="header-actions">
                  <PPIconButton :icon="searchOutline" size="small" />
                  <PPIconButton :icon="notificationsOutline" size="small" badge />
                </div>
              </div>
            </template>

            <!-- Scrollable Feed -->
            <div class="feed-container">
              <div class="post-card" v-for="i in 3" :key="i">
                <div class="post-header">
                  <div class="avatar"></div>
                  <div class="post-meta">
                    <span class="user-name">User {{ i }}</span>
                    <span class="post-time">2 hours ago</span>
                  </div>
                </div>
                <div class="post-content">
                  This is a sample post in the social media feed to demonstrate the layout. The bottom navigation provides easy access to primary routes, while the FAB handles the primary action.
                </div>
                <div class="post-actions">
                  <PPIconButton :icon="heartOutline" size="small" />
                  <PPIconButton :icon="chatbubbleOutline" size="small" />
                  <PPIconButton :icon="shareOutline" size="small" />
                </div>
              </div>
              <div style="height: 80px;"></div> <!-- Spacer for FAB/Nav -->
            </div>

            <!-- FAB -->
            <div style="position: absolute; bottom: 70px; right: 16px;">
              <PPFab :icon="addOutline" color="primary" />
            </div>

            <!-- Bottom Nav -->
            <template #footer>
              <PPBottomNav 
                v-model="mobileTab"
                :items="[
                  { label: 'Home', value: 'home', icon: homeOutline },
                  { label: 'Explore', value: 'explore', icon: compassOutline },
                  { label: 'Profile', value: 'profile', icon: personOutline }
                ]"
              />
            </template>
          </PPMaterialApp>
        </div>
      </div>
    </div>

    <!-- Web Dashboard Layout -->
    <div class="variant-group" style="margin-top: 48px;">
      <h3>Web Layout: Analytics Dashboard</h3>
      <p class="custom-guide">A responsive web layout with a permanent sidebar navigation, a top header, and a grid-based dashboard.</p>
      
      <div class="component-demo web-demo-wrapper">
        <div class="dashboard-layout">
          <!-- Sidebar -->
          <div class="dashboard-sidebar">
            <div class="sidebar-logo">AnalyticsPro</div>
            <ul class="sidebar-nav">
              <li class="active"><ion-icon :icon="pieChartOutline" /> Overview</li>
              <li><ion-icon :icon="barChartOutline" /> Reports</li>
              <li><ion-icon :icon="peopleOutline" /> Audience</li>
              <li><ion-icon :icon="settingsOutline" /> Settings</li>
            </ul>
          </div>
          
          <!-- Main Area -->
          <div class="dashboard-main">
            <!-- Header -->
            <div class="dashboard-header">
              <span class="page-title">Overview</span>
              <div class="user-profile">
                <div class="avatar-small"></div>
                <span>Admin User</span>
              </div>
            </div>
            
            <!-- Grid Content -->
            <div class="dashboard-content">
              <div class="stats-grid">
                <div class="stat-card">
                  <span class="stat-label">Total Users</span>
                  <span class="stat-value">24,592</span>
                </div>
                <div class="stat-card">
                  <span class="stat-label">Revenue</span>
                  <span class="stat-value">$12,450</span>
                </div>
                <div class="stat-card">
                  <span class="stat-label">Bounce Rate</span>
                  <span class="stat-value">42.3%</span>
                </div>
              </div>
              <div class="chart-card">
                <div class="chart-placeholder">
                  <ion-icon :icon="barChartOutline" style="font-size: 64px; color: #cbd5e1;" />
                  <span>Interactive Chart Area</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Desktop Mail Client -->
    <div class="variant-group" style="margin-top: 48px;">
      <h3>Desktop Layout: Mail Client (3-Pane View)</h3>
      <p class="custom-guide">A dense, information-rich layout utilizing a 3-pane structure typical of native desktop applications.</p>
      
      <div class="component-demo desktop-demo-wrapper">
        <div class="mail-layout">
          <!-- Left Pane: Folders -->
          <div class="pane-folders">
            <div class="folder-header">Mailbox</div>
            <ul class="folder-list">
              <li class="active"><ion-icon :icon="mailOutline" /> Inbox <span class="badge">12</span></li>
              <li><ion-icon :icon="sendOutline" /> Sent</li>
              <li><ion-icon :icon="documentOutline" /> Drafts</li>
              <li><ion-icon :icon="trashOutline" /> Trash</li>
            </ul>
          </div>
          
          <!-- Middle Pane: Message List -->
          <div class="pane-list">
            <div class="list-search">
              <ion-icon :icon="searchOutline" />
              <input type="text" placeholder="Search mail..." />
            </div>
            <div class="message-item active">
              <div class="msg-sender">Product Team</div>
              <div class="msg-subject">Q3 Roadmap Update</div>
              <div class="msg-preview">Here is the latest update regarding our...</div>
            </div>
            <div class="message-item">
              <div class="msg-sender">Design Dept</div>
              <div class="msg-subject">New UI Assets</div>
              <div class="msg-preview">Please find attached the latest assets...</div>
            </div>
          </div>
          
          <!-- Right Pane: Reading Pane -->
          <div class="pane-reading">
            <!-- Ribbon for Actions -->
            <PPRibbon variant="classic" :collapsible="true" model-value="message">
              <PPRibbonTab title="Message" id="message">
                <PPRibbonGroup title="Respond">
                  <PPRibbonButton :icon="arrowUndoOutline" label="Reply" size="large" />
                  <PPRibbonButton :icon="arrowRedoOutline" label="Forward" size="large" />
                </PPRibbonGroup>
                <PPRibbonGroup title="Delete">
                  <PPRibbonButton :icon="trashOutline" label="Delete" size="large" />
                </PPRibbonGroup>
              </PPRibbonTab>
            </PPRibbon>
            
            <div class="email-content">
              <h2 style="margin-top: 0; margin-bottom: 8px; font-size: 24px; color: #0f172a;">Q3 Roadmap Update</h2>
              <div class="email-meta">From: Product Team &lt;product@example.com&gt;</div>
              <div class="email-body">
                <p>Hello everyone,</p>
                <p>We are excited to share the upcoming milestones for Q3. We will be focusing heavily on optimizing the desktop layouts and improving performance across the board.</p>
                <p>Best,<br>Product Team</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { IonIcon } from '@ionic/vue';
import { 
  searchOutline, notificationsOutline, addOutline, heartOutline, chatbubbleOutline, shareOutline,
  homeOutline, compassOutline, personOutline, pieChartOutline, barChartOutline, peopleOutline, settingsOutline,
  mailOutline, sendOutline, documentOutline, trashOutline, arrowUndoOutline, arrowRedoOutline
} from 'ionicons/icons';
import { 
  PPMaterialApp, PPFab, PPBottomNav, PPIconButton,
  PPRibbon, PPRibbonTab, PPRibbonGroup, PPRibbonButton
} from '@phanna/ui-framework';

const mobileTab = ref('home');
<\/script>

<style scoped>
/* Mobile Layout */
.mobile-demo-wrapper {
  display: flex;
  justify-content: center;
  background-color: #f1f5f9;
  padding: 32px 0;
  border-radius: 8px;
}
.mock-phone {
  width: 375px;
  height: 700px;
  border: 12px solid #1e293b;
  border-radius: 36px;
  overflow: hidden;
  position: relative;
  background: white;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
}
.mobile-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: white;
  border-bottom: 1px solid #e2e8f0;
}
.app-title {
  font-size: 18px;
  font-weight: 700;
  color: #0f172a;
}
.header-actions {
  display: flex;
  gap: 8px;
}
.feed-container {
  padding: 16px;
  background: #f8fafc;
  height: calc(100% - 110px);
  overflow-y: auto;
}
.post-card {
  background: white;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  border: 1px solid #e2e8f0;
}
.post-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}
.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #cbd5e1;
}
.post-meta {
  display: flex;
  flex-direction: column;
}
.user-name { font-weight: 600; font-size: 14px; }
.post-time { font-size: 12px; color: #64748b; }
.post-content { font-size: 14px; color: #334155; margin-bottom: 12px; line-height: 1.5; }
.post-actions {
  display: flex;
  gap: 16px;
  border-top: 1px solid #f1f5f9;
  padding-top: 8px;
}

/* Web Dashboard Layout */
.web-demo-wrapper {
  background-color: #f1f5f9;
  padding: 24px;
  border-radius: 8px;
}
.dashboard-layout {
  display: flex;
  height: 600px;
  background: #f8fafc;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
  border: 1px solid #e2e8f0;
}
.dashboard-sidebar {
  width: 240px;
  background: #1e293b;
  color: white;
  display: flex;
  flex-direction: column;
}
.sidebar-logo {
  padding: 24px;
  font-size: 20px;
  font-weight: bold;
  border-bottom: 1px solid #334155;
  color: #38bdf8;
}
.sidebar-nav {
  list-style: none;
  padding: 16px 0;
  margin: 0;
}
.sidebar-nav li {
  padding: 12px 24px;
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
  color: #cbd5e1;
}
.sidebar-nav li:hover { background: #334155; }
.sidebar-nav li.active { background: #0ea5e9; color: white; font-weight: 500; }
.dashboard-main {
  flex: 1;
  display: flex;
  flex-direction: column;
}
.dashboard-header {
  height: 64px;
  background: white;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
}
.page-title { font-size: 20px; font-weight: 600; color: #0f172a; }
.user-profile {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 14px;
  font-weight: 500;
}
.avatar-small { width: 32px; height: 32px; border-radius: 50%; background: #94a3b8; }
.dashboard-content {
  padding: 24px;
  flex: 1;
  overflow-y: auto;
}
.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-bottom: 24px;
}
.stat-card {
  background: white;
  padding: 24px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.stat-label { font-size: 14px; color: #64748b; font-weight: 500; }
.stat-value { font-size: 32px; font-weight: 700; color: #0f172a; }
.chart-card {
  background: white;
  height: 300px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  padding: 24px;
}
.chart-placeholder {
  width: 100%;
  height: 100%;
  background: #f8fafc;
  border: 2px dashed #cbd5e1;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 16px;
  color: #94a3b8;
}

/* Desktop Mail Layout */
.desktop-demo-wrapper {
  background-color: #f1f5f9;
  padding: 24px;
  border-radius: 8px;
}
.mail-layout {
  display: flex;
  height: 600px;
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
  border: 1px solid #e2e8f0;
}
.pane-folders {
  width: 200px;
  background: #f8fafc;
  border-right: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
}
.folder-header {
  padding: 16px;
  font-weight: 600;
  color: #64748b;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.folder-list {
  list-style: none;
  padding: 0;
  margin: 0;
}
.folder-list li {
  padding: 8px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 14px;
  color: #334155;
  cursor: pointer;
}
.folder-list li:hover { background: #e2e8f0; }
.folder-list li.active { background: #e0f2fe; color: #0284c7; font-weight: 500; border-left: 3px solid #0284c7; }
.folder-list ion-icon { font-size: 18px; }
.badge { margin-left: auto; background: #0284c7; color: white; padding: 2px 6px; border-radius: 12px; font-size: 11px; }

.pane-list {
  width: 300px;
  background: white;
  border-right: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
}
.list-search {
  padding: 12px;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  gap: 8px;
  background: #f8fafc;
}
.list-search input {
  border: none; background: transparent; outline: none; width: 100%; font-size: 13px;
}
.message-item {
  padding: 16px;
  border-bottom: 1px solid #e2e8f0;
  cursor: pointer;
}
.message-item:hover { background: #f8fafc; }
.message-item.active { background: #eff6ff; }
.msg-sender { font-weight: 600; font-size: 14px; color: #0f172a; margin-bottom: 4px; }
.msg-subject { font-size: 13px; font-weight: 500; color: #334155; margin-bottom: 4px; }
.msg-preview { font-size: 12px; color: #64748b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.pane-reading {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: white;
}
.pane-reading :deep(.pp-ribbon--classic .pp-ribbon-header) {
  padding-top: 0;
}
.pane-reading :deep(.pp-ribbon--classic .pp-ribbon-tab-header) {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
.pane-reading :deep(.pp-ribbon-tabs) {
  padding: 0 8px;
}
.email-content {
  padding: 32px;
  flex: 1;
  overflow-y: auto;
}
.email-meta { font-size: 13px; color: #64748b; margin-bottom: 32px; border-bottom: 1px solid #e2e8f0; padding-bottom: 16px; }
.email-body { font-size: 15px; color: #334155; line-height: 1.6; }
</style>
`)])],-1))],64))}}),Se=G(Pe,[["__scopeId","data-v-aac627d2"]]);export{Se as A};
