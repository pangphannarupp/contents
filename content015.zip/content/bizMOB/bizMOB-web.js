/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/naming-convention */
/**
 * @title bizMOB Web Extend
 * @author mhchoi@mcnc.co.kr
 * @version 1.0
 */
var bizMOBWebCore = {};

bizMOBWebCore.name = "bizMOBWebCore";
bizMOBWebCore.version = "1.0";

/**
 * Web Module Class
 */
bizMOBWebCore.Module = {};
bizMOBWebCore.Module.serviceName = "Module";
bizMOBWebCore.Module.config = {};

// bizMOB Web Logger
// param._sService, param._sAction, param._sLogType, param._sMessage, param._oParams
bizMOBWebCore.Module.logger = function () {
    // 릴리즈 환경에서는 로그 출력 안함.
    if (bizMOBWebCore.App.config._bIsRelease) return;

    // 콘솔 로그 타입 스타일 정의
    var baseStyle = "padding: 2px 4px; border-radius: 2px;";
    var infoStyle = baseStyle + " color: white; background: #1a73e8;";
    var logStyle = baseStyle + " color: white; background: #546e7a;";
    var debugStyle = baseStyle + " color: white; background: #009688;";
    var warnStyle = baseStyle + " color: white; background: #ffbb33;";
    var errorStyle = baseStyle + " color: white; background: #d9534f;";

    // 콘솔 로그 Class 스타일 정의
    var bracketStyle = "font-weight: bold;";
    var infoBracketStyle = bracketStyle + " color: #1a73e8;";
    var logBracketStyle = bracketStyle + " color: #546e7a;";
    var debugBracketStyle = bracketStyle + " color: #009688;";
    var warnBracketStyle = bracketStyle + " color: #ffbb33;";
    var errorBracketStyle = bracketStyle + " color: #d9534f;";

    var { _sService, _sAction, _sLogType, _sMessage, _oParams } = arguments[0];

    var msg = "";

    // JSON.stringify 오류시 빈 값으로 처리
    try {
        msg = typeof _sMessage === "object" ? JSON.stringify(_sMessage) : _sMessage;
    } catch (error) {
        msg = "";
    }

    // 콘솔 로그 정의
    var trace = "[Web][" + _sService + "]" + "[" + _sAction + "]";
    var log = msg.replace(/\{/gi, "\n{").replace(/\}/gi, "}\n").replace(/\\"/gi, "");

    _oParams = _oParams && _oParams.length > 0 ? _oParams : "";

    // 로그 출력
    switch (_sLogType) {
        case "I":
            console.info("%c bizMOB INFO %c " + "%c" + trace + "%c " + log, infoStyle, "", infoBracketStyle, "", ..._oParams);
            break;
        case "L":
            console.log("%c bizMOB LOG %c " + "%c" + trace + "%c " + log, logStyle, "", logBracketStyle, "", ..._oParams);
            break;
        case "D":
            console.debug("%c bizMOB DEBUG %c " + "%c" + trace + "%c " + log, debugStyle, "", debugBracketStyle, "", ..._oParams);
            break;
        case "W":
            console.warn("%c bizMOB WARN %c " + "%c" + trace + "%c " + log, warnStyle, "", warnBracketStyle, "", ..._oParams);
            break;
        case "E":
            console.error("%c bizMOB ERROR %c " + "%c" + trace + "%c " + log, errorStyle, "", errorBracketStyle, "", ..._oParams);
            break;
    }
};

/**
 * 파라미터 체크
 *
 * @param Object oParams	확인될 파라미터 정보 객체.
 * @param Array aRequired	필수 파라미터 목록.
 *
 * @return boolean result 파라미터 체크 결과
 */
bizMOBWebCore.Module.checkParam = function (oParams, aRequired) {
    var action = "checkParam"; // 함수 동작을 식별하기 위한 변수
    var typeList = {
        // 변수 타입에 대한 매핑 객체
        a: "array",
        o: "object",
        f: "function",
        b: "boolean",
        s: "string",
        n: "number",
        v: "variable",
        e: "element"
    };

    var param = oParams || {}; // 전달된 파라미터 객체
    var paramKeys = Object.keys(param); // 전달된 파라미터 객체의 속성 목록
    var required = aRequired || []; // 필수 파라미터 목록
    var missingKeys = required.filter(function (key) {
        // 없는 필수 파라미터 목록
        return paramKeys.indexOf(key) === -1;
    });

    // 전달된 파라미터가 오브젝트가 아닌 경우
    if (typeof param !== "object") {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "E", _sMessage: "Invalid parameter format. Parameter have to define JSON." }); // 로그 출력
        return false;
    }
    // 전달된 파라미터가 없는 경우
    else if (!paramKeys.length) {
        if (required.length == 0) {
            // 필수 파라미터가 없는 경우
            return true; // 유효성 검사 통과
        } else {
            bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "L", _sMessage: "Cannot found parameters." }); // 로그 출력
            return false; // 유효성 검사 실패
        }
    }
    // 필수 파라미터가 없는 경우
    else if (missingKeys.length) {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "E", _sMessage: "Parameter is required. - " + missingKeys.join(", ") }); // 로그 출력
        return false;
    }
    // 정상 파라미터
    else {
        // 파라미터 객체 속성 순회
        for (var key in param) {
            if (Object.hasOwnProperty.call(param, key)) {
                var type = key.substring(1, 2); // key값 앞에 _s, _n...에서 s, n...을 추출
                var value = param[key]; // value

                // 속성 값이 없는 경우
                if (value === undefined) {
                    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "L", _sMessage: "Parameter is undefined. it skip check - " + key }); // 로그 출력
                }
                // 속성 값이 null인 경우
                else if (value === null) {
                    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "L", _sMessage: "Parameter is null. it skip check. - " + key }); // 로그 출력
                }
                // 정의되지 않은 타입이면 false
                if (typeList[type] === undefined) {
                    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "E", _sMessage: "Parameter is unknown variable type. - " + key }); // 로그 출력
                    return false;
                }
                // 배열 타입인데, 배열이 아닌 경우 false
                else if (typeList[type] === "array" && !Array.isArray(value)) {
                    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "E", _sMessage: "Parameter is not an array. - " + key }); // 로그 출력
                    return false;
                }
                // 배열 타입인데, 배열이 비어있는 경우 false
                else if (typeList[type] === "array" && value.length === 0) {
                    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "E", _sMessage: "Parameter is empty Array. - " + key }); // 로그 출력
                    return false;
                }
                // 오브젝트 타입인데, 오브젝트가 아닌 경우 false
                else if (typeList[type] === "object" && typeof value !== "object") {
                    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "E", _sMessage: "Parameter is not an object. - " + key }); // 로그 출력
                    return false;
                }
                // 그 외 타입인데, 타입이 다른 경우 false
                else if (typeList[type] !== typeof value) {
                    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: action, _sLogType: "E", _sMessage: "Parameter have wrong value. - " + key }); // 로그 출력
                    return false;
                }
                // variable 또는 element 타입인 경우 true
                else if (typeList[type] === "variable" || typeList[type] === "element") {
                    return true;
                }
                // 유효성 검사 통과
                else {
                    return true;
                }
            }
        }
    }
};

/**
 * Web EventManager Class
 */
bizMOBWebCore.EventManager = {};
bizMOBWebCore.EventManager.serviceName = "EventManager";
bizMOBWebCore.EventManager.config = {};

bizMOBWebCore.EventManager.storage = {
    // Web init
    ready: true
};

// 이벤트 셋업 (웹에서는 EventManager.storage에 있는 이벤트를 set시 바로 실행)
bizMOBWebCore.EventManager.set = function () {
    var sEvent = arguments[0]._sEvent;
    var fCallback = arguments[0]._fCallback;

    if (bizMOBWebCore.EventManager.storage[sEvent]) {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "set", _sLogType: "L", _sMessage: "Event execute. - " + sEvent });
        fCallback({ type: "web" });
    } else {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "set", _sLogType: "W", _sMessage: "This event is not supported on the web. - " + sEvent });
    }
};

/**
 * Web App Class
 */
bizMOBWebCore.App = {};
bizMOBWebCore.App.serviceName = "App";
bizMOBWebCore.App.config = {
    _bIsRelease: false, // 릴리즈 여부
    _sAppKey: "" // App Key
};

/**
 * Web Device Class
 */
bizMOBWebCore.DeviceManager = {};
bizMOBWebCore.DeviceManager.serviceName = "DeviceManager";

// App 판단 여부
bizMOBWebCore.DeviceManager.isApp = function () {
    return !!window.BMCManager || (!!window.webkit && !!window.webkit.messageHandlers && !!window.webkit.messageHandlers.BMCManager);
};

// Web 판단 여부
bizMOBWebCore.DeviceManager.isWeb = function () {
    return !bizMOBWebCore.DeviceManager.isApp();
};

// Mobile 여부
bizMOBWebCore.DeviceManager.isMobile = function () {
    var UA = navigator.userAgent || navigator.vendor || window.opera;
    return UA && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(UA);
};

// PC 여부
bizMOBWebCore.DeviceManager.isPC = function () {
    return !bizMOBWebCore.DeviceManager.isMobile();
};

// Android 여부
bizMOBWebCore.DeviceManager.isAndroid = function () {
    var UA = navigator.userAgent || navigator.vendor || window.opera;
    return /android/i.test(UA);
};

// IOS 여부
bizMOBWebCore.DeviceManager.isIOS = function () {
    var UA = navigator.userAgent || navigator.vendor || window.opera;
    return /iPad|iPhone|iPod/.test(UA) && !window.MSStream;
};

// Tablet 여부
bizMOBWebCore.DeviceManager.isTablet = function () {
    var UA = navigator.userAgent || navigator.vendor || window.opera;
    return /(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk|(puffin(?!.*(IP|AP|WP))))/.test(UA.toLowerCase());
};

//Phone 여부
bizMOBWebCore.DeviceManager.isPhone = function () {
    return bizMOBWebCore.DeviceManager.isMobile() && !bizMOBWebCore.DeviceManager.isTablet();
};

/**
 * Web Network Class
 */
bizMOBWebCore.Network = {};
bizMOBWebCore.Network.serviceName = "Network";
bizMOBWebCore.Network.config = {
    _sBaseUrl: "", // Client Base Url
    _sApiContext: "", // Client Context
    _sProxContext: "", // Proxy Context
    _bIsProxy: false, // Proxy 사용 여부
    _bIsCrypto: false, // 암호화 여부
    _sCryAuthToken: "", // 암호화 Token
    _sCrySymKey: "" // 암호화 Key
};

// locale 변경
bizMOBWebCore.Network.changeLocale = function (arg) {
    // 언어 코드 (ko, ko-KR, en, en-US, ...)
    var localeCode = arg._sLocaleCd;
    // full locale 값 조회
    var fullLocale = bizMOBWebCore.Localization.getFullLocale(localeCode);

    // Web 환경에 맞는 언어코드 변경 로직
    bizMOBWebCore.Localization.locale = fullLocale;
    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "changeLocale", _sLogType: "L", _sMessage: "Network locale change: " + fullLocale });
};

// 메시지 암호화
bizMOBWebCore.Network.encryption = function () {
    var CryptoJS = window.CryptoJS;
    var arg = arguments[0] || {};
    var message = arg._sMessage || "";

    try {
        var key = atob(bizMOBWebCore.Network.config._sCrySymKey);
        var iv = bizMOBWebCore.Network.config._sCrySymKey.substring(0, 16);
        var encrypt = CryptoJS.AES.encrypt(message, CryptoJS.enc.Utf8.parse(key), {
            iv: CryptoJS.enc.Utf8.parse(iv),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });

        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "encryption", _sLogType: "L", _sMessage: "Message encryption success: " + message });
        return { result: true, message: encrypt.toString() };
    } catch (error) {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "encryption", _sLogType: "L", _sMessage: "Message encryption failed: " + message });
        return { result: false, message: message };
    }
};

// 메시지 복호화
bizMOBWebCore.Network.decryption = function () {
    var CryptoJS = window.CryptoJS;
    var arg = arguments[0] || {};
    var message = arg._sMessage || "";

    try {
        var key = atob(bizMOBWebCore.Network.config._sCrySymKey);
        var iv = bizMOBWebCore.Network.config._sCrySymKey.substring(0, 16);
        var decipher = CryptoJS.AES.decrypt(message, CryptoJS.enc.Utf8.parse(key), {
            iv: CryptoJS.enc.Utf8.parse(iv),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });

        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "decryption", _sLogType: "L", _sMessage: "Message decryption success: " + message });
        return { result: true, message: decipher.toString(CryptoJS.enc.Utf8) };
    } catch (error) {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "decryption", _sLogType: "E", _sMessage: "Message decryption failed: " + message });
        return { result: false, message: message };
    }
};

/**
 * bizMOB Web Server Request
 * @param {string} _sTrcode bizMOB Server 전문코드
 * @param {object} _oHeader bizMOB Server 전문 Header 객체
 * @param {object} _oBody bizMOB Server 전문 Body 객체
 * @param {boolean} _bProgressEnable (default: true) 서버에 통신 요청시 progress 표시 여부( true 또는 false )
 * @param {number} _nTimeout (default: 60) 서버에 통신 요청시 timeout 시간 (sec)
 * @param {function} _fCallback 서버와 통신 후 실행될 callback 함수
 *
 * @return
 */
bizMOBWebCore.Network.requestTr = function (arg) {
    /** Parameter 셋팅 */
    var timeout = (arg._nTimeout ? arg._nTimeout : 60) * 1000; // native api와 시간 단위를 맞춤
    var message = {
        header: Object.assign(
            {},
            {
                result: true,
                error_code: "",
                error_text: "",
                info_text: "",
                message_version: "",
                login_session_id: "",
                trcode: arg._sTrcode
            },
            arg._oHeader
        ),
        body: arg._oBody
    };
    var body = { message: JSON.stringify(message) };

    /** Http.fetch 호출 */
    // url 생성
    var isProxy = bizMOBWebCore.Network.config._bIsProxy; // serve, build
    var context = isProxy ? bizMOBWebCore.Network.config._sProxContext : bizMOBWebCore.Network.config._sApiContext;
    var url = (bizMOBWebCore.Network.config._sApiContext === "/" ? "" : context) + "/" + arg._sTrcode + ".json" + (arg._sQuery ? "?" + arg._sQuery : ""); // 일반 조화시 url

    // fetch 옵션 생성
    var option = bizMOBWebCore.Http.bizmobOption({ _oHttpHeader: arg._oHttpHeader, _oBody: body });

    // fetch 호출
    bizMOBWebCore.Http.fetch(url, option, timeout)
        .then(function (res) {
            var message = res.data;

            // callback 함수 호출
            bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "requestTr", _sLogType: "L", _sMessage: "Request trcode success: " + arg._sTrcode });
            arg._fCallback && arg._fCallback(message);
        })
        .catch(function () {
            bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "requestTr", _sLogType: "E", _sMessage: "Request trCode failed: " + arg._sTrcode });
            arg._fCallback && arg._fCallback({ header: Object.assign({}, message.header || {}, { result: false, error_code: "NE0002" }) });
        });
};

/**
 * bizMOB Web Server Request Login
 * @param {string} _sUserId 인증 받을 사용자 아이디
 * @param {string} _sPassword 인증 받을 사용자 패스워드
 * @param {string} _sTrcode 레거시 로그인 인증 전문코드
 * @param {string} _oHeader 레거시 로그인 인증 전문 Header 객체
 * @param {string} _oBody 레거시 로그인 인증 전문 Body 객체
 * @param {boolean} _bProgressEnable (default:true) 서버에 통신 요청시 progress 표시 여부( true 또는 false )
 * @param {number} _nTimeout (default: 60) 서버에 통신 요청시 timeout 시간 (sec)
 * @param {function} _fCallback 서버와 통신 후 실행될 callback 함수
 */
bizMOBWebCore.Network.requestLogin = function (arg) {
    /** Parameter 셋팅 */
    var timeout = (arg._nTimeout ? arg._nTimeout : 60) * 1000; // native api와 시간 단위를 맞춤
    var legacy_message = {
        header: Object.assign(
            {},
            {
                result: true,
                error_code: "",
                error_text: "",
                info_text: "",
                message_version: "",
                login_session_id: "",
                trcode: arg._sTrcode
            },
            arg._oHeader
        ),
        body: arg._oBody
    };
    var message = {
        header: {
            result: true,
            error_code: "",
            error_text: "",
            info_text: "",
            locale: bizMOBWebCore.Localization.locale,
            message_version: "",
            login_session_id: "",
            trcode: "LOGIN"
        },
        body: {
            os_type: "web",
            user_id: arg._sUserId,
            password: arg._sPassword,
            legacy_message: legacy_message,
            legacy_trcode: arg._sTrcode,
            app_key: bizMOBWebCore.App.config._sAppKey,
            emulator_flag: true,
            manual_phone_number: false,
            device_id: "",
            phone_number: ""
        }
    };
    var body = { message: JSON.stringify(message) };

    /** Http.fetch 호출 */
    // url 생성
    var isProxy = bizMOBWebCore.Network.config._bIsProxy; // serve, build
    var context = isProxy ? bizMOBWebCore.Network.config._sProxContext : bizMOBWebCore.Network.config._sApiContext;
    var url = (bizMOBWebCore.Network.config._sApiContext === "/" ? "" : context) + "/LOGIN.json" + (arg._sQuery ? "?" + arg._sQuery : ""); // 일반 조화시 url

    // fetch 옵션 생성
    var option = bizMOBWebCore.Http.bizmobOption({ _oHttpHeader: arg._oHttpHeader, _oBody: body });

    /** Http.fetch 호출 */
    bizMOBWebCore.Http.fetch(url, option, timeout)
        .then(function (res) {
            var message = res.data;
            // callback 함수 호출
            bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "requestTr", _sLogType: "L", _sMessage: "Request login success: " + arg._sTrcode });
            arg._fCallback && arg._fCallback(message.header.result ? message.body.legacy_message : message);
        })
        .catch(function () {
            bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "requestTr", _sLogType: "E", _sMessage: "Request login failed: " + arg._sTrcode });
            arg._fCallback && arg._fCallback({ header: Object.assign({}, message.header || {}, { result: false, error_code: "NE0002" }) });
        });
};

/**
 * bizMOB Server 전문 통신
 *
 * @param {String} _sUrl 서버 URL
 * @param {String} _sMethod 통신 방식 (get, post)
 * @param {String} _oHeader Http Header
 * @param {String} _oBody Http Body
 * @param {Number} _nTimeout (default: 60) 서버에 통신 요청시 timeout 시간 (sec)
 * @param {Function} _fCallback	서버와 통신 후 실행될 callback 함수
 *
 * @returns {Object} Response 객체
 * @returns {Boolean} returns.result 결과
 * @returns {Number} returns.response_code 응답 코드 (200 <= .. <= 300)
 * @returns {String} returns.response_data 응답 데이터
 * @returns {Object} returns.error 응답 실패시 에러 객체 (실패시에만 존재)
 * @returns {Number} returns.error.code Native 응답 실패코드 (ERR000)
 * @returns {String} returns.error.message Native에서 주는 응답 실패 메시지
 * @returns {Number} returns.error.response_code Server 응답 실패코드 (401, 402, ...) -- 없을 수도 있음
 * @returns {String} returns.error.response_data Server 응답 실패 데이터 -- 없을 수도 있음
 */
bizMOBWebCore.Network.requestHttp = function (arg) {
    var url = arg._sUrl;
    var timeout = (arg._nTimeout ? arg._nTimeout : 60) * 1000;
    var option = Object.assign({}, arg._oOption, {
        method: arg._sMethod,
        headers: Object.assign(
            {},
            {
                "Content-Type": "application/json"
            },
            arg._oHeader
        )
    });

    // Body 메시지 처리
    if (arg._oBody) {
        // Get 처리
        if (option.method.toLocaleUpperCase() === "GET") {
            url += "?" + new URLSearchParams(arg._oBody || {}).toString();
        }
        // 그 외 method 처리
        else {
            option.body = new URLSearchParams(arg._oBody || {}).toString();
        }
    }

    // Http.fetch 요청
    bizMOBWebCore.Http.fetch(url, option, timeout)
        .then(function (res) {
            let responseData = null;

            try {
                // 보통 JSON 형태의 응답값
                responseData = JSON.stringify(res.data);
            } catch (error) {
                // 오류가 난 경우 전달받은 값 전달
                responseData = res.data;
            }

            if (200 <= res.status && res.status < 300) {
                arg._fCallback &&
                    arg._fCallback({
                        result: true,
                        response_code: res.status,
                        response_data: responseData
                    });
            } else {
                arg._fCallback &&
                    arg._fCallback({
                        result: false,
                        error: {
                            code: "ERR001",
                            message: "Response failed",
                            response_code: res.status,
                            response_data: responseData
                        }
                    });
            }
        })
        .catch(function (res) {
            arg._fCallback &&
                arg._fCallback({
                    result: false,
                    error: {
                        code: "ERR000",
                        message: "Request failed",
                        response_code: res.status,
                        response_data: res.data
                    }
                });
        });
};

/**
 * Web Properties Class
 */
bizMOBWebCore.Properties = {};
bizMOBWebCore.Properties.prefix = "bizMOB:WEB:PROPERTIES:";
bizMOBWebCore.Properties.serviceName = "Properties";
bizMOBWebCore.Properties.config = {};

/**
 * bizMOB Web Properties Set
 * @param {object} arg
 * @param {string} arg._sKey Properties key
 * @param {any} arg._vValue Properties value
 * @param {object[]} arg._aList data map list (Ex. [{_sKey: "1", _vValue: "1"}, ...])
 */
bizMOBWebCore.Properties.set = function (arg) {
    var dataList = [];

    if (Object.hasOwnProperty.call(arg, "_aList")) {
        dataList = arg._aList;
    } else {
        dataList = [arg];
    }

    for (const data of dataList) {
        var prop = bizMOBWebCore.Properties.prefix + data._sKey;
        var value = data._vValue;
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "set", _sLogType: "L", _sMessage: "bizMOB properties set: " + data._sKey });
        localStorage.setItem(prop, value);
    }
};

/**
 * bizMOB Web Properties Get
 * @param {object} arg
 * @param {string} arg._sKey Properties key
 * @returns Properties value
 */
bizMOBWebCore.Properties.get = function (arg) {
    var prefix = bizMOBWebCore.Properties.prefix;

    if (arg && Object.hasOwnProperty.call(arg, "_sKey")) {
        var prop = prefix + arg._sKey;

        return localStorage.getItem(prop);
    } else {
        var storage = localStorage;
        var result = {};

        for (var key in storage) {
            if (Object.hasOwnProperty.call(storage, key)) {
                if (key.indexOf(prefix) === 0) {
                    result[key.replace(prefix, "")] = storage[key];
                }
            }
        }

        return result;
    }
};

/**
 * bizMOB Web Properties Remove
 * @param {object} arg
 * @param {string} arg._sKey Properties key
 */
bizMOBWebCore.Properties.remove = function (arg) {
    var prop = bizMOBWebCore.Properties.prefix + arg._sKey;

    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "remove", _sLogType: "L", _sMessage: "bizMOB properties remove: " + arg._sKey });

    localStorage.removeItem(prop);
    return true;
};

/**
 * Web System Class
 */
bizMOBWebCore.System = {};
bizMOBWebCore.System.serviceName = "System";
bizMOBWebCore.System.config = {};

bizMOBWebCore.System.getGPS = function (arg) {
    if ("geolocation" in navigator) {
        // Geolocation API 사용 가능
        navigator.geolocation.getCurrentPosition(
            function (position) {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;

                arg._fCallback &&
                    arg._fCallback({
                        result: true,
                        longitude: longitude,
                        latitude: latitude,
                        address: ""
                    });
            },
            function (error) {
                console.error("Geolocation error:", error);
                arg._fCallback &&
                    arg._fCallback({
                        result: false,
                        longitude: 0,
                        latitude: 0,
                        address: ""
                    });
            }
        );
    } else {
        // Geolocation API 사용 불가
        arg._fCallback &&
            arg._fCallback({
                result: false,
                longitude: 0,
                latitude: 0,
                address: ""
            });
    }
};

/**
 * Web Localization Class
 */
bizMOBWebCore.Localization = {};
bizMOBWebCore.Localization.serviceName = "Localization";
bizMOBWebCore.Localization.config = {};

// 현재 언어 값
bizMOBWebCore.Localization.locale = "";

// 언어 코드로 (언어코드)-(국가코드) 형태의 full locale 코드 반환
bizMOBWebCore.Localization.getFullLocale = function (localeCode) {
    // 사용자 언어 목록에서 언어 코드(ko, ...)에 대응되는 full locale(ko-KR, ...) 코드
    var fullLocale = navigator.languages.find(function (lang) {
        return lang.toLowerCase().startsWith(localeCode.toLowerCase() + "-");
    });
    // 미리 지정한 언어 목록에서 언어 코드에 대응되는 preset locale 코드
    var presetLocale = window.bizMOB.Localization.localeInfo[localeCode.toLowerCase()];

    // 전달받은 언어 코드가 full locale(ko-KR)값이라면 그대로 전달
    if (localeCode.indexOf("-") > 0) {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "getFullLocale", _sLogType: "L", _sMessage: "Gets the full locale value: (parameter) " + localeCode });
        return localeCode;
    }
    // 전달받은 언어 코드가 'ko' 형식이고, navigator.languages 목록에서 'ko-KR' 형식이 있다면 찾은 값 전달
    else if (fullLocale) {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "getFullLocale", _sLogType: "L", _sMessage: "Gets the full locale value: (navigator) " + fullLocale });
        return fullLocale;
    }
    // 전달받은 언어 코드가 'ko' 형식이고, 프리셋에 있다면 프리셋 언어코드를 전달
    else if (presetLocale) {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "getFullLocale", _sLogType: "L", _sMessage: "Gets the full locale value: (preset) " + presetLocale });
        return presetLocale;
    }
    // 전달받은 언어 코드가 navigator, 프리셋에 전부 없다면 전달받은 값 그대로 전달 (ko)
    else {
        bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "getFullLocale", _sLogType: "L", _sMessage: "Gets the full locale value: (unknown) " + presetLocale });
        return localeCode;
    }
};

// 설정된 (언어)-(국가) 코드 조회
bizMOBWebCore.Localization.getLocale = function (arg) {
    var locale = bizMOBWebCore.Localization.locale; // 설정한 언어 코드
    var defaultLocale = bizMOBWebCore.Localization.getFullLocale(navigator.language); // 기본 언어 코드

    // 설정한 locale가 있는 경우 (Ex. ko-KR)
    if (locale) {
        arg._fCallback && arg._fCallback({ result: true, locale: bizMOBWebCore.Localization.locale });
    }
    // 그 외에는 Default 언어 코드 전달
    else {
        arg._fCallback && arg._fCallback({ result: true, locale: defaultLocale });
    }
};

// 언어코드에 맞는 (언어)-(국가) 코드 저장
bizMOBWebCore.Localization.setLocale = function (arg) {
    // 언어 코드 (ko, ko-KR, en, en-US, ...)
    var localeCode = arg._sLocaleCd;
    // full locale 값 조회
    var fullLocale = bizMOBWebCore.Localization.getFullLocale(localeCode);

    // Web 환경에 맞는 언어코드 변경 로직
    bizMOBWebCore.Localization.locale = fullLocale;
    bizMOBWebCore.Module.logger({ _sService: this.serviceName, _sAction: "setLocale", _sLogType: "L", _sMessage: "Localization locale set: " + fullLocale });

    // callback 함수 호출
    arg._fCallback && arg._fCallback({ result: true, locale: bizMOBWebCore.Localization.locale });
};

/**
 * Web Http Class
 */
bizMOBWebCore.Http = {};

// bizMOB Server용 fetch option 정보
bizMOBWebCore.Http.bizmobOption = function () {
    var arg = arguments[0] || {};
    var httpHeader = arg._oHttpHeader || null; // http header
    var headers = Object.assign(
        {},
        {
            // 컨텐츠 타입
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        },
        httpHeader
    );
    var body = arg._oBody || {}; // body data

    // 언어 코드 추가
    if (bizMOBWebCore.Localization.locale && !headers["Accept-Language"]) {
        headers["Accept-Language"] = bizMOBWebCore.Localization.locale;
    }

    // 옵션 반환
    return {
        mode: "cors", // no-cors, *cors, same-origin
        cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
        method: "POST",
        headers: headers,
        body: new URLSearchParams(body || {}).toString()
    };
};

/**
 * 요청 파라미터를 fetch 형태에 맞춰서 변경 후 요청
 * @param {object} arg 요청 객체
 * @param {string} arg._sUrl
 * @param {string} arg._sMethod 요청 방식 (GET, POST, PUT, DELETE, ...)
 * @param {number} arg._nTimeout 요청 제한시간 (sec 단위)
 * @param {number} arg._nRetries API 요청 회수 (default: 1 -- 한번 요청 실패시 응답)
 * @param {object} arg._oOption fetch options
 * @param {object} arg._oHeader request 요청 header
 * @param {object} arg._oBody request 요청 body -- JSON.stringify(data) 또는 new URLSearchParams(data).toString() 후 전달
 * @param {function} arg._fCallback (custom) 요청 성공/실패시 응답값 반환 함수
 * @return
 */
bizMOBWebCore.Http.request = function (arg) {
    // 변수 설정
    var url = arg._sUrl;
    var option = Object.assign({}, arg._oOption, {
        method: arg._sMethod,
        headers: arg._oHeader
    });
    var timeout = (arg._nTimeout ? arg._nTimeout : 60) * 1000; // requestTr과 시간 단위를 맞춤
    var retries = arg._nRetries;

    // Body 메시지 처리
    if (arg._oBody) {
        // Get 처리
        if (option.method.toLocaleUpperCase() === "GET") {
            url += "?" + new URLSearchParams(arg._oBody || {}).toString();
        }
        // 그 외 method 처리
        else {
            option.body = new URLSearchParams(arg._oBody || {}).toString();
        }
    }

    // Http.fetch 요청
    bizMOBWebCore.Http.fetch(url, option, timeout, retries)
        .then(function (res) {
            arg._fCallback && arg._fCallback(res);
        })
        .catch(function (res) {
            arg._fCallback && arg._fCallback(res);
        });
};

/**
 * Mock
 * @param {String} sClassName
 * @param {String} sMethod
 * @param {Object} oMessage
 */
bizMOBWebCore.Http.requestMock = function (sClassName, sMethod, oMessage) {
    var call = oMessage._fCallback || oMessage.callback || null;
    var baseUrl = bizMOBWebCore.Network.config._sBaseUrl;
    var className = sClassName === "PushManager" ? "Push" : sClassName;
    var url = "";
    var option = {
        method: "GET"
    };

    switch (sMethod) {
        case "executer": // callPlugin
            url = baseUrl + "mock/bizMOB/callPlugin/" + oMessage._sID + "/" + sMethod + ".json?param=" + JSON.stringify(oMessage._oParam);
            break;

        case "requestTr":
        case "requestLogin":
            url = baseUrl + "mock/" + oMessage._sTrcode + ".json?param=" + JSON.stringify(oMessage);
            break;

        case "requestTimeout": // setTimeout
            url = baseUrl + "mock/bizMOB/" + className + "/setTimeout.json?param=" + JSON.stringify(oMessage._oParam);
            break;

        default:
            url = baseUrl + "mock/bizMOB/" + className + "/" + sMethod + ".json?param=" + JSON.stringify(oMessage);
            break;
    }

    bizMOBWebCore.Http.fetch(url, option)
        .then(function (res) {
            bizMOBWebCore.Module.logger({ _sService: className, _sAction: sMethod, _sLogType: "D", _sMessage: " mock response." });
            call && call(res.data);
        })
        .catch(function () {
            bizMOBWebCore.Module.logger({ _sService: className, _sAction: sMethod, _sLogType: "E", _sMessage: className + " " + sMethod + " mock not found." });
            call && call({ result: false, type: "mock" });
        });
};

/**
 * timeout + retries + fetch
 * @param {string} url
 * @param {object} opt
 * @param {number} limitTime
 * @param {number} retries
 *
 * @return
 * @param {boolean} ok
 * @param {number} status
 * @param {string} statusText
 * @param {object} data
 */
bizMOBWebCore.Http.fetch = function (url, opt, limitTime, retries) {
    var option = opt; // fetch option
    var limit = limitTime || 60 * 1000; // timeout
    var retry = retries || 1;

    // Fetch
    var attemptFetch = function (url, opt) {
        return new Promise(function (resolve, reject) {
            fetch(url, opt).then(function (res) {
                if (res.ok) {
                    resolve(res.json());
                } else {
                    reject(res);
                }
            });
        });
    };

    // Timeout
    var timeout = function (timeout) {
        return new Promise(function (_, reject) {
            setTimeout(function () {
                reject(new Error("timeout error"));
            }, timeout);
        });
    };

    // Promise Return
    return new Promise(function (resolve, reject) {
        var attempts = 1;
        var executeFetch = function () {
            var fetchAttempt = Promise.race([attemptFetch(url, option), timeout(limit)]);
            var maxRetry = retry;

            // Fetch
            fetchAttempt
                .then(function (data) {
                    resolve({ ok: true, status: 200, statusText: "OK", data: data });
                })
                .catch(function (res) {
                    if (attempts < maxRetry) {
                        attempts++;
                        executeFetch();
                    } else {
                        reject({
                            ok: res.ok,
                            status: res.status,
                            statusText: res.statusText,
                            data: null
                        });
                    }
                });
        };

        executeFetch();
    });
};
