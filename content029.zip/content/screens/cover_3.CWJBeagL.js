const s="/assets/cover_3.D3bmhT1x.jpg";export{s as C};
