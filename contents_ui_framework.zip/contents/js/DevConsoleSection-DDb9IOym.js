import{P as n}from"./AccountCardSection-DXixqG3L.js";import{d,o as u,j as g,l as e,a as s,w as l,A as t,u as r,L as m,F as f}from"../vendors/vendor-ah_eQdvw.js";const v={class:"component-section"},y={style:{"margin-top":"32px"}},b={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"16px","align-items":"center","justify-content":"center",height:"200px"}},x={style:{display:"flex",gap:"12px","flex-wrap":"wrap","justify-content":"center"}},C=d({__name:"DevConsoleSection",setup(h){const i=()=>{console.info("User clicked the info button.")},a=()=>{console.log("Sending data to server:",{userId:123,status:"active",timestamp:new Date().toISOString()})},c=()=>{console.warn("Network request is taking longer than expected.")},p=()=>{console.error("Failed to parse JSON response.",new Error("Unexpected token u in JSON at position 0"))};return(P,o)=>(u(),g(f,null,[e("div",v,[o[6]||(o[6]=e("h2",null,"Developer Console (vConsole)",-1)),o[7]||(o[7]=e("p",null,"A floating, in-app developer console that intercepts `console.log`, `console.error`, and other output methods. Extremely useful for debugging on mobile devices where standard DevTools are not accessible.",-1)),e("div",y,[e("div",b,[o[4]||(o[4]=e("p",{style:{color:"#64748b","font-size":"14px","text-align":"center"}},"Click these buttons to generate console logs.",-1)),e("div",x,[s(r(n),{onClick:i},{default:l(()=>[...o[0]||(o[0]=[t("console.info()",-1)])]),_:1}),s(r(n),{variant:"outline",color:"primary",onClick:a},{default:l(()=>[...o[1]||(o[1]=[t("console.log(Object)",-1)])]),_:1}),s(r(n),{color:"warning",onClick:c},{default:l(()=>[...o[2]||(o[2]=[t("console.warn()",-1)])]),_:1}),s(r(n),{color:"danger",onClick:p},{default:l(()=>[...o[3]||(o[3]=[t("console.error()",-1)])]),_:1})]),o[5]||(o[5]=e("p",{style:{color:"#64748b","font-size":"13px","margin-top":"8px"}},[t("Look at the bottom right of the screen for the "),e("b",null,"vConsole"),t(" toggle button!")],-1))])]),o[8]||(o[8]=m(`<div style="margin-top:40px;"><h3>Usage Example</h3><p>Simply drop the \`PPConsole\` component into your main layout (like \`App.vue\` or your global shell component). It will automatically intercept all console output and render a floating toggle button on the screen.</p><pre class="code-block" style="background:#f8fafc;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;!-- Your app content --&gt;
  &lt;router-view /&gt;

  &lt;!-- Place this once in your App.vue (maybe wrap in a v-if=&quot;isDev&quot; to hide in prod) --&gt;
  &lt;PPConsole /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPConsole } from &#39;@phanna/ui-framework&#39;;
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),o[9]||(o[9]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Developer Console (vConsole)</h2>
    <p>A floating, in-app developer console that intercepts \`console.log\`, \`console.error\`, and other output methods. Extremely useful for debugging on mobile devices where standard DevTools are not accessible.</p>

    <div style="margin-top: 32px;">
      <div class="demo-box" style="display: flex; flex-direction: column; gap: 16px; align-items: center; justify-content: center; height: 200px;">
        <p style="color: #64748b; font-size: 14px; text-align: center;">Click these buttons to generate console logs.</p>
        <div style="display: flex; gap: 12px; flex-wrap: wrap; justify-content: center;">
          <PPButton @click="logInfo">console.info()</PPButton>
          <PPButton variant="outline" color="primary" @click="logData">console.log(Object)</PPButton>
          <PPButton color="warning" @click="logWarning">console.warn()</PPButton>
          <PPButton color="danger" @click="logError">console.error()</PPButton>
        </div>
        <p style="color: #64748b; font-size: 13px; margin-top: 8px;">Look at the bottom right of the screen for the <b>vConsole</b> toggle button!</p>
      </div>
    </div>

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <p>Simply drop the \`PPConsole\` component into your main layout (like \`App.vue\` or your global shell component). It will automatically intercept all console output and render a floating toggle button on the screen.</p>
      
      <pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;!-- Your app content --&gt;
  &lt;router-view /&gt;

  &lt;!-- Place this once in your App.vue (maybe wrap in a v-if="isDev" to hide in prod) --&gt;
  &lt;PPConsole /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPConsole } from '@phanna/ui-framework';
&lt;/script&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPButton } from '@phanna/ui-framework';

const logInfo = () => {
  console.info('User clicked the info button.');
};

const logData = () => {
  console.log('Sending data to server:', {
    userId: 123,
    status: 'active',
    timestamp: new Date().toISOString()
  });
};

const logWarning = () => {
  console.warn('Network request is taking longer than expected.');
};

const logError = () => {
  console.error('Failed to parse JSON response.', new Error('Unexpected token u in JSON at position 0'));
};
<\/script>
`)])],-1))],64))}});export{C as _};
