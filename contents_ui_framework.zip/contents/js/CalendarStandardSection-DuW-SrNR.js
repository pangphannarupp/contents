import{v as c,P as p,y as m,M as v}from"./AccountCardSection-DXixqG3L.js";import{d as f,o as S,j as C,l as t,A as a,a as l,u as n,w as P,F as b,p as g}from"../vendors/vendor-ah_eQdvw.js";const h={class:"guide-section"},k={class:"variant-group"},D={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},x={class:"variant-group"},y={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},w={class:"variant-group"},I={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},O={class:"variant-group"},B={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},L={class:"variant-group"},M={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},A={class:"variant-group"},R={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},K=f({__name:"CalendarStandardSection",setup(T){const r=g(!1),s=g(!1),d=u=>console.log("Setup: "+u);return(u,e)=>(S(),C(b,null,[t("div",h,[e[32]||(e[32]=t("h2",null,"12. Standard Calendar",-1)),t("div",k,[e[12]||(e[12]=t("h3",null,"Standard Selection",-1)),e[13]||(e[13]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),a(),t("code",null,"config={ selectionMode: 'Single' }"),a(" (default)")],-1)),t("div",D,[l(n(c),{onDateSelected:e[0]||(e[0]=o=>d("Selected Date: "+o.date.toLocaleDateString()))})]),e[14]||(e[14]=t("pre",{class:"code-block"},[t("code",null,'<PPCalendar @date-selected="onSelect" />')],-1))]),t("div",x,[e[15]||(e[15]=t("h3",null,"Range Selection & Limits",-1)),e[16]||(e[16]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),a(),t("code",null,"config={ selectionMode: 'Range', minDate: ..., maxDate: ... }")],-1)),t("div",y,[l(n(c),{config:{selectionMode:"Range",minDate:new Date(new Date().getFullYear(),new Date().getMonth(),1),maxDate:new Date(new Date().getFullYear(),new Date().getMonth()+1,0)},onRangeSelected:e[1]||(e[1]=(o,i)=>d("Range: "+(o?o.date.toLocaleDateString():"")+" to "+(i?i.date.toLocaleDateString():"")))},null,8,["config"])]),e[17]||(e[17]=t("pre",{class:"code-block"},[t("code",null,`<PPCalendar :config="{ selectionMode: 'Range', minDate, maxDate }" />`)],-1))]),t("div",w,[e[18]||(e[18]=t("h3",null,"Week Selection",-1)),e[19]||(e[19]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),a(),t("code",null,"config={ selectionMode: 'Week' }")],-1)),t("div",I,[l(n(c),{config:{selectionMode:"Week"},onRangeSelected:e[2]||(e[2]=(o,i)=>d("Week: "+(o?o.date.toLocaleDateString():"")+" to "+(i?i.date.toLocaleDateString():"")))})]),e[20]||(e[20]=t("pre",{class:"code-block"},[t("code",null,`<PPCalendar :config="{ selectionMode: 'Week' }" />`)],-1))]),t("div",O,[e[21]||(e[21]=t("h3",null,"Hide Header Controls",-1)),e[22]||(e[22]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),a(),t("code",null,"hideHeaderPicker"),a(", "),t("code",null,"hideNavButtons")],-1)),t("div",B,[l(n(c),{"hide-header-picker":!0,"hide-nav-buttons":!0,onDateSelected:e[3]||(e[3]=o=>d("Selected Date: "+o.date.toLocaleDateString()))})]),e[23]||(e[23]=t("pre",{class:"code-block"},[t("code",null,'<PPCalendar :hide-header-picker="true" :hide-nav-buttons="true" />')],-1))]),t("div",L,[e[25]||(e[25]=t("h3",null,"Calendar Bottom Sheet",-1)),e[26]||(e[26]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),a(),t("code",null,"<PPCalendarSheet>")],-1)),t("div",M,[l(n(p),{onClick:e[4]||(e[4]=o=>r.value=!0)},{default:P(()=>[...e[24]||(e[24]=[a("Open Calendar Sheet",-1)])]),_:1}),l(n(m),{modelValue:r.value,"onUpdate:modelValue":e[5]||(e[5]=o=>r.value=o),title:"Select a Date",showActionButtons:!0,onConfirm:e[6]||(e[6]=o=>{d("Confirmed: "+(o?o.date.toLocaleDateString():"")),r.value=!1}),onCancel:e[7]||(e[7]=o=>r.value=!1)},null,8,["modelValue"])]),e[27]||(e[27]=t("pre",{class:"code-block"},[t("code",null,'<PPCalendarSheet v-model="isOpen" />')],-1))]),t("div",A,[e[29]||(e[29]=t("h3",null,"Calendar Island Popup",-1)),e[30]||(e[30]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),a(),t("code",null,"<PPCalendarIsland>")],-1)),t("div",R,[l(n(p),{onClick:e[8]||(e[8]=o=>s.value=!0)},{default:P(()=>[...e[28]||(e[28]=[a("Open Calendar Island",-1)])]),_:1}),l(n(v),{modelValue:s.value,"onUpdate:modelValue":e[9]||(e[9]=o=>s.value=o),title:"Select a Date",showActionButtons:!0,onConfirm:e[10]||(e[10]=o=>{d("Confirmed: "+(o?o.date.toLocaleDateString():"")),s.value=!1}),onCancel:e[11]||(e[11]=o=>s.value=!1)},null,8,["modelValue"])]),e[31]||(e[31]=t("pre",{class:"code-block"},[t("code",null,'<PPCalendarIsland v-model="isOpen" />')],-1))]),e[33]||(e[33]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-special-color: /* value */;
  --pp-calendar-subtitle-color: /* value */;
  --pp-calendar-subtitle-text: /* value */;
  --pp-calendar-sunday-color: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-danger-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[34]||(e[34]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>12. Standard Calendar</h2>

        <div class="variant-group">
          <h3>Standard Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Single' }</code> (default)</p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPCalendar 
              @date-selected="s => alertVal('Selected Date: ' + s.date.toLocaleDateString())"
            />
          </div>
          <pre class="code-block"><code>&lt;PPCalendar @date-selected="onSelect" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Range Selection & Limits</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Range', minDate: ..., maxDate: ... }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPCalendar 
              :config="{ 
                selectionMode: 'Range', 
                minDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1), 
                maxDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0) 
              }"
              @range-selected="(start, end) => alertVal('Range: ' + (start ? start.date.toLocaleDateString() : '') + ' to ' + (end ? end.date.toLocaleDateString() : ''))"
            />
          </div>
          <pre class="code-block"><code>&lt;PPCalendar :config="{ selectionMode: 'Range', minDate, maxDate }" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Week Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Week' }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPCalendar 
              :config="{ selectionMode: 'Week' }"
              @range-selected="(start, end) => alertVal('Week: ' + (start ? start.date.toLocaleDateString() : '') + ' to ' + (end ? end.date.toLocaleDateString() : ''))"
            />
          </div>
          <pre class="code-block"><code>&lt;PPCalendar :config="{ selectionMode: 'Week' }" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Hide Header Controls</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>hideHeaderPicker</code>, <code>hideNavButtons</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPCalendar 
              :hide-header-picker="true"
              :hide-nav-buttons="true"
              @date-selected="s => alertVal('Selected Date: ' + s.date.toLocaleDateString())"
            />
          </div>
          <pre class="code-block"><code>&lt;PPCalendar :hide-header-picker="true" :hide-nav-buttons="true" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Calendar Bottom Sheet</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPCalendarSheet&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showStdCalendarSheet = true">Open Calendar Sheet</PPButton>
            <PPCalendarSheet 
              v-model="showStdCalendarSheet"
              title="Select a Date"
              :showActionButtons="true"
              @confirm="(d) => { alertVal('Confirmed: ' + (d ? d.date.toLocaleDateString() : '')); showStdCalendarSheet = false; }"
              @cancel="showStdCalendarSheet = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPCalendarSheet v-model="isOpen" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Calendar Island Popup</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPCalendarIsland&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showStdCalendarIsland = true">Open Calendar Island</PPButton>
            <PPCalendarIsland 
              v-model="showStdCalendarIsland"
              title="Select a Date"
              :showActionButtons="true"
              @confirm="(d) => { alertVal('Confirmed: ' + (d ? d.date.toLocaleDateString() : '')); showStdCalendarIsland = false; }"
              @cancel="showStdCalendarIsland = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPCalendarIsland v-model="isOpen" /&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-special-color: /* value */;
  --pp-calendar-subtitle-color: /* value */;
  --pp-calendar-subtitle-text: /* value */;
  --pp-calendar-sunday-color: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-danger-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const showStdCalendarSheet = ref(false);

const showStdCalendarIsland = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{K as _};
