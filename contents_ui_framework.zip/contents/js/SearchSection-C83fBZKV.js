import{a2 as u}from"./AccountCardSection-DXixqG3L.js";import{d as F,q as T,o as p,j as m,l as t,a as h,u as y,A as b,y as a,k as w,w as B,L as N,F as D,p as r,m as C}from"../vendors/vendor-ah_eQdvw.js";import{_ as J}from"./App-D7rwXoHs.js";const U={class:"component-section"},j={class:"demo-grid",style:{display:"flex",gap:"24px","flex-wrap":"wrap"}},E={class:"demo-box",style:{flex:"1","min-width":"300px"}},O={key:0,style:{"margin-top":"16px","font-size":"14px",color:"#003399"}},_={class:"demo-box",style:{flex:"1","min-width":"300px"}},Y={style:{display:"flex","align-items":"center",gap:"12px",width:"100%"}},G={style:{width:"32px",height:"32px",background:"#e2e8f0","border-radius":"50%",display:"flex","align-items":"center","justify-content":"center","font-weight":"bold",color:"#64748b"}},K={style:{display:"flex","flex-direction":"column"}},M={style:{"font-size":"15px",color:"#1e293b"}},Q={style:{"font-size":"12px",color:"#94a3b8"}},W={class:"demo-box",style:{flex:"1","min-width":"300px"}},X={key:0,style:{"margin-top":"16px","font-size":"14px",color:"#003399"}},Z={class:"demo-box",style:{flex:"1","min-width":"300px"}},$={key:0,style:{"margin-top":"16px","font-size":"14px",color:"#003399"}},ee=F({__name:"SearchSection",setup(te){const i=r(""),v=r(""),l=r(["Vue Components","Ionic Framework","Vite Plugin"]),q=["Vue Components","Vue Router","Vuex","Pinia","Vite","Vitest","Ionic Framework","Capacitor"],V=C(()=>{if(!i.value)return[];const o=i.value.toLowerCase();return q.filter(e=>e.toLowerCase().includes(o))}),H=o=>{const e=typeof o=="object"?o.label:o;v.value=e,l.value.includes(e)||(l.value.unshift(e),l.value.length>5&&l.value.pop())},P=()=>{l.value=[]},k=({index:o})=>{l.value.splice(o,1)},f=r(""),n=r(!1),g=r([]),R=[{label:"Alice Smith",role:"Admin",id:1},{label:"Bob Johnson",role:"Editor",id:2},{label:"Charlie Brown",role:"Viewer",id:3},{label:"Diana Prince",role:"Admin",id:4}];let x;T(f,o=>{if(x&&clearTimeout(x),!o){g.value=[],n.value=!1;return}n.value=!0,x=setTimeout(()=>{const e=o.toLowerCase();g.value=R.filter(s=>s.label.toLowerCase().includes(e)||s.role.toLowerCase().includes(e)),n.value=!1},800)});const L=o=>{console.log("Selected user:",o)},c=r(""),S=r(""),A=C(()=>{if(!c.value)return[];const o=c.value.toLowerCase();return["Vue","React","Angular","Svelte","SolidJS","AlpineJS"].filter(e=>e.toLowerCase().includes(o))}),z=o=>{S.value=o},d=r(""),I=o=>{console.log("Search triggered with:",o)};return(o,e)=>(p(),m(D,null,[t("div",U,[e[15]||(e[15]=t("h2",null,"Search Component",-1)),e[16]||(e[16]=t("p",null,"A comprehensive search component that supports real-time results and search history.",-1)),t("div",j,[t("div",E,[e[5]||(e[5]=t("h3",null,"Search with History",-1)),e[6]||(e[6]=t("p",{style:{"font-size":"14px",color:"#666","margin-bottom":"16px"}},'Try typing "vue" or focusing to see history.',-1)),h(y(u),{modelValue:i.value,"onUpdate:modelValue":e[0]||(e[0]=s=>i.value=s),results:V.value,history:l.value,onSearch:H,onClearHistory:P,onRemoveHistoryItem:k},null,8,["modelValue","results","history"]),v.value?(p(),m("div",O,[e[4]||(e[4]=b(" Last searched: ",-1)),t("strong",null,a(v.value),1)])):w("",!0)]),t("div",_,[e[7]||(e[7]=t("h3",null,"Simulated API Search",-1)),e[8]||(e[8]=t("p",{style:{"font-size":"14px",color:"#666","margin-bottom":"16px"}},"Types something to trigger loading state.",-1)),h(y(u),{modelValue:f.value,"onUpdate:modelValue":e[1]||(e[1]=s=>f.value=s),results:g.value,loading:n.value,placeholder:"Search users...",onSearch:L},{result:B(({item:s})=>[t("div",Y,[t("div",G,a(s.label.charAt(0)),1),t("div",K,[t("span",M,a(s.label),1),t("span",Q,a(s.role),1)])])]),_:1},8,["modelValue","results","loading"])]),t("div",W,[e[10]||(e[10]=t("h3",null,"Filter List",-1)),e[11]||(e[11]=t("p",{style:{"font-size":"14px",color:"#666","margin-bottom":"16px"}},"Search with results but no history state.",-1)),h(y(u),{modelValue:c.value,"onUpdate:modelValue":e[2]||(e[2]=s=>c.value=s),results:A.value,placeholder:"Filter framework...",onSearch:z},null,8,["modelValue","results"]),S.value?(p(),m("div",X,[e[9]||(e[9]=b(" Selected: ",-1)),t("strong",null,a(S.value),1)])):w("",!0)]),t("div",Z,[e[13]||(e[13]=t("h3",null,"Simple Search Input",-1)),e[14]||(e[14]=t("p",{style:{"font-size":"14px",color:"#666","margin-bottom":"16px"}},"Just the styled input, no dropdown menu.",-1)),h(y(u),{modelValue:d.value,"onUpdate:modelValue":e[3]||(e[3]=s=>d.value=s),placeholder:"Type to search...",onSearch:I},null,8,["modelValue"]),d.value?(p(),m("div",$,[e[12]||(e[12]=b(" Current query: ",-1)),t("strong",null,a(d.value),1)])):w("",!0)])]),e[17]||(e[17]=N(`<div style="margin-top:40px;" data-v-eded9b1e><h3 data-v-eded9b1e>Usage Example</h3><pre class="code-block" data-v-eded9b1e><code data-v-eded9b1e>&lt;template&gt;
  &lt;PPSearch
    v-model=&quot;query&quot;
    :results=&quot;searchResults&quot;
    :history=&quot;searchHistory&quot;
    @search=&quot;onSearch&quot;
    @clear-history=&quot;onClearHistory&quot;
  /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from &#39;vue&#39;;
import { PPSearch } from &#39;@phanna/ui-framework&#39;;

const query = ref(&#39;&#39;);
const searchHistory = ref([&#39;React&#39;, &#39;Vue&#39;, &#39;Angular&#39;]);
const searchResults = ref([
  { label: &#39;Vue 3 Framework&#39;, id: 1 },
  { label: &#39;React Native&#39;, id: 2 }
]);

const onSearch = (item) =&gt; {
  const term = typeof item === &#39;object&#39; ? item.label : item;
  if (!searchHistory.value.includes(term)) {
    searchHistory.value.unshift(term);
  }
};

const onClearHistory = () =&gt; {
  searchHistory.value = [];
};
&lt;/script&gt;</code></pre></div><div class="variant-group" data-v-eded9b1e><h3 data-v-eded9b1e>Customizing CSS</h3><p class="custom-guide" data-v-eded9b1e>You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block" data-v-eded9b1e><code data-v-eded9b1e>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[18]||(e[18]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Search Component</h2>
    <p>A comprehensive search component that supports real-time results and search history.</p>

    <div class="demo-grid" style="display: flex; gap: 24px; flex-wrap: wrap;">
      
      <!-- Basic Search -->
      <div class="demo-box" style="flex: 1; min-width: 300px;">
        <h3>Search with History</h3>
        <p style="font-size: 14px; color: #666; margin-bottom: 16px;">Try typing "vue" or focusing to see history.</p>
        <PPSearch
          v-model="query1"
          :results="filteredResults1"
          :history="searchHistory"
          @search="handleSearch1"
          @clear-history="clearHistory"
          @remove-history-item="removeHistoryItem"
        />
        
        <div v-if="lastSearch1" style="margin-top: 16px; font-size: 14px; color: #003399;">
          Last searched: <strong>{{ lastSearch1 }}</strong>
        </div>
      </div>

      <!-- Loading State -->
      <div class="demo-box" style="flex: 1; min-width: 300px;">
        <h3>Simulated API Search</h3>
        <p style="font-size: 14px; color: #666; margin-bottom: 16px;">Types something to trigger loading state.</p>
        <PPSearch
          v-model="query2"
          :results="filteredResults2"
          :loading="isLoading"
          placeholder="Search users..."
          @search="handleSearch2"
        >
          <!-- Custom Result Template -->
          <template #result="{ item }">
            <div style="display: flex; align-items: center; gap: 12px; width: 100%;">
              <div style="width: 32px; height: 32px; background: #e2e8f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #64748b;">
                {{ item.label.charAt(0) }}
              </div>
              <div style="display: flex; flex-direction: column;">
                <span style="font-size: 15px; color: #1e293b;">{{ item.label }}</span>
                <span style="font-size: 12px; color: #94a3b8;">{{ item.role }}</span>
              </div>
            </div>
          </template>
        </PPSearch>
      </div>


      <!-- Basic Filter Search (No History) -->
      <div class="demo-box" style="flex: 1; min-width: 300px;">
        <h3>Filter List</h3>
        <p style="font-size: 14px; color: #666; margin-bottom: 16px;">Search with results but no history state.</p>
        <PPSearch
          v-model="query3"
          :results="filteredResults3"
          placeholder="Filter framework..."
          @search="handleSearch3"
        />
        <div style="margin-top: 16px; font-size: 14px; color: #003399;" v-if="lastSearch3">
          Selected: <strong>{{ lastSearch3 }}</strong>
        </div>
      </div>

      <!-- Simple Search Input (No Dropdown) -->
      <div class="demo-box" style="flex: 1; min-width: 300px;">
        <h3>Simple Search Input</h3>
        <p style="font-size: 14px; color: #666; margin-bottom: 16px;">Just the styled input, no dropdown menu.</p>
        <PPSearch
          v-model="query4"
          placeholder="Type to search..."
          @search="handleSearch4"
        />
        <div style="margin-top: 16px; font-size: 14px; color: #003399;" v-if="query4">
          Current query: <strong>{{ query4 }}</strong>
        </div>
      </div>

    </div>

    <!-- Code Example -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block"><code>&lt;template&gt;
  &lt;PPSearch
    v-model="query"
    :results="searchResults"
    :history="searchHistory"
    @search="onSearch"
    @clear-history="onClearHistory"
  /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPSearch } from '@phanna/ui-framework';

const query = ref('');
const searchHistory = ref(['React', 'Vue', 'Angular']);
const searchResults = ref([
  { label: 'Vue 3 Framework', id: 1 },
  { label: 'React Native', id: 2 }
]);

const onSearch = (item) => {
  const term = typeof item === 'object' ? item.label : item;
  if (!searchHistory.value.includes(term)) {
    searchHistory.value.unshift(term);
  }
};

const onClearHistory = () => {
  searchHistory.value = [];
};
&lt;/script&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue';
import { PPSearch } from '@phanna/ui-framework';

// Demo 1 State
const query1 = ref('');
const lastSearch1 = ref('');
const searchHistory = ref(['Vue Components', 'Ionic Framework', 'Vite Plugin']);
const allResults = [
  'Vue Components',
  'Vue Router',
  'Vuex',
  'Pinia',
  'Vite',
  'Vitest',
  'Ionic Framework',
  'Capacitor',
];

const filteredResults1 = computed(() => {
  if (!query1.value) return [];
  const q = query1.value.toLowerCase();
  return allResults.filter(r => r.toLowerCase().includes(q));
});

const handleSearch1 = (item: any) => {
  const term = typeof item === 'object' ? item.label : item;
  lastSearch1.value = term;
  
  if (!searchHistory.value.includes(term)) {
    searchHistory.value.unshift(term);
    if (searchHistory.value.length > 5) searchHistory.value.pop();
  }
};

const clearHistory = () => {
  searchHistory.value = [];
};

const removeHistoryItem = ({ index }: { index: number }) => {
  searchHistory.value.splice(index, 1);
};

// Demo 2 State
const query2 = ref('');
const isLoading = ref(false);
const filteredResults2 = ref<any[]>([]);

const users = [
  { label: 'Alice Smith', role: 'Admin', id: 1 },
  { label: 'Bob Johnson', role: 'Editor', id: 2 },
  { label: 'Charlie Brown', role: 'Viewer', id: 3 },
  { label: 'Diana Prince', role: 'Admin', id: 4 },
];

let timeoutId: any;
watch(query2, (newVal) => {
  if (timeoutId) clearTimeout(timeoutId);
  if (!newVal) {
    filteredResults2.value = [];
    isLoading.value = false;
    return;
  }
  
  isLoading.value = true;
  timeoutId = setTimeout(() => {
    const q = newVal.toLowerCase();
    filteredResults2.value = users.filter(u => u.label.toLowerCase().includes(q) || u.role.toLowerCase().includes(q));
    isLoading.value = false;
  }, 800);
});

const handleSearch2 = (item: any) => {
  console.log('Selected user:', item);
};

// Demo 3 State
const query3 = ref('');
const lastSearch3 = ref('');
const filteredResults3 = computed(() => {
  if (!query3.value) return [];
  const q = query3.value.toLowerCase();
  return ['Vue', 'React', 'Angular', 'Svelte', 'SolidJS', 'AlpineJS'].filter(r => r.toLowerCase().includes(q));
});
const handleSearch3 = (item: any) => {
  lastSearch3.value = item;
};

// Demo 4 State
const query4 = ref('');
const handleSearch4 = (val: string) => {
  console.log('Search triggered with:', val);
};
<\/script>

<style scoped>
.demo-box {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 24px;
}
.code-block {
  background: #f8fafc;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
}
</style>
`)])],-1))],64))}}),le=J(ee,[["__scopeId","data-v-eded9b1e"]]);export{le as S};
