import{bj as a}from"./AccountCardSection-DXixqG3L.js";import{d as P,o as i,j as s,l as e,a as n,u as l,y as c,F as u,p as d}from"../vendors/vendor-ah_eQdvw.js";const m={class:"guide-section"},p={class:"variant-group"},g={class:"component-demo"},h={style:{"margin-top":"10px"}},y=P({__name:"RatingSection",setup(v){const o=d(3);return(C,t)=>(i(),s(u,null,[e("div",m,[t[4]||(t[4]=e("h2",null,"Rating",-1)),e("div",p,[t[2]||(t[2]=e("h3",null,"Interactive & Readonly Rating",-1)),e("div",g,[n(l(a),{modelValue:o.value,"onUpdate:modelValue":t[0]||(t[0]=r=>o.value=r),max:5},null,8,["modelValue"]),e("p",h,"Rating: "+c(o.value),1),t[1]||(t[1]=e("br",null,null,-1)),n(l(a),{modelValue:4,max:5,readonly:""})]),t[3]||(t[3]=e("pre",{class:"code-block"},[e("code",null,`<template>
  <PPRating v-model="ratingVal" :max="5" />
  
  <!-- Readonly Mode -->
  <PPRating :modelValue="4" :max="5" readonly />
</template>

<script setup>
import { ref } from 'vue';
const ratingVal = ref(3);
<\/script>`)],-1))]),t[5]||(t[5]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[6]||(t[6]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Rating</h2>
        <div class="variant-group">
          <h3>Interactive & Readonly Rating</h3>
          <div class="component-demo">
            <PPRating v-model="ratingVal" :max="5" />
            <p style="margin-top: 10px;">Rating: {{ ratingVal }}</p>
            <br>
            <PPRating :modelValue="4" :max="5" readonly />
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPRating v-model="ratingVal" :max="5" /&gt;
  
  &lt;!-- Readonly Mode --&gt;
  &lt;PPRating :modelValue="4" :max="5" readonly /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
const ratingVal = ref(3);
&lt;/script&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const ratingVal = ref(3);



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{y as _};
