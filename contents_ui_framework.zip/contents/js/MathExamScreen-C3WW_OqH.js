import{aX as m,aY as c}from"./AccountCardSection-DXixqG3L.js";import{d as l,o as i,j as x,l as t,A as r,a as s,u as n,p as d}from"../vendors/vendor-ah_eQdvw.js";import{_ as f}from"./App-D7rwXoHs.js";const u={class:"component-section"},p={class:"demo-box template-demo"},_={class:"exam-scratchpad"},q={class:"exam-paper"},g=l({__name:"MathExamScreen",setup(v){const a=d(`
\\begin{array}{l}
\\text{\\Large ប្រឡងជ្រើសរើសសិស្សពូកែ គណិតវិទ្យា រូបវិទ្យានិង} \\\\[0.2em]
\\text{\\Large អក្សរសិល្ប៍ខ្មែរ ថ្នាក់ទី៩ និងទី១២ ប្រចាំរាជធានីភ្នំពេញ} \\\\[1em]
\\text{\\large សម័យប្រឡង ២០ កុម្ភៈ ឆ្នាំ២០២០} \\\\[0.5em]
\\text{\\large វិញ្ញាសាទី១៖ គណិតវិទ្យាទី១២ សម្រាប់ថ្ងៃទី១ (២០-០២-២០)} \\\\[0.5em]
\\text{(រយៈពេល ៣ ម៉ោង)} \\\\[2em]
\\text{១. (៥ពិន្ទុ) រកចំនួនតួចែកវិជ្ជមាននៃចំនួន } A = [2019^3 + 3(2019 \\times 2020) + 1]^2 \\text{ ។} \\\\[1.5em]
\\text{២. (៥ពិន្ទុ) តាង } x = 1 + \\sqrt[3]{2} + \\sqrt[3]{4} + \\sqrt[3]{8} + \\sqrt[3]{16} + \\sqrt[3]{32} \\text{ ។ រកតម្លៃនៃ } B = \\left(1 + \\frac{1}{x}\\right)^{30} \\text{ ។} \\\\[1.5em]
\\text{៣. (១០ពិន្ទុ) តាង } a_1, a_2, a_3, ... \\text{ ជាស្វីតនៃចំនួនពិត ដែល } a_1 = 2 \\text{ និងចំពោះ } n \\geq 1 \\\\[0.5em]
a_{n+1} = \\frac{1+a_n}{1-a_n} \\text{ ។ កំណត់ } a_{2020} \\text{ ។} \\\\[1.5em]
\\text{៤. (១០ពិន្ទុ) រកតម្លៃធំបំផុត និងតម្លៃតូចបំផុតនៃ } y = \\frac{3x^2 + 2x + 2}{x^2 + 2x + 2} \\text{ ។} \\\\[1.5em]
\\text{៥. (១០ពិន្ទុ) រកសមីការដឺក្រេទី២ ដែលមានមេគុណជាចំនួនគត់ ហើយមានឫស} \\\\[0.5em]
\\cos 72^\\circ \\text{ និង } \\cos 144^\\circ \\text{ ។} \\\\[1.5em]
\\text{៦. (១៥ពិន្ទុ) ដោយមិនប្រើម៉ាស៊ីនគិតលេខ គណនា} \\\\[0.5em]
P = \\frac{1}{\\cos^2 10^\\circ} + \\frac{1}{\\sin^2 20^\\circ} + \\frac{1}{\\sin^2 40^\\circ} - \\frac{1}{\\cos^2 45^\\circ} \\\\[1.5em]
\\text{៧. (១៥ពិន្ទុ) ប្រៀបធៀប } S_n = \\sum_{k=1}^{n} \\frac{k}{(2n-2k+1)(2n-k+1)} \\text{ និង } T_n = \\sum_{k=1}^{n} \\frac{1}{k} \\text{ ។} \\\\[1.5em]
\\text{៨. (១៥ពិន្ទុ) ស្រាយបញ្ជាក់ថា } \\sqrt[3]{\\frac{2}{1}} + \\sqrt[3]{\\frac{3}{2}} + ... + \\sqrt[3]{\\frac{1011}{1010}} - \\frac{2019}{2} < \\frac{1}{3} + \\frac{1}{6} + \\frac{1}{9} + ... + \\frac{1}{9096}
\\end{array}
`);return(k,e)=>(i(),x("div",u,[e[3]||(e[3]=t("h2",null,"Math Examination Template",-1)),e[4]||(e[4]=t("p",null,[r("A template for rendering formal mathematical examination papers using "),t("code",null,"PPMathPreview"),r(" for crisp LaTeX rendering.")],-1)),t("div",p,[t("div",_,[e[1]||(e[1]=t("h3",null,"Math Equation Builder",-1)),e[2]||(e[2]=t("p",null,"Use this editor to build and copy LaTeX equations.",-1)),s(n(m),{modelValue:a.value,"onUpdate:modelValue":e[0]||(e[0]=o=>a.value=o)},null,8,["modelValue"])]),t("div",q,[s(n(c),{equation:a.value,displayMode:!0},null,8,["equation"])])])]))}}),V=f(g,[["__scopeId","data-v-47e38991"]]);export{V as M};
