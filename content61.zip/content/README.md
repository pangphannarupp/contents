# puzzle

> Jigsaw Puzzle Game Created Using HTML and jQuery<br>
> Just download the code, unzip it, and run index.html to run.<br>

## Project Address

>[Click here to view the project demonstration](https://miss1.github.io/puzzle/)<br>

>Or use your phone to scan the following QR code<br>
![image](https://github.com/miss1/puzzle/raw/master/screenshot/puzzle.png)

## Screenshot
![image](https://github.com/miss1/puzzle/raw/master/screenshot/screenshot1.png)<br>
