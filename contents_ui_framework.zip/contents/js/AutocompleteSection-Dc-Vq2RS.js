import{u as P}from"./AccountCardSection-DXixqG3L.js";import{d as s,o as u,j as c,l as e,a as p,u as d,F as m,p as n}from"../vendors/vendor-ah_eQdvw.js";const v={class:"guide-section"},g={class:"variant-group"},S={class:"component-demo"},y=s({__name:"AutocompleteSection",setup(C){const l=n(""),r=n([{label:"Cambodia",value:"KH"},{label:"Cameroon",value:"CM"},{label:"Canada",value:"CA"},{label:"United States",value:"US"},{label:"United Kingdom",value:"UK"},{label:"Thailand",value:"TH"},{label:"Vietnam",value:"VN"}]),i=a=>console.log("Setup: "+a);return(a,t)=>(u(),c(m,null,[e("div",v,[t[5]||(t[5]=e("h2",null,"15. Autocomplete",-1)),e("div",g,[t[2]||(t[2]=e("h3",null,"Searchable Dropdown",-1)),t[3]||(t[3]=e("p",{class:"custom-guide"},"Type to filter from a list of predefined options.",-1)),e("div",S,[p(d(P),{modelValue:l.value,"onUpdate:modelValue":t[0]||(t[0]=o=>l.value=o),label:"Select Country",placeholder:"Start typing (e.g., Cam...)",options:r.value,onItemSelect:t[1]||(t[1]=o=>i("Selected "+JSON.stringify(o)))},null,8,["modelValue","options"])]),t[4]||(t[4]=e("pre",{class:"code-block"},[e("code",null,`<PPAutocomplete 
  v-model="value"
  label="Select Country"
  placeholder="Start typing..."
  :options="countryOptions"
/>`)],-1))]),t[6]||(t[6]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[7]||(t[7]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>15. Autocomplete</h2>

        <div class="variant-group">
          <h3>Searchable Dropdown</h3>
          <p class="custom-guide">Type to filter from a list of predefined options.</p>
          <div class="component-demo">
            <PPAutocomplete 
              v-model="autoVal"
              label="Select Country"
              placeholder="Start typing (e.g., Cam...)"
              :options="countryOptions"
              @item-select="val => alertVal('Selected ' + JSON.stringify(val))"
            />
          </div>
          <pre class="code-block"><code>&lt;PPAutocomplete 
  v-model="value"
  label="Select Country"
  placeholder="Start typing..."
  :options="countryOptions"
/></code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const autoVal = ref('');

const countryOptions = ref([
  { label: 'Cambodia', value: 'KH' },
  { label: 'Cameroon', value: 'CM' },
  { label: 'Canada', value: 'CA' },
  { label: 'United States', value: 'US' },
  { label: 'United Kingdom', value: 'UK' },
  { label: 'Thailand', value: 'TH' },
  { label: 'Vietnam', value: 'VN' }
]);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{y as _};
