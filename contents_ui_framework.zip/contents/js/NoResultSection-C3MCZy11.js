import{b5 as s}from"./AccountCardSection-DXixqG3L.js";import{d as n,o as l,j as c,l as e,a as i,u as t,c3 as r,F as a}from"../vendors/vendor-ah_eQdvw.js";import{_ as d}from"./App-D7rwXoHs.js";const u={class:"guide-section"},p={class:"demo-box"},m={style:{"margin-bottom":"24px"}},y={class:"demo-box"},g={style:{"margin-bottom":"24px"}},v=n({__name:"NoResultSection",setup(b){return(f,o)=>(l(),c(a,null,[e("div",u,[o[2]||(o[2]=e("h2",null,"No Result",-1)),o[3]||(o[3]=e("p",null,"An empty state component to display when a search or filter yields no results.",-1)),o[4]||(o[4]=e("h3",null,"Basic Usage",-1)),e("div",p,[e("div",m,[i(t(s),{title:"No matches found",description:"Try changing your search or filter."})]),o[0]||(o[0]=e("pre",{class:"code-block",style:{margin:"0"}},[e("code",null,`<PPNoResult 
  title="No matches found" 
  description="Try changing your search or filter."
/>`)],-1))]),o[5]||(o[5]=e("h3",{style:{"margin-top":"32px"}},"Custom Icon",-1)),e("div",y,[e("div",g,[i(t(s),{title:"No connectivity",subtitle:"Please check your internet connection.",icon:t(r)},null,8,["icon"])]),o[1]||(o[1]=e("pre",{class:"code-block",style:{margin:"0"}},[e("code",null,`<PPNoResult 
  title="No connectivity" 
  subtitle="Please check your internet connection."
  :icon="wifiOutline"
/>`)],-1))]),o[6]||(o[6]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[7]||(o[7]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>No Result</h2>
    <p>An empty state component to display when a search or filter yields no results.</p>

    <h3>Basic Usage</h3>
    <div class="demo-box">
      <div style="margin-bottom: 24px;">
        <PPNoResult 
          title="No matches found" 
          description="Try changing your search or filter."
        />
      </div>
      <pre class="code-block" style="margin: 0;"><code>&lt;PPNoResult 
  title="No matches found" 
  description="Try changing your search or filter."
/&gt;</code></pre>
    </div>

    <h3 style="margin-top: 32px;">Custom Icon</h3>
    <div class="demo-box">
      <div style="margin-bottom: 24px;">
        <PPNoResult 
          title="No connectivity" 
          subtitle="Please check your internet connection."
          :icon="wifiOutline"
        />
      </div>
      <pre class="code-block" style="margin: 0;"><code>&lt;PPNoResult 
  title="No connectivity" 
  subtitle="Please check your internet connection."
  :icon="wifiOutline"
/&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPNoResult } from '@phanna/ui-framework';
import { wifiOutline } from 'ionicons/icons';
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),P=d(v,[["__scopeId","data-v-d6ad4d4e"]]);export{P as N};
