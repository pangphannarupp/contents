import{a,a6 as p}from"./AccountCardSection-DXixqG3L.js";import{d as h,o as n,j as s,l as t,a as l,w as o,F as d,z as g,y as c,u as r}from"../vendors/vendor-ah_eQdvw.js";import{_ as u}from"./App-D7rwXoHs.js";const b={class:"guide-section"},x={class:"variant-group"},v={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative"}},f={style:{padding:"24px"}},m={class:"variant-group"},y={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative"}},w={style:{padding:"24px"}},k={class:"variant-group"},P={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative"}},C={style:{padding:"24px"}},B={class:"variant-group"},H={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative"}},S={style:{display:"flex",gap:"4px","align-items":"center"}},T={style:{padding:"24px"}},z={class:"variant-group"},M={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative"}},I={style:{padding:"16px 24px"}},A={class:"variant-group"},D={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative",background:"#f8fafc"}},O={style:{padding:"24px","padding-top":"32px"}},j={class:"variant-group"},q={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative"}},F={style:{padding:"24px"}},V={class:"variant-group"},W={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative",background:"#0f172a"}},L={style:{padding:"24px",color:"#cbd5e1"}},N={class:"variant-group"},G={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative",background:"#f1f5f9"}},R={style:{padding:"0 16px","margin-top":"-32px",position:"relative","z-index":"1"}},$={style:{"margin-top":"24px"}},E={style:{"font-weight":"600",color:"#1e293b"}},K={class:"variant-group"},X={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative",background:"#f8fafc"}},Y={style:{padding:"24px","padding-top":"48px"}},J={class:"variant-group"},Q={class:"component-demo",style:{height:"400px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative"}},U={style:{position:"absolute",bottom:"32px",left:"24px",right:"24px","z-index":"2"}},Z={style:{background:"white","border-radius":"24px",padding:"12px 20px",display:"flex","align-items":"center","box-shadow":"0 4px 12px rgba(0,0,0,0.15)"}},_={viewBox:"0 0 24 24",fill:"none",stroke:"#64748b","stroke-width":"2",width:"20",height:"20",style:{"margin-right":"12px"}},tt={style:{padding:"24px",background:"white","min-height":"400px","border-top-left-radius":"24px","border-top-right-radius":"24px",position:"relative","z-index":"2"}},et=h({__name:"CollapseAppbarSection",setup(ot){return(it,e)=>(n(),s(d,null,[t("div",b,[e[64]||(e[64]=t("h2",null,"Collapsing Appbar",-1)),t("div",x,[e[3]||(e[3]=t("h3",null,"Scroll to Collapse",-1)),e[4]||(e[4]=t("p",{class:"custom-guide"},"A Material Design style collapsing toolbar. Scroll the content below to see it shrink!",-1)),t("div",v,[l(r(p),{title:"Profile",expandedHeight:200,collapsedHeight:56},{background:o(()=>[...e[0]||(e[0]=[t("img",{src:"https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=1000&auto=format&fit=crop",alt:"bg"},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[1]||(e[1]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),profile:o(()=>[...e[2]||(e[2]=[t("img",{src:"https://i.pravatar.cc/150?img=68",alt:"Profile",style:{width:"32px",height:"32px","border-radius":"50%",border:"2px solid white","object-fit":"cover","box-shadow":"0 2px 4px rgba(0,0,0,0.2)"}},null,-1)])]),default:o(()=>[t("div",f,[(n(),s(d,null,g(10,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," Scrollable content block "+c(i)+". Keep scrolling to see the header collapse. ",1)),64))])]),_:1})]),e[5]||(e[5]=t("pre",{class:"code-block"},[t("code",null,`<PPCollapsingToolbar title="Profile" :expandedHeight="200" :collapsedHeight="56">
  <template #background>
    <img src="..." alt="bg" />
  </template>
  <template #start>
    <PPIconButton color="white">
      <!-- Back Icon -->
    </PPIconButton>
  </template>
  <template #profile>
    <img src="..." alt="Profile" class="avatar" />
  </template>
  
  <div class="content">
    <!-- Scrollable content -->
  </div>
</PPCollapsingToolbar>`)],-1))]),t("div",m,[e[8]||(e[8]=t("h3",null,"Standard Header (No Profile)",-1)),e[9]||(e[9]=t("p",{class:"custom-guide"},"Without a profile picture, the title scales and aligns correctly by itself. Here it moves to the center when collapsed.",-1)),t("div",y,[l(r(p),{title:"Dashboard",expandedHeight:200,collapsedHeight:56,centerTitleOnCollapse:""},{background:o(()=>[...e[6]||(e[6]=[t("img",{src:"https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000&auto=format&fit=crop",alt:"bg"},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[7]||(e[7]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),default:o(()=>[t("div",w,[(n(),s(d,null,g(10,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," Scrollable content block "+c(i)+". Keep scrolling to see the header collapse. ",1)),64))])]),_:1})]),e[10]||(e[10]=t("pre",{class:"code-block"},[t("code",null,`<PPCollapsingToolbar title="Dashboard" :expandedHeight="200" :collapsedHeight="56" centerTitleOnCollapse>
  <template #background>
    <img src="..." alt="bg" />
  </template>
  <template #start>
    <PPIconButton color="white">
      <!-- Back Icon -->
    </PPIconButton>
  </template>
  
  <div class="content">
    <!-- Scrollable content -->
  </div>
</PPCollapsingToolbar>`)],-1))]),t("div",k,[e[14]||(e[14]=t("h3",null,"Gradient Background & Icon Profile",-1)),e[15]||(e[15]=t("p",{class:"custom-guide"},"A vibrant gradient background with an icon instead of an image for the profile.",-1)),t("div",P,[l(r(p),{title:"Plugin Details",expandedHeight:200,collapsedHeight:56},{background:o(()=>[...e[11]||(e[11]=[t("div",{style:{width:"100%",height:"100%",background:"linear-gradient(135deg, #ff4081 0%, #ffe0b2 50%, #81d4fa 100%)"}},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[12]||(e[12]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),profile:o(()=>[...e[13]||(e[13]=[t("div",{style:{width:"32px",height:"32px","border-radius":"50%",border:"2px solid white","background-color":"white",display:"flex","align-items":"center","justify-content":"center",color:"#ff4081"}},[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"18",height:"18"},[t("path",{d:"M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"})])],-1)])]),default:o(()=>[t("div",C,[(n(),s(d,null,g(5,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," Scrollable content block "+c(i)+". This style is great for dynamic plugin pages! ",1)),64))])]),_:1})])]),t("div",B,[e[20]||(e[20]=t("h3",null,"Solid Color with Actions",-1)),e[21]||(e[21]=t("p",{class:"custom-guide"},"A solid color background using the end slot for actions like search and settings.",-1)),t("div",H,[l(r(p),{title:"Settings",expandedHeight:150,collapsedHeight:56,centerTitleOnCollapse:""},{background:o(()=>[...e[16]||(e[16]=[t("div",{style:{width:"100%",height:"100%","background-color":"var(--pp-primary, #007aff)"}},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[17]||(e[17]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),end:o(()=>[t("div",S,[l(r(a),{color:"transparent"},{default:o(()=>[...e[18]||(e[18]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("circle",{cx:"11",cy:"11",r:"8"}),t("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})],-1)])]),_:1}),l(r(a),{color:"transparent"},{default:o(()=>[...e[19]||(e[19]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("circle",{cx:"12",cy:"12",r:"3"}),t("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"})],-1)])]),_:1})])]),default:o(()=>[t("div",T,[(n(),s(d,null,g(8,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," List item "+c(i)+". This style allows adding quick actions directly on the appbar. ",1)),64))])]),_:1})])]),t("div",z,[e[25]||(e[25]=t("h3",null,"Sticky Segment (Tabs)",-1)),e[26]||(e[26]=t("p",{class:"custom-guide"},"A segment control that scrolls with the content but sticks to the bottom of the collapsed header.",-1)),t("div",M,[l(r(p),{title:"Transactions",expandedHeight:200,collapsedHeight:56},{background:o(()=>[...e[22]||(e[22]=[t("div",{style:{width:"100%",height:"100%",background:"linear-gradient(to right, #4facfe 0%, #00f2fe 100%)"}},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[23]||(e[23]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),default:o(()=>[e[24]||(e[24]=t("div",{style:{position:"sticky",top:"56px","z-index":"20",background:"white",padding:"8px 16px","box-shadow":"0 4px 6px -1px rgba(0,0,0,0.05)"}},[t("div",{style:{display:"flex",background:"#f1f5f9","border-radius":"8px",padding:"4px"}},[t("div",{style:{flex:"1","text-align":"center",padding:"6px",background:"white","border-radius":"6px","box-shadow":"0 1px 3px rgba(0,0,0,0.1)","font-weight":"500","font-size":"14px"}},"Recent"),t("div",{style:{flex:"1","text-align":"center",padding:"6px","border-radius":"6px",color:"#64748b","font-weight":"500","font-size":"14px"}},"Scheduled")])],-1)),t("div",I,[(n(),s(d,null,g(12,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," Scrollable item "+c(i)+". Notice how the segment tabs stick right under the header when you scroll down. ",1)),64))])]),_:1})])]),t("div",A,[e[29]||(e[29]=t("h3",null,"Floating Header Style",-1)),e[30]||(e[30]=t("p",{class:"custom-guide"},"By using CSS overrides, you can make the expanded header look like a floating island.",-1)),t("div",D,[l(r(p),{title:"Overview",expandedHeight:220,collapsedHeight:64,class:"floating-collapse-appbar"},{background:o(()=>[...e[27]||(e[27]=[t("div",{style:{width:"100%",height:"100%",background:"#ffffff","border-radius":"20px","box-shadow":"0 10px 25px -5px rgba(0,0,0,0.1)"}},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent",style:{color:"#1e293b"}},{default:o(()=>[...e[28]||(e[28]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),default:o(()=>[t("div",O,[(n(),s(d,null,g(8,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," Floating content "+c(i)+". This style pushes the header inward using CSS. ",1)),64))])]),_:1})])]),t("div",j,[e[34]||(e[34]=t("h3",null,"Glassmorphism (Frosted Glass)",-1)),e[35]||(e[35]=t("p",{class:"custom-guide"},"A premium iOS-style blurred glass effect using backdrop-filter. This requires a background image and a translucent overlay.",-1)),t("div",q,[l(r(p),{title:"Discover",expandedHeight:220,collapsedHeight:60},{background:o(()=>[...e[31]||(e[31]=[t("div",{style:{position:"absolute",inset:"0"}},[t("img",{src:"https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000&auto=format&fit=crop",alt:"bg",style:{width:"100%",height:"100%","object-fit":"cover"}})],-1),t("div",{style:{position:"absolute",inset:"0",background:"rgba(255, 255, 255, 0.2)","backdrop-filter":"blur(12px)","-webkit-backdrop-filter":"blur(12px)","border-bottom":"1px solid rgba(255, 255, 255, 0.3)"}},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[32]||(e[32]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),end:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[33]||(e[33]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("circle",{cx:"11",cy:"11",r:"8"}),t("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})],-1)])]),_:1})]),default:o(()=>[t("div",F,[(n(),s(d,null,g(10,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," Scroll up to see the beautiful frosted glass effect compress. The background image blurs heavily under the title. ")),64))])]),_:1})])]),t("div",V,[e[38]||(e[38]=t("h3",null,"Dark Mode Aesthetic",-1)),e[39]||(e[39]=t("p",{class:"custom-guide"},"A sleek, dark-themed header with subtle glowing accents.",-1)),t("div",W,[l(r(p),{title:"Wallet",expandedHeight:200,collapsedHeight:56,class:"dark-collapse-appbar"},{background:o(()=>[...e[36]||(e[36]=[t("div",{style:{width:"100%",height:"100%",background:"linear-gradient(180deg, #1e293b 0%, #0f172a 100%)",position:"relative",overflow:"hidden"}},[t("div",{style:{position:"absolute",top:"-50px",right:"-20px",width:"150px",height:"150px",background:"#3b82f6","border-radius":"50%",filter:"blur(60px)",opacity:"0.5"}}),t("div",{style:{position:"absolute",bottom:"0",left:"0",right:"0",height:"1px",background:"linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.5), transparent)"}})],-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[37]||(e[37]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),default:o(()=>[t("div",L,[(n(),s(d,null,g(8,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px"}}," Dark mode content. The appbar title text is styled to be white using a CSS override. ")),64))])]),_:1})])]),t("div",N,[e[62]||(e[62]=t("h3",null,"Card Overlap Style",-1)),e[63]||(e[63]=t("p",{class:"custom-guide"},"The content scrolls over the header, creating a layered, dimensional look. Very common in modern finance apps.",-1)),t("div",G,[l(r(p),{title:"Account details",expandedHeight:240,collapsedHeight:60},{background:o(()=>[...e[40]||(e[40]=[t("div",{style:{width:"100%",height:"100%",background:"#2563eb","background-image":"radial-gradient(circle at 100% 0%, #3b82f6 0%, transparent 50%)"}},null,-1)])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[41]||(e[41]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),default:o(()=>[t("div",R,[e[45]||(e[45]=t("div",{style:{background:"white","border-radius":"16px",padding:"24px","box-shadow":"0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05)","text-align":"center"}},[t("div",{style:{"font-size":"14px",color:"#64748b","font-weight":"500"}},"Total Balance"),t("div",{style:{"font-size":"32px","font-weight":"700",color:"#0f172a","margin-top":"8px"}},"$12,450.00"),t("div",{style:{display:"flex",gap:"12px","margin-top":"24px"}},[t("div",{style:{flex:"1",padding:"12px",background:"#eff6ff",color:"#2563eb","border-radius":"12px","font-weight":"600"}},"Transfer"),t("div",{style:{flex:"1",padding:"12px",background:"#eff6ff",color:"#2563eb","border-radius":"12px","font-weight":"600"}},"Pay")])],-1)),t("div",$,[e[44]||(e[44]=t("h4",{style:{margin:"0 0 16px 0",color:"#334155"}},"Recent Activity",-1)),(n(),s(d,null,g(8,i=>t("div",{key:i,style:{background:"white",padding:"16px","border-radius":"12px","margin-bottom":"12px",display:"flex","justify-content":"space-between"}},[t("div",null,[t("div",E,"Payment "+c(i),1),e[42]||(e[42]=t("div",{style:{"font-size":"13px",color:"#94a3b8","margin-top":"4px"}},"Today",-1))]),e[43]||(e[43]=t("div",{style:{"font-weight":"600",color:"#ef4444"}},"-$45.00",-1))])),64))])])]),_:1})]),t("div",K,[e[52]||(e[52]=t("h3",null,"E-Commerce Product (Rounded Bottom)",-1)),e[53]||(e[53]=t("p",{class:"custom-guide"},"A product detail page style where the header contains the product image with rounded bottom corners, collapsing into a solid bar.",-1)),t("div",X,[l(r(p),{title:"Wireless Headphones",expandedHeight:260,collapsedHeight:60,class:"ecommerce-sliver"},{background:o(()=>[...e[46]||(e[46]=[t("div",{style:{width:"100%",height:"100%",background:"#ffffff","border-bottom-left-radius":"32px","border-bottom-right-radius":"32px",overflow:"hidden",display:"flex","align-items":"center","justify-content":"center"}},[t("img",{src:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1000&auto=format&fit=crop",alt:"Product",style:{width:"80%",height:"80%","object-fit":"contain","margin-bottom":"20px"}})],-1)])]),start:o(()=>[l(r(a),{color:"transparent",style:{color:"#0f172a",background:"rgba(255,255,255,0.7) !important","border-radius":"50%"}},{default:o(()=>[...e[47]||(e[47]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"20",height:"20"},[t("path",{d:"M19 12H5M12 19l-7-7 7-7"})],-1)])]),_:1})]),end:o(()=>[l(r(a),{color:"transparent",style:{color:"#0f172a",background:"rgba(255,255,255,0.7) !important","border-radius":"50%"}},{default:o(()=>[...e[48]||(e[48]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"20",height:"20"},[t("path",{d:"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"})],-1)])]),_:1})]),default:o(()=>[t("div",Y,[e[49]||(e[49]=t("h2",{style:{margin:"0",color:"#0f172a","font-size":"24px"}},"Sony WH-1000XM4",-1)),e[50]||(e[50]=t("div",{style:{color:"#2563eb","font-weight":"bold","font-size":"20px","margin-top":"8px"}},"$348.00",-1)),e[51]||(e[51]=t("div",{style:{"margin-top":"16px",display:"flex",gap:"8px"}},[t("span",{style:{background:"#f1f5f9",padding:"4px 12px","border-radius":"16px","font-size":"12px","font-weight":"500"}},"Noise Cancelling"),t("span",{style:{background:"#f1f5f9",padding:"4px 12px","border-radius":"16px","font-size":"12px","font-weight":"500"}},"Bluetooth 5.0")],-1)),(n(),s(d,null,g(5,i=>t("p",{key:i,style:{"margin-top":"20px","font-size":"15px",color:"#475569","line-height":"1.6"}}," Product description block "+c(i)+". Scroll down to see the product image disappear and the header pin to the top. ",1)),64))])]),_:1})])]),t("div",J,[e[60]||(e[60]=t("h3",null,"Parallax Image with Integrated Search",-1)),e[61]||(e[61]=t("p",{class:"custom-guide"},"A large destination image that contains a search bar inside the expanded area. A classic travel/booking app layout.",-1)),t("div",Q,[l(r(p),{title:"Explore",expandedHeight:280,collapsedHeight:64},{background:o(()=>[e[56]||(e[56]=t("div",{style:{position:"absolute",inset:"0"}},[t("img",{src:"https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=1000&auto=format&fit=crop",alt:"Travel",style:{width:"100%",height:"100%","object-fit":"cover"}}),t("div",{style:{position:"absolute",inset:"0",background:"linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0) 50%, rgba(0,0,0,0.6) 100%)"}})],-1)),t("div",U,[t("div",Z,[(n(),s("svg",_,[...e[54]||(e[54]=[t("circle",{cx:"11",cy:"11",r:"8"},null,-1),t("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])),e[55]||(e[55]=t("input",{type:"text",placeholder:"Where do you want to go?",style:{border:"none",background:"transparent",outline:"none",width:"100%","font-size":"15px",color:"#0f172a"}},null,-1))])])]),start:o(()=>[l(r(a),{color:"transparent"},{default:o(()=>[...e[57]||(e[57]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2",width:"24",height:"24"},[t("line",{x1:"3",y1:"12",x2:"21",y2:"12"}),t("line",{x1:"3",y1:"6",x2:"21",y2:"6"}),t("line",{x1:"3",y1:"18",x2:"21",y2:"18"})],-1)])]),_:1})]),default:o(()=>[t("div",tt,[e[58]||(e[58]=t("h3",{style:{"margin-top":"0"}},"Top Destinations",-1)),e[59]||(e[59]=t("div",{style:{display:"flex",gap:"16px","overflow-x":"auto","padding-bottom":"16px","margin-top":"16px"}},[t("div",{style:{"min-width":"120px",height:"160px","border-radius":"12px",background:"#e2e8f0"}}),t("div",{style:{"min-width":"120px",height:"160px","border-radius":"12px",background:"#e2e8f0"}}),t("div",{style:{"min-width":"120px",height:"160px","border-radius":"12px",background:"#e2e8f0"}})],-1)),(n(),s(d,null,g(5,i=>t("p",{key:i,style:{"margin-bottom":"20px","font-size":"16px",color:"#555"}}," Discover places block "+c(i)+". ",1)),64))])]),_:1})])])]),e[65]||(e[65]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-app-bar-bg: /* value */;
  --pp-app-bar-color: /* value */;
  --pp-app-bar-height: /* value */;
  --pp-app-bar-pb: /* value */;
  --pp-app-bar-pt: /* value */;
  --pp-app-bar-radius: /* value */;
  --pp-app-bar-title-size: /* value */;
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[66]||(e[66]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>Collapsing Appbar</h2>
        <div class="variant-group">
          <h3>Scroll to Collapse</h3>
          <p class="custom-guide">A Material Design style collapsing toolbar. Scroll the content below to see it shrink!</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative;">
            <PPCollapsingToolbar title="Profile" :expandedHeight="200" :collapsedHeight="56">
              <template #background>
                <img src="https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=1000&auto=format&fit=crop" alt="bg" />
              </template>
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              
              <template #profile>
                <img src="https://i.pravatar.cc/150?img=68" alt="Profile" style="width: 32px; height: 32px; border-radius: 50%; border: 2px solid white; object-fit: cover; box-shadow: 0 2px 4px rgba(0,0,0,0.2);" />
              </template>
              
              <div style="padding: 24px;">
                <p v-for="i in 10" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  Scrollable content block {{ i }}. Keep scrolling to see the header collapse.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
          <pre class="code-block"><code>&lt;PPCollapsingToolbar title="Profile" :expandedHeight="200" :collapsedHeight="56"&gt;
  &lt;template #background&gt;
    &lt;img src="..." alt="bg" /&gt;
  &lt;/template&gt;
  &lt;template #start&gt;
    &lt;PPIconButton color="white"&gt;
      &lt;!-- Back Icon --&gt;
    &lt;/PPIconButton&gt;
  &lt;/template&gt;
  &lt;template #profile&gt;
    &lt;img src="..." alt="Profile" class="avatar" /&gt;
  &lt;/template&gt;
  
  &lt;div class="content"&gt;
    &lt;!-- Scrollable content --&gt;
  &lt;/div&gt;
&lt;/PPCollapsingToolbar&gt;</code></pre>
        </div>
        
        <div class="variant-group">
          <h3>Standard Header (No Profile)</h3>
          <p class="custom-guide">Without a profile picture, the title scales and aligns correctly by itself. Here it moves to the center when collapsed.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative;">
            <PPCollapsingToolbar title="Dashboard" :expandedHeight="200" :collapsedHeight="56" centerTitleOnCollapse>
              <template #background>
                <img src="https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000&auto=format&fit=crop" alt="bg" />
              </template>
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              
              <div style="padding: 24px;">
                <p v-for="i in 10" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  Scrollable content block {{ i }}. Keep scrolling to see the header collapse.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
          <pre class="code-block"><code>&lt;PPCollapsingToolbar title="Dashboard" :expandedHeight="200" :collapsedHeight="56" centerTitleOnCollapse&gt;
  &lt;template #background&gt;
    &lt;img src="..." alt="bg" /&gt;
  &lt;/template&gt;
  &lt;template #start&gt;
    &lt;PPIconButton color="white"&gt;
      &lt;!-- Back Icon --&gt;
    &lt;/PPIconButton&gt;
  &lt;/template&gt;
  
  &lt;div class="content"&gt;
    &lt;!-- Scrollable content --&gt;
  &lt;/div&gt;
&lt;/PPCollapsingToolbar&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Gradient Background & Icon Profile</h3>
          <p class="custom-guide">A vibrant gradient background with an icon instead of an image for the profile.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative;">
            <PPCollapsingToolbar title="Plugin Details" :expandedHeight="200" :collapsedHeight="56">
              <template #background>
                <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #ff4081 0%, #ffe0b2 50%, #81d4fa 100%);"></div>
              </template>
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              
              <template #profile>
                <div style="width: 32px; height: 32px; border-radius: 50%; border: 2px solid white; background-color: white; display: flex; align-items: center; justify-content: center; color: #ff4081;">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                </div>
              </template>
              
              <div style="padding: 24px;">
                <p v-for="i in 5" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  Scrollable content block {{ i }}. This style is great for dynamic plugin pages!
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>

        <div class="variant-group">
          <h3>Solid Color with Actions</h3>
          <p class="custom-guide">A solid color background using the end slot for actions like search and settings.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative;">
            <PPCollapsingToolbar title="Settings" :expandedHeight="150" :collapsedHeight="56" centerTitleOnCollapse>
              <template #background>
                <div style="width: 100%; height: 100%; background-color: var(--pp-primary, #007aff);"></div>
              </template>
              
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>

              <template #end>
                <div style="display: flex; gap: 4px; align-items: center;">
                  <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></PPIconButton>
                  <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></PPIconButton>
                </div>
              </template>
              
              <div style="padding: 24px;">
                <p v-for="i in 8" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  List item {{ i }}. This style allows adding quick actions directly on the appbar.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>
        <div class="variant-group">
          <h3>Sticky Segment (Tabs)</h3>
          <p class="custom-guide">A segment control that scrolls with the content but sticks to the bottom of the collapsed header.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative;">
            <PPCollapsingToolbar title="Transactions" :expandedHeight="200" :collapsedHeight="56">
              <template #background>
                <div style="width: 100%; height: 100%; background: linear-gradient(to right, #4facfe 0%, #00f2fe 100%);"></div>
              </template>
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              
              <!-- Sticky Segment Container -->
              <div style="position: sticky; top: 56px; z-index: 20; background: white; padding: 8px 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                <div style="display: flex; background: #f1f5f9; border-radius: 8px; padding: 4px;">
                  <div style="flex: 1; text-align: center; padding: 6px; background: white; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); font-weight: 500; font-size: 14px;">Recent</div>
                  <div style="flex: 1; text-align: center; padding: 6px; border-radius: 6px; color: #64748b; font-weight: 500; font-size: 14px;">Scheduled</div>
                </div>
              </div>
              
              <div style="padding: 16px 24px;">
                <p v-for="i in 12" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  Scrollable item {{ i }}. Notice how the segment tabs stick right under the header when you scroll down.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>

        <div class="variant-group">
          <h3>Floating Header Style</h3>
          <p class="custom-guide">By using CSS overrides, you can make the expanded header look like a floating island.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative; background: #f8fafc;">
            <PPCollapsingToolbar title="Overview" :expandedHeight="220" :collapsedHeight="64" class="floating-collapse-appbar">
              <template #background>
                <div style="width: 100%; height: 100%; background: #ffffff; border-radius: 20px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);"></div>
              </template>
              <template #start>
                <PPIconButton color="transparent" style="color: #1e293b;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              
              <div style="padding: 24px; padding-top: 32px;">
                <p v-for="i in 8" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  Floating content {{ i }}. This style pushes the header inward using CSS.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>
        <div class="variant-group">
          <h3>Glassmorphism (Frosted Glass)</h3>
          <p class="custom-guide">A premium iOS-style blurred glass effect using backdrop-filter. This requires a background image and a translucent overlay.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative;">
            <PPCollapsingToolbar title="Discover" :expandedHeight="220" :collapsedHeight="60">
              <template #background>
                <!-- Base image -->
                <div style="position: absolute; inset: 0;">
                  <img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000&auto=format&fit=crop" alt="bg" style="width: 100%; height: 100%; object-fit: cover;" />
                </div>
                <!-- Glass overlay -->
                <div style="position: absolute; inset: 0; background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border-bottom: 1px solid rgba(255, 255, 255, 0.3);"></div>
              </template>
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              <template #end>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></PPIconButton>
              </template>
              
              <div style="padding: 24px;">
                <p v-for="i in 10" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  Scroll up to see the beautiful frosted glass effect compress. The background image blurs heavily under the title.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>

        <div class="variant-group">
          <h3>Dark Mode Aesthetic</h3>
          <p class="custom-guide">A sleek, dark-themed header with subtle glowing accents.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative; background: #0f172a;">
            <PPCollapsingToolbar title="Wallet" :expandedHeight="200" :collapsedHeight="56" class="dark-collapse-appbar">
              <template #background>
                <div style="width: 100%; height: 100%; background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%); position: relative; overflow: hidden;">
                  <!-- Glowing orb -->
                  <div style="position: absolute; top: -50px; right: -20px; width: 150px; height: 150px; background: #3b82f6; border-radius: 50%; filter: blur(60px); opacity: 0.5;"></div>
                  <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.5), transparent);"></div>
                </div>
              </template>
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              
              <div style="padding: 24px; color: #cbd5e1;">
                <p v-for="i in 8" :key="i" style="margin-bottom: 20px; font-size: 16px;">
                  Dark mode content. The appbar title text is styled to be white using a CSS override.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>

        <div class="variant-group">
          <h3>Card Overlap Style</h3>
          <p class="custom-guide">The content scrolls over the header, creating a layered, dimensional look. Very common in modern finance apps.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative; background: #f1f5f9;">
            <PPCollapsingToolbar title="Account details" :expandedHeight="240" :collapsedHeight="60">
              <template #background>
                <div style="width: 100%; height: 100%; background: #2563eb; background-image: radial-gradient(circle at 100% 0%, #3b82f6 0%, transparent 50%);"></div>
              </template>
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              
              <!-- Overlapping Card Container -->
              <div style="padding: 0 16px; margin-top: -32px; position: relative; z-index: 1;">
                <div style="background: white; border-radius: 16px; padding: 24px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05); text-align: center;">
                  <div style="font-size: 14px; color: #64748b; font-weight: 500;">Total Balance</div>
                  <div style="font-size: 32px; font-weight: 700; color: #0f172a; margin-top: 8px;">$12,450.00</div>
                  <div style="display: flex; gap: 12px; margin-top: 24px;">
                    <div style="flex: 1; padding: 12px; background: #eff6ff; color: #2563eb; border-radius: 12px; font-weight: 600;">Transfer</div>
                    <div style="flex: 1; padding: 12px; background: #eff6ff; color: #2563eb; border-radius: 12px; font-weight: 600;">Pay</div>
                  </div>
                </div>
                
                <div style="margin-top: 24px;">
                  <h4 style="margin: 0 0 16px 0; color: #334155;">Recent Activity</h4>
                  <div v-for="i in 8" :key="i" style="background: white; padding: 16px; border-radius: 12px; margin-bottom: 12px; display: flex; justify-content: space-between;">
                    <div>
                      <div style="font-weight: 600; color: #1e293b;">Payment {{ i }}</div>
                      <div style="font-size: 13px; color: #94a3b8; margin-top: 4px;">Today</div>
                    </div>
                    <div style="font-weight: 600; color: #ef4444;">-$45.00</div>
                  </div>
                </div>
              </div>
            </PPCollapsingToolbar>
          </div>
        <div class="variant-group">
          <h3>E-Commerce Product (Rounded Bottom)</h3>
          <p class="custom-guide">A product detail page style where the header contains the product image with rounded bottom corners, collapsing into a solid bar.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative; background: #f8fafc;">
            <PPCollapsingToolbar title="Wireless Headphones" :expandedHeight="260" :collapsedHeight="60" class="ecommerce-sliver">
              <template #background>
                <div style="width: 100%; height: 100%; background: #ffffff; border-bottom-left-radius: 32px; border-bottom-right-radius: 32px; overflow: hidden; display: flex; align-items: center; justify-content: center;">
                  <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1000&auto=format&fit=crop" alt="Product" style="width: 80%; height: 80%; object-fit: contain; margin-bottom: 20px;" />
                </div>
              </template>
              <template #start>
                <PPIconButton color="transparent" style="color: #0f172a; background: rgba(255,255,255,0.7) !important; border-radius: 50%;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></PPIconButton>
              </template>
              <template #end>
                <PPIconButton color="transparent" style="color: #0f172a; background: rgba(255,255,255,0.7) !important; border-radius: 50%;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></PPIconButton>
              </template>
              
              <div style="padding: 24px; padding-top: 48px;">
                <h2 style="margin: 0; color: #0f172a; font-size: 24px;">Sony WH-1000XM4</h2>
                <div style="color: #2563eb; font-weight: bold; font-size: 20px; margin-top: 8px;">$348.00</div>
                <div style="margin-top: 16px; display: flex; gap: 8px;">
                  <span style="background: #f1f5f9; padding: 4px 12px; border-radius: 16px; font-size: 12px; font-weight: 500;">Noise Cancelling</span>
                  <span style="background: #f1f5f9; padding: 4px 12px; border-radius: 16px; font-size: 12px; font-weight: 500;">Bluetooth 5.0</span>
                </div>
                <p v-for="i in 5" :key="i" style="margin-top: 20px; font-size: 15px; color: #475569; line-height: 1.6;">
                  Product description block {{ i }}. Scroll down to see the product image disappear and the header pin to the top.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>

        <div class="variant-group">
          <h3>Parallax Image with Integrated Search</h3>
          <p class="custom-guide">A large destination image that contains a search bar inside the expanded area. A classic travel/booking app layout.</p>
          <div class="component-demo" style="height: 400px; padding: 0; border-radius: 12px; overflow: hidden; position: relative;">
            <PPCollapsingToolbar title="Explore" :expandedHeight="280" :collapsedHeight="64">
              <template #background>
                <div style="position: absolute; inset: 0;">
                  <img src="https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=1000&auto=format&fit=crop" alt="Travel" style="width: 100%; height: 100%; object-fit: cover;" />
                  <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0) 50%, rgba(0,0,0,0.6) 100%);"></div>
                </div>
                
                <!-- Search bar injected into background so it scrolls with parallax -->
                <div style="position: absolute; bottom: 32px; left: 24px; right: 24px; z-index: 2;">
                  <div style="background: white; border-radius: 24px; padding: 12px 20px; display: flex; align-items: center; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
                    <svg viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="2" width="20" height="20" style="margin-right: 12px;"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input type="text" placeholder="Where do you want to go?" style="border: none; background: transparent; outline: none; width: 100%; font-size: 15px; color: #0f172a;" />
                  </div>
                </div>
              </template>
              
              <template #start>
                <PPIconButton color="transparent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg></PPIconButton>
              </template>
              
              <div style="padding: 24px; background: white; min-height: 400px; border-top-left-radius: 24px; border-top-right-radius: 24px; position: relative; z-index: 2;">
                <h3 style="margin-top: 0;">Top Destinations</h3>
                <div style="display: flex; gap: 16px; overflow-x: auto; padding-bottom: 16px; margin-top: 16px;">
                  <div style="min-width: 120px; height: 160px; border-radius: 12px; background: #e2e8f0;"></div>
                  <div style="min-width: 120px; height: 160px; border-radius: 12px; background: #e2e8f0;"></div>
                  <div style="min-width: 120px; height: 160px; border-radius: 12px; background: #e2e8f0;"></div>
                </div>
                <p v-for="i in 5" :key="i" style="margin-bottom: 20px; font-size: 16px; color: #555;">
                  Discover places block {{ i }}.
                </p>
              </div>
            </PPCollapsingToolbar>
          </div>
        </div>

      </div>
    
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-app-bar-bg: /* value */;
  --pp-app-bar-color: /* value */;
  --pp-app-bar-height: /* value */;
  --pp-app-bar-pb: /* value */;
  --pp-app-bar-pt: /* value */;
  --pp-app-bar-radius: /* value */;
  --pp-app-bar-title-size: /* value */;
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPCollapsingToolbar, PPIconButton } from '@phanna/ui-framework';
<\/script>

<style scoped>
.guide-section {
  padding: 16px;
}
.custom-guide {
  color: #64748b;
  margin-bottom: 16px;
}
.code-block {
  background: #1e293b;
  color: #e2e8f0;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  margin-top: 16px;
}
.floating-collapse-appbar :deep(.pp-collapsing-header) {
  margin: 16px;
  width: calc(100% - 32px);
  border-radius: 20px;
  background: transparent;
  box-shadow: none;
}
.floating-collapse-appbar :deep(.pp-collapsing-title) {
  color: #1e293b;
}

/* Fallback for transparent icon button until framework rebuild cache is cleared */
:deep(.pp-icon-btn--transparent) {
  background-color: transparent !important;
  color: inherit;
  box-shadow: none !important;
}
:deep(.pp-icon-btn--transparent:active) {
  background-color: rgba(0, 0, 0, 0.1) !important;
}
:deep(.floating-collapse-appbar .pp-icon-btn--transparent) {
  color: #1e293b !important;
}
:deep(.pp-collapsing-header:not(.floating-collapse-appbar) .pp-icon-btn--transparent) {
  color: #ffffff;
}
.dark-collapse-appbar :deep(.pp-collapsing-title) {
  color: #ffffff !important;
}
.ecommerce-sliver :deep(.pp-collapsing-header.collapsed) {
  background: white !important;
  box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
}
.ecommerce-sliver :deep(.pp-collapsing-title) {
  color: #0f172a !important;
}
</style>
`)])],-1))],64))}}),nt=u(et,[["__scopeId","data-v-86a9283f"]]);export{nt as C};
