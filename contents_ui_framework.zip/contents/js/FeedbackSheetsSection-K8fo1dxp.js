import{P as d,az as p,aA as f,aB as g}from"./AccountCardSection-DXixqG3L.js";import{d as v,o as h,j as b,l as o,A as n,a as l,w as P,u as s,L as C,F as S,p as c}from"../vendors/vendor-ah_eQdvw.js";const x={class:"guide-section"},k={class:"variant-group"},T={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd",padding:"20px","border-radius":"12px",display:"flex","flex-direction":"column",gap:"12px"}},y={class:"variant-group"},A={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd",padding:"20px","border-radius":"12px",display:"flex","flex-direction":"column",gap:"12px"}},w={class:"variant-group"},O={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd",padding:"20px","border-radius":"12px",display:"flex","flex-direction":"column",gap:"12px"}},V=v({__name:"FeedbackSheetsSection",setup(I){const r=c(!1),a=c(!1),i=c(!1),m=u=>console.log("Setup: "+u);return(u,e)=>(h(),b(S,null,[o("div",x,[e[18]||(e[18]=o("h2",null,"9. Feedback & Action Sheets",-1)),o("div",k,[e[8]||(e[8]=o("h3",null,"PPToast",-1)),e[9]||(e[9]=o("p",{class:"custom-guide"},[o("strong",null,"Props:"),n(),o("code",null,"modelValue"),n(", "),o("code",null,"message"),n(", "),o("code",null,"duration")],-1)),o("div",T,[l(s(d),{onClick:e[0]||(e[0]=t=>r.value=!0)},{default:P(()=>[...e[7]||(e[7]=[n("Trigger Toast",-1)])]),_:1}),l(s(p),{modelValue:r.value,"onUpdate:modelValue":e[1]||(e[1]=t=>r.value=t),message:"User has been deleted."},null,8,["modelValue"])]),e[10]||(e[10]=o("pre",{class:"code-block"},[o("code",null,'<PPToast v-model="showToast" message="User has been deleted." />')],-1))]),o("div",y,[e[12]||(e[12]=C('<h3>PPConfirmSheet</h3><p class="custom-guide"><strong>Props:</strong> <code>modelValue</code>, <code>title</code>, <code>subtitle</code>, <code>confirmText</code>, <code>cancelText</code></p>',2)),o("div",A,[l(s(d),{onClick:e[2]||(e[2]=t=>a.value=!0)},{default:P(()=>[...e[11]||(e[11]=[n("Trigger Confirm Sheet",-1)])]),_:1}),l(s(f),{modelValue:a.value,"onUpdate:modelValue":e[3]||(e[3]=t=>a.value=t),title:"Delete User?",subtitle:"This action cannot be undone.",confirmText:"Delete",cancelText:"Cancel"},null,8,["modelValue"])]),e[13]||(e[13]=o("pre",{class:"code-block"},[o("code",null,`<PPConfirmSheet 
  v-model="showConfirmSheet" 
  title="Delete User?"
  subtitle="This action cannot be undone."
  confirmText="Delete"
  cancelText="Cancel"
/>`)],-1))]),o("div",w,[e[15]||(e[15]=o("h3",null,"PPReceiveAmountSheet",-1)),e[16]||(e[16]=o("p",{class:"custom-guide"},[o("strong",null,"Events:"),n(),o("code",null,"@confirm"),n(" (emits payload with currency and amount)")],-1)),o("div",O,[l(s(d),{onClick:e[4]||(e[4]=t=>i.value=!0)},{default:P(()=>[...e[14]||(e[14]=[n("Trigger Receive Amount Sheet",-1)])]),_:1}),l(s(g),{modelValue:i.value,"onUpdate:modelValue":e[5]||(e[5]=t=>i.value=t),onConfirm:e[6]||(e[6]=t=>m(`Received ${t.currency} ${t.amount}`))},null,8,["modelValue"])]),e[17]||(e[17]=o("pre",{class:"code-block"},[o("code",null,`<PPReceiveAmountSheet 
  v-model="showReceiveAmount" 
  @confirm="handleConfirm" 
/>`)],-1))]),e[19]||(e[19]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[20]||(e[20]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
<div class="guide-section">
        <h2>9. Feedback & Action Sheets</h2>

        <div class="variant-group">
          <h3>PPToast</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>modelValue</code>, <code>message</code>, <code>duration</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; padding: 20px; border-radius: 12px; display: flex; flex-direction: column; gap: 12px;">
            <PPButton @click="showToast = true">Trigger Toast</PPButton>
            <PPToast v-model="showToast" message="User has been deleted." />
          </div>
          <pre class="code-block"><code>&lt;PPToast v-model="showToast" message="User has been deleted." /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPConfirmSheet</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>modelValue</code>, <code>title</code>, <code>subtitle</code>, <code>confirmText</code>, <code>cancelText</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; padding: 20px; border-radius: 12px; display: flex; flex-direction: column; gap: 12px;">
            <PPButton @click="showConfirmSheet = true">Trigger Confirm Sheet</PPButton>
            <PPConfirmSheet 
              v-model="showConfirmSheet" 
              title="Delete User?"
              subtitle="This action cannot be undone."
              confirmText="Delete"
              cancelText="Cancel"
            />
          </div>
          <pre class="code-block"><code>&lt;PPConfirmSheet 
  v-model="showConfirmSheet" 
  title="Delete User?"
  subtitle="This action cannot be undone."
  confirmText="Delete"
  cancelText="Cancel"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPReceiveAmountSheet</h3>
          <p class="custom-guide"><strong>Events:</strong> <code>@confirm</code> (emits payload with currency and amount)</p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; padding: 20px; border-radius: 12px; display: flex; flex-direction: column; gap: 12px;">
            <PPButton @click="showReceiveAmount = true">Trigger Receive Amount Sheet</PPButton>
            <PPReceiveAmountSheet 
              v-model="showReceiveAmount" 
              @confirm="val => alertVal(\`Received \${val.currency} \${val.amount}\`)"
            />
          </div>
          <pre class="code-block"><code>&lt;PPReceiveAmountSheet 
  v-model="showReceiveAmount" 
  @confirm="handleConfirm" 
/&gt;</code></pre>
        </div>

      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const showToast = ref(false);

const showConfirmSheet = ref(false);

const showReceiveAmount = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{V as _};
