import{d as D,p as o,o as L,j as $,l as e,V as s,bj as u,A as p,a as l,w as c,n as m,y as n,u as i,bk as b,F as M}from"../vendors/vendor-ah_eQdvw.js";import{ah as d}from"./AccountCardSection-DXixqG3L.js";import{_ as U}from"./App-D7rwXoHs.js";const F={class:"component-section"},B={class:"demo-box"},E={class:"demo-content"},N={style:{display:"flex",gap:"16px","margin-bottom":"16px","flex-wrap":"wrap","align-items":"center"}},O={class:"demo-box"},j={class:"demo-content"},G={style:{display:"flex",gap:"16px","margin-bottom":"16px","flex-wrap":"wrap","align-items":"center"}},Y={class:"demo-box"},q={class:"demo-content"},H={style:{display:"flex",gap:"16px","margin-bottom":"16px","flex-wrap":"wrap","align-items":"center"}},J={style:{"margin-top":"16px",padding:"12px",background:"#f0f0f0","border-radius":"4px","font-size":"14px"}},K={class:"demo-box"},Q={class:"demo-content"},W={style:{padding:"16px","background-color":"#f9f9f9","border-radius":"8px",border:"1px dashed #ccc"}},X={style:{"margin-top":"8px"}},Z={class:"demo-box"},_={class:"demo-content"},ee={style:{display:"flex",gap:"16px","margin-bottom":"16px","flex-wrap":"wrap","align-items":"center"}},te={class:"demo-box"},ae={class:"demo-content"},oe={class:"demo-box"},se={class:"demo-content"},ne={class:"demo-box"},le={class:"demo-content"},ie={class:"demo-box"},de={class:"demo-content"},re=D({__name:"TableSection",setup(pe){const r=o([{key:"id",title:"ID",width:"60px",sortable:!0},{key:"name",title:"Name",sortable:!0},{key:"role",title:"Role",sortable:!0},{key:"status",title:"Status"}]),v=o(!1),x=o(!1),f=o(!1),y=o(!0),w=o("outline"),P=o("rounded"),S=o("right"),h=o("left"),k=o(!0),C=o([]),T=o(!0),z=o([{key:"category",title:"Category"},{key:"name",title:"Item Name"},{key:"price",title:"Price"}]),A=o([{id:1,category:"Fruits",name:"Apple",price:"$1.00"},{id:2,category:"Fruits",name:"Banana",price:"$0.50"},{id:3,category:"Vegetables",name:"Carrot",price:"$0.80"},{id:4,category:"Vegetables",name:"Broccoli",price:"$1.20"}]),I=({rowIndex:V,columnIndex:t})=>{if(t===0)return V%2===0?{rowspan:2,colspan:1}:{rowspan:0,colspan:0}},g=o([{id:1,name:"User 1",role:"Admin",status:"active"},{id:2,name:"User 2",role:"Editor",status:"inactive"},{id:3,name:"User 3",role:"Viewer",status:"active"},{id:4,name:"User 4",role:"Admin",status:"inactive"}]),R=o(Array.from({length:24}).map((V,t)=>({id:t+1,name:`User ${t+1}`,role:t%3===0?"Admin":t%2===0?"Editor":"Viewer",status:t%4===0?"inactive":"active"})));return(V,t)=>(L(),$(M,null,[e("div",F,[t[40]||(t[40]=e("h2",null,"Table",-1)),t[41]||(t[41]=e("p",null,"A data table component with sorting, pagination, selection, and expansion support.",-1)),e("div",B,[t[14]||(t[14]=e("h3",null,"Basic & Styling",-1)),e("div",E,[e("div",N,[e("label",null,[s(e("input",{type:"checkbox","onUpdate:modelValue":t[0]||(t[0]=a=>v.value=a)},null,512),[[u,v.value]]),t[11]||(t[11]=p(" Striped",-1))]),e("label",null,[s(e("input",{type:"checkbox","onUpdate:modelValue":t[1]||(t[1]=a=>x.value=a)},null,512),[[u,x.value]]),t[12]||(t[12]=p(" Bordered",-1))]),e("label",null,[s(e("input",{type:"checkbox","onUpdate:modelValue":t[2]||(t[2]=a=>f.value=a)},null,512),[[u,f.value]]),t[13]||(t[13]=p(" Compact",-1))])]),l(i(d),{columns:r.value,data:g.value,striped:v.value,bordered:x.value,compact:f.value},{status:c(({row:a})=>[e("span",{class:m(["status-badge",`is-${a.status}`])},n(a.status),3)]),_:1},8,["columns","data","striped","bordered","compact"])]),t[15]||(t[15]=e("pre",{class:"code-block"},[e("code",null,`<PPTable 
  :columns="columns" 
  :data="data"
  :striped="true"
  :bordered="true"
  :compact="false"
>
  <template #status="{ row }">
    <span :class="\`is-\${row.status}\`">{{ row.status }}</span>
  </template>
</PPTable>`)],-1))]),e("div",O,[t[21]||(t[21]=e("h3",null,"Pagination",-1)),e("div",j,[e("div",G,[e("label",null,[s(e("input",{type:"checkbox","onUpdate:modelValue":t[3]||(t[3]=a=>y.value=a)},null,512),[[u,y.value]]),t[16]||(t[16]=p(" First/Last",-1))]),s(e("select",{"onUpdate:modelValue":t[4]||(t[4]=a=>w.value=a),style:{padding:"4px 8px","border-radius":"4px",border:"1px solid #ccc"}},[...t[17]||(t[17]=[e("option",{value:"outline"},"Pagination: Outline",-1),e("option",{value:"solid"},"Pagination: Solid",-1),e("option",{value:"ghost"},"Pagination: Ghost",-1)])],512),[[b,w.value]]),s(e("select",{"onUpdate:modelValue":t[5]||(t[5]=a=>P.value=a),style:{padding:"4px 8px","border-radius":"4px",border:"1px solid #ccc"}},[...t[18]||(t[18]=[e("option",{value:"rounded"},"Shape: Rounded",-1),e("option",{value:"circle"},"Shape: Circle",-1)])],512),[[b,P.value]]),s(e("select",{"onUpdate:modelValue":t[6]||(t[6]=a=>S.value=a),style:{padding:"4px 8px","border-radius":"4px",border:"1px solid #ccc"}},[...t[19]||(t[19]=[e("option",{value:"left"},"Align: Left",-1),e("option",{value:"center"},"Align: Center",-1),e("option",{value:"right"},"Align: Right",-1)])],512),[[b,S.value]]),s(e("select",{"onUpdate:modelValue":t[7]||(t[7]=a=>h.value=a),style:{padding:"4px 8px","border-radius":"4px",border:"1px solid #ccc"}},[...t[20]||(t[20]=[e("option",{value:"left"},"Size Changer: Left",-1),e("option",{value:"right"},"Size Changer: Right",-1)])],512),[[b,h.value]])]),l(i(d),{columns:r.value,data:R.value,pagination:!0,pageSize:5,paginationVariant:w.value,paginationShape:P.value,paginationAlign:S.value,showSizeChanger:!0,sizeChangerPosition:h.value,pageSizes:[5,10,15,20],showFirstLast:y.value},{status:c(({row:a})=>[e("span",{class:m(["status-badge",`is-${a.status}`])},n(a.status),3)]),_:1},8,["columns","data","paginationVariant","paginationShape","paginationAlign","sizeChangerPosition","showFirstLast"])]),t[22]||(t[22]=e("pre",{class:"code-block"},[e("code",null,`<PPTable 
  :columns="columns" 
  :data="data" 
  :pagination="true" 
  :pageSize="5"
  paginationVariant="outline"
  paginationShape="rounded"
  paginationAlign="right"
  :showSizeChanger="true"
  :pageSizes="[5, 10, 15, 20]"
  :showFirstLast="true"
/>`)],-1))]),e("div",Y,[t[25]||(t[25]=e("h3",null,"Selectable Rows",-1)),e("div",q,[e("div",H,[e("label",null,[s(e("input",{type:"checkbox","onUpdate:modelValue":t[8]||(t[8]=a=>k.value=a)},null,512),[[u,k.value]]),t[23]||(t[23]=p(" Multiple",-1))])]),l(i(d),{columns:r.value,data:g.value,selectable:!0,multiple:k.value,modelValue:C.value,"onUpdate:modelValue":t[9]||(t[9]=a=>C.value=a)},{status:c(({row:a})=>[e("span",{class:m(["status-badge",`is-${a.status}`])},n(a.status),3)]),_:1},8,["columns","data","multiple","modelValue"]),e("div",J,[t[24]||(t[24]=e("strong",null,"Selected IDs:",-1)),p(" "+n(C.value.map(a=>a.id).join(", ")||"None"),1)])]),t[26]||(t[26]=e("pre",{class:"code-block"},[e("code",null,`<PPTable 
  :columns="columns" 
  :data="data" 
  :selectable="true"
  :multiple="true"
  v-model="selectedRows"
/>`)],-1))]),e("div",K,[t[27]||(t[27]=e("h3",null,"Expandable Rows",-1)),e("div",Q,[l(i(d),{columns:r.value,data:g.value,expandable:!0},{status:c(({row:a})=>[e("span",{class:m(["status-badge",`is-${a.status}`])},n(a.status),3)]),expanded:c(({row:a})=>[e("div",W,[e("strong",null,"Expanded details for "+n(a.name),1),e("p",X,"ID: "+n(a.id),1),e("p",null,"Role: "+n(a.role),1),e("p",null,"Status: "+n(a.status),1)])]),_:1},8,["columns","data"])]),t[28]||(t[28]=e("pre",{class:"code-block"},[e("code",null,`<PPTable 
  :columns="columns" 
  :data="data" 
  :expandable="true"
>
  <template #expanded="{ row }">
    <div>Expanded details for {{ row.name }}</div>
  </template>
</PPTable>`)],-1))]),e("div",Z,[t[30]||(t[30]=e("h3",null,"Loading State",-1)),e("div",_,[e("div",ee,[e("label",null,[s(e("input",{type:"checkbox","onUpdate:modelValue":t[10]||(t[10]=a=>T.value=a)},null,512),[[u,T.value]]),t[29]||(t[29]=p(" Loading",-1))])]),l(i(d),{columns:r.value,data:g.value,loading:T.value,skeletonRows:4},{status:c(({row:a})=>[e("span",{class:m(["status-badge",`is-${a.status}`])},n(a.status),3)]),_:1},8,["columns","data","loading"])]),t[31]||(t[31]=e("pre",{class:"code-block"},[e("code",null,`<PPTable 
  :columns="columns" 
  :data="data" 
  :loading="true"
  :skeletonRows="4"
/>`)],-1))]),e("div",te,[t[32]||(t[32]=e("h3",null,"Empty State",-1)),e("div",ae,[l(i(d),{columns:r.value,data:[],emptyText:"Custom No Data Message"},null,8,["columns"])]),t[33]||(t[33]=e("pre",{class:"code-block"},[e("code",null,`<PPTable 
  :columns="columns" 
  :data="[]" 
  emptyText="Custom No Data Message"
  emptyIcon="<svg...></svg>"
/>`)],-1))]),e("div",oe,[t[34]||(t[34]=e("h3",null,"Empty State",-1)),e("div",se,[l(i(d),{columns:r.value,data:[],emptyText:"Custom No Data Message"},null,8,["columns"])]),t[35]||(t[35]=e("pre",{class:"code-block"},[e("code",null,`&lt;PPTable 
  :columns="columns" 
  :data="[]" 
  emptyText="Custom No Data Message"
/&gt;`)],-1))]),e("div",ne,[t[36]||(t[36]=e("h3",null,"Empty State",-1)),e("div",le,[l(i(d),{columns:r.value,data:[],emptyText:"Custom No Data Message"},null,8,["columns"])]),t[37]||(t[37]=e("pre",{class:"code-block"},[e("code",null,`&lt;PPTable 
  :columns="columns" 
  :data="[]" 
  emptyText="Custom No Data Message"
/&gt;`)],-1))]),e("div",ie,[t[38]||(t[38]=e("h3",null,"Row/Column Spanning",-1)),e("div",de,[l(i(d),{columns:z.value,data:A.value,bordered:!0,spanMethod:I},null,8,["columns","data"])]),t[39]||(t[39]=e("pre",{class:"code-block"},[e("code",null,`<PPTable 
  :columns="columns" 
  :data="data" 
  :bordered="true"
  :spanMethod="handleSpan"
/>

// In script:
const handleSpan = ({ rowIndex, columnIndex }) => {
  // Merge first column for rows 0 and 1
  if (columnIndex === 0) {
    if (rowIndex % 2 === 0) {
      return { rowspan: 2, colspan: 1 };
    } else {
      return { rowspan: 0, colspan: 0 };
    }
  }
};`)],-1))]),t[42]||(t[42]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[43]||(t[43]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Table</h2>
    <p>A data table component with sorting, pagination, selection, and expansion support.</p>

    <!-- Basic & Styling -->
    <div class="demo-box">
      <h3>Basic & Styling</h3>
      <div class="demo-content">
        <div style="display: flex; gap: 16px; margin-bottom: 16px; flex-wrap: wrap; align-items: center;">
          <label><input type="checkbox" v-model="isStriped"> Striped</label>
          <label><input type="checkbox" v-model="isBordered"> Bordered</label>
          <label><input type="checkbox" v-model="isCompact"> Compact</label>
        </div>

        <PPTable 
          :columns="columns" 
          :data="basicData"
          :striped="isStriped"
          :bordered="isBordered"
          :compact="isCompact"
        >
          <template #status="{ row }">
            <span class="status-badge" :class="\`is-\${row.status}\`">{{ row.status }}</span>
          </template>
        </PPTable>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPTable 
  :columns="columns" 
  :data="data"
  :striped="true"
  :bordered="true"
  :compact="false"
&gt;
  &lt;template #status="{ row }"&gt;
    &lt;span :class="\`is-\${row.status}\`"&gt;{{ row.status }}&lt;/span&gt;
  &lt;/template&gt;
&lt;/PPTable&gt;</code></pre>
    </div>

    <!-- Pagination -->
    <div class="demo-box">
      <h3>Pagination</h3>
      <div class="demo-content">
        <div style="display: flex; gap: 16px; margin-bottom: 16px; flex-wrap: wrap; align-items: center;">
          <label><input type="checkbox" v-model="showFirstLast"> First/Last</label>
          <select v-model="paginationVariant" style="padding: 4px 8px; border-radius: 4px; border: 1px solid #ccc;">
            <option value="outline">Pagination: Outline</option>
            <option value="solid">Pagination: Solid</option>
            <option value="ghost">Pagination: Ghost</option>
          </select>
          <select v-model="paginationShape" style="padding: 4px 8px; border-radius: 4px; border: 1px solid #ccc;">
            <option value="rounded">Shape: Rounded</option>
            <option value="circle">Shape: Circle</option>
          </select>
          <select v-model="paginationAlign" style="padding: 4px 8px; border-radius: 4px; border: 1px solid #ccc;">
            <option value="left">Align: Left</option>
            <option value="center">Align: Center</option>
            <option value="right">Align: Right</option>
          </select>
          <select v-model="sizeChangerPosition" style="padding: 4px 8px; border-radius: 4px; border: 1px solid #ccc;">
            <option value="left">Size Changer: Left</option>
            <option value="right">Size Changer: Right</option>
          </select>
        </div>

        <PPTable 
          :columns="columns" 
          :data="tableData" 
          :pagination="true" 
          :pageSize="5"
          :paginationVariant="paginationVariant"
          :paginationShape="paginationShape"
          :paginationAlign="paginationAlign"
          :showSizeChanger="true"
          :sizeChangerPosition="sizeChangerPosition"
          :pageSizes="[5, 10, 15, 20]"
          :showFirstLast="showFirstLast"
        >
          <template #status="{ row }">
            <span class="status-badge" :class="\`is-\${row.status}\`">{{ row.status }}</span>
          </template>
        </PPTable>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPTable 
  :columns="columns" 
  :data="data" 
  :pagination="true" 
  :pageSize="5"
  paginationVariant="outline"
  paginationShape="rounded"
  paginationAlign="right"
  :showSizeChanger="true"
  :pageSizes="[5, 10, 15, 20]"
  :showFirstLast="true"
/&gt;</code></pre>
    </div>

    <!-- Selection -->
    <div class="demo-box">
      <h3>Selectable Rows</h3>
      <div class="demo-content">
        <div style="display: flex; gap: 16px; margin-bottom: 16px; flex-wrap: wrap; align-items: center;">
          <label><input type="checkbox" v-model="isMultiple"> Multiple</label>
        </div>

        <PPTable 
          :columns="columns" 
          :data="basicData" 
          :selectable="true"
          :multiple="isMultiple"
          v-model="selectedRows"
        >
          <template #status="{ row }">
            <span class="status-badge" :class="\`is-\${row.status}\`">{{ row.status }}</span>
          </template>
        </PPTable>
        
        <div style="margin-top: 16px; padding: 12px; background: #f0f0f0; border-radius: 4px; font-size: 14px;">
          <strong>Selected IDs:</strong> {{ selectedRows.map(r => r.id).join(', ') || 'None' }}
        </div>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPTable 
  :columns="columns" 
  :data="data" 
  :selectable="true"
  :multiple="true"
  v-model="selectedRows"
/&gt;</code></pre>
    </div>

    <!-- Expandable -->
    <div class="demo-box">
      <h3>Expandable Rows</h3>
      <div class="demo-content">
        <PPTable 
          :columns="columns" 
          :data="basicData" 
          :expandable="true"
        >
          <template #status="{ row }">
            <span class="status-badge" :class="\`is-\${row.status}\`">{{ row.status }}</span>
          </template>
          
          <template #expanded="{ row }">
            <div style="padding: 16px; background-color: #f9f9f9; border-radius: 8px; border: 1px dashed #ccc;">
              <strong>Expanded details for {{ row.name }}</strong>
              <p style="margin-top: 8px;">ID: {{ row.id }}</p>
              <p>Role: {{ row.role }}</p>
              <p>Status: {{ row.status }}</p>
            </div>
          </template>
        </PPTable>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPTable 
  :columns="columns" 
  :data="data" 
  :expandable="true"
&gt;
  &lt;template #expanded="{ row }"&gt;
    &lt;div&gt;Expanded details for {{ row.name }}&lt;/div&gt;
  &lt;/template&gt;
&lt;/PPTable&gt;</code></pre>
    </div>

    <!-- Loading State -->
    <div class="demo-box">
      <h3>Loading State</h3>
      <div class="demo-content">
        <div style="display: flex; gap: 16px; margin-bottom: 16px; flex-wrap: wrap; align-items: center;">
          <label><input type="checkbox" v-model="isLoading"> Loading</label>
        </div>
        <PPTable 
          :columns="columns" 
          :data="basicData" 
          :loading="isLoading"
          :skeletonRows="4"
        >
          <template #status="{ row }">
            <span class="status-badge" :class="\`is-\${row.status}\`">{{ row.status }}</span>
          </template>
        </PPTable>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPTable 
  :columns="columns" 
  :data="data" 
  :loading="true"
  :skeletonRows="4"
/&gt;</code></pre>
    </div>

    <!-- Row/Column Spanning -->
    <div class="demo-box">
      <h3>Row/Column Spanning</h3>
      <div class="demo-content">
        <PPTable 
          :columns="spanColumns" 
          :data="spanData" 
          :bordered="true"
          :spanMethod="handleSpan"
        />
      </div>
      <pre class="code-block" v-pre><code>&lt;PPTable 
  :columns="columns" 
  :data="data" 
  :bordered="true"
  :spanMethod="handleSpan"
/&gt;

// In script:
const handleSpan = ({ rowIndex, columnIndex }) =&gt; {
  // Merge first column for rows 0 and 1
  if (columnIndex === 0) {
    if (rowIndex % 2 === 0) {
      return { rowspan: 2, colspan: 1 };
    } else {
      return { rowspan: 0, colspan: 0 };
    }
  }
};</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPTable } from '@phanna/ui-framework';

const columns = ref([
  { key: 'id', title: 'ID', width: '60px', sortable: true },
  { key: 'name', title: 'Name', sortable: true },
  { key: 'role', title: 'Role', sortable: true },
  { key: 'status', title: 'Status' }
]);

const isStriped = ref(false);
const isBordered = ref(false);
const isCompact = ref(false);

const showFirstLast = ref(true);
const paginationVariant = ref('outline');
const paginationShape = ref('rounded');
const paginationAlign = ref('right');
const sizeChangerPosition = ref('left');

const isMultiple = ref(true);
const selectedRows = ref<any[]>([]);

const isLoading = ref(true);

const spanColumns = ref([
  { key: 'category', title: 'Category' },
  { key: 'name', title: 'Item Name' },
  { key: 'price', title: 'Price' }
]);

const spanData = ref([
  { id: 1, category: 'Fruits', name: 'Apple', price: '$1.00' },
  { id: 2, category: 'Fruits', name: 'Banana', price: '$0.50' },
  { id: 3, category: 'Vegetables', name: 'Carrot', price: '$0.80' },
  { id: 4, category: 'Vegetables', name: 'Broccoli', price: '$1.20' }
]);

const handleSpan = ({ rowIndex, columnIndex }: { row: any, column: any, rowIndex: number, columnIndex: number }) => {
  // Merge the 'Category' column (columnIndex === 0) for every 2 rows
  if (columnIndex === 0) {
    if (rowIndex % 2 === 0) {
      return { rowspan: 2, colspan: 1 }; // span this row to cover the next one
    } else {
      return { rowspan: 0, colspan: 0 }; // hide this row's cell
    }
  }
};

const basicData = ref([
  { id: 1, name: 'User 1', role: 'Admin', status: 'active' },
  { id: 2, name: 'User 2', role: 'Editor', status: 'inactive' },
  { id: 3, name: 'User 3', role: 'Viewer', status: 'active' },
  { id: 4, name: 'User 4', role: 'Admin', status: 'inactive' }
]);

const tableData = ref(Array.from({ length: 24 }).map((_, i) => ({
  id: i + 1,
  name: \`User \${i + 1}\`,
  role: i % 3 === 0 ? 'Admin' : i % 2 === 0 ? 'Editor' : 'Viewer',
  status: i % 4 === 0 ? 'inactive' : 'active'
})));
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 4px;
}
.status-badge {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
  text-transform: capitalize;
}
.status-badge.is-active {
  background-color: #e8f5e9;
  color: #2e7d32;
}
.status-badge.is-inactive {
  background-color: #ffebee;
  color: #c62828;
}
</style>
`)])],-1))],64))}}),ge=U(re,[["__scopeId","data-v-e019a246"]]);export{ge as T};
