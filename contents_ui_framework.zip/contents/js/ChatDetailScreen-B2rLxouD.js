import{d as l,o as c,j as d,l as a,a as t,w as o,A as v,y as m,u as s,aO as p,M as b,aP as u,aQ as g,L as h,aR as f,aS as y,n as w,p as B}from"../vendors/vendor-ah_eQdvw.js";import{P as k,a as i,Z as _,a0 as n,a1 as C}from"./AccountCardSection-DXixqG3L.js";import{_ as P}from"./App-D7rwXoHs.js";const A={class:"screen-preview-container"},O={class:"header-actions"},S={class:"chat-detail-screen"},z={class:"chat-body",ref:"chatBody"},x={class:"message-row received"},D={class:"message-row received align-top"},M={class:"message-row received"},V={class:"chat-footer"},L=l({__name:"ChatDetailScreen",setup(N){const r=B(!1);return(T,e)=>(c(),d("div",A,[a("div",O,[t(s(k),{variant:"primary",size:"small",onClick:e[0]||(e[0]=I=>r.value=!r.value)},{default:o(()=>[v(" Toggle "+m(r.value?"Light":"Dark")+" Mode ",1)]),_:1})]),a("div",{class:w(["phone-mockup",{"dark-mode":r.value}])},[a("div",S,[t(s(_),{title:"Bryan",class:"transparent-appbar"},{left:o(()=>[t(s(i),{icon:s(g),color:"transparent",class:"header-icon-btn"},null,8,["icon"])]),right:o(()=>[t(s(i),{icon:s(p),color:"transparent",class:"header-icon-btn"},null,8,["icon"]),t(s(i),{icon:s(b),color:"transparent",class:"header-icon-btn"},null,8,["icon"]),t(s(i),{icon:s(u),color:"transparent",class:"header-icon-btn"},null,8,["icon"])]),_:1}),a("div",z,[a("div",x,[t(s(n),{src:"https://i.pravatar.cc/150?img=11",name:"Bryan",size:"md",class:"msg-avatar"}),e[1]||(e[1]=a("div",{class:"message-bubble received-bubble"}," Looking forward to the trip. ",-1))]),e[4]||(e[4]=a("div",{class:"message-row sent"},[a("div",{class:"message-bubble sent-bubble"}," Same! Can't wait. ")],-1)),e[5]||(e[5]=a("div",{class:"message-timestamp"}," Today 8:43 AM ",-1)),a("div",D,[t(s(n),{src:"https://i.pravatar.cc/150?img=11",name:"Bryan",size:"md",class:"msg-avatar"}),e[2]||(e[2]=h('<div class="message-bubble received-bubble rich-card" data-v-de64eddf><img src="https://picsum.photos/400/200?random=1" alt="Antelope Canyon" class="rich-card-image" data-v-de64eddf><div class="rich-card-content" data-v-de64eddf><div class="rich-card-title" data-v-de64eddf>Antelope Canyon guide tour</div><div class="rich-card-subtitle" data-v-de64eddf>airbnb.com</div></div></div>',1))]),a("div",M,[t(s(n),{src:"https://i.pravatar.cc/150?img=11",name:"Bryan",size:"md",class:"msg-avatar"}),e[3]||(e[3]=a("div",{class:"message-bubble received-bubble"}," What do you think? ",-1))]),e[6]||(e[6]=a("div",{class:"message-row sent"},[a("div",{class:"message-bubble sent-bubble"}," Oh yes this looks great! ")],-1))],512),a("div",V,[t(s(i),{icon:s(f),color:"transparent",class:"footer-icon-btn"},null,8,["icon"]),t(s(i),{icon:s(y),color:"transparent",class:"footer-icon-btn"},null,8,["icon"]),t(s(C),{placeholder:"Message",class:"chat-input"})]),e[7]||(e[7]=a("div",{class:"home-indicator"},null,-1))])],2),e[8]||(e[8]=a("div",{class:"usage-section"},[a("h3",null,"Code Usage"),a("pre",{class:"code-block"},[a("code",null,`
<template>
  <div class="chat-detail-screen">
    <PPAppBar title="Bryan" class="transparent-appbar">
      <template #left>
        <PPIconButton :icon="arrowBackOutline" color="transparent" class="header-icon-btn" />
      </template>
    </PPAppBar>
    
    <div class="chat-body">
      <div class="message-row received">
        <PPAvatar src="https://i.pravatar.cc/150?img=11" name="Bryan" size="md" />
        <div class="message-bubble received-bubble">
          Looking forward to the trip.
        </div>
      </div>
      <div class="message-row sent">
        <div class="message-bubble sent-bubble">
          Same! Can't wait.
        </div>
      </div>
    </div>
  </div>
</template>
      `)])],-1))]))}}),Q=P(L,[["__scopeId","data-v-de64eddf"]]);export{Q as C};
