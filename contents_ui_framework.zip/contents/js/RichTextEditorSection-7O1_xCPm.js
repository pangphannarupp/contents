import{bm as l}from"./AccountCardSection-DXixqG3L.js";import{d as u,o as m,j as g,l as t,a as d,u as a,A as c,F as x,p as i}from"../vendors/vendor-ah_eQdvw.js";import{_ as h}from"./App-D7rwXoHs.js";const v={class:"component-section"},b={class:"demo-box"},f={class:"demo-content"},y={class:"demo-box"},T={class:"demo-content"},C=u({__name:"RichTextEditorSection",setup(S){const s=i("<h2>Welcome to the Editor</h2><p>This is a <b>lightweight</b> editor built specifically for standard use cases!</p><ul><li>Bold and Italic</li><li>Headings</li><li>Lists (like this one)</li><li>And Links</li></ul>"),n=i("<p>Click the Star or Box icon in the toolbar!</p>"),p=i([{icon:"⭐",title:"Insert Gold Star",html:'<span style="color: gold; font-size: 24px;">★</span>'},{icon:"📦",title:"Insert Alert Box",action:({insertHTML:r})=>{r('<div style="border: 1px solid #ff9800; padding: 16px; border-radius: 8px; background: #fff3e0; color: #e65100; margin: 16px 0;"><strong>Alert:</strong> This is a custom HTML block inserted via API!</div>')}}]);return(r,o)=>(m(),g(x,null,[t("div",v,[o[9]||(o[9]=t("h2",null,"Rich Text Editor",-1)),o[10]||(o[10]=t("p",null,"A native, lightweight WYSIWYG editor for standard text formatting and content creation without heavy dependencies.",-1)),t("div",b,[o[2]||(o[2]=t("h3",null,"Basic Editor",-1)),o[3]||(o[3]=t("p",{class:"helper-text"},"Supports v-model binding directly to HTML output.",-1)),t("div",f,[d(a(l),{modelValue:s.value,"onUpdate:modelValue":o[0]||(o[0]=e=>s.value=e),placeholder:"Start writing your amazing story...",minHeight:"250px"},null,8,["modelValue"])]),o[4]||(o[4]=t("div",{class:"output-preview"},[t("h4",null,"Bound HTML Output:"),t("pre",null,[t("code",null,"{{ editorContent }}")])],-1)),o[5]||(o[5]=t("pre",{class:"code-block"},[t("code",null,`<PPRichTextEditor 
  v-model="editorContent" 
  placeholder="Start writing your amazing story..."
  minHeight="250px"
/>`)],-1))]),t("div",y,[o[6]||(o[6]=t("h3",null,"Custom Toolbar Buttons",-1)),o[7]||(o[7]=t("p",{class:"helper-text"},[c("You can add your own toolbar buttons using the "),t("code",null,"customButtons"),c(" prop to insert custom HTML or trigger custom actions.")],-1)),t("div",T,[d(a(l),{modelValue:n.value,"onUpdate:modelValue":o[1]||(o[1]=e=>n.value=e),placeholder:"Try the custom buttons in the toolbar...",minHeight:"150px",customButtons:p.value},null,8,["modelValue","customButtons"])]),o[8]||(o[8]=t("pre",{class:"code-block"},[t("code",null,`<PPRichTextEditor 
  v-model="content"
  :customButtons="[
    { icon: '⭐', title: 'Insert Star', html: '<span style=\\'color: gold; font-size: 24px;\\'>★</span>' },
    { icon: '📦', title: 'Insert Card', action: ({ insertHTML }) => {
        insertHTML('<div style=\\'border: 1px solid #ccc; padding: 16px; border-radius: 8px; background: #f9f9f9;\\'>Custom Component</div>')
    }}
  ]"
/>`)],-1))]),o[11]||(o[11]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[12]||(o[12]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Rich Text Editor</h2>
    <p>A native, lightweight WYSIWYG editor for standard text formatting and content creation without heavy dependencies.</p>

    <div class="demo-box">
      <h3>Basic Editor</h3>
      <p class="helper-text">Supports v-model binding directly to HTML output.</p>
      
      <div class="demo-content">
        <PPRichTextEditor 
          v-model="editorContent" 
          placeholder="Start writing your amazing story..."
          minHeight="250px"
        />
      </div>

      <div class="output-preview">
        <h4>Bound HTML Output:</h4>
        <pre><code>{{ editorContent }}</code></pre>
      </div>

      <pre class="code-block" v-pre><code>&lt;PPRichTextEditor 
  v-model="editorContent" 
  placeholder="Start writing your amazing story..."
  minHeight="250px"
/&gt;</code></pre>
    </div>

    <div class="demo-box">
      <h3>Custom Toolbar Buttons</h3>
      <p class="helper-text">You can add your own toolbar buttons using the <code>customButtons</code> prop to insert custom HTML or trigger custom actions.</p>
      
      <div class="demo-content">
        <PPRichTextEditor 
          v-model="customEditorContent" 
          placeholder="Try the custom buttons in the toolbar..."
          minHeight="150px"
          :customButtons="myCustomButtons"
        />
      </div>

      <pre class="code-block" v-pre><code>&lt;PPRichTextEditor 
  v-model="content"
  :customButtons="[
    { icon: '⭐', title: 'Insert Star', html: '&lt;span style=\\'color: gold; font-size: 24px;\\'&gt;★&lt;/span&gt;' },
    { icon: '📦', title: 'Insert Card', action: ({ insertHTML }) => {
        insertHTML('&lt;div style=\\'border: 1px solid #ccc; padding: 16px; border-radius: 8px; background: #f9f9f9;\\'&gt;Custom Component&lt;/div&gt;')
    }}
  ]"
/&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPRichTextEditor } from '@phanna/ui-framework';

const editorContent = ref('<h2>Welcome to the Editor</h2><p>This is a <b>lightweight</b> editor built specifically for standard use cases!</p><ul><li>Bold and Italic</li><li>Headings</li><li>Lists (like this one)</li><li>And Links</li></ul>');

const customEditorContent = ref('<p>Click the Star or Box icon in the toolbar!</p>');

const myCustomButtons = ref([
  {
    icon: '⭐',
    title: 'Insert Gold Star',
    html: '<span style="color: gold; font-size: 24px;">★</span>'
  },
  {
    icon: '📦',
    title: 'Insert Alert Box',
    action: ({ insertHTML }: { insertHTML: (html: string) => void }) => {
      insertHTML('<div style="border: 1px solid #ff9800; padding: 16px; border-radius: 8px; background: #fff3e0; color: #e65100; margin: 16px 0;"><strong>Alert:</strong> This is a custom HTML block inserted via API!</div>');
    }
  }
]);
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
}
.helper-text {
  font-size: 13px;
  color: #666;
  margin-bottom: 16px;
}
.code-block {
  background: #282c34;
  color: #abb2bf;
  padding: 16px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 14px;
  line-height: 1.5;
  margin-top: 24px;
}

.output-preview {
  margin-top: 24px;
  padding: 16px;
  background: #f5f7fa;
  border-left: 4px solid #003399;
  border-radius: 4px;
}

.output-preview h4 {
  margin-top: 0;
  margin-bottom: 12px;
  font-size: 14px;
  color: #333;
}

.output-preview pre {
  margin: 0;
  white-space: pre-wrap;
  word-wrap: break-word;
  font-family: monospace;
  font-size: 13px;
  color: #d63384;
}
</style>
`)])],-1))],64))}}),H=h(C,[["__scopeId","data-v-82c0244e"]]);export{H as R};
