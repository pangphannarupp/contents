import{H as s,I as i,Q as o,J as n,K as d,S as u,V as p,X as c}from"./AccountCardSection-DXixqG3L.js";import{d as v,o as h,j as g,l as a,a as r,u as t,F as f}from"../vendors/vendor-ah_eQdvw.js";const m={class:"guide-section"},y={class:"variant-group"},b={class:"variant-group"},P={class:"variant-group",style:{display:"flex",gap:"32px","justify-content":"center","flex-wrap":"wrap"}},C={class:"variant-group"},x={class:"variant-group"},S={class:"variant-group",style:{display:"flex",gap:"32px","justify-content":"center","flex-wrap":"wrap"}},T=v({__name:"ChartsSection",setup(k){return(w,e)=>(h(),g(f,null,[a("div",m,[e[8]||(e[8]=a("h2",null,"Charts & Graphs",-1)),a("div",y,[e[0]||(e[0]=a("h3",null,"Scatter & Bubble Chart",-1)),r(t(s),{data:[{x:10,y:20,r:12,color:"#eb445a"},{x:30,y:70,r:8,color:"var(--pp-primary-light, #3880ff)"},{x:50,y:40,r:20,color:"#2dd36f"},{x:80,y:90,r:15,color:"#ffc409"},{x:90,y:10,r:6,color:"#92949c"}],maxX:100,maxY:100})]),a("div",b,[e[1]||(e[1]=a("h3",null,"Funnel Chart",-1)),r(t(i),{data:[{label:"Visitors",value:1e4},{label:"Signups",value:5e3},{label:"Cart Adds",value:2500},{label:"Purchases",value:500}],height:240})]),a("div",P,[a("div",null,[e[2]||(e[2]=a("h3",{style:{"text-align":"center"}},"Progress Gauge",-1)),r(t(o),{value:82,max:100,size:180,thickness:14,gradient:["#3dc2ff","var(--pp-primary-light, #3880ff)"],label:"Performance",format:l=>l+"%"},null,8,["format"])]),a("div",null,[e[3]||(e[3]=a("h3",{style:{"text-align":"center"}},"Radar Chart",-1)),r(t(n),{size:180,data:[80,60,90,70,85],labels:["Speed","Power","Agility","Stamina","Skill"],color:"#eb445a"})])]),a("div",C,[e[4]||(e[4]=a("h3",null,"Line Chart (Gradients & Dashes)",-1)),r(t(d),{data:[10,30,20,50,40,80,60],labels:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],gradient:["var(--pp-primary-light, #3880ff)","#2dd36f"],dashed:!0,showPoints:!0,dashedGrid:!0,strokeWidth:4})]),a("div",x,[e[5]||(e[5]=a("h3",null,"Bar Chart (Thick Gradients)",-1)),r(t(u),{data:[{label:"Jan",value:40,gradient:["var(--pp-primary-light, #3880ff)","#2dd36f"]},{label:"Feb",value:70,gradient:["#ffc409","#eb445a"]},{label:"Mar",value:25,gradient:["#2dd36f","#3dc2ff"]},{label:"Apr",value:90,gradient:["#eb445a","#92949c"]}],barWidth:24,barRadius:12})]),a("div",S,[a("div",null,[e[6]||(e[6]=a("h3",{style:{"text-align":"center"}},"Donut Chart (Pill)",-1)),r(t(p),{size:140,data:[{value:45,color:"var(--pp-primary-light, #3880ff)"},{value:25,color:"#2dd36f"},{value:30,color:"#ffc409"}],label:"Total",value:"100%",rounded:!0,thickness:24})]),a("div",null,[e[7]||(e[7]=a("h3",{style:{"text-align":"center"}},"Pie Chart",-1)),r(t(c),{size:140,data:[{value:40,color:"#eb445a"},{value:60,color:"var(--pp-primary-light, #3880ff)"}]})])]),e[9]||(e[9]=a("div",{class:"variant-group"},[a("h3",null,"Customizing CSS"),a("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),a("pre",{class:"code-block"},[a("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[10]||(e[10]=a("div",{class:"variant-group",style:{"margin-top":"40px"}},[a("h3",null,"Full Page Source Code"),a("p",{class:"custom-guide"},"Complete source code for this section."),a("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[a("code",null,`<template>
<div class="guide-section">
        <h2>Charts & Graphs</h2>

        <div class="variant-group">
          <h3>Scatter & Bubble Chart</h3>
          <PPScatterChart 
            :data="[
              { x: 10, y: 20, r: 12, color: '#eb445a' },
              { x: 30, y: 70, r: 8, color: 'var(--pp-primary-light, #3880ff)' },
              { x: 50, y: 40, r: 20, color: '#2dd36f' },
              { x: 80, y: 90, r: 15, color: '#ffc409' },
              { x: 90, y: 10, r: 6, color: '#92949c' }
            ]"
            :maxX="100"
            :maxY="100"
          />
        </div>

        <div class="variant-group">
          <h3>Funnel Chart</h3>
          <PPFunnelChart 
            :data="[
              { label: 'Visitors', value: 10000 },
              { label: 'Signups', value: 5000 },
              { label: 'Cart Adds', value: 2500 },
              { label: 'Purchases', value: 500 }
            ]"
            :height="240"
          />
        </div>


        <div class="variant-group" style="display: flex; gap: 32px; justify-content: center; flex-wrap: wrap;">
          <div>
            <h3 style="text-align: center;">Progress Gauge</h3>
            <PPProgressGauge 
              :value="82"
              :max="100"
              :size="180"
              :thickness="14"
              :gradient="['#3dc2ff', 'var(--pp-primary-light, #3880ff)']"
              label="Performance"
              :format="(val) => val + '%'"
            />
          </div>
          <div>
            <h3 style="text-align: center;">Radar Chart</h3>
            <PPRadarChart 
              :size="180"
              :data="[80, 60, 90, 70, 85]"
              :labels="['Speed', 'Power', 'Agility', 'Stamina', 'Skill']"
              color="#eb445a"
            />
          </div>
        </div>

        
        <div class="variant-group">
          <h3>Line Chart (Gradients & Dashes)</h3>
          <PPLineChart 
            :data="[10, 30, 20, 50, 40, 80, 60]" 
            :labels="['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']"
            :gradient="['var(--pp-primary-light, #3880ff)', '#2dd36f']"
            :dashed="true"
            :showPoints="true"
            :dashedGrid="true"
            :strokeWidth="4"
          />
        </div>

        <div class="variant-group">
          <h3>Bar Chart (Thick Gradients)</h3>
          <PPBarChart 
            :data="[
              { label: 'Jan', value: 40, gradient: ['var(--pp-primary-light, #3880ff)', '#2dd36f'] },
              { label: 'Feb', value: 70, gradient: ['#ffc409', '#eb445a'] },
              { label: 'Mar', value: 25, gradient: ['#2dd36f', '#3dc2ff'] },
              { label: 'Apr', value: 90, gradient: ['#eb445a', '#92949c'] }
            ]"
            :barWidth="24"
            :barRadius="12"
          />
        </div>

        <div class="variant-group" style="display: flex; gap: 32px; justify-content: center; flex-wrap: wrap;">
          <div>
            <h3 style="text-align: center;">Donut Chart (Pill)</h3>
            <PPDonutChart 
              :size="140"
              :data="[
                { value: 45, color: 'var(--pp-primary-light, #3880ff)' },
                { value: 25, color: '#2dd36f' },
                { value: 30, color: '#ffc409' }
              ]"
              label="Total"
              value="100%"
              :rounded="true"
              :thickness="24"
            />
          </div>
          <div>
            <h3 style="text-align: center;">Pie Chart</h3>
            <PPPieChart 
              :size="140"
              :data="[
                { value: 40, color: '#eb445a' },
                { value: 60, color: 'var(--pp-primary-light, #3880ff)' }
              ]"
            />
          </div>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{T as _};
