import{h as s,i as e}from"../main.js";function a(t){return s("MuiListItemIcon",t)}const l=e("MuiListItemIcon",["root","alignItemsFlexStart"]);export{a as g,l};
