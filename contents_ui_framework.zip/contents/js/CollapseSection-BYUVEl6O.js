import{a7 as s,a8 as i}from"./AccountCardSection-DXixqG3L.js";import{d as m,o as c,j as C,l as t,a as o,w as l,u as a,A as n,y as d,F as g,p as u}from"../vendors/vendor-ah_eQdvw.js";const v={class:"guide-section"},f={class:"variant-group"},h={class:"component-demo"},b={style:{"margin-top":"16px","font-size":"12px",color:"#666"}},I={class:"variant-group",style:{"margin-top":"32px"}},S={class:"component-demo"},y={style:{"margin-top":"16px","font-size":"12px",color:"#666"}},k={class:"variant-group",style:{"margin-top":"32px"}},x={class:"component-demo"},A={class:"component-demo"},O={class:"component-demo"},w=m({__name:"CollapseSection",setup(M){const P=u(["1"]),r=u("A");return(B,e)=>(c(),C(g,null,[t("div",v,[e[29]||(e[29]=t("p",{class:"guide-desc"},"A flexible container for hiding and showing content panels.",-1)),t("div",f,[e[5]||(e[5]=t("h3",null,"Standard Mode (Multiple Open)",-1)),e[6]||(e[6]=t("p",{class:"custom-guide"},"Multiple panels can be expanded simultaneously.",-1)),t("div",h,[o(a(i),{modelValue:P.value,"onUpdate:modelValue":e[0]||(e[0]=p=>P.value=p)},{default:l(()=>[o(a(s),{name:"1",title:"Panel 1"},{default:l(()=>[...e[2]||(e[2]=[n(" Content for Panel 1. This can contain text, forms, or any other components. ",-1)])]),_:1}),o(a(s),{name:"2",title:"Panel 2"},{default:l(()=>[...e[3]||(e[3]=[n(" Content for Panel 2. ",-1)])]),_:1}),o(a(s),{name:"3",title:"Panel 3 (Disabled)",disabled:""},{default:l(()=>[...e[4]||(e[4]=[n(" You shouldn't see this. ",-1)])]),_:1})]),_:1},8,["modelValue"]),t("p",b,"Active panels: "+d(P.value),1)]),e[7]||(e[7]=t("pre",{class:"code-block"},[t("code",null,`<PPCollapse v-model="collapseModel1">
  <PPCollapseItem name="1" title="Panel 1">
    Content for Panel 1. This can contain text, forms, or any other components.
  </PPCollapseItem>
  <PPCollapseItem name="2" title="Panel 2">
    Content for Panel 2.
  </PPCollapseItem>
  <PPCollapseItem name="3" title="Panel 3 (Disabled)" disabled>
    You shouldn't see this.
  </PPCollapseItem>
</PPCollapse>`)],-1))]),t("div",I,[e[12]||(e[12]=t("h3",null,"Accordion Mode (Single Open)",-1)),e[13]||(e[13]=t("p",{class:"custom-guide"},"Only one panel can be open at a time.",-1)),t("div",S,[o(a(i),{modelValue:r.value,"onUpdate:modelValue":e[1]||(e[1]=p=>r.value=p),accordion:""},{default:l(()=>[o(a(s),{name:"A",title:"Section A"},{default:l(()=>[...e[8]||(e[8]=[n(" Content for Section A. ",-1)])]),_:1}),o(a(s),{name:"B"},{title:l(()=>[...e[9]||(e[9]=[t("strong",{style:{color:"var(--pp-primary-color)"}},"Custom Header B",-1)])]),default:l(()=>[e[10]||(e[10]=n(" Content for Section B. ",-1))]),_:1}),o(a(s),{name:"C",title:"Section C"},{default:l(()=>[...e[11]||(e[11]=[n(" Content for Section C. ",-1)])]),_:1})]),_:1},8,["modelValue"]),t("p",y,"Active panel: "+d(r.value),1)]),e[14]||(e[14]=t("pre",{class:"code-block"},[t("code",null,'<PPCollapse v-model="collapseModel2" accordion>...</PPCollapse>')],-1))]),t("div",k,[e[21]||(e[21]=t("h3",null,"Variants",-1)),e[22]||(e[22]=t("p",{class:"custom-guide"},[n("Change the visual style using the "),t("code",null,"variant"),n(" prop.")],-1)),e[23]||(e[23]=t("h4",{style:{"margin-top":"16px"}},"Flush Variant",-1)),e[24]||(e[24]=t("p",{class:"guide-desc"},"No outer borders or background.",-1)),t("div",x,[o(a(i),{variant:"flush"},{default:l(()=>[o(a(s),{name:"1",title:"Flush Panel 1"},{default:l(()=>[...e[15]||(e[15]=[n("Content inside flush panel.",-1)])]),_:1}),o(a(s),{name:"2",title:"Flush Panel 2"},{default:l(()=>[...e[16]||(e[16]=[n("Content inside flush panel.",-1)])]),_:1})]),_:1})]),e[25]||(e[25]=t("h4",{style:{"margin-top":"24px"}},"Separated Variant",-1)),e[26]||(e[26]=t("p",{class:"guide-desc"},"Each panel acts as an individual card.",-1)),t("div",A,[o(a(i),{variant:"separated"},{default:l(()=>[o(a(s),{name:"1",title:"Separated Panel 1"},{default:l(()=>[...e[17]||(e[17]=[n("Content inside separated panel.",-1)])]),_:1}),o(a(s),{name:"2",title:"Separated Panel 2"},{default:l(()=>[...e[18]||(e[18]=[n("Content inside separated panel.",-1)])]),_:1})]),_:1})]),e[27]||(e[27]=t("h4",{style:{"margin-top":"24px"}},"Filled Variant",-1)),e[28]||(e[28]=t("p",{class:"guide-desc"},"Light colored background for headers.",-1)),t("div",O,[o(a(i),{variant:"filled"},{default:l(()=>[o(a(s),{name:"1",title:"Filled Panel 1"},{default:l(()=>[...e[19]||(e[19]=[n("Content inside filled panel with a white background.",-1)])]),_:1}),o(a(s),{name:"2",title:"Filled Panel 2"},{default:l(()=>[...e[20]||(e[20]=[n("Content inside filled panel with a white background.",-1)])]),_:1})]),_:1})])]),e[30]||(e[30]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-icon-color: /* value */;
  --pp-text-color: /* value */;
  --pp-text-disabled-color: /* value */;
  --pp-text-secondary: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[31]||(e[31]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <p class="guide-desc">A flexible container for hiding and showing content panels.</p>

        <div class="variant-group">
          <h3>Standard Mode (Multiple Open)</h3>
          <p class="custom-guide">Multiple panels can be expanded simultaneously.</p>
          <div class="component-demo">
            <PPCollapse v-model="collapseModel1">
              <PPCollapseItem name="1" title="Panel 1">
                Content for Panel 1. This can contain text, forms, or any other components.
              </PPCollapseItem>
              <PPCollapseItem name="2" title="Panel 2">
                Content for Panel 2.
              </PPCollapseItem>
              <PPCollapseItem name="3" title="Panel 3 (Disabled)" disabled>
                You shouldn't see this.
              </PPCollapseItem>
            </PPCollapse>
            <p style="margin-top: 16px; font-size: 12px; color: #666;">Active panels: {{ collapseModel1 }}</p>
          </div>
          <pre class="code-block"><code>&lt;PPCollapse v-model="collapseModel1"&gt;
  &lt;PPCollapseItem name="1" title="Panel 1"&gt;
    Content for Panel 1. This can contain text, forms, or any other components.
  &lt;/PPCollapseItem&gt;
  &lt;PPCollapseItem name="2" title="Panel 2"&gt;
    Content for Panel 2.
  &lt;/PPCollapseItem&gt;
  &lt;PPCollapseItem name="3" title="Panel 3 (Disabled)" disabled&gt;
    You shouldn't see this.
  &lt;/PPCollapseItem&gt;
&lt;/PPCollapse&gt;</code></pre>
        </div>

        <div class="variant-group" style="margin-top: 32px;">
          <h3>Accordion Mode (Single Open)</h3>
          <p class="custom-guide">Only one panel can be open at a time.</p>
          <div class="component-demo">
            <PPCollapse v-model="collapseModel2" accordion>
              <PPCollapseItem name="A" title="Section A">
                Content for Section A.
              </PPCollapseItem>
              <PPCollapseItem name="B">
                <template #title>
                  <strong style="color: var(--pp-primary-color);">Custom Header B</strong>
                </template>
                Content for Section B.
              </PPCollapseItem>
              <PPCollapseItem name="C" title="Section C">
                Content for Section C.
              </PPCollapseItem>
            </PPCollapse>
            <p style="margin-top: 16px; font-size: 12px; color: #666;">Active panel: {{ collapseModel2 }}</p>
          </div>
          <pre class="code-block"><code>&lt;PPCollapse v-model="collapseModel2" accordion&gt;...&lt;/PPCollapse&gt;</code></pre>
        </div>

        <div class="variant-group" style="margin-top: 32px;">
          <h3>Variants</h3>
          <p class="custom-guide">Change the visual style using the <code>variant</code> prop.</p>
          
          <h4 style="margin-top: 16px;">Flush Variant</h4>
          <p class="guide-desc">No outer borders or background.</p>
          <div class="component-demo">
            <PPCollapse variant="flush">
              <PPCollapseItem name="1" title="Flush Panel 1">Content inside flush panel.</PPCollapseItem>
              <PPCollapseItem name="2" title="Flush Panel 2">Content inside flush panel.</PPCollapseItem>
            </PPCollapse>
          </div>
          
          <h4 style="margin-top: 24px;">Separated Variant</h4>
          <p class="guide-desc">Each panel acts as an individual card.</p>
          <div class="component-demo">
            <PPCollapse variant="separated">
              <PPCollapseItem name="1" title="Separated Panel 1">Content inside separated panel.</PPCollapseItem>
              <PPCollapseItem name="2" title="Separated Panel 2">Content inside separated panel.</PPCollapseItem>
            </PPCollapse>
          </div>
          
          <h4 style="margin-top: 24px;">Filled Variant</h4>
          <p class="guide-desc">Light colored background for headers.</p>
          <div class="component-demo">
            <PPCollapse variant="filled">
              <PPCollapseItem name="1" title="Filled Panel 1">Content inside filled panel with a white background.</PPCollapseItem>
              <PPCollapseItem name="2" title="Filled Panel 2">Content inside filled panel with a white background.</PPCollapseItem>
            </PPCollapse>
          </div>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-icon-color: /* value */;
  --pp-text-color: /* value */;
  --pp-text-disabled-color: /* value */;
  --pp-text-secondary: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const collapseModel1 = ref(['1']);

const collapseModel2 = ref('A');



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{w as _};
