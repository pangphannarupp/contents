import{i as e,h as s}from"../main.js";function a(t){return s("MuiListItemText",t)}const l=e("MuiListItemText",["root","multiline","dense","inset","primary","secondary"]);export{a as g,l};
