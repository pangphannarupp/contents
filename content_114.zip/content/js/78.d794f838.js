"use strict";(self["webpackChunkvue_core_client"]=self["webpackChunkvue_core_client"]||[]).push([[78],{78:function(e,t,n){n.r(t),n.d(t,{startStatusTap:function(){return c}});var r=n(65),o=n(74),s=n(587);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const c=()=>{const e=window;e.addEventListener("statusTap",(()=>{(0,r.wj)((()=>{const t=e.innerWidth,n=e.innerHeight,c=document.elementFromPoint(t/2,n/2);if(!c)return;const i=(0,o.a)(c);i&&new Promise((e=>(0,s.c)(i,e))).then((()=>{(0,r.Iu)((async()=>{i.style.setProperty("--overflow","hidden"),await(0,o.s)(i,300),i.style.removeProperty("--overflow")}))}))}))}))}}}]);
//# sourceMappingURL=78.d794f838.js.map