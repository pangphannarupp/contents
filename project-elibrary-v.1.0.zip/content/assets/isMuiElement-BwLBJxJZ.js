import{r}from"./index-BgEvt14v.js";function e(i,a){return r.isValidElement(i)&&a.indexOf(i.type.muiName??i.type?._payload?.value?.muiName)!==-1}export{e as i};
