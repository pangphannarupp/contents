import{d as I,Q as C,o as v,j as f,l as t,a as l,u as o,w as a,A as i,E as d,b9 as x,ba as y,F as b,z as S,p as r}from"../vendors/vendor-ah_eQdvw.js";import{av as k,a4 as O,P as p,Y as w,aw as B}from"./AccountCardSection-DXixqG3L.js";const T={class:"guide-section"},A={class:"variant-group"},D={class:"component-demo"},F={style:{display:"flex",gap:"8px","margin-bottom":"16px","align-items":"center","flex-wrap":"wrap"}},z={style:{width:"200px"}},V={style:{width:"24px",height:"24px","border-radius":"50%",background:"#2dd36f",display:"flex","align-items":"center","justify-content":"center"}},W={style:{display:"flex",gap:"4px","margin-top":"24px","align-items":"center","justify-content":"center"}},R=I({__name:"DynamicIslandSection",setup(K){const s=r(!1),P=r("compact"),u=r("top"),c=r(!1),m=g=>{P.value=g,s.value=!0};return(g,e)=>{const h=C("PPIconButton");return v(),f(b,null,[t("div",T,[e[18]||(e[18]=t("h2",null,"19. Dynamic Island",-1)),t("div",A,[e[15]||(e[15]=t("h3",null,"Interactive Demo",-1)),e[16]||(e[16]=t("p",{class:"custom-guide"},"A fluid, shape-shifting popup that anchors to the top of the screen.",-1)),t("div",D,[t("div",F,[t("div",z,[l(o(k),{modelValue:u.value,"onUpdate:modelValue":e[0]||(e[0]=n=>u.value=n),options:[{label:"Top",value:"top"},{label:"Bottom",value:"bottom"},{label:"Left",value:"left"},{label:"Right",value:"right"}],placeholder:"Select Position"},null,8,["modelValue"])]),l(o(O),{modelValue:c.value,"onUpdate:modelValue":e[1]||(e[1]=n=>c.value=n)},{default:a(()=>[...e[8]||(e[8]=[i("Full Width",-1)])]),_:1},8,["modelValue"])]),l(o(w),null,{default:a(()=>[l(o(p),{onClick:e[2]||(e[2]=n=>m("minimal"))},{default:a(()=>[...e[9]||(e[9]=[i("Minimal",-1)])]),_:1}),l(o(p),{onClick:e[3]||(e[3]=n=>m("compact"))},{default:a(()=>[...e[10]||(e[10]=[i("Compact",-1)])]),_:1}),l(o(p),{onClick:e[4]||(e[4]=n=>m("expanded"))},{default:a(()=>[...e[11]||(e[11]=[i("Expanded",-1)])]),_:1}),l(o(p),{variant:"outline-danger",onClick:e[5]||(e[5]=n=>s.value=!1)},{default:a(()=>[...e[12]||(e[12]=[i("Close",-1)])]),_:1})]),_:1}),l(o(B),{modelValue:s.value,"onUpdate:modelValue":e[7]||(e[7]=n=>s.value=n),state:P.value,position:u.value,fullWidth:c.value,offset:16,autoHideTimeout:P.value==="expanded"?0:3e3},{"compact-left":a(()=>[t("div",V,[l(o(d),{icon:o(x),style:{color:"black","font-size":"14px"}},null,8,["icon"])])]),"compact-center":a(()=>[...e[13]||(e[13]=[i(" 00:14 ",-1)])]),"compact-right":a(()=>[l(o(d),{icon:o(y),style:{color:"#2dd36f","font-size":"20px"}},null,8,["icon"])]),"expanded-header":a(()=>[...e[14]||(e[14]=[t("div",{style:{display:"flex","align-items":"center",gap:"12px"}},[t("img",{src:"https://i.pravatar.cc/150?img=68",style:{width:"48px",height:"48px","border-radius":"50%","object-fit":"cover"}}),t("div",null,[t("h4",{style:{margin:"0","font-size":"16px",color:"white"}},"Jane Doe"),t("p",{style:{margin:"0",color:"#aaa","font-size":"12px"}},"iPhone")])],-1),t("div",{style:{"font-size":"24px",color:"#aaa"}},"00:14",-1)])]),"expanded-body":a(()=>[t("div",W,[(v(),f(b,null,S(5,n=>t("div",{key:n,style:{width:"4px",height:"24px",background:"#2dd36f","border-radius":"2px"}})),64))])]),"expanded-footer":a(()=>[l(h,{color:"danger",style:{"border-radius":"50%",width:"56px",height:"56px"},onClick:e[6]||(e[6]=n=>s.value=!1)},{default:a(()=>[l(o(d),{icon:o(x),style:{transform:"rotate(135deg)"}},null,8,["icon"])]),_:1}),l(h,{color:"success",style:{"border-radius":"50%",width:"56px",height:"56px"}},{default:a(()=>[l(o(d),{icon:o(y)},null,8,["icon"])]),_:1})]),_:1},8,["modelValue","state","position","fullWidth","autoHideTimeout"])]),e[17]||(e[17]=t("pre",{class:"code-block"},[t("code",null,`<PPDynamicIsland 
  v-model="isIslandOpen"
  :state="islandState"
  :position="islandPosition"
  :fullWidth="islandFullWidth"
  :offset="16"
  :autoHideTimeout="islandState === 'expanded' ? 0 : 3000"
>
  <!-- Compact Slots -->
  <template #compact-left>
    <!-- Icon or Avatar -->
  </template>
  <template #compact-center>
    <!-- Title or Text -->
  </template>
  <template #compact-right>
    <!-- Status Icon -->
  </template>

  <!-- Expanded Slots -->
  <template #expanded-header>
    <!-- Caller Info -->
  </template>
  <template #expanded-body>
    <!-- Audio Visualizer / Content -->
  </template>
  <template #expanded-footer>
    <!-- Action Buttons -->
  </template>
</PPDynamicIsland>`)],-1))]),e[19]||(e[19]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-island-accent: /* value */;
  --pp-island-bg: /* value */;
  --pp-island-color: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[20]||(e[20]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>19. Dynamic Island</h2>

        <div class="variant-group">
          <h3>Interactive Demo</h3>
          <p class="custom-guide">A fluid, shape-shifting popup that anchors to the top of the screen.</p>
          <div class="component-demo">
            <div style="display: flex; gap: 8px; margin-bottom: 16px; align-items: center; flex-wrap: wrap;">
              <div style="width: 200px;">
                <PPSelect v-model="islandPosition" :options="[{label: 'Top', value: 'top'}, {label: 'Bottom', value: 'bottom'}, {label: 'Left', value: 'left'}, {label: 'Right', value: 'right'}]" placeholder="Select Position" />
              </div>
              <PPCheckbox v-model="islandFullWidth">Full Width</PPCheckbox>
            </div>
            <PPButtonGroup>
              <PPButton @click="showIsland('minimal')">Minimal</PPButton>
              <PPButton @click="showIsland('compact')">Compact</PPButton>
              <PPButton @click="showIsland('expanded')">Expanded</PPButton>
              <PPButton variant="outline-danger" @click="isIslandOpen = false">Close</PPButton>
            </PPButtonGroup>

            <PPDynamicIsland 
              v-model="isIslandOpen"
              :state="islandState"
              :position="islandPosition"
              :fullWidth="islandFullWidth"
              :offset="16"
              :autoHideTimeout="islandState === 'expanded' ? 0 : 3000"
            >
              <!-- Compact Slots -->
              <template #compact-left>
                <div style="width: 24px; height: 24px; border-radius: 50%; background: #2dd36f; display: flex; align-items: center; justify-content: center;">
                  <ion-icon :icon="phonePortraitOutline" style="color: black; font-size: 14px;"></ion-icon>
                </div>
              </template>
              <template #compact-center>
                00:14
              </template>
              <template #compact-right>
                <ion-icon :icon="volumeHighOutline" style="color: #2dd36f; font-size: 20px;"></ion-icon>
              </template>

              <!-- Expanded Slots -->
              <template #expanded-header>
                <div style="display: flex; align-items: center; gap: 12px;">
                  <img src="https://i.pravatar.cc/150?img=68" style="width: 48px; height: 48px; border-radius: 50%; object-fit: cover;" />
                  <div>
                    <h4 style="margin: 0; font-size: 16px; color: white;">Jane Doe</h4>
                    <p style="margin: 0; color: #aaa; font-size: 12px;">iPhone</p>
                  </div>
                </div>
                <div style="font-size: 24px; color: #aaa;">00:14</div>
              </template>
              
              <template #expanded-body>
                <div style="display: flex; gap: 4px; margin-top: 24px; align-items: center; justify-content: center;">
                  <div v-for="i in 5" :key="i" style="width: 4px; height: 24px; background: #2dd36f; border-radius: 2px;"></div>
                </div>
              </template>

              <template #expanded-footer>
                <PPIconButton color="danger" style="border-radius: 50%; width: 56px; height: 56px;" @click="isIslandOpen = false">
                  <ion-icon :icon="phonePortraitOutline" style="transform: rotate(135deg);"></ion-icon>
                </PPIconButton>
                <PPIconButton color="success" style="border-radius: 50%; width: 56px; height: 56px;">
                  <ion-icon :icon="volumeHighOutline"></ion-icon>
                </PPIconButton>
              </template>
            </PPDynamicIsland>
          </div>
          <pre class="code-block"><code>&lt;PPDynamicIsland 
  v-model="isIslandOpen"
  :state="islandState"
  :position="islandPosition"
  :fullWidth="islandFullWidth"
  :offset="16"
  :autoHideTimeout="islandState === 'expanded' ? 0 : 3000"
&gt;
  &lt;!-- Compact Slots --&gt;
  &lt;template #compact-left&gt;
    &lt;!-- Icon or Avatar --&gt;
  &lt;/template&gt;
  &lt;template #compact-center&gt;
    &lt;!-- Title or Text --&gt;
  &lt;/template&gt;
  &lt;template #compact-right&gt;
    &lt;!-- Status Icon --&gt;
  &lt;/template&gt;

  &lt;!-- Expanded Slots --&gt;
  &lt;template #expanded-header&gt;
    &lt;!-- Caller Info --&gt;
  &lt;/template&gt;
  &lt;template #expanded-body&gt;
    &lt;!-- Audio Visualizer / Content --&gt;
  &lt;/template&gt;
  &lt;template #expanded-footer&gt;
    &lt;!-- Action Buttons --&gt;
  &lt;/template&gt;
&lt;/PPDynamicIsland&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-island-accent: /* value */;
  --pp-island-bg: /* value */;
  --pp-island-color: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const isIslandOpen = ref(false);

const islandState = ref('compact');

const islandPosition = ref('top');

const islandFullWidth = ref(false);

const showIsland = (state: string) => {
  islandState.value = state;
  isIslandOpen.value = true;
};



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64)}}});export{R as _};
