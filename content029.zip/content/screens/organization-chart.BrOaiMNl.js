import{j as G,t as J,Z as se}from"../main.js";import{r as q}from"./vendor-core.DRgC1GeB.js";import{d as _e}from"./vendor-ui.Bpqj8LhC.js";import"./vendor-utils.BVNAvSm4.js";function H(e,r){return r||(r=e.slice(0)),e.raw=r,e}var Pe=function(){function e(t){var n=this;this._insertTag=function(a){n.container.insertBefore(a,n.tags.length===0?n.insertionPoint?n.insertionPoint.nextSibling:n.prepend?n.container.firstChild:n.before:n.tags[n.tags.length-1].nextSibling),n.tags.push(a)},this.isSpeedy=t.speedy===void 0?!0:t.speedy,this.tags=[],this.ctr=0,this.nonce=t.nonce,this.key=t.key,this.container=t.container,this.prepend=t.prepend,this.insertionPoint=t.insertionPoint,this.before=null}var r=e.prototype;return r.hydrate=function(t){t.forEach(this._insertTag)},r.insert=function(t){this.ctr%(this.isSpeedy?65e3:1)==0&&this._insertTag(function(i){var s=document.createElement("style");return s.setAttribute("data-emotion",i.key),i.nonce!==void 0&&s.setAttribute("nonce",i.nonce),s.appendChild(document.createTextNode("")),s.setAttribute("data-s",""),s}(this));var n=this.tags[this.tags.length-1];if(this.isSpeedy){var a=function(i){if(i.sheet)return i.sheet;for(var s=0;s<document.styleSheets.length;s++)if(document.styleSheets[s].ownerNode===i)return document.styleSheets[s]}(n);try{a.insertRule(t,a.cssRules.length)}catch{}}else n.appendChild(document.createTextNode(t));this.ctr++},r.flush=function(){this.tags.forEach(function(t){return t.parentNode&&t.parentNode.removeChild(t)}),this.tags=[],this.ctr=0},e}(),C="-ms-",g="-webkit-",Ge=Math.abs,X=String.fromCharCode,Ie=Object.assign;function we(e){return e.trim()}function f(e,r,t){return e.replace(r,t)}function ne(e,r){return e.indexOf(r)}function $(e,r){return 0|e.charCodeAt(r)}function B(e,r,t){return e.slice(r,t)}function O(e){return e.length}function ie(e){return e.length}function Z(e,r){return r.push(e),e}var z=1,T=1,xe=0,A=0,x=0,W="";function D(e,r,t,n,a,i,s){return{value:e,root:r,parent:t,type:n,props:a,children:i,line:z,column:T,length:s,return:""}}function M(e,r){return Ie(D("",null,null,"",null,null,0),e,{length:-e.length},r)}function Te(){return x=A>0?$(W,--A):0,T--,x===10&&(T=1,z--),x}function S(){return x=A<xe?$(W,A++):0,T++,x===10&&(T=1,z++),x}function N(){return $(W,A)}function K(){return A}function L(e,r){return B(W,e,r)}function F(e){switch(e){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function ke(e){return z=T=1,xe=O(W=e),A=0,[]}function Ce(e){return W="",e}function U(e){return we(L(A-1,ae(e===91?e+2:e===40?e+1:e)))}function We(e){for(;(x=N())&&x<33;)S();return F(e)>2||F(x)>3?"":" "}function Me(e,r){for(;--r&&S()&&!(x<48||x>102||x>57&&x<65||x>70&&x<97););return L(e,K()+(r<6&&N()==32&&S()==32))}function ae(e){for(;S();)switch(x){case e:return A;case 34:case 39:e!==34&&e!==39&&ae(x);break;case 40:e===41&&ae(e);break;case 92:S()}return A}function qe(e,r){for(;S()&&e+x!==57&&(e+x!==84||N()!==47););return"/*"+L(r,A-1)+"*"+X(e===47?e:S())}function Be(e){for(;!F(N());)S();return L(e,A)}function Fe(e){return Ce(Y("",null,null,null,[""],e=ke(e),0,[0],e))}function Y(e,r,t,n,a,i,s,l,m){for(var v=0,h=0,c=s,o=0,p=0,u=0,w=1,E=1,d=1,b=0,k="",_=a,R=i,j=n,y=k;E;)switch(u=b,b=S()){case 40:if(u!=108&&y.charCodeAt(c-1)==58){ne(y+=f(U(b),"&","&\f"),"&\f")!=-1&&(d=-1);break}case 34:case 39:case 91:y+=U(b);break;case 9:case 10:case 13:case 32:y+=We(u);break;case 92:y+=Me(K()-1,7);continue;case 47:switch(N()){case 42:case 47:Z(He(qe(S(),K()),r,t),m);break;default:y+="/"}break;case 123*w:l[v++]=O(y)*d;case 125*w:case 59:case 0:switch(b){case 0:case 125:E=0;case 59+h:p>0&&O(y)-c&&Z(p>32?ce(y+";",n,t,c-1):ce(f(y," ","")+";",n,t,c-2),m);break;case 59:y+=";";default:if(Z(j=oe(y,r,t,v,h,a,l,k,_=[],R=[],c),i),b===123)if(h===0)Y(y,r,j,j,_,i,c,l,R);else switch(o){case 100:case 109:case 115:Y(e,j,j,n&&Z(oe(e,j,j,0,0,a,l,k,a,_=[],c),R),a,R,c,l,n?_:R);break;default:Y(y,j,j,j,[""],R,0,l,R)}}v=h=p=0,w=d=1,k=y="",c=s;break;case 58:c=1+O(y),p=u;default:if(w<1){if(b==123)--w;else if(b==125&&w++==0&&Te()==125)continue}switch(y+=X(b),b*w){case 38:d=h>0?1:(y+="\f",-1);break;case 44:l[v++]=(O(y)-1)*d,d=1;break;case 64:N()===45&&(y+=U(S())),o=N(),h=c=O(k=y+=Be(K())),b++;break;case 45:u===45&&O(y)==2&&(w=0)}}return i}function oe(e,r,t,n,a,i,s,l,m,v,h){for(var c=a-1,o=a===0?i:[""],p=ie(o),u=0,w=0,E=0;u<n;++u)for(var d=0,b=B(e,c+1,c=Ge(w=s[u])),k=e;d<p;++d)(k=we(w>0?o[d]+" "+b:f(b,/&\f/g,o[d])))&&(m[E++]=k);return D(e,r,t,a===0?"rule":l,m,v,h)}function He(e,r,t){return D(e,r,t,"comm",X(x),B(e,2,-2),0)}function ce(e,r,t,n){return D(e,r,t,"decl",B(e,0,n),B(e,n+1,-1),n)}function $e(e,r){switch(function(t,n){return(((n<<2^$(t,0))<<2^$(t,1))<<2^$(t,2))<<2^$(t,3)}(e,r)){case 5103:return g+"print-"+e+e;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return g+e+e;case 5349:case 4246:case 4810:case 6968:case 2756:return g+e+"-moz-"+e+C+e+e;case 6828:case 4268:return g+e+C+e+e;case 6165:return g+e+C+"flex-"+e+e;case 5187:return g+e+f(e,/(\w+).+(:[^]+)/,"-webkit-box-$1$2-ms-flex-$1$2")+e;case 5443:return g+e+C+"flex-item-"+f(e,/flex-|-self/,"")+e;case 4675:return g+e+C+"flex-line-pack"+f(e,/align-content|flex-|-self/,"")+e;case 5548:return g+e+C+f(e,"shrink","negative")+e;case 5292:return g+e+C+f(e,"basis","preferred-size")+e;case 6060:return g+"box-"+f(e,"-grow","")+g+e+C+f(e,"grow","positive")+e;case 4554:return g+f(e,/([^-])(transform)/g,"$1-webkit-$2")+e;case 6187:return f(f(f(e,/(zoom-|grab)/,g+"$1"),/(image-set)/,g+"$1"),e,"")+e;case 5495:case 3959:return f(e,/(image-set\([^]*)/,g+"$1$`$1");case 4968:return f(f(e,/(.+:)(flex-)?(.*)/,"-webkit-box-pack:$3-ms-flex-pack:$3"),/s.+-b[^;]+/,"justify")+g+e+e;case 4095:case 3583:case 4068:case 2532:return f(e,/(.+)-inline(.+)/,g+"$1$2")+e;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(O(e)-1-r>6)switch($(e,r+1)){case 109:if($(e,r+4)!==45)break;case 102:return f(e,/(.+:)(.+)-([^]+)/,"$1-webkit-$2-$3$1-moz-"+($(e,r+3)==108?"$3":"$2-$3"))+e;case 115:return~ne(e,"stretch")?$e(f(e,"stretch","fill-available"),r)+e:e}break;case 4949:if($(e,r+1)!==115)break;case 6444:switch($(e,O(e)-3-(~ne(e,"!important")&&10))){case 107:return f(e,":",":"+g)+e;case 101:return f(e,/(.+:)([^;!]+)(;|!.+)?/,"$1"+g+($(e,14)===45?"inline-":"")+"box$3$1"+g+"$2$3$1"+C+"$2box$3")+e}break;case 5936:switch($(e,r+11)){case 114:return g+e+C+f(e,/[svh]\w+-[tblr]{2}/,"tb")+e;case 108:return g+e+C+f(e,/[svh]\w+-[tblr]{2}/,"tb-rl")+e;case 45:return g+e+C+f(e,/[svh]\w+-[tblr]{2}/,"lr")+e}return g+e+C+e+e}return e}function I(e,r){for(var t="",n=ie(e),a=0;a<n;a++)t+=r(e[a],a,e,r)||"";return t}function Le(e,r,t,n){switch(e.type){case"@import":case"decl":return e.return=e.return||e.value;case"comm":return"";case"@keyframes":return e.return=e.value+"{"+I(e.children,n)+"}";case"rule":e.value=e.props.join(",")}return O(t=I(e.children,n))?e.return=e.value+"{"+t+"}":""}function Ve(e){var r=Object.create(null);return function(t){return r[t]===void 0&&(r[t]=e(t)),r[t]}}var Ze=function(e,r,t){for(var n=0,a=0;n=a,a=N(),n===38&&a===12&&(r[t]=1),!F(a);)S();return L(e,A)},le=new WeakMap,Je=function(e){if(e.type==="rule"&&e.parent&&!(e.length<1)){for(var r=e.value,t=e.parent,n=e.column===t.column&&e.line===t.line;t.type!=="rule";)if(!(t=t.parent))return;if((e.props.length!==1||r.charCodeAt(0)===58||le.get(t))&&!n){le.set(e,!0);for(var a=[],i=function(h,c){return Ce(function(o,p){var u=-1,w=44;do switch(F(w)){case 0:w===38&&N()===12&&(p[u]=1),o[u]+=Ze(A-1,p,u);break;case 2:o[u]+=U(w);break;case 4:if(w===44){o[++u]=N()===58?"&\f":"",p[u]=o[u].length;break}default:o[u]+=X(w)}while(w=S());return o}(ke(h),c))}(r,a),s=t.props,l=0,m=0;l<i.length;l++)for(var v=0;v<s.length;v++,m++)e.props[m]=a[l]?i[l].replace(/&\f/g,s[v]):s[v]+" "+i[l]}}},Ke=function(e){if(e.type==="decl"){var r=e.value;r.charCodeAt(0)===108&&r.charCodeAt(2)===98&&(e.return="",e.value="")}},Ue=[function(e,r,t,n){if(e.length>-1&&!e.return)switch(e.type){case"decl":e.return=$e(e.value,e.length);break;case"@keyframes":return I([M(e,{value:f(e.value,"@","@"+g)})],n);case"rule":if(e.length)return function(a,i){return a.map(i).join("")}(e.props,function(a){switch(function(i,s){return(i=/(::plac\w+|:read-\w+)/.exec(i))?i[0]:i}(a)){case":read-only":case":read-write":return I([M(e,{props:[f(a,/:(read-\w+)/,":-moz-$1")]})],n);case"::placeholder":return I([M(e,{props:[f(a,/:(plac\w+)/,":-webkit-input-$1")]}),M(e,{props:[f(a,/:(plac\w+)/,":-moz-$1")]}),M(e,{props:[f(a,/:(plac\w+)/,C+"input-$1")]})],n)}return""})}}],Ye={animationIterationCount:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},Qe=/[A-Z]|^ms/g,Xe=/_EMO_([^_]+?)_([^]*?)_EMO_/g,Ae=function(e){return e.charCodeAt(1)===45},ue=function(e){return e!=null&&typeof e!="boolean"},re=Ve(function(e){return Ae(e)?e:e.replace(Qe,"-$&").toLowerCase()}),de=function(e,r){switch(e){case"animation":case"animationName":if(typeof r=="string")return r.replace(Xe,function(t,n,a){return P={name:n,styles:a,next:P},n})}return Ye[e]===1||Ae(e)||typeof r!="number"||r===0?r:r+"px"};function Q(e,r,t){if(t==null)return"";if(t.__emotion_styles!==void 0)return t;switch(typeof t){case"boolean":return"";case"object":if(t.anim===1)return P={name:t.name,styles:t.styles,next:P},t.name;if(t.styles!==void 0){var n=t.next;if(n!==void 0)for(;n!==void 0;)P={name:n.name,styles:n.styles,next:P},n=n.next;var a=t.styles+";";return a}return function(s,l,m){var v="";if(Array.isArray(m))for(var h=0;h<m.length;h++)v+=Q(s,l,m[h])+";";else for(var c in m){var o=m[c];if(typeof o!="object")l!=null&&l[o]!==void 0?v+=c+"{"+l[o]+"}":ue(o)&&(v+=re(c)+":"+de(c,o)+";");else if(!Array.isArray(o)||typeof o[0]!="string"||l!=null&&l[o[0]]!==void 0){var p=Q(s,l,o);switch(c){case"animation":case"animationName":v+=re(c)+":"+p+";";break;default:v+=c+"{"+p+"}"}}else for(var u=0;u<o.length;u++)ue(o[u])&&(v+=re(c)+":"+de(c,o[u])+";")}return v}(e,r,t)}if(r==null)return t;var i=r[t];return i!==void 0?i:t}var P,fe=/label:\s*([^\s;\n{]+)\s*(;|$)/g,te=function(e,r,t){if(e.length===1&&typeof e[0]=="object"&&e[0]!==null&&e[0].styles!==void 0)return e[0];var n=!0,a="";P=void 0;var i=e[0];i==null||i.raw===void 0?(n=!1,a+=Q(t,r,i)):a+=i[0];for(var s=1;s<e.length;s++)a+=Q(t,r,e[s]),n&&(a+=i[s]);fe.lastIndex=0;for(var l,m="";(l=fe.exec(a))!==null;)m+="-"+l[1];var v=function(h){for(var c,o=0,p=0,u=h.length;u>=4;++p,u-=4)c=1540483477*(65535&(c=255&h.charCodeAt(p)|(255&h.charCodeAt(++p))<<8|(255&h.charCodeAt(++p))<<16|(255&h.charCodeAt(++p))<<24))+(59797*(c>>>16)<<16),o=1540483477*(65535&(c^=c>>>24))+(59797*(c>>>16)<<16)^1540483477*(65535&o)+(59797*(o>>>16)<<16);switch(u){case 3:o^=(255&h.charCodeAt(p+2))<<16;case 2:o^=(255&h.charCodeAt(p+1))<<8;case 1:o=1540483477*(65535&(o^=255&h.charCodeAt(p)))+(59797*(o>>>16)<<16)}return(((o=1540483477*(65535&(o^=o>>>13))+(59797*(o>>>16)<<16))^o>>>15)>>>0).toString(36)}(a)+m;return{name:v,styles:a,next:P}};function Se(e,r,t){var n="";return t.split(" ").forEach(function(a){e[a]!==void 0?r.push(e[a]+";"):n+=a+" "}),n}var ze=function(e,r,t){(function(i,s,l){var m=i.key+"-"+s.name;i.registered[m]===void 0&&(i.registered[m]=s.styles)})(e,r);var n=e.key+"-"+r.name;if(e.inserted[r.name]===void 0){var a=r;do e.insert(r===a?"."+n:"",a,e.sheet,!0),a=a.next;while(a!==void 0)}};function he(e,r){if(e.inserted[r.name]===void 0)return e.insert("",r,e.sheet,!0)}function pe(e,r,t){var n=[],a=Se(e,n,t);return n.length<2?t:a+r(n)}var ve,ge,me,ye,be,De=function e(r){for(var t="",n=0;n<r.length;n++){var a=r[n];if(a!=null){var i=void 0;switch(typeof a){case"boolean":break;case"object":if(Array.isArray(a))i=e(a);else for(var s in i="",a)a[s]&&s&&(i&&(i+=" "),i+=s);break;default:i=a}i&&(t&&(t+=" "),t+=i)}}return t},je=function(e){var r=function(n){var a=n.key;if(a==="css"){var i=document.querySelectorAll("style[data-emotion]:not([data-s])");Array.prototype.forEach.call(i,function(d){d.getAttribute("data-emotion").indexOf(" ")!==-1&&(document.head.appendChild(d),d.setAttribute("data-s",""))})}var s=n.stylisPlugins||Ue,l,m,v={},h=[];l=n.container||document.head,Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="'+a+' "]'),function(d){for(var b=d.getAttribute("data-emotion").split(" "),k=1;k<b.length;k++)v[b[k]]=!0;h.push(d)});var c=[Je,Ke],o,p,u=[Le,(p=function(d){o.insert(d)},function(d){d.root||(d=d.return)&&p(d)})],w=function(d){var b=ie(d);return function(k,_,R,j){for(var y="",ee=0;ee<b;ee++)y+=d[ee](k,_,R,j)||"";return y}}(c.concat(s,u));m=function(d,b,k,_){o=k,I(Fe(d?d+"{"+b.styles+"}":b.styles),w),_&&(E.inserted[b.name]=!0)};var E={key:a,sheet:new Pe({key:a,container:l,nonce:n.nonce,speedy:n.speedy,prepend:n.prepend,insertionPoint:n.insertionPoint}),nonce:n.nonce,inserted:v,registered:{},insert:m};return E.sheet.hydrate(h),E}({key:"css"});r.sheet.speedy=function(n){this.isSpeedy=n},r.compat=!0;var t=function(){for(var n=arguments.length,a=new Array(n),i=0;i<n;i++)a[i]=arguments[i];var s=te(a,r.registered,void 0);return ze(r,s),r.key+"-"+s.name};return{css:t,cx:function(){for(var n=arguments.length,a=new Array(n),i=0;i<n;i++)a[i]=arguments[i];return pe(r.registered,t,De(a))},injectGlobal:function(){for(var n=arguments.length,a=new Array(n),i=0;i<n;i++)a[i]=arguments[i];var s=te(a,r.registered);he(r,s)},keyframes:function(){for(var n=arguments.length,a=new Array(n),i=0;i<n;i++)a[i]=arguments[i];var s=te(a,r.registered),l="animation-"+s.name;return he(r,{name:s.name,styles:"@keyframes "+l+"{"+s.styles+"}"}),l},hydrate:function(n){n.forEach(function(a){r.inserted[a]=!0})},flush:function(){r.registered={},r.inserted={},r.sheet.flush()},sheet:r.sheet,cache:r,getRegisteredStyles:Se.bind(null,r.registered),merge:pe.bind(null,r.registered,t)}}(),er=je.cx,V=je.css,Oe=V(ve||(ve=H([`
  content: '';
  position: absolute;
  top: 0;
  height: var(--tree-line-height);
  box-sizing: border-box;
`]))),rr=V(ge||(ge=H([`
  display: flex;
  padding-inline-start: 0;
  margin: 0;
  padding-top: var(--tree-line-height);
  position: relative;

  ::before {
    `,`;
    left: calc(50% - var(--tree-line-width) / 2);
    width: 0;
    border-left: var(--tree-line-width) var(--tree-node-line-style)
      var(--tree-line-color);
  }
`])),Oe),tr=V(me||(me=H([`
  flex: auto;
  text-align: center;
  list-style-type: none;
  position: relative;
  padding: var(--tree-line-height) var(--tree-node-padding) 0
    var(--tree-node-padding);
`]))),nr=V(ye||(ye=H([`
  ::before,
  ::after {
    `,`;
    right: 50%;
    width: 50%;
    border-top: var(--tree-line-width) var(--tree-node-line-style)
      var(--tree-line-color);
  }
  ::after {
    left: 50%;
    border-left: var(--tree-line-width) var(--tree-node-line-style)
      var(--tree-line-color);
  }

  :only-of-type {
    padding: 0;
    ::after,
    :before {
      display: none;
    }
  }

  :first-of-type {
    ::before {
      border: 0 none;
    }
    ::after {
      border-radius: var(--tree-line-border-radius) 0 0 0;
    }
  }

  :last-of-type {
    ::before {
      border-right: var(--tree-line-width) var(--tree-node-line-style)
        var(--tree-line-color);
      border-radius: 0 var(--tree-line-border-radius) 0 0;
    }
    ::after {
      border: 0 none;
    }
  }
`])),Oe);function Ne(e){var r=e.children,t=e.label;return q.createElement("li",{className:er(tr,nr,e.className)},t,q.Children.count(r)>0&&q.createElement("ul",{className:rr},r))}function ar(e){var r=e.children,t=e.label,n=e.lineHeight,a=n===void 0?"20px":n,i=e.lineWidth,s=i===void 0?"1px":i,l=e.lineColor,m=l===void 0?"black":l,v=e.nodePadding,h=v===void 0?"5px":v,c=e.lineStyle,o=c===void 0?"solid":c,p=e.lineBorderRadius,u=p===void 0?"5px":p;return q.createElement("ul",{className:V(be||(be=H([`
        padding-inline-start: 0;
        margin: 0;
        display: flex;

        --line-height: `,`;
        --line-width: `,`;
        --line-color: `,`;
        --line-border-radius: `,`;
        --line-style: `,`;
        --node-padding: `,`;

        --tree-line-height: var(--line-height, 20px);
        --tree-line-width: var(--line-width, 1px);
        --tree-line-color: var(--line-color, black);
        --tree-line-border-radius: var(--line-border-radius, 5px);
        --tree-node-line-style: var(--line-style, solid);
        --tree-node-padding: var(--node-padding, 5px);
      `])),a,s,m,u,o,h)},q.createElement(Ne,{label:t},r))}function lr({organizations:e=[]}){return G.jsx(ar,{lineWidth:"1px",lineColor:J.colors.palette.primary.default,lineBorderRadius:"24px",label:G.jsx(Ee,{children:"Root"}),children:e.map(r=>G.jsx(Re,{organization:r},r.id))})}function Re({organization:{name:e,children:r}}){return G.jsx(Ne,{label:G.jsx(Ee,{children:e}),children:r?.map(t=>G.jsx(Re,{organization:t},t.id))})}const Ee=_e.div`
  transition: box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  overflow: hidden;
  position: relative;
  z-index: 0;
  padding: 16px;
  border-radius: 12px;
  display: inline-flex;
  text-transform: capitalize;
  color: ${J.colors.palette.primary.default};
  background-color: ${se(J.colors.palette.primary.lightChannel,.2)};
  border: 1px solid ${se(J.colors.palette.primary.darkerChannel,.24)};
`;export{lr as default};
