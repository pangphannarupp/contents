import{d as g,o as i,j as c,l as o,V as y,a1 as b,F as m,z as h,a as x,u as C,E as w,y as l,k as v,p as d,m as k,bf as I}from"../vendors/vendor-ah_eQdvw.js";import{_ as S}from"./App-D7rwXoHs.js";const _={class:"component-section"},N={style:{margin:"20px 0"}},T={class:"icons-grid"},O=["onClick"],j={class:"icon-name"},z={key:0,class:"no-results"},V={key:1,class:"toast"},L=g({__name:"IconsSection",setup(Q){const r=d(""),a=d(!1),p=d(""),u=k(()=>{const n=r.value.toLowerCase(),e={};for(const[s,t]of Object.entries(I))typeof t=="string"&&s.toLowerCase().includes(n)&&(e[s]=t);return e}),f=n=>{navigator.clipboard.writeText(n),p.value=n,a.value=!0,setTimeout(()=>{a.value=!1},2e3)};return(n,e)=>(i(),c(m,null,[o("div",_,[e[1]||(e[1]=o("h2",null,"Icons Collection",-1)),e[2]||(e[2]=o("p",null,"A comprehensive set of SVG icons provided by Ionicons. Click any icon to copy its import name.",-1)),o("div",N,[y(o("input",{type:"text","onUpdate:modelValue":e[0]||(e[0]=s=>r.value=s),placeholder:"Search icons... (e.g., arrow, home, user)",class:"icon-search-input"},null,512),[[b,r.value]])]),o("div",T,[(i(!0),c(m,null,h(u.value,(s,t)=>(i(),c("div",{key:t,class:"icon-card",onClick:U=>f(t)},[x(C(w),{icon:s,class:"icon-svg"},null,8,["icon"]),o("div",j,l(String(t)),1)],8,O))),128))]),Object.keys(u.value).length===0?(i(),c("div",z,' No icons found matching "'+l(r.value)+'" ',1)):v("",!0),a.value?(i(),c("div",V,' Copied "'+l(p.value)+'" to clipboard! ',1)):v("",!0),e[3]||(e[3]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[4]||(e[4]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="component-section">
    <h2>Icons Collection</h2>
    <p>A comprehensive set of SVG icons provided by Ionicons. Click any icon to copy its import name.</p>
    

    <div style="margin: 20px 0;">
      <input 
        type="text" 
        v-model="searchQuery" 
        placeholder="Search icons... (e.g., arrow, home, user)" 
        class="icon-search-input" 
      />
    </div>

    <div class="icons-grid">
      <div 
        v-for="(iconObj, iconName) in filteredIcons" 
        :key="iconName" 
        class="icon-card"
        @click="copyIconName(iconName as string)"
      >
        <ion-icon :icon="iconObj" class="icon-svg"></ion-icon>
        <div class="icon-name">{{ String(iconName) }}</div>
      </div>
    </div>
    
    <div v-if="Object.keys(filteredIcons).length === 0" class="no-results">
      No icons found matching "{{ searchQuery }}"
    </div>
    
    <div v-if="showCopiedToast" class="toast">
      Copied "{{ copiedName }}" to clipboard!
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { IonIcon } from '@ionic/vue';
import * as ionIcons from 'ionicons/icons';

const searchQuery = ref('');
const showCopiedToast = ref(false);
const copiedName = ref('');

// Filter icons based on search query
const filteredIcons = computed(() => {
  const query = searchQuery.value.toLowerCase();
  const result: Record<string, string> = {};
  
  for (const [name, icon] of Object.entries(ionIcons)) {
    if (typeof icon === 'string' && name.toLowerCase().includes(query)) {
      result[name] = icon;
    }
  }
  
  return result;
});

const copyIconName = (name: string) => {
  navigator.clipboard.writeText(name);
  copiedName.value = name;
  showCopiedToast.value = true;
  
  setTimeout(() => {
    showCopiedToast.value = false;
  }, 2000);
};
<\/script>

<style scoped>
.icon-search-input {
  width: 100%;
  max-width: 400px;
  padding: 12px 16px;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  font-size: 14px;
  background: white;
  color: #334155;
  outline: none;
  transition: border-color 0.2s;
}

.icon-search-input:focus {
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.icons-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
  gap: 16px;
}

.icon-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px 12px;
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.icon-card:hover {
  background: #f8fafc;
  border-color: #3b82f6;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1);
}

.icon-svg {
  font-size: 32px;
  color: #475569;
  margin-bottom: 12px;
  transition: color 0.2s;
}

.icon-card:hover .icon-svg {
  color: #3b82f6;
}

.icon-name {
  font-size: 11px;
  color: #64748b;
  text-align: center;
  word-break: break-word;
  line-height: 1.4;
}

.no-results {
  padding: 40px;
  text-align: center;
  color: #64748b;
  font-style: italic;
}

.toast {
  position: fixed;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%);
  background: #1e293b;
  color: white;
  padding: 12px 24px;
  border-radius: 30px;
  font-size: 14px;
  font-weight: 500;
  box-shadow: 0 10px 25px rgba(0,0,0,0.2);
  z-index: 1000;
  animation: fadeUp 0.3s ease-out forwards;
}

@keyframes fadeUp {
  from { opacity: 0; transform: translate(-50%, 20px); }
  to { opacity: 1; transform: translate(-50%, 0); }
}


</style>
`)])],-1))],64))}}),F=S(L,[["__scopeId","data-v-07d3b5e3"]]);export{F as I};
