import{e as o,j as r}from"../main.js";const s=o(r.jsx("path",{d:"M12 8V4l8 8-8 8v-4H4V8z"}),"Forward");export{s as F};
