import{P as n,bU as s,aA as p,ar as u,aw as g}from"./AccountCardSection-DXixqG3L.js";import{d as h,o as f,j as y,l as t,a as i,w as l,A as a,u as c,L as P,F as C}from"../vendors/vendor-ah_eQdvw.js";const v={class:"component-section"},w={class:"demo-box",style:{"margin-top":"32px",display:"flex",gap:"16px","align-items":"center","justify-content":"center",height:"160px",background:"#f8fafc","border-radius":"8px","flex-wrap":"wrap"}},U=h({__name:"UIUtilSection",setup(x){const r=()=>{const o=s.showBottomSheet(p,{title:"Are you sure?",subtitle:"This is triggered imperatively without template code.",confirmText:"Confirm",cancelText:"Cancel",onConfirm:()=>{console.log("Confirmed via UIUtil"),o.close()}})},m=()=>{const o=s.showDialog(u,{title:"Delete Item",message:"Are you sure you want to delete this? This action cannot be undone.",confirmText:"Delete",cancelText:"Cancel",onConfirm:()=>{console.log("Deleted!"),o.close()}})},d=()=>{const o=s.showDynamicIsland(g,{state:"compact",position:"top",fullWidth:!1,onClick:()=>{o.close()}})};return(o,e)=>(f(),y(C,null,[t("div",v,[e[3]||(e[3]=t("h2",null,"Imperative Components (UIUtil)",-1)),e[4]||(e[4]=t("p",null,"A utility to dynamically show components like BottomSheets or Dialogs from TypeScript/JavaScript without declaring them in your template.",-1)),t("div",w,[i(c(n),{onClick:r},{default:l(()=>[...e[0]||(e[0]=[a("Show Confirm Sheet",-1)])]),_:1}),i(c(n),{variant:"secondary",onClick:m},{default:l(()=>[...e[1]||(e[1]=[a("Show Dialog",-1)])]),_:1}),i(c(n),{variant:"outline",onClick:d},{default:l(()=>[...e[2]||(e[2]=[a("Show Dynamic Island",-1)])]),_:1})]),e[5]||(e[5]=P(`<div style="margin-top:40px;"><h3>Usage Example</h3><pre class="code-block" style="background:#1e293b;color:#e2e8f0;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;PPButton @click=&quot;handleAction&quot;&gt;Perform Action&lt;/PPButton&gt;
&lt;/template&gt;

&lt;script setup lang=&quot;ts&quot;&gt;
import { UIUtil, PPConfirmSheet, PPConfirm, PPDynamicIsland } from &#39;@phanna/ui-framework&#39;;

const handleAction = () =&gt; {
  const sheet = UIUtil.showBottomSheet(PPConfirmSheet, {
    title: &#39;Are you sure?&#39;,
    subtitle: &#39;This action cannot be undone.&#39;,
    confirmText: &#39;Yes, Delete&#39;,
    cancelText: &#39;Cancel&#39;,
    onConfirm: () =&gt; {
      console.log(&#39;User confirmed!&#39;);
      sheet.close();
    }
  });
};
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[6]||(e[6]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Imperative Components (UIUtil)</h2>
    <p>A utility to dynamically show components like BottomSheets or Dialogs from TypeScript/JavaScript without declaring them in your template.</p>

    <div class="demo-box" style="margin-top: 32px; display: flex; gap: 16px; align-items: center; justify-content: center; height: 160px; background: #f8fafc; border-radius: 8px; flex-wrap: wrap;">
      <PPButton @click="showConfirmSheet">Show Confirm Sheet</PPButton>
      <PPButton variant="secondary" @click="showDialog">Show Dialog</PPButton>
      <PPButton variant="outline" @click="showIsland">Show Dynamic Island</PPButton>
    </div>

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block" style="background: #1e293b; color: #e2e8f0; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPButton @click="handleAction"&gt;Perform Action&lt;/PPButton&gt;
&lt;/template&gt;

&lt;script setup lang="ts"&gt;
import { UIUtil, PPConfirmSheet, PPConfirm, PPDynamicIsland } from '@phanna/ui-framework';

const handleAction = () =&gt; {
  const sheet = UIUtil.showBottomSheet(PPConfirmSheet, {
    title: 'Are you sure?',
    subtitle: 'This action cannot be undone.',
    confirmText: 'Yes, Delete',
    cancelText: 'Cancel',
    onConfirm: () =&gt; {
      console.log('User confirmed!');
      sheet.close();
    }
  });
};
&lt;/script&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { UIUtil, PPConfirmSheet, PPConfirm, PPDynamicIsland, PPButton } from '@phanna/ui-framework';

const showConfirmSheet = () => {
  const sheet = UIUtil.showBottomSheet(PPConfirmSheet, {
    title: 'Are you sure?',
    subtitle: 'This is triggered imperatively without template code.',
    confirmText: 'Confirm',
    cancelText: 'Cancel',
    onConfirm: () => {
      console.log('Confirmed via UIUtil');
      sheet.close();
    }
  });
};

const showDialog = () => {
  const dialog = UIUtil.showDialog(PPConfirm, {
    title: 'Delete Item',
    message: 'Are you sure you want to delete this? This action cannot be undone.',
    confirmText: 'Delete',
    cancelText: 'Cancel',
    onConfirm: () => {
      console.log('Deleted!');
      dialog.close();
    }
  });
};

const showIsland = () => {
  const island = UIUtil.showDynamicIsland(PPDynamicIsland, {
    state: 'compact',
    position: 'top',
    fullWidth: false,
    'onClick': () => {
      island.close();
    }
  });
};
<\/script>
`)])],-1))],64))}});export{U as _};
