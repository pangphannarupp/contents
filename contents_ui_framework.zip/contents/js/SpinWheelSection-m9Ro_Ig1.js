import{by as r,P as h}from"./AccountCardSection-DXixqG3L.js";import{d as y,o as d,j as u,l as e,a,u as t,w as x,A as b,y as f,k as S,F as P,p as c}from"../vendors/vendor-ah_eQdvw.js";const F={class:"guide-section"},k={class:"variant-group"},_={class:"component-demo",style:{display:"flex","flex-direction":"column","align-items":"center",padding:"40px","background-color":"#f4f5f8","border-radius":"12px",gap:"24px"}},C={style:{display:"flex","flex-direction":"column","align-items":"center",gap:"12px"}},w={key:0,style:{"margin-top":"16px","font-weight":"bold","font-size":"18px",color:"#007aff"}},W={class:"variant-group"},A={class:"component-demo",style:{display:"flex","flex-direction":"column","align-items":"center",padding:"40px","background-color":"#f4f5f8","border-radius":"12px",gap:"24px"}},T={class:"variant-group"},z={class:"component-demo",style:{display:"flex","flex-direction":"column","align-items":"center",padding:"40px","background-color":"#f4f5f8","border-radius":"12px",gap:"24px"}},D=y({__name:"SpinWheelSection",setup(B){const p=c(null),n=c(!1),o=c(""),l=[{label:"$10 Voucher",value:"10_voucher",color:"#FF3B30"},{label:"Free Coffee",value:"free_coffee",color:"#FF9500"},{label:"Try Again",value:"try_again",color:"#8E8E93"},{label:"50% Off",value:"50_off",color:"#4CD964"},{label:"Free Pastry",value:"free_pastry",color:"#5AC8FA"},{label:"$5 Cashback",value:"5_cashback",color:"#007AFF"},{label:"Try Again",value:"try_again",color:"#8E8E93"},{label:"Mystery Box",value:"mystery_box",color:"#AF52DE"}],v=()=>{var i;if(n.value)return;const s=Math.floor(Math.random()*l.length);o.value="",(i=p.value)==null||i.spinTo(s)},g=()=>{n.value=!0},m=s=>{n.value=!1,s.value==="try_again"?o.value="Oh no! Try Again!":o.value=`🎉 You won: ${s.label}!`};return(s,i)=>(d(),u(P,null,[e("div",F,[i[6]||(i[6]=e("h2",null,"Spin the Wheel",-1)),i[7]||(i[7]=e("p",{class:"guide-desc"},"A fun and interactive spin the wheel component for gamification and lotteries.",-1)),e("div",k,[i[0]||(i[0]=e("h3",null,"Basic Spin Wheel",-1)),e("div",_,[a(t(r),{ref_key:"wheelRef",ref:p,items:l,spinDuration:4e3,spins:5,onStart:g,onFinish:m},null,512),e("div",C,[a(t(h),{variant:"primary",disabled:n.value,onClick:v},{default:x(()=>[b(f(n.value?"Spinning...":"Spin the Wheel!"),1)]),_:1},8,["disabled"]),o.value?(d(),u("div",w,f(o.value),1)):S("",!0)])]),i[1]||(i[1]=e("pre",{class:"code-block"},[e("code",null,`<PPSpinWheel 
  ref="wheelRef"
  :items="prizes"
  @finish="onSpinFinish"
/>`)],-1))]),e("div",W,[i[2]||(i[2]=e("h3",null,"Donut Variant",-1)),e("div",A,[a(t(r),{items:l,variant:"donut"})]),i[3]||(i[3]=e("pre",{class:"code-block"},[e("code",null,'<PPSpinWheel variant="donut" :items="prizes" />')],-1))]),e("div",T,[i[4]||(i[4]=e("h3",null,"Casino Variant",-1)),e("div",z,[a(t(r),{items:l,variant:"casino"})]),i[5]||(i[5]=e("pre",{class:"code-block"},[e("code",null,'<PPSpinWheel variant="casino" :items="prizes" />')],-1))]),i[8]||(i[8]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),i[9]||(i[9]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Spin the Wheel</h2>
    <p class="guide-desc">A fun and interactive spin the wheel component for gamification and lotteries.</p>

    <div class="variant-group">
      <h3>Basic Spin Wheel</h3>
      <div class="component-demo" style="display: flex; flex-direction: column; align-items: center; padding: 40px; background-color: #f4f5f8; border-radius: 12px; gap: 24px;">
        <PPSpinWheel 
          ref="wheelRef"
          :items="prizes"
          :spinDuration="4000"
          :spins="5"
          @start="onSpinStart"
          @finish="onSpinFinish"
        />
        
        <div style="display: flex; flex-direction: column; align-items: center; gap: 12px;">
          <PPButton 
            variant="primary" 
            :disabled="isSpinning"
            @click="spinWheel"
          >
            {{ isSpinning ? 'Spinning...' : 'Spin the Wheel!' }}
          </PPButton>
          
          <div v-if="resultText" style="margin-top: 16px; font-weight: bold; font-size: 18px; color: #007aff;">
            {{ resultText }}
          </div>
        </div>
      </div>
      <pre class="code-block"><code>&lt;PPSpinWheel 
  ref="wheelRef"
  :items="prizes"
  @finish="onSpinFinish"
/&gt;</code></pre>
    </div>

    <div class="variant-group">
      <h3>Donut Variant</h3>
      <div class="component-demo" style="display: flex; flex-direction: column; align-items: center; padding: 40px; background-color: #f4f5f8; border-radius: 12px; gap: 24px;">
        <PPSpinWheel 
          :items="prizes"
          variant="donut"
        />
      </div>
      <pre class="code-block"><code>&lt;PPSpinWheel variant="donut" :items="prizes" /&gt;</code></pre>
    </div>

    <div class="variant-group">
      <h3>Casino Variant</h3>
      <div class="component-demo" style="display: flex; flex-direction: column; align-items: center; padding: 40px; background-color: #f4f5f8; border-radius: 12px; gap: 24px;">
        <PPSpinWheel 
          :items="prizes"
          variant="casino"
        />
      </div>
      <pre class="code-block"><code>&lt;PPSpinWheel variant="casino" :items="prizes" /&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPSpinWheel, PPButton } from '@phanna/ui-framework';

const wheelRef = ref<any>(null);
const isSpinning = ref(false);
const resultText = ref('');

const prizes = [
  { label: '$10 Voucher', value: '10_voucher', color: '#FF3B30' },
  { label: 'Free Coffee', value: 'free_coffee', color: '#FF9500' },
  { label: 'Try Again', value: 'try_again', color: '#8E8E93' },
  { label: '50% Off', value: '50_off', color: '#4CD964' },
  { label: 'Free Pastry', value: 'free_pastry', color: '#5AC8FA' },
  { label: '$5 Cashback', value: '5_cashback', color: '#007AFF' },
  { label: 'Try Again', value: 'try_again', color: '#8E8E93' },
  { label: 'Mystery Box', value: 'mystery_box', color: '#AF52DE' }
];

const spinWheel = () => {
  if (isSpinning.value) return;
  
  // Randomly select a winning index
  const winnerIndex = Math.floor(Math.random() * prizes.length);
  
  resultText.value = '';
  wheelRef.value?.spinTo(winnerIndex);
};

const onSpinStart = () => {
  isSpinning.value = true;
};

const onSpinFinish = (item: any) => {
  isSpinning.value = false;
  if (item.value === 'try_again') {
    resultText.value = 'Oh no! Try Again!';
  } else {
    resultText.value = \`🎉 You won: \${item.label}!\`;
  }
};
<\/script>
`)])],-1))],64))}});export{D as _};
