import{bo as r,bp as m,b6 as S,b7 as b}from"./AccountCardSection-DXixqG3L.js";import{d as x,o as g,j as p,l as e,a as l,w as n,u as o,A as i,y as d,L as f,k as y,F as v,z as B,p as P}from"../vendors/vendor-ah_eQdvw.js";const w={class:"component-section"},k={style:{"margin-top":"40px"}},V={class:"demo-box",style:{padding:"40px",background:"#f8fafc","border-radius":"12px",display:"flex","flex-direction":"column","align-items":"center",gap:"40px"}},h={style:{background:"url('https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=600&auto=format&fit=crop') center/cover",padding:"40px","border-radius":"12px"}},T={style:{"font-size":"14px",color:"#64748b","margin-top":"20px"}},L={style:{"margin-top":"24px",padding:"24px",background:"#ffffff","border-radius":"12px",border:"1px solid #e2e8f0",width:"100%","max-width":"400px","min-height":"150px"}},C={key:0,style:{"text-align":"center"}},z={width:"48",height:"48",viewBox:"0 0 24 24",fill:"none",stroke:"#3b82f6","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",style:{"margin-bottom":"12px"}},M={key:1,style:{"text-align":"center"}},G={width:"48",height:"48",viewBox:"0 0 24 24",fill:"none",stroke:"#10b981","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",style:{"margin-bottom":"12px"}},U={key:2,style:{"text-align":"center"}},A={width:"48",height:"48",viewBox:"0 0 24 24",fill:"none",stroke:"#f59e0b","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",style:{"margin-bottom":"12px"}},E={style:{"margin-top":"40px"}},O={class:"demo-box",style:{padding:"40px",background:"#f8fafc","border-radius":"12px",display:"flex","flex-direction":"column","align-items":"center",gap:"20px"}},j={style:{"font-size":"14px",color:"#64748b"}},D=x({__name:"SegmentSection",setup(q){const s=P("map"),u=P("All"),c=["All","Electronics","Clothing","Books","Home & Garden","Sports","Toys","Health"];return(H,t)=>(g(),p(v,null,[e("div",w,[t[43]||(t[43]=e("h2",null,"Segment Controls",-1)),t[44]||(t[44]=e("p",null,"Segment controls allow users to toggle between different views or options.",-1)),e("div",k,[t[36]||(t[36]=e("h3",null,"Basic Segment (PPSegment)",-1)),t[37]||(t[37]=e("p",null,"A simple segmented control for toggling between a few options.",-1)),e("div",V,[e("div",null,[t[9]||(t[9]=e("p",{style:{"text-align":"center","margin-bottom":"12px","font-size":"14px",color:"#64748b"}},"Pill Variant (Default)",-1)),l(o(m),{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=a=>s.value=a),variant:"pill"},{default:n(()=>[l(o(r),{value:"map"},{default:n(()=>[...t[6]||(t[6]=[i("Map View",-1)])]),_:1}),l(o(r),{value:"list"},{default:n(()=>[...t[7]||(t[7]=[i("List View",-1)])]),_:1}),l(o(r),{value:"grid"},{default:n(()=>[...t[8]||(t[8]=[i("Grid View",-1)])]),_:1})]),_:1},8,["modelValue"])]),e("div",null,[t[13]||(t[13]=e("p",{style:{"text-align":"center","margin-bottom":"12px","font-size":"14px",color:"#64748b"}},"Underline Variant",-1)),l(o(m),{modelValue:s.value,"onUpdate:modelValue":t[1]||(t[1]=a=>s.value=a),variant:"underline",style:{width:"300px"}},{default:n(()=>[l(o(r),{value:"map"},{default:n(()=>[...t[10]||(t[10]=[i("Map",-1)])]),_:1}),l(o(r),{value:"list"},{default:n(()=>[...t[11]||(t[11]=[i("List",-1)])]),_:1}),l(o(r),{value:"grid"},{default:n(()=>[...t[12]||(t[12]=[i("Grid",-1)])]),_:1})]),_:1},8,["modelValue"])]),e("div",null,[t[17]||(t[17]=e("p",{style:{"text-align":"center","margin-bottom":"12px","font-size":"14px",color:"#64748b"}},"Block Variant",-1)),l(o(m),{modelValue:s.value,"onUpdate:modelValue":t[2]||(t[2]=a=>s.value=a),variant:"block",style:{width:"300px",background:"#e2e8f0"}},{default:n(()=>[l(o(r),{value:"map"},{default:n(()=>[...t[14]||(t[14]=[i("Map",-1)])]),_:1}),l(o(r),{value:"list"},{default:n(()=>[...t[15]||(t[15]=[i("List",-1)])]),_:1}),l(o(r),{value:"grid"},{default:n(()=>[...t[16]||(t[16]=[i("Grid",-1)])]),_:1})]),_:1},8,["modelValue"])]),e("div",null,[t[21]||(t[21]=e("p",{style:{"text-align":"center","margin-bottom":"12px","font-size":"14px",color:"#64748b"}},"Material UI 3 Variant",-1)),l(o(m),{modelValue:s.value,"onUpdate:modelValue":t[3]||(t[3]=a=>s.value=a),variant:"material3",style:{width:"300px"}},{default:n(()=>[l(o(r),{value:"map"},{default:n(()=>[...t[18]||(t[18]=[i("Map",-1)])]),_:1}),l(o(r),{value:"list"},{default:n(()=>[...t[19]||(t[19]=[i("List",-1)])]),_:1}),l(o(r),{value:"grid"},{default:n(()=>[...t[20]||(t[20]=[i("Grid",-1)])]),_:1})]),_:1},8,["modelValue"])]),e("div",h,[t[25]||(t[25]=e("p",{style:{"text-align":"center","margin-bottom":"12px","font-size":"14px",color:"#ffffff","text-shadow":"0 1px 2px rgba(0,0,0,0.5)"}},"iOS Liquid Glass Variant",-1)),l(o(m),{modelValue:s.value,"onUpdate:modelValue":t[4]||(t[4]=a=>s.value=a),variant:"ios-glass",style:{width:"300px"}},{default:n(()=>[l(o(r),{value:"map"},{default:n(()=>[...t[22]||(t[22]=[i("Map",-1)])]),_:1}),l(o(r),{value:"list"},{default:n(()=>[...t[23]||(t[23]=[i("List",-1)])]),_:1}),l(o(r),{value:"grid"},{default:n(()=>[...t[24]||(t[24]=[i("Grid",-1)])]),_:1})]),_:1},8,["modelValue"])]),e("p",T,[t[26]||(t[26]=i("Selected: ",-1)),e("strong",null,d(s.value),1)]),e("div",L,[s.value==="map"?(g(),p("div",C,[(g(),p("svg",z,[...t[27]||(t[27]=[e("polygon",{points:"3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"},null,-1),e("line",{x1:"9",y1:"3",x2:"9",y2:"18"},null,-1),e("line",{x1:"15",y1:"6",x2:"15",y2:"21"},null,-1)])])),t[28]||(t[28]=e("h4",{style:{margin:"0 0 8px 0",color:"#0f172a"}},"Map View",-1)),t[29]||(t[29]=e("p",{style:{margin:"0",color:"#64748b","font-size":"14px"}},"This is the map view content.",-1))])):s.value==="list"?(g(),p("div",M,[(g(),p("svg",G,[...t[30]||(t[30]=[f('<line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line>',6)])])),t[31]||(t[31]=e("h4",{style:{margin:"0 0 8px 0",color:"#0f172a"}},"List View",-1)),t[32]||(t[32]=e("p",{style:{margin:"0",color:"#64748b","font-size":"14px"}},"This is the list view content.",-1))])):s.value==="grid"?(g(),p("div",U,[(g(),p("svg",A,[...t[33]||(t[33]=[e("rect",{x:"3",y:"3",width:"7",height:"7"},null,-1),e("rect",{x:"14",y:"3",width:"7",height:"7"},null,-1),e("rect",{x:"14",y:"14",width:"7",height:"7"},null,-1),e("rect",{x:"3",y:"14",width:"7",height:"7"},null,-1)])])),t[34]||(t[34]=e("h4",{style:{margin:"0 0 8px 0",color:"#0f172a"}},"Grid View",-1)),t[35]||(t[35]=e("p",{style:{margin:"0",color:"#64748b","font-size":"14px"}},"This is the grid view content.",-1))])):y("",!0)])]),t[38]||(t[38]=e("div",{style:{"margin-top":"16px"}},[e("h4",null,"Usage Example"),e("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[e("code",null,`<template>
  <PPSegment v-model="activeTab">
    <PPSegmentButton value="map">Map View</PPSegmentButton>
    <PPSegmentButton value="list">List View</PPSegmentButton>
    <PPSegmentButton value="grid">Grid View</PPSegmentButton>
  </PPSegment>

  <!-- Underline Variant -->
  <PPSegment v-model="activeTab" variant="underline">
    <PPSegmentButton value="map">Map</PPSegmentButton>
    <PPSegmentButton value="list">List</PPSegmentButton>
  </PPSegment>

  <!-- Block Variant -->
  <PPSegment v-model="activeTab" variant="block">
    <PPSegmentButton value="map">Map</PPSegmentButton>
    <PPSegmentButton value="list">List</PPSegmentButton>
  </PPSegment>

  <!-- Material UI 3 Variant -->
  <PPSegment v-model="activeTab" variant="material3">
    <PPSegmentButton value="map">Map</PPSegmentButton>
    <PPSegmentButton value="list">List</PPSegmentButton>
  </PPSegment>

  <!-- iOS Liquid Glass Variant -->
  <PPSegment v-model="activeTab" variant="ios-glass">
    <PPSegmentButton value="map">Map</PPSegmentButton>
    <PPSegmentButton value="list">List</PPSegmentButton>
  </PPSegment>

  <!-- Tab Content Example -->
  <div class="tab-content">
    <div v-if="activeTab === 'map'">Map View Content</div>
    <div v-else-if="activeTab === 'list'">List View Content</div>
    <div v-else-if="activeTab === 'grid'">Grid View Content</div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { PPSegment, PPSegmentButton } from '@phanna/ui-framework';

const activeTab = ref('map');
<\/script>`)])],-1))]),e("div",E,[t[40]||(t[40]=e("h3",null,"Scrollable Segment (PPScrollSegment)",-1)),t[41]||(t[41]=e("p",null,"A scrollable segmented control for a large number of options.",-1)),e("div",O,[l(o(b),{modelValue:u.value,"onUpdate:modelValue":t[5]||(t[5]=a=>u.value=a),style:{width:"100%","max-width":"400px"}},{default:n(()=>[(g(),p(v,null,B(c,a=>l(o(S),{key:a,value:a},{default:n(()=>[i(d(a),1)]),_:2},1032,["value"])),64))]),_:1},8,["modelValue"]),e("p",j,[t[39]||(t[39]=i("Selected: ",-1)),e("strong",null,d(u.value),1)])]),t[42]||(t[42]=e("div",{style:{"margin-top":"16px"}},[e("h4",null,"Usage Example"),e("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[e("code",null,`<template>
  <PPScrollSegment v-model="activeCategory">
    <PPScrollSegmentButton value="all">All</PPScrollSegmentButton>
    <PPScrollSegmentButton value="electronics">Electronics</PPScrollSegmentButton>
    <PPScrollSegmentButton value="clothing">Clothing</PPScrollSegmentButton>
    <PPScrollSegmentButton value="books">Books</PPScrollSegmentButton>
    <PPScrollSegmentButton value="home">Home & Garden</PPScrollSegmentButton>
  </PPScrollSegment>
</template>

<script setup>
import { ref } from 'vue';
import { PPScrollSegment, PPScrollSegmentButton } from '@phanna/ui-framework';

const activeCategory = ref('all');
<\/script>`)])],-1))]),t[45]||(t[45]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-background-alt: /* value */;
  --pp-border-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-variant: /* value */;
  --pp-scroll-segment-bg: /* value */;
  --pp-scroll-segment-border-radius: /* value */;
  --pp-scroll-segment-btn-active-bg: /* value */;
  --pp-scroll-segment-btn-active-border-color: /* value */;
  --pp-scroll-segment-btn-active-color: /* value */;
  --pp-scroll-segment-btn-bg: /* value */;
  --pp-scroll-segment-btn-border-color: /* value */;
  --pp-scroll-segment-btn-color: /* value */;
  --pp-scroll-segment-btn-font-size: /* value */;
  --pp-scroll-segment-btn-padding: /* value */;
  --pp-scroll-segment-btn-radius: /* value */;
  --pp-scroll-segment-btn-shadow: /* value */;
  --pp-scroll-segment-gap: /* value */;
  --pp-scroll-segment-margin-bottom: /* value */;
  --pp-scroll-segment-padding: /* value */;
  --pp-segment-bg: /* value */;
  --pp-segment-border-color: /* value */;
  --pp-segment-btn-active-bg: /* value */;
  --pp-segment-btn-active-color: /* value */;
  --pp-segment-btn-active-shadow: /* value */;
  --pp-segment-btn-color: /* value */;
  --pp-segment-btn-font-size: /* value */;
  --pp-segment-btn-font-weight: /* value */;
  --pp-segment-btn-padding: /* value */;
  --pp-segment-btn-radius: /* value */;
  --pp-segment-icon-size: /* value */;
  --pp-segment-padding: /* value */;
  --pp-segment-radius: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[46]||(t[46]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Segment Controls</h2>
    <p>Segment controls allow users to toggle between different views or options.</p>

    <!-- Basic Segment -->
    <div style="margin-top: 40px;">
      <h3>Basic Segment (PPSegment)</h3>
      <p>A simple segmented control for toggling between a few options.</p>
      
      <div class="demo-box" style="padding: 40px; background: #f8fafc; border-radius: 12px; display: flex; flex-direction: column; align-items: center; gap: 40px;">
        <!-- Pill Variant (Default) -->
        <div>
          <p style="text-align: center; margin-bottom: 12px; font-size: 14px; color: #64748b;">Pill Variant (Default)</p>
          <PPSegment v-model="activeTab" variant="pill">
            <PPSegmentButton value="map">Map View</PPSegmentButton>
            <PPSegmentButton value="list">List View</PPSegmentButton>
            <PPSegmentButton value="grid">Grid View</PPSegmentButton>
          </PPSegment>
        </div>

        <!-- Underline Variant -->
        <div>
          <p style="text-align: center; margin-bottom: 12px; font-size: 14px; color: #64748b;">Underline Variant</p>
          <PPSegment v-model="activeTab" variant="underline" style="width: 300px;">
            <PPSegmentButton value="map">Map</PPSegmentButton>
            <PPSegmentButton value="list">List</PPSegmentButton>
            <PPSegmentButton value="grid">Grid</PPSegmentButton>
          </PPSegment>
        </div>

        <!-- Block Variant -->
        <div>
          <p style="text-align: center; margin-bottom: 12px; font-size: 14px; color: #64748b;">Block Variant</p>
          <PPSegment v-model="activeTab" variant="block" style="width: 300px; background: #e2e8f0;">
            <PPSegmentButton value="map">Map</PPSegmentButton>
            <PPSegmentButton value="list">List</PPSegmentButton>
            <PPSegmentButton value="grid">Grid</PPSegmentButton>
          </PPSegment>
        </div>

        <!-- Material UI 3 Variant -->
        <div>
          <p style="text-align: center; margin-bottom: 12px; font-size: 14px; color: #64748b;">Material UI 3 Variant</p>
          <PPSegment v-model="activeTab" variant="material3" style="width: 300px;">
            <PPSegmentButton value="map">Map</PPSegmentButton>
            <PPSegmentButton value="list">List</PPSegmentButton>
            <PPSegmentButton value="grid">Grid</PPSegmentButton>
          </PPSegment>
        </div>

        <!-- iOS Liquid Glass Variant -->
        <div style="background: url('https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=600&auto=format&fit=crop') center/cover; padding: 40px; border-radius: 12px;">
          <p style="text-align: center; margin-bottom: 12px; font-size: 14px; color: #ffffff; text-shadow: 0 1px 2px rgba(0,0,0,0.5);">iOS Liquid Glass Variant</p>
          <PPSegment v-model="activeTab" variant="ios-glass" style="width: 300px;">
            <PPSegmentButton value="map">Map</PPSegmentButton>
            <PPSegmentButton value="list">List</PPSegmentButton>
            <PPSegmentButton value="grid">Grid</PPSegmentButton>
          </PPSegment>
        </div>

        <p style="font-size: 14px; color: #64748b; margin-top: 20px;">Selected: <strong>{{ activeTab }}</strong></p>

        <!-- Tab Content Example -->
        <div style="margin-top: 24px; padding: 24px; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; width: 100%; max-width: 400px; min-height: 150px;">
          <div v-if="activeTab === 'map'" style="text-align: center;">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 12px;"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"></polygon><line x1="9" y1="3" x2="9" y2="18"></line><line x1="15" y1="6" x2="15" y2="21"></line></svg>
            <h4 style="margin: 0 0 8px 0; color: #0f172a;">Map View</h4>
            <p style="margin: 0; color: #64748b; font-size: 14px;">This is the map view content.</p>
          </div>
          <div v-else-if="activeTab === 'list'" style="text-align: center;">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 12px;"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
            <h4 style="margin: 0 0 8px 0; color: #0f172a;">List View</h4>
            <p style="margin: 0; color: #64748b; font-size: 14px;">This is the list view content.</p>
          </div>
          <div v-else-if="activeTab === 'grid'" style="text-align: center;">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 12px;"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
            <h4 style="margin: 0 0 8px 0; color: #0f172a;">Grid View</h4>
            <p style="margin: 0; color: #64748b; font-size: 14px;">This is the grid view content.</p>
          </div>
        </div>
      </div>

      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPSegment v-model="activeTab"&gt;
    &lt;PPSegmentButton value="map"&gt;Map View&lt;/PPSegmentButton&gt;
    &lt;PPSegmentButton value="list"&gt;List View&lt;/PPSegmentButton&gt;
    &lt;PPSegmentButton value="grid"&gt;Grid View&lt;/PPSegmentButton&gt;
  &lt;/PPSegment&gt;

  &lt;!-- Underline Variant --&gt;
  &lt;PPSegment v-model="activeTab" variant="underline"&gt;
    &lt;PPSegmentButton value="map"&gt;Map&lt;/PPSegmentButton&gt;
    &lt;PPSegmentButton value="list"&gt;List&lt;/PPSegmentButton&gt;
  &lt;/PPSegment&gt;

  &lt;!-- Block Variant --&gt;
  &lt;PPSegment v-model="activeTab" variant="block"&gt;
    &lt;PPSegmentButton value="map"&gt;Map&lt;/PPSegmentButton&gt;
    &lt;PPSegmentButton value="list"&gt;List&lt;/PPSegmentButton&gt;
  &lt;/PPSegment&gt;

  &lt;!-- Material UI 3 Variant --&gt;
  &lt;PPSegment v-model="activeTab" variant="material3"&gt;
    &lt;PPSegmentButton value="map"&gt;Map&lt;/PPSegmentButton&gt;
    &lt;PPSegmentButton value="list"&gt;List&lt;/PPSegmentButton&gt;
  &lt;/PPSegment&gt;

  &lt;!-- iOS Liquid Glass Variant --&gt;
  &lt;PPSegment v-model="activeTab" variant="ios-glass"&gt;
    &lt;PPSegmentButton value="map"&gt;Map&lt;/PPSegmentButton&gt;
    &lt;PPSegmentButton value="list"&gt;List&lt;/PPSegmentButton&gt;
  &lt;/PPSegment&gt;

  &lt;!-- Tab Content Example --&gt;
  &lt;div class="tab-content"&gt;
    &lt;div v-if="activeTab === 'map'"&gt;Map View Content&lt;/div&gt;
    &lt;div v-else-if="activeTab === 'list'"&gt;List View Content&lt;/div&gt;
    &lt;div v-else-if="activeTab === 'grid'"&gt;Grid View Content&lt;/div&gt;
  &lt;/div&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPSegment, PPSegmentButton } from '@phanna/ui-framework';

const activeTab = ref('map');
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- Scrollable Segment -->
    <div style="margin-top: 40px;">
      <h3>Scrollable Segment (PPScrollSegment)</h3>
      <p>A scrollable segmented control for a large number of options.</p>
      
      <div class="demo-box" style="padding: 40px; background: #f8fafc; border-radius: 12px; display: flex; flex-direction: column; align-items: center; gap: 20px;">
        <PPScrollSegment v-model="activeScrollTab" style="width: 100%; max-width: 400px;">
          <PPScrollSegmentButton v-for="cat in categories" :key="cat" :value="cat">
            {{ cat }}
          </PPScrollSegmentButton>
        </PPScrollSegment>
        <p style="font-size: 14px; color: #64748b;">Selected: <strong>{{ activeScrollTab }}</strong></p>
      </div>

      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPScrollSegment v-model="activeCategory"&gt;
    &lt;PPScrollSegmentButton value="all"&gt;All&lt;/PPScrollSegmentButton&gt;
    &lt;PPScrollSegmentButton value="electronics"&gt;Electronics&lt;/PPScrollSegmentButton&gt;
    &lt;PPScrollSegmentButton value="clothing"&gt;Clothing&lt;/PPScrollSegmentButton&gt;
    &lt;PPScrollSegmentButton value="books"&gt;Books&lt;/PPScrollSegmentButton&gt;
    &lt;PPScrollSegmentButton value="home"&gt;Home & Garden&lt;/PPScrollSegmentButton&gt;
  &lt;/PPScrollSegment&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPScrollSegment, PPScrollSegmentButton } from '@phanna/ui-framework';

const activeCategory = ref('all');
&lt;/script&gt;</code></pre>
      </div>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-background-alt: /* value */;
  --pp-border-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-variant: /* value */;
  --pp-scroll-segment-bg: /* value */;
  --pp-scroll-segment-border-radius: /* value */;
  --pp-scroll-segment-btn-active-bg: /* value */;
  --pp-scroll-segment-btn-active-border-color: /* value */;
  --pp-scroll-segment-btn-active-color: /* value */;
  --pp-scroll-segment-btn-bg: /* value */;
  --pp-scroll-segment-btn-border-color: /* value */;
  --pp-scroll-segment-btn-color: /* value */;
  --pp-scroll-segment-btn-font-size: /* value */;
  --pp-scroll-segment-btn-padding: /* value */;
  --pp-scroll-segment-btn-radius: /* value */;
  --pp-scroll-segment-btn-shadow: /* value */;
  --pp-scroll-segment-gap: /* value */;
  --pp-scroll-segment-margin-bottom: /* value */;
  --pp-scroll-segment-padding: /* value */;
  --pp-segment-bg: /* value */;
  --pp-segment-border-color: /* value */;
  --pp-segment-btn-active-bg: /* value */;
  --pp-segment-btn-active-color: /* value */;
  --pp-segment-btn-active-shadow: /* value */;
  --pp-segment-btn-color: /* value */;
  --pp-segment-btn-font-size: /* value */;
  --pp-segment-btn-font-weight: /* value */;
  --pp-segment-btn-padding: /* value */;
  --pp-segment-btn-radius: /* value */;
  --pp-segment-icon-size: /* value */;
  --pp-segment-padding: /* value */;
  --pp-segment-radius: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { 
  PPSegment, 
  PPSegmentButton,
  PPScrollSegment,
  PPScrollSegmentButton
} from '@phanna/ui-framework';

const activeTab = ref('map');
const activeScrollTab = ref('All');

const categories = ['All', 'Electronics', 'Clothing', 'Books', 'Home & Garden', 'Sports', 'Toys', 'Health'];
<\/script>
`)])],-1))],64))}});export{D as _};
