import{bh as l,bi as n}from"./AccountCardSection-DXixqG3L.js";import{d as r,o as s,j as p,l as e,a as t,w as u,u as a,y as c,F as d,p as m}from"../vendors/vendor-ah_eQdvw.js";const v={class:"guide-section"},g={class:"variant-group"},h={class:"component-demo"},b={style:{"margin-top":"10px"}},f=r({__name:"RadioSection",setup(C){const i=m("option1");return(S,o)=>(s(),p(d,null,[e("div",v,[o[3]||(o[3]=e("h2",null,"Radio & Radio Group",-1)),e("div",g,[o[1]||(o[1]=e("h3",null,"Radio Group",-1)),e("div",h,[t(a(n),{modelValue:i.value,"onUpdate:modelValue":o[0]||(o[0]=P=>i.value=P)},{default:u(()=>[t(a(l),{value:"option1",label:"Option 1"}),t(a(l),{value:"option2",label:"Option 2"}),t(a(l),{value:"option3",label:"Option 3"})]),_:1},8,["modelValue"]),e("p",b,"Selected: "+c(i.value),1)]),o[2]||(o[2]=e("pre",{class:"code-block"},[e("code",null,`<template>
  <PPRadioGroup v-model="radioVal">
    <PPRadio value="option1" label="Option 1" />
    <PPRadio value="option2" label="Option 2" />
    <PPRadio value="option3" label="Option 3" />
  </PPRadioGroup>
</template>

<script setup>
import { ref } from 'vue';
const radioVal = ref('option1');
<\/script>`)],-1))]),o[4]||(o[4]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[5]||(o[5]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Radio & Radio Group</h2>
        <div class="variant-group">
          <h3>Radio Group</h3>
          <div class="component-demo">
            <PPRadioGroup v-model="radioVal">
              <PPRadio value="option1" label="Option 1" />
              <PPRadio value="option2" label="Option 2" />
              <PPRadio value="option3" label="Option 3" />
            </PPRadioGroup>
            <p style="margin-top: 10px;">Selected: {{ radioVal }}</p>
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPRadioGroup v-model="radioVal"&gt;
    &lt;PPRadio value="option1" label="Option 1" /&gt;
    &lt;PPRadio value="option2" label="Option 2" /&gt;
    &lt;PPRadio value="option3" label="Option 3" /&gt;
  &lt;/PPRadioGroup&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
const radioVal = ref('option1');
&lt;/script&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const radioVal = ref('option1');



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{f as _};
