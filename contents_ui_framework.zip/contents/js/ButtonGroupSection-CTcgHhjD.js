import{P as a,Y as l}from"./AccountCardSection-DXixqG3L.js";import{d as r,o as s,j as P,l as o,a as n,w as u,u as i,A as e,F as d}from"../vendors/vendor-ah_eQdvw.js";const p={class:"guide-section"},v={class:"variant-group"},B={class:"component-demo"},c={class:"variant-group"},g={class:"component-demo"},m={class:"variant-group"},f={class:"component-demo"},G={class:"variant-group"},b={class:"component-demo"},C=r({__name:"ButtonGroupSection",setup(y){return(k,t)=>(s(),P(d,null,[o("div",p,[t[20]||(t[20]=o("h2",null,"1.5 Button Group",-1)),o("div",v,[t[3]||(t[3]=o("h3",null,"Connected Group (Default)",-1)),o("div",B,[n(i(l),null,{default:u(()=>[n(i(a),{variant:"outline"},{default:u(()=>[...t[0]||(t[0]=[e("Left",-1)])]),_:1}),n(i(a),{variant:"outline"},{default:u(()=>[...t[1]||(t[1]=[e("Middle",-1)])]),_:1}),n(i(a),{variant:"outline"},{default:u(()=>[...t[2]||(t[2]=[e("Right",-1)])]),_:1})]),_:1})]),t[4]||(t[4]=o("pre",{class:"code-block"},[o("code",null,`<PPButtonGroup>
  <PPButton variant="outline">Left</PPButton>
  <PPButton variant="outline">Middle</PPButton>
  <PPButton variant="outline">Right</PPButton>
</PPButtonGroup>`)],-1))]),o("div",c,[t[8]||(t[8]=o("h3",null,"Segmented Group",-1)),o("div",g,[n(i(l),{variant:"segmented"},{default:u(()=>[n(i(a),{variant:"primary"},{default:u(()=>[...t[5]||(t[5]=[e("Active",-1)])]),_:1}),n(i(a),{variant:"ghost"},{default:u(()=>[...t[6]||(t[6]=[e("Inactive",-1)])]),_:1}),n(i(a),{variant:"ghost"},{default:u(()=>[...t[7]||(t[7]=[e("Disabled",-1)])]),_:1})]),_:1})]),t[9]||(t[9]=o("pre",{class:"code-block"},[o("code",null,`<PPButtonGroup variant="segmented">
  <PPButton variant="primary">Active</PPButton>
  <PPButton variant="ghost">Inactive</PPButton>
  <PPButton variant="ghost">Disabled</PPButton>
</PPButtonGroup>`)],-1))]),o("div",m,[t[13]||(t[13]=o("h3",null,"Separated Group",-1)),o("div",f,[n(i(l),{variant:"separated"},{default:u(()=>[n(i(a),{variant:"outline"},{default:u(()=>[...t[10]||(t[10]=[e("Action 1",-1)])]),_:1}),n(i(a),{variant:"outline"},{default:u(()=>[...t[11]||(t[11]=[e("Action 2",-1)])]),_:1}),n(i(a),{variant:"outline"},{default:u(()=>[...t[12]||(t[12]=[e("Action 3",-1)])]),_:1})]),_:1})]),t[14]||(t[14]=o("pre",{class:"code-block"},[o("code",null,`<PPButtonGroup variant="separated">
  <PPButton variant="outline">Action 1</PPButton>
  <PPButton variant="outline">Action 2</PPButton>
  <PPButton variant="outline">Action 3</PPButton>
</PPButtonGroup>`)],-1))]),o("div",G,[t[18]||(t[18]=o("h3",null,"Vertical Group",-1)),o("div",b,[n(i(l),{vertical:""},{default:u(()=>[n(i(a),{variant:"outline",block:""},{default:u(()=>[...t[15]||(t[15]=[e("Top",-1)])]),_:1}),n(i(a),{variant:"outline",block:""},{default:u(()=>[...t[16]||(t[16]=[e("Middle",-1)])]),_:1}),n(i(a),{variant:"outline",block:""},{default:u(()=>[...t[17]||(t[17]=[e("Bottom",-1)])]),_:1})]),_:1})]),t[19]||(t[19]=o("pre",{class:"code-block"},[o("code",null,`<PPButtonGroup vertical>
  ...
</PPButtonGroup>`)],-1))]),t[21]||(t[21]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[22]||(t[22]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
<div class="guide-section">
        <h2>1.5 Button Group</h2>

        <div class="variant-group">
          <h3>Connected Group (Default)</h3>
          <div class="component-demo">
            <PPButtonGroup>
              <PPButton variant="outline">Left</PPButton>
              <PPButton variant="outline">Middle</PPButton>
              <PPButton variant="outline">Right</PPButton>
            </PPButtonGroup>
          </div>
          <pre class="code-block"><code>&lt;PPButtonGroup&gt;
  &lt;PPButton variant="outline"&gt;Left&lt;/PPButton&gt;
  &lt;PPButton variant="outline"&gt;Middle&lt;/PPButton&gt;
  &lt;PPButton variant="outline"&gt;Right&lt;/PPButton&gt;
&lt;/PPButtonGroup&gt;</code></pre>
        </div>
        
        <div class="variant-group">
          <h3>Segmented Group</h3>
          <div class="component-demo">
            <PPButtonGroup variant="segmented">
              <PPButton variant="primary">Active</PPButton>
              <PPButton variant="ghost">Inactive</PPButton>
              <PPButton variant="ghost">Disabled</PPButton>
            </PPButtonGroup>
          </div>
          <pre class="code-block"><code>&lt;PPButtonGroup variant="segmented"&gt;
  &lt;PPButton variant="primary"&gt;Active&lt;/PPButton&gt;
  &lt;PPButton variant="ghost"&gt;Inactive&lt;/PPButton&gt;
  &lt;PPButton variant="ghost"&gt;Disabled&lt;/PPButton&gt;
&lt;/PPButtonGroup&gt;</code></pre>
        </div>
        
        <div class="variant-group">
          <h3>Separated Group</h3>
          <div class="component-demo">
            <PPButtonGroup variant="separated">
              <PPButton variant="outline">Action 1</PPButton>
              <PPButton variant="outline">Action 2</PPButton>
              <PPButton variant="outline">Action 3</PPButton>
            </PPButtonGroup>
          </div>
          <pre class="code-block"><code>&lt;PPButtonGroup variant="separated"&gt;
  &lt;PPButton variant="outline"&gt;Action 1&lt;/PPButton&gt;
  &lt;PPButton variant="outline"&gt;Action 2&lt;/PPButton&gt;
  &lt;PPButton variant="outline"&gt;Action 3&lt;/PPButton&gt;
&lt;/PPButtonGroup&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Vertical Group</h3>
          <div class="component-demo">
            <PPButtonGroup vertical>
              <PPButton variant="outline" block>Top</PPButton>
              <PPButton variant="outline" block>Middle</PPButton>
              <PPButton variant="outline" block>Bottom</PPButton>
            </PPButtonGroup>
          </div>
          <pre class="code-block"><code>&lt;PPButtonGroup vertical&gt;
  ...
&lt;/PPButtonGroup&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPButton, PPButtonGroup } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{C as _};
