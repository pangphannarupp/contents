import{b3 as l,b4 as n,P as p}from"./AccountCardSection-DXixqG3L.js";import{d as v,o as b,j as g,l as t,a as i,u as o,c1 as f,aS as h,c2 as y,U as x,w as c,A as d,L as P,F as S,p as w}from"../vendors/vendor-ah_eQdvw.js";const k={class:"component-section"},O={style:{"margin-top":"32px"}},C={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"24px"}},I={style:{"margin-top":"32px"}},B={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"48px"}},A={style:{display:"flex","justify-content":"space-between","max-width":"400px",margin:"0 auto",width:"100%"}},U=v({__name:"NavigationPathSection",setup(z){const u=[{label:"Home",href:"#"},{label:"Dashboard",href:"#"},{label:"Reports"}],m=[{label:"Library",icon:f,href:"#"},{label:"Images",icon:h,href:"#"},{label:"Vacation 2026",icon:y}],s=w(1),r=[{title:"Account Setup",description:"Create your credentials"},{title:"Personal Info",description:"Address and details"},{title:"Payment",description:"Add credit card"},{title:"Review",description:"Confirm your order"}];return(F,e)=>(b(),g(S,null,[t("div",k,[e[11]||(e[11]=t("h2",null,"Navigation Paths",-1)),e[12]||(e[12]=t("p",null,"Components for guiding users through a sequence of steps or a hierarchical structure.",-1)),t("div",O,[e[3]||(e[3]=t("h3",null,"Breadcrumbs",-1)),e[4]||(e[4]=t("p",null,"A hierarchical trail of links to help users navigate back to previous pages.",-1)),t("div",C,[i(o(l),{items:u}),i(o(l),{items:m,separatorIcon:o(x)},null,8,["separatorIcon"])])]),t("div",I,[e[9]||(e[9]=t("h3",null,"Stepper",-1)),e[10]||(e[10]=t("p",null,"A wizard component for multi-step processes.",-1)),t("div",B,[t("div",null,[e[5]||(e[5]=t("h4",{style:{"margin-top":"0",color:"#64748b","font-size":"14px"}},"Horizontal (Clickable)",-1)),i(o(n),{steps:r,activeStep:s.value,"onUpdate:activeStep":e[0]||(e[0]=a=>s.value=a),clickable:""},null,8,["activeStep"])]),t("div",A,[i(o(p),{variant:"outline",onClick:e[1]||(e[1]=a=>s.value--),disabled:s.value===0},{default:c(()=>[...e[6]||(e[6]=[d("Previous",-1)])]),_:1},8,["disabled"]),i(o(p),{onClick:e[2]||(e[2]=a=>s.value++),disabled:s.value===r.length-1},{default:c(()=>[...e[7]||(e[7]=[d("Next",-1)])]),_:1},8,["disabled"])]),t("div",null,[e[8]||(e[8]=t("h4",{style:{"margin-top":"0",color:"#64748b","font-size":"14px"}},"Vertical",-1)),i(o(n),{steps:r,activeStep:1,orientation:"vertical"})])])]),e[13]||(e[13]=P(`<div style="margin-top:40px;"><h3>Usage Example</h3><pre class="code-block" style="background:#f8fafc;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;PPBreadcrumb :items=&quot;breadcrumbs&quot; :separatorIcon=&quot;chevronForwardOutline&quot; /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPBreadcrumb } from &#39;@phanna/ui-framework&#39;;
import { chevronForwardOutline, homeOutline } from &#39;ionicons/icons&#39;;

const breadcrumbs = [
  { label: &#39;Home&#39;, icon: homeOutline, href: &#39;/&#39; },
  { label: &#39;Settings&#39; }
];
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[14]||(e[14]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Navigation Paths</h2>
    <p>Components for guiding users through a sequence of steps or a hierarchical structure.</p>

    <!-- Breadcrumb -->
    <div style="margin-top: 32px;">
      <h3>Breadcrumbs</h3>
      <p>A hierarchical trail of links to help users navigate back to previous pages.</p>
      
      <div class="demo-box" style="display: flex; flex-direction: column; gap: 24px;">
        <PPBreadcrumb :items="breadcrumbItems1" />
        
        <PPBreadcrumb :items="breadcrumbItems2" :separatorIcon="chevronForwardOutline" />
      </div>
    </div>

    <!-- Stepper -->
    <div style="margin-top: 32px;">
      <h3>Stepper</h3>
      <p>A wizard component for multi-step processes.</p>
      
      <div class="demo-box" style="display: flex; flex-direction: column; gap: 48px;">
        <div>
          <h4 style="margin-top: 0; color: #64748b; font-size: 14px;">Horizontal (Clickable)</h4>
          <PPStepper 
            :steps="stepperItems" 
            v-model:activeStep="activeStep" 
            clickable 
          />
        </div>
        
        <div style="display: flex; justify-content: space-between; max-width: 400px; margin: 0 auto; width: 100%;">
          <PPButton variant="outline" @click="activeStep--" :disabled="activeStep === 0">Previous</PPButton>
          <PPButton @click="activeStep++" :disabled="activeStep === stepperItems.length - 1">Next</PPButton>
        </div>

        <div>
          <h4 style="margin-top: 0; color: #64748b; font-size: 14px;">Vertical</h4>
          <PPStepper 
            :steps="stepperItems" 
            :activeStep="1" 
            orientation="vertical" 
          />
        </div>
      </div>
    </div>


    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPBreadcrumb :items="breadcrumbs" :separatorIcon="chevronForwardOutline" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPBreadcrumb } from '@phanna/ui-framework';
import { chevronForwardOutline, homeOutline } from 'ionicons/icons';

const breadcrumbs = [
  { label: 'Home', icon: homeOutline, href: '/' },
  { label: 'Settings' }
];
&lt;/script&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPBreadcrumb, PPStepper, PPButton } from '@phanna/ui-framework';
import { folderOutline, imageOutline, imagesOutline, chevronForwardOutline } from 'ionicons/icons';

const breadcrumbItems1 = [
  { label: 'Home', href: '#' },
  { label: 'Dashboard', href: '#' },
  { label: 'Reports' }
];

const breadcrumbItems2 = [
  { label: 'Library', icon: folderOutline, href: '#' },
  { label: 'Images', icon: imageOutline, href: '#' },
  { label: 'Vacation 2026', icon: imagesOutline }
];

const activeStep = ref(1);

const stepperItems = [
  { title: 'Account Setup', description: 'Create your credentials' },
  { title: 'Personal Info', description: 'Address and details' },
  { title: 'Payment', description: 'Add credit card' },
  { title: 'Review', description: 'Confirm your order' }
];
<\/script>
`)])],-1))],64))}});export{U as _};
