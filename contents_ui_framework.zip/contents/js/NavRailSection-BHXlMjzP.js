import{d as s,o as P,j as c,l as e,a as u,u as d,A as m,y as p,F as g,p as i,aB as v,bc as h,aD as b}from"../vendors/vendor-ah_eQdvw.js";import{b2 as C}from"./AccountCardSection-DXixqG3L.js";const k={class:"guide-section"},S={class:"variant-group"},f={class:"component-demo",style:{height:"400px",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden",display:"flex",background:"#fff"}},y={style:{flex:"1",padding:"24px"}},A=s({__name:"NavRailSection",setup(I){const l=i("Home"),a=i([{label:"Home",active:!0,icon:v},{label:"History",badge:"1",icon:h},{label:"Profile",icon:b}]),n=o=>{a.value.forEach(t=>t.active=!1),o.active=!0,l.value=o.label},r=o=>console.log("Setup: "+o);return(o,t)=>(P(),c(g,null,[e("div",k,[t[6]||(t[6]=e("h2",null,"18. Navigation Rail (Material 3)",-1)),e("div",S,[t[3]||(t[3]=e("h3",null,"Interactive Demo",-1)),t[4]||(t[4]=e("p",{class:"custom-guide"},"A vertical navigation rail typically used on larger screens.",-1)),e("div",f,[u(d(C),{items:a.value,showMenu:"",onMenuClick:t[0]||(t[0]=O=>r("Menu Toggle Clicked!")),onItemClick:n},null,8,["items"]),e("div",y,[t[2]||(t[2]=e("h3",{style:{"margin-top":"0"}},"Main Content Area",-1)),e("p",null,[t[1]||(t[1]=m("Selected tab: ",-1)),e("strong",null,p(l.value),1)])])]),t[5]||(t[5]=e("pre",{class:"code-block"},[e("code",null,`<PPNavigationRail 
  :items="railItems" 
  @item-click="onRailClick" 
/>`)],-1))]),t[7]||(t[7]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[8]||(t[8]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>18. Navigation Rail (Material 3)</h2>

        <div class="variant-group">
          <h3>Interactive Demo</h3>
          <p class="custom-guide">A vertical navigation rail typically used on larger screens.</p>
          <div class="component-demo" style="height: 400px; border: 1px solid #ddd; border-radius: 12px; overflow: hidden; display: flex; background: #fff;">
            <PPNavigationRail 
              :items="navRailItems" 
              showMenu
              @menu-click="alertVal('Menu Toggle Clicked!')"
              @item-click="handleRailClick"
            />
            <div style="flex: 1; padding: 24px;">
              <h3 style="margin-top: 0">Main Content Area</h3>
              <p>Selected tab: <strong>{{ selectedRailItem }}</strong></p>
            </div>
          </div>
          <pre class="code-block"><code>&lt;PPNavigationRail 
  :items="railItems" 
  @item-click="onRailClick" 
/&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const selectedRailItem = ref('Home');

const navRailItems = ref([
  { label: 'Home', active: true, icon: homeOutline },
  { label: 'History', badge: '1', icon: documentTextOutline },
  { label: 'Profile', icon: personOutline }
]);

const handleRailClick = (item: any) => {
  navRailItems.value.forEach(i => i.active = false);
  item.active = true;
  selectedRailItem.value = item.label;
};

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{A as _};
