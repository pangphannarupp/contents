import{aG as o}from"./AccountCardSection-DXixqG3L.js";import{d as i,o as a,j as l,l as e,a as n,w as s,u as r,F as p}from"../vendors/vendor-ah_eQdvw.js";const c={class:"guide-section"},d={class:"variant-group"},u={class:"component-demo",style:{display:"flex",gap:"16px","align-items":"center"}},m={style:{width:"60px",height:"60px","border-radius":"50%",overflow:"hidden"}},y=i({__name:"ImageTransitionSection",setup(g){return(h,t)=>(a(),l(p,null,[e("div",c,[t[5]||(t[5]=e("h2",null,"Image Transition (List to Detail)",-1)),e("div",d,[t[3]||(t[3]=e("h3",null,"Seamless Fullscreen Expansion",-1)),t[4]||(t[4]=e("p",{class:"custom-guide"},"Tap the thumbnail to see it expand perfectly into a full-screen detail view!",-1)),e("div",u,[e("div",m,[n(r(o),null,{image:s(()=>[...t[0]||(t[0]=[e("img",{src:"https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=1000&auto=format&fit=crop",alt:"Thumbnail"},null,-1)])]),detail:s(()=>[...t[1]||(t[1]=[e("div",{style:{padding:"24px",color:"#333"}},[e("h2",{style:{"margin-top":"0","font-size":"28px"}},"Jane Doe"),e("p",{style:{"font-size":"16px","line-height":"1.5",color:"#666"}}," This image expanded beautifully without needing a route transition! Click the back button in the top left corner to collapse it right back into the list. ")],-1)])]),_:1})]),t[2]||(t[2]=e("div",null,[e("strong",{style:{display:"block","font-size":"16px"}},"Jane Doe"),e("span",{style:{color:"#666","font-size":"14px"}},"Tap image to view profile")],-1))])]),t[6]||(t[6]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[7]||(t[7]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Image Transition (List to Detail)</h2>
        <div class="variant-group">
          <h3>Seamless Fullscreen Expansion</h3>
          <p class="custom-guide">Tap the thumbnail to see it expand perfectly into a full-screen detail view!</p>
          <div class="component-demo" style="display: flex; gap: 16px; align-items: center;">
            <div style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden;">
              <PPImageTransition>
                <template #image>
                  <img 
                    src="https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=1000&auto=format&fit=crop" 
                    alt="Thumbnail"
                  />
                </template>
                <template #detail>
                  <div style="padding: 24px; color: #333;">
                    <h2 style="margin-top: 0; font-size: 28px;">Jane Doe</h2>
                    <p style="font-size: 16px; line-height: 1.5; color: #666;">
                      This image expanded beautifully without needing a route transition! 
                      Click the back button in the top left corner to collapse it right back into the list.
                    </p>
                  </div>
                </template>
              </PPImageTransition>
            </div>
            <div>
              <strong style="display: block; font-size: 16px;">Jane Doe</strong>
              <span style="color: #666; font-size: 14px;">Tap image to view profile</span>
            </div>
          </div>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPImageTransition } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{y as _};
