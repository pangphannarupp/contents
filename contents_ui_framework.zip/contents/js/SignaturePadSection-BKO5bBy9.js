import{d as z,o as h,j as y,l as o,a,u as t,c4 as O,E as f,V as b,a1 as P,aT as V,y as A,cc as E,w as d,A as u,k as R,F as D,p as s}from"../vendors/vendor-ah_eQdvw.js";import{bq as I,P as c,br as M,bs as F}from"./AccountCardSection-DXixqG3L.js";import{_ as U}from"./App-D7rwXoHs.js";const W={class:"guide-section"},N={class:"demo-box"},_={class:"options-toolbar"},T={class:"toolbar-item"},j={class:"toolbar-item"},Y={class:"slider-container"},$={class:"size-label"},q={class:"toolbar-item"},G={class:"action-buttons"},H={key:0,class:"signature-preview"},J=["src"],K={class:"demo-box",style:{"flex-direction":"row",gap:"16px"}},L=z({__name:"SignaturePadSection",setup(Q){const i=s(null),n=s(null),p=s(!1),g=s(!1),v=s("#000000"),r=s(2),m=s("#ffffff"),k=()=>{console.log("Started drawing")},w=()=>{console.log("Finished drawing")},C=()=>{i.value&&(i.value.clear(),n.value=null)},B=()=>{i.value&&!i.value.isEmpty()&&(n.value=i.value.getData())},S=x=>{n.value=x};return(x,e)=>(h(),y(D,null,[o("div",W,[e[12]||(e[12]=o("h2",null,"Signature Pad",-1)),e[13]||(e[13]=o("p",null,"A native canvas-based signature pad that works on both touch and mouse devices.",-1)),e[14]||(e[14]=o("h3",null,"Standard Signature",-1)),o("div",N,[o("div",_,[o("div",T,[a(t(f),{icon:t(O),class:"toolbar-icon"},null,8,["icon"]),b(o("input",{type:"color","onUpdate:modelValue":e[0]||(e[0]=l=>v.value=l),class:"color-picker",title:"Pen Color"},null,512),[[P,v.value]])]),o("div",j,[a(t(f),{icon:t(V),class:"toolbar-icon"},null,8,["icon"]),o("div",Y,[b(o("input",{type:"range","onUpdate:modelValue":e[1]||(e[1]=l=>r.value=l),min:"1",max:"10",class:"size-slider",title:"Pen Size"},null,512),[[P,r.value,void 0,{number:!0}]]),o("span",$,A(r.value)+"px",1)])]),o("div",q,[a(t(f),{icon:t(E),class:"toolbar-icon"},null,8,["icon"]),b(o("input",{type:"color","onUpdate:modelValue":e[2]||(e[2]=l=>m.value=l),class:"color-picker",title:"Background Color"},null,512),[[P,m.value]])])]),a(t(I),{ref_key:"sigPadRef",ref:i,placeholder:"Please sign here",strokeColor:v.value,lineWidth:r.value,backgroundColor:m.value,onBegin:k,onEnd:w},null,8,["strokeColor","lineWidth","backgroundColor"]),o("div",G,[a(t(c),{variant:"outline",onClick:C},{default:d(()=>[...e[7]||(e[7]=[u("Clear",-1)])]),_:1}),a(t(c),{onClick:B},{default:d(()=>[...e[8]||(e[8]=[u("Save",-1)])]),_:1})]),n.value?(h(),y("div",H,[e[9]||(e[9]=o("h4",null,"Saved Result:",-1)),o("img",{src:n.value,alt:"Saved signature"},null,8,J)])):R("",!0)]),e[15]||(e[15]=o("h3",null,"Modal Examples",-1)),o("div",K,[a(t(c),{variant:"outline",onClick:e[3]||(e[3]=l=>p.value=!0)},{default:d(()=>[...e[10]||(e[10]=[u("Open Alert",-1)])]),_:1}),a(t(c),{onClick:e[4]||(e[4]=l=>g.value=!0)},{default:d(()=>[...e[11]||(e[11]=[u("Open Bottom Sheet",-1)])]),_:1})]),a(t(M),{modelValue:p.value,"onUpdate:modelValue":e[5]||(e[5]=l=>p.value=l),title:"Sign Contract",onSave:S},null,8,["modelValue"]),a(t(F),{modelValue:g.value,"onUpdate:modelValue":e[6]||(e[6]=l=>g.value=l),title:"Sign Delivery",onSave:S},null,8,["modelValue"]),e[16]||(e[16]=o("pre",{class:"code-block"},[o("code",null,`<PPSignaturePad 
  ref="sigPad" 
  placeholder="Sign here" 
  :lineWidth="3" 
  strokeColor="#003399" 
/>

<script setup>
import { ref } from 'vue';

const sigPad = ref(null);

const save = () => {
  if (sigPad.value.isEmpty()) return;
  const base64Image = sigPad.value.getData();
  console.log(base64Image);
};

const clear = () => {
  sigPad.value.clear();
};
<\/script>`)],-1)),e[17]||(e[17]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[18]||(e[18]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="guide-section">
    <h2>Signature Pad</h2>
    <p>A native canvas-based signature pad that works on both touch and mouse devices.</p>

    <h3>Standard Signature</h3>
    <div class="demo-box">
      <div class="options-toolbar">
        <div class="toolbar-item">
          <ion-icon :icon="colorPaletteOutline" class="toolbar-icon" />
          <input type="color" v-model="penColor" class="color-picker" title="Pen Color" />
        </div>
        
        <div class="toolbar-item">
          <ion-icon :icon="pencilOutline" class="toolbar-icon" />
          <div class="slider-container">
            <input type="range" v-model.number="penSize" min="1" max="10" class="size-slider" title="Pen Size" />
            <span class="size-label">{{ penSize }}px</span>
          </div>
        </div>

        <div class="toolbar-item">
          <ion-icon :icon="brushOutline" class="toolbar-icon" />
          <input type="color" v-model="bgColor" class="color-picker" title="Background Color" />
        </div>
      </div>

      <PPSignaturePad 
        ref="sigPadRef"
        placeholder="Please sign here"
        :strokeColor="penColor"
        :lineWidth="penSize"
        :backgroundColor="bgColor"
        @begin="onBegin"
        @end="onEnd"
      />
      
      <div class="action-buttons">
        <PPButton variant="outline" @click="clearPad">Clear</PPButton>
        <PPButton @click="saveSignature">Save</PPButton>
      </div>

      <div v-if="savedSignature" class="signature-preview">
        <h4>Saved Result:</h4>
        <img :src="savedSignature" alt="Saved signature" />
      </div>
    </div>
    
    <h3>Modal Examples</h3>
    <div class="demo-box" style="flex-direction: row; gap: 16px;">
      <PPButton variant="outline" @click="showAlert = true">Open Alert</PPButton>
      <PPButton @click="showSheet = true">Open Bottom Sheet</PPButton>
    </div>

    <PPSignaturePadAlert
      v-model="showAlert"
      title="Sign Contract"
      @save="onSaveModal"
    />

    <PPSignaturePadSheet
      v-model="showSheet"
      title="Sign Delivery"
      @save="onSaveModal"
    />
    
    <pre class="code-block"><code>&lt;PPSignaturePad 
  ref="sigPad" 
  placeholder="Sign here" 
  :lineWidth="3" 
  strokeColor="#003399" 
/&gt;

&lt;script setup&gt;
import { ref } from 'vue';

const sigPad = ref(null);

const save = () => {
  if (sigPad.value.isEmpty()) return;
  const base64Image = sigPad.value.getData();
  console.log(base64Image);
};

const clear = () => {
  sigPad.value.clear();
};
&lt;/script&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { IonIcon } from '@ionic/vue';
import { pencilOutline, colorPaletteOutline, brushOutline } from 'ionicons/icons';
import { PPSignaturePad, PPSignaturePadAlert, PPSignaturePadSheet, PPButton } from '@phanna/ui-framework';

const sigPadRef = ref<any>(null);
const savedSignature = ref<string | null>(null);

const showAlert = ref(false);
const showSheet = ref(false);

const penColor = ref('#000000');
const penSize = ref(2);
const bgColor = ref('#ffffff');

const onBegin = () => {
  console.log('Started drawing');
};

const onEnd = () => {
  console.log('Finished drawing');
};

const clearPad = () => {
  if (sigPadRef.value) {
    sigPadRef.value.clear();
    savedSignature.value = null;
  }
};

const saveSignature = () => {
  if (sigPadRef.value && !sigPadRef.value.isEmpty()) {
    savedSignature.value = sigPadRef.value.getData();
  }
};

const onSaveModal = (data: string) => {
  savedSignature.value = data;
};
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; display: flex; flex-direction: column; gap: 16px; }
.options-toolbar { display: flex; gap: 24px; align-items: center; padding: 12px 20px; background: #ffffff; border: 1px solid #e5e7eb; border-radius: 8px; flex-wrap: wrap; box-shadow: 0 2px 4px rgba(0,0,0,0.02); margin-bottom: 8px; }
.toolbar-item { display: flex; align-items: center; gap: 8px; }
.toolbar-icon { font-size: 20px; color: #4b5563; }
.color-picker { width: 28px; height: 28px; padding: 0; border: none; border-radius: 50%; cursor: pointer; overflow: hidden; }
.color-picker::-webkit-color-swatch-wrapper { padding: 0; }
.color-picker::-webkit-color-swatch { border: 2px solid #e5e7eb; border-radius: 50%; }
.slider-container { display: flex; align-items: center; gap: 8px; }
.size-slider { width: 80px; accent-color: #003399; }
.size-label { font-size: 12px; color: #6b7280; width: 28px; }
.action-buttons { display: flex; gap: 12px; justify-content: flex-end; }
.signature-preview { margin-top: 16px; border-top: 1px solid #e0e0e0; padding-top: 16px; }
.signature-preview img { border: 1px dashed #ccc; background: white; max-width: 100%; height: auto; }
</style>
`)])],-1))],64))}}),oe=U(L,[["__scopeId","data-v-86e7c04d"]]);export{oe as S};
