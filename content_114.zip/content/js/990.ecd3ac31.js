"use strict";(self["webpackChunkvue_core_client"]=self["webpackChunkvue_core_client"]||[]).push([[990],{990:function(e,t,n){n.r(t),n.d(t,{createSwipeBackGesture:function(){return o}});var r=n(587),c=n(545),i=n(515);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const o=(e,t,n,o,s)=>{const a=e.ownerDocument.defaultView,u=(0,c.i)(e),l=e=>{const t=50,{startX:n}=e;return u?n>=a.innerWidth-t:n<=t},h=e=>u?-e.deltaX:e.deltaX,d=e=>u?-e.velocityX:e.velocityX,f=e=>l(e)&&t(),k=e=>{const t=h(e),n=t/a.innerWidth;o(n)},v=e=>{const t=h(e),n=a.innerWidth,c=t/n,i=d(e),o=n/2,u=i>=0&&(i>.2||t>o),l=u?1-c:c,f=l*n;let k=0;if(f>5){const e=f/Math.abs(i);k=Math.min(e,540)}s(u,c<=0?.01:(0,r.h)(0,c,.9999),k)};return(0,i.createGesture)({el:e,gestureName:"goback-swipe",gesturePriority:40,threshold:10,canStart:f,onStart:n,onMove:k,onEnd:v})}}}]);
//# sourceMappingURL=990.ecd3ac31.js.map