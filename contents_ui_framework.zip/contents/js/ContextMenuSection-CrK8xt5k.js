import{P as r,bl as c}from"./AccountCardSection-DXixqG3L.js";import{d as u,o as d,j as b,l as e,a as t,w as i,u as o,A as m,c4 as a,c6 as p,c7 as g,aI as n,b4 as h,a7 as C,F as O}from"../vendors/vendor-ah_eQdvw.js";import{_ as P}from"./App-D7rwXoHs.js";const f={class:"guide-section"},v={class:"variant-group"},x={class:"demo-box",style:{height:"300px",display:"flex","align-items":"flex-start"}},S=u({__name:"ContextMenuSection",setup(R){const s=[{label:"Highlight Cell Rules",icon:a,children:[{label:"Greater Than..."},{label:"Less Than..."},{label:"Between..."},{label:"Equal To..."}]},{label:"Top/Bottom Rules",icon:p,children:[{label:"Top 10 Items..."},{label:"Top 10%..."},{label:"Bottom 10 Items..."},{label:"Bottom 10%..."}]},{divider:!0},{label:"Data Bars",icon:g,children:[{label:"Gradient Fill"},{label:"Solid Fill"}]},{label:"Color Scales",icon:a,children:[{label:"Green-Yellow-Red"},{label:"Red-Yellow-Green"}]},{label:"Icon Sets",icon:n,children:[{label:"Directional"},{label:"Shapes"},{label:"Indicators"}]},{divider:!0},{label:"New Rule",icon:h},{label:"Clear Rules",icon:C,children:[{label:"Clear Rules from Selected Cells"},{label:"Clear Rules from Entire Sheet"}]},{label:"Manage Rules",icon:n}];return(B,l)=>(d(),b(O,null,[e("div",f,[l[3]||(l[3]=e("h2",null,"Context Menu",-1)),l[4]||(l[4]=e("p",null,"A multi-level context menu that supports icons, dividers, and nested submenus.",-1)),e("div",v,[l[1]||(l[1]=e("h3",null,"Basic Usage",-1)),e("div",x,[t(o(c),{items:s,placement:"bottom-left"},{trigger:i(()=>[t(o(r),null,{default:i(()=>[...l[0]||(l[0]=[m("Click to Open Menu",-1)])]),_:1})]),_:1})]),l[2]||(l[2]=e("pre",{class:"code-block",style:{"max-height":"400px","overflow-y":"auto"}},[e("code",null,`<template>
  <PPContextMenu :items="menuItems" placement="bottom-left">
    <template #trigger>
      <PPButton>Click to Open Menu</PPButton>
    </template>
  </PPContextMenu>
</template>

<script setup lang="ts">
import { PPContextMenu, PPButton } from '@phanna/ui-framework';
import { colorPaletteOutline, listOutline, listCircleOutline, addCircleOutline, trashOutline, settingsOutline } from 'ionicons/icons';

const menuItems = [
  {
    label: 'Highlight Cell Rules',
    icon: colorPaletteOutline,
    children: [
      { label: 'Greater Than...' },
      { label: 'Less Than...' },
      { label: 'Between...' },
      { label: 'Equal To...' }
    ]
  },
  {
    label: 'Top/Bottom Rules',
    icon: listOutline,
    children: [
      { label: 'Top 10 Items...' },
      { label: 'Top 10%...' },
      { label: 'Bottom 10 Items...' },
      { label: 'Bottom 10%...' }
    ]
  },
  { divider: true },
  {
    label: 'Data Bars',
    icon: listCircleOutline,
    children: [
      { label: 'Gradient Fill' },
      { label: 'Solid Fill' }
    ]
  },
  {
    label: 'Color Scales',
    icon: colorPaletteOutline,
    children: [
      { label: 'Green-Yellow-Red' },
      { label: 'Red-Yellow-Green' }
    ]
  },
  {
    label: 'Icon Sets',
    icon: settingsOutline,
    children: [
      { label: 'Directional' },
      { label: 'Shapes' },
      { label: 'Indicators' }
    ]
  },
  { divider: true },
  { label: 'New Rule', icon: addCircleOutline },
  { 
    label: 'Clear Rules', 
    icon: trashOutline,
    children: [
      { label: 'Clear Rules from Selected Cells' },
      { label: 'Clear Rules from Entire Sheet' }
    ]
  },
  { label: 'Manage Rules', icon: settingsOutline }
];
<\/script>`)],-1))]),l[5]||(l[5]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),l[6]||(l[6]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Context Menu</h2>
    <p>A multi-level context menu that supports icons, dividers, and nested submenus.</p>
    
    <div class="variant-group">
      <h3>Basic Usage</h3>
      <div class="demo-box" style="height: 300px; display: flex; align-items: flex-start;">
        <PPContextMenu :items="menuItems" placement="bottom-left">
          <template #trigger>
            <PPButton>Click to Open Menu</PPButton>
          </template>
        </PPContextMenu>
      </div>
      <pre class="code-block" style="max-height: 400px; overflow-y: auto;"><code>&lt;template&gt;
  &lt;PPContextMenu :items="menuItems" placement="bottom-left"&gt;
    &lt;template #trigger&gt;
      &lt;PPButton&gt;Click to Open Menu&lt;/PPButton&gt;
    &lt;/template&gt;
  &lt;/PPContextMenu&gt;
&lt;/template&gt;

&lt;script setup lang="ts"&gt;
import { PPContextMenu, PPButton } from '@phanna/ui-framework';
import { colorPaletteOutline, listOutline, listCircleOutline, addCircleOutline, trashOutline, settingsOutline } from 'ionicons/icons';

const menuItems = [
  {
    label: 'Highlight Cell Rules',
    icon: colorPaletteOutline,
    children: [
      { label: 'Greater Than...' },
      { label: 'Less Than...' },
      { label: 'Between...' },
      { label: 'Equal To...' }
    ]
  },
  {
    label: 'Top/Bottom Rules',
    icon: listOutline,
    children: [
      { label: 'Top 10 Items...' },
      { label: 'Top 10%...' },
      { label: 'Bottom 10 Items...' },
      { label: 'Bottom 10%...' }
    ]
  },
  { divider: true },
  {
    label: 'Data Bars',
    icon: listCircleOutline,
    children: [
      { label: 'Gradient Fill' },
      { label: 'Solid Fill' }
    ]
  },
  {
    label: 'Color Scales',
    icon: colorPaletteOutline,
    children: [
      { label: 'Green-Yellow-Red' },
      { label: 'Red-Yellow-Green' }
    ]
  },
  {
    label: 'Icon Sets',
    icon: settingsOutline,
    children: [
      { label: 'Directional' },
      { label: 'Shapes' },
      { label: 'Indicators' }
    ]
  },
  { divider: true },
  { label: 'New Rule', icon: addCircleOutline },
  { 
    label: 'Clear Rules', 
    icon: trashOutline,
    children: [
      { label: 'Clear Rules from Selected Cells' },
      { label: 'Clear Rules from Entire Sheet' }
    ]
  },
  { label: 'Manage Rules', icon: settingsOutline }
];
&lt;/script&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPContextMenu, PPButton } from '@phanna/ui-framework';
import { colorPaletteOutline, listOutline, listCircleOutline, addCircleOutline, trashOutline, settingsOutline } from 'ionicons/icons';

const menuItems = [
  {
    label: 'Highlight Cell Rules',
    icon: colorPaletteOutline,
    children: [
      { label: 'Greater Than...' },
      { label: 'Less Than...' },
      { label: 'Between...' },
      { label: 'Equal To...' }
    ]
  },
  {
    label: 'Top/Bottom Rules',
    icon: listOutline,
    children: [
      { label: 'Top 10 Items...' },
      { label: 'Top 10%...' },
      { label: 'Bottom 10 Items...' },
      { label: 'Bottom 10%...' }
    ]
  },
  { divider: true },
  {
    label: 'Data Bars',
    icon: listCircleOutline,
    children: [
      { label: 'Gradient Fill' },
      { label: 'Solid Fill' }
    ]
  },
  {
    label: 'Color Scales',
    icon: colorPaletteOutline,
    children: [
      { label: 'Green-Yellow-Red' },
      { label: 'Red-Yellow-Green' }
    ]
  },
  {
    label: 'Icon Sets',
    icon: settingsOutline,
    children: [
      { label: 'Directional' },
      { label: 'Shapes' },
      { label: 'Indicators' }
    ]
  },
  { divider: true },
  { label: 'New Rule', icon: addCircleOutline },
  { 
    label: 'Clear Rules', 
    icon: trashOutline,
    children: [
      { label: 'Clear Rules from Selected Cells' },
      { label: 'Clear Rules from Entire Sheet' }
    ]
  },
  { label: 'Manage Rules', icon: settingsOutline }
];
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),w=P(S,[["__scopeId","data-v-7d8732e5"]]);export{w as C};
