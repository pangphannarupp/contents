import{d as g,o as i,j as o,l as a,a as e,w as d,A as b,y as l,u as t,aP as P,F as m,z as v,a8 as C,aB as f,aH as B,aI as y,n as k,p as u}from"../vendors/vendor-ah_eQdvw.js";import{P as A,a as V,Z as D,a2 as O,a0 as S,b as w,c as I}from"./AccountCardSection-DXixqG3L.js";import{_ as N}from"./App-D7rwXoHs.js";const x={class:"screen-preview-container"},z={class:"header-actions"},F={class:"contacts-screen"},T={class:"search-wrapper"},L={class:"contacts-scroll-area"},G={class:"group-letter"},M={class:"group-items"},U={class:"contact-name"},j={class:"bottom-nav-wrapper"},E=g({__name:"ContactsScreen",setup(H){const c=u(!1),p=u("contacts"),h=[{id:"chats",label:"Chats",icon:f},{id:"contacts",label:"Contacts",icon:B},{id:"settings",label:"Settings",icon:y}],_=[{letter:"A",contacts:[{name:"Alicia",avatar:"https://i.pravatar.cc/150?img=1"},{name:"Anthony",avatar:"https://i.pravatar.cc/150?img=11"}]},{letter:"B",contacts:[{name:"Ben",avatar:"https://i.pravatar.cc/150?img=13"},{name:"Bryan",avatar:"https://i.pravatar.cc/150?img=14"},{name:"Brianna",avatar:"https://i.pravatar.cc/150?img=5"}]},{letter:"C",contacts:[{name:"Cindy",avatar:"https://i.pravatar.cc/150?img=9"}]},{letter:"D",contacts:[{name:"Daisy",avatar:"https://i.pravatar.cc/150?img=10"},{name:"Diana",avatar:"https://i.pravatar.cc/150?img=12"}]}];return(Z,s)=>(i(),o("div",x,[a("div",z,[e(t(A),{variant:"primary",size:"small",onClick:s[0]||(s[0]=n=>c.value=!c.value)},{default:d(()=>[b(" Toggle "+l(c.value?"Light":"Dark")+" Mode ",1)]),_:1})]),a("div",{class:k(["phone-mockup",{"dark-mode":c.value}])},[a("div",F,[e(t(D),{title:"Contacts",class:"transparent-appbar"},{right:d(()=>[e(t(V),{icon:t(P),color:"transparent",class:"header-icon-btn"},null,8,["icon"])]),_:1}),a("div",T,[e(t(O),{placeholder:"Search",class:"contacts-search"})]),a("div",L,[(i(),o(m,null,v(_,n=>a("div",{key:n.letter,class:"contact-group"},[a("div",G,l(n.letter),1),a("div",M,[(i(!0),o(m,null,v(n.contacts,r=>(i(),o("div",{key:r.name,class:"contact-item"},[e(t(S),{src:r.avatar,name:r.name,size:"md"},null,8,["src","name"]),a("span",U,l(r.name),1)]))),128))])])),64))]),e(t(w),{icon:t(C),color:"primary",class:"contacts-fab"},null,8,["icon"]),a("div",j,[e(t(I),{items:h,modelValue:p.value,"onUpdate:modelValue":s[1]||(s[1]=n=>p.value=n)},null,8,["modelValue"]),s[2]||(s[2]=a("div",{class:"home-indicator"},null,-1))])])],2),s[3]||(s[3]=a("div",{class:"usage-section"},[a("h3",null,"Code Usage"),a("pre",{class:"code-block"},[a("code",null,`
<template>
  <div class="contacts-screen">
    <PPAppBar title="Contacts" class="transparent-appbar">
      <template #right>
        <PPIconButton :icon="ellipsisVerticalOutline" color="transparent" />
      </template>
    </PPAppBar>

    <div class="search-wrapper">
      <PPSearch placeholder="Search" />
    </div>

    <div class="contacts-list">
      <!-- Contact Items Grouped by Letter -->
      <div class="contact-group">
        <div class="group-letter">A</div>
        <div class="group-items">
          <div class="contact-item">
            <PPAvatar src="..." name="Alicia" size="md" />
            <span class="contact-name">Alicia</span>
          </div>
        </div>
      </div>
    </div>

    <PPFab :icon="addOutline" color="primary" class="contacts-fab" />

    <PPBottomNav :items="bottomNavItems" v-model="activeTab" />
  </div>
</template>
      `)])],-1))]))}}),K=N(E,[["__scopeId","data-v-056a1ee1"]]);export{K as C};
