import{n as s,a1 as n}from"./AccountCardSection-DXixqG3L.js";import{d as r,o as u,j as p,l,a as o,u as d,A as i,w as m,F as v,p as c}from"../vendors/vendor-ah_eQdvw.js";const x={class:"guide-section"},g={class:"variant-group"},y={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"16px"}},P={class:"variant-group"},V={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"8px"}},f={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"8px"}},b={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"8px"}},h={class:"variant-group"},I={class:"component-demo"},k=r({__name:"InputSection",setup(S){const t=c("");return(w,e)=>(u(),p(v,null,[l("div",x,[e[26]||(e[26]=l("h2",null,"Text Input & Textarea",-1)),l("div",g,[e[14]||(e[14]=l("h3",null,"PPTextField Styles",-1)),l("div",y,[o(d(s),{modelValue:t.value,"onUpdate:modelValue":e[0]||(e[0]=a=>t.value=a),label:"Outlined (Default)",placeholder:"Enter text",clearable:""},null,8,["modelValue"]),o(d(s),{modelValue:t.value,"onUpdate:modelValue":e[1]||(e[1]=a=>t.value=a),variant:"filled",label:"Filled",placeholder:"Enter text",clearable:""},null,8,["modelValue"])]),e[15]||(e[15]=l("pre",{class:"code-block"},[l("code",null,'<PPTextField variant="outlined|filled" label="..." clearable />')],-1))]),l("div",P,[e[17]||(e[17]=l("h3",null,"Standard Text Input (PPInput)",-1)),e[18]||(e[18]=l("h4",{style:{"margin-top":"16px"}},"Variants",-1)),l("div",V,[o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[2]||(e[2]=a=>t.value=a),label:"Outline (Default)",variant:"outline",placeholder:"Outline variant"},null,8,["modelValue"]),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[3]||(e[3]=a=>t.value=a),label:"Filled",variant:"filled",placeholder:"Filled variant"},null,8,["modelValue"]),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[4]||(e[4]=a=>t.value=a),label:"Underlined",variant:"underlined",placeholder:"Underlined variant"},null,8,["modelValue"])]),e[19]||(e[19]=l("h4",{style:{"margin-top":"24px"}},"Sizes & Shapes",-1)),l("div",f,[o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[5]||(e[5]=a=>t.value=a),size:"sm",placeholder:"Small (sm)"},null,8,["modelValue"]),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[6]||(e[6]=a=>t.value=a),size:"md",placeholder:"Medium (md) - Default"},null,8,["modelValue"]),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[7]||(e[7]=a=>t.value=a),size:"lg",placeholder:"Large (lg)"},null,8,["modelValue"]),e[16]||(e[16]=l("div",{style:{"margin-top":"16px"}},null,-1)),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[8]||(e[8]=a=>t.value=a),rounded:"",placeholder:"Rounded Pill Style"},null,8,["modelValue"])]),e[20]||(e[20]=l("h4",{style:{"margin-top":"24px"}},"Constraints & Formatting",-1)),e[21]||(e[21]=l("p",{class:"guide-desc"},[i("Restrict input using "),l("code",null,"maxLength"),i(", "),l("code",null,"numberOnly"),i(", "),l("code",null,"min"),i(", "),l("code",null,"max"),i(", and "),l("code",null,"format"),i(".")],-1)),l("div",b,[o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[9]||(e[9]=a=>t.value=a),maxLength:10,placeholder:"Max length 10"},null,8,["modelValue"]),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[10]||(e[10]=a=>t.value=a),numberOnly:"",placeholder:"Numbers only"},null,8,["modelValue"]),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[11]||(e[11]=a=>t.value=a),min:10,max:100,placeholder:"Min 10, Max 100",type:"number"},null,8,["modelValue"]),o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[12]||(e[12]=a=>t.value=a),format:"####-####-####-####",placeholder:"Card format (####-####-####-####)"},null,8,["modelValue"])]),e[22]||(e[22]=l("pre",{class:"code-block"},[l("code",null,'<PPInput variant="outline|filled|underlined" size="sm|md|lg" rounded />')],-1))]),l("div",h,[e[24]||(e[24]=l("h3",null,"Password Input (with icon)",-1)),l("div",I,[o(d(n),{modelValue:t.value,"onUpdate:modelValue":e[13]||(e[13]=a=>t.value=a),label:"Password",type:"password",placeholder:"Enter pass",clearable:""},{iconLeft:m(()=>[...e[23]||(e[23]=[l("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2"},[l("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2",ry:"2"}),l("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"})],-1)])]),_:1},8,["modelValue"])]),e[25]||(e[25]=l("pre",{class:"code-block"},[l("code",null,`<PPInput type="password">
  <template #iconLeft>...</template>
</PPInput>`)],-1))]),e[27]||(e[27]=l("div",{class:"variant-group"},[l("h3",null,"Customizing CSS"),l("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),l("pre",{class:"code-block"},[l("code",null,`/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[28]||(e[28]=l("div",{class:"variant-group",style:{"margin-top":"40px"}},[l("h3",null,"Full Page Source Code"),l("p",{class:"custom-guide"},"Complete source code for this section."),l("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[l("code",null,`<template>
<div class="guide-section">
        <h2>Text Input & Textarea</h2>
        
        <div class="variant-group">
          <h3>PPTextField Styles</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 16px;">
            <PPTextField v-model="textVal" label="Outlined (Default)" placeholder="Enter text" clearable />
            <PPTextField v-model="textVal" variant="filled" label="Filled" placeholder="Enter text" clearable />
          </div>
          <pre class="code-block"><code>&lt;PPTextField variant="outlined|filled" label="..." clearable /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Standard Text Input (PPInput)</h3>
          
          <h4 style="margin-top: 16px;">Variants</h4>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 8px;">
            <PPInput v-model="textVal" label="Outline (Default)" variant="outline" placeholder="Outline variant" />
            <PPInput v-model="textVal" label="Filled" variant="filled" placeholder="Filled variant" />
            <PPInput v-model="textVal" label="Underlined" variant="underlined" placeholder="Underlined variant" />
          </div>
          
          <h4 style="margin-top: 24px;">Sizes & Shapes</h4>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 8px;">
            <PPInput v-model="textVal" size="sm" placeholder="Small (sm)" />
            <PPInput v-model="textVal" size="md" placeholder="Medium (md) - Default" />
            <PPInput v-model="textVal" size="lg" placeholder="Large (lg)" />
            <div style="margin-top: 16px;"></div>
            <PPInput v-model="textVal" rounded placeholder="Rounded Pill Style" />
          </div>

          <h4 style="margin-top: 24px;">Constraints & Formatting</h4>
          <p class="guide-desc">Restrict input using <code>maxLength</code>, <code>numberOnly</code>, <code>min</code>, <code>max</code>, and <code>format</code>.</p>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 8px;">
            <PPInput v-model="textVal" :maxLength="10" placeholder="Max length 10" />
            <PPInput v-model="textVal" numberOnly placeholder="Numbers only" />
            <PPInput v-model="textVal" :min="10" :max="100" placeholder="Min 10, Max 100" type="number" />
            <PPInput v-model="textVal" format="####-####-####-####" placeholder="Card format (####-####-####-####)" />
          </div>
          
          <pre class="code-block"><code>&lt;PPInput variant="outline|filled|underlined" size="sm|md|lg" rounded /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Password Input (with icon)</h3>
          <div class="component-demo">
            <PPInput v-model="textVal" label="Password" type="password" placeholder="Enter pass" clearable>
              <template #iconLeft>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
              </template>
            </PPInput>
          </div>
          <pre class="code-block"><code>&lt;PPInput type="password"&gt;
  &lt;template #iconLeft&gt;...&lt;/template&gt;
&lt;/PPInput&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPTextField, PPInput } from '@phanna/ui-framework';

const textVal = ref('');
<\/script>
`)])],-1))],64))}});export{k as _};
