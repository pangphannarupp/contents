import{P as r,$ as u}from"./AccountCardSection-DXixqG3L.js";import{d as m,o as c,j as g,l as e,a as l,w as s,A as i,u as a,L as f,F as b,p as d}from"../vendors/vendor-ah_eQdvw.js";const v={class:"component-section"},h={class:"demo-box",style:{"margin-top":"32px",display:"flex",gap:"16px","align-items":"center","justify-content":"center",height:"160px",background:"#f8fafc","border-radius":"8px"}},P={style:{padding:"16px"}},y={style:{display:"flex","flex-direction":"column",gap:"12px"}},B={style:{padding:"24px","text-align":"center"}},C=m({__name:"BottomSheetSection",setup(k){const n=d(!1),p=d(!1);return(x,t)=>(c(),g(b,null,[e("div",v,[t[15]||(t[15]=e("h2",null,"Bottom Sheet",-1)),t[16]||(t[16]=e("p",null,"A modal that slides up from the bottom of the screen, typically used for mobile layouts to present actions or information.",-1)),e("div",h,[l(a(r),{onClick:t[0]||(t[0]=o=>n.value=!0)},{default:s(()=>[...t[7]||(t[7]=[i("Default Bottom Sheet",-1)])]),_:1}),l(a(r),{variant:"secondary",onClick:t[1]||(t[1]=o=>p.value=!0)},{default:s(()=>[...t[8]||(t[8]=[i("Blur Backdrop",-1)])]),_:1})]),l(a(u),{modelValue:n.value,"onUpdate:modelValue":t[4]||(t[4]=o=>n.value=o),title:"Settings"},{default:s(()=>[e("div",P,[t[11]||(t[11]=e("p",{style:{"margin-bottom":"24px",color:"#475569"}},"Configure your preferences below.",-1)),e("div",y,[l(a(r),{variant:"outline",block:"",onClick:t[2]||(t[2]=o=>n.value=!1)},{default:s(()=>[...t[9]||(t[9]=[i("Option 1",-1)])]),_:1}),l(a(r),{variant:"outline",block:"",onClick:t[3]||(t[3]=o=>n.value=!1)},{default:s(()=>[...t[10]||(t[10]=[i("Option 2",-1)])]),_:1})])])]),_:1},8,["modelValue"]),l(a(u),{modelValue:p.value,"onUpdate:modelValue":t[6]||(t[6]=o=>p.value=o),backdropType:"blur"},{default:s(()=>[e("div",B,[t[13]||(t[13]=e("h3",{style:{"margin-top":"0",color:"#1e293b"}},"Blurred Background",-1)),t[14]||(t[14]=e("p",{style:{color:"#64748b","margin-bottom":"32px"}},"This sheet uses a blurred backdrop for a frosted glass effect.",-1)),l(a(r),{block:"",onClick:t[5]||(t[5]=o=>p.value=!1)},{default:s(()=>[...t[12]||(t[12]=[i("Close",-1)])]),_:1})])]),_:1},8,["modelValue"]),t[17]||(t[17]=f(`<div style="margin-top:40px;"><h3>Usage Example</h3><pre class="code-block" style="background:#1e293b;color:#e2e8f0;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;PPButton @click=&quot;isOpen = true&quot;&gt;Open Sheet&lt;/PPButton&gt;

  &lt;PPBottomSheet v-model=&quot;isOpen&quot; backdropType=&quot;blur&quot;&gt;
    &lt;div style=&quot;padding: 24px;&quot;&gt;
      &lt;h3&gt;Sheet Content&lt;/h3&gt;
      &lt;p&gt;This is a sliding bottom sheet.&lt;/p&gt;
    &lt;/div&gt;
  &lt;/PPBottomSheet&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from &#39;vue&#39;;
import { PPBottomSheet, PPButton } from &#39;@phanna/ui-framework&#39;;

const isOpen = ref(false);
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  --pp-bottom-sheet-backdrop: /* value */;
  --pp-bottom-sheet-backdrop-black: /* value */;
  --pp-bottom-sheet-backdrop-blur-bg: /* value */;
  --pp-bottom-sheet-bg: /* value */;
  --pp-bottom-sheet-handle-color: /* value */;
  --pp-bottom-sheet-radius: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),t[18]||(t[18]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Bottom Sheet</h2>
    <p>A modal that slides up from the bottom of the screen, typically used for mobile layouts to present actions or information.</p>

    <div class="demo-box" style="margin-top: 32px; display: flex; gap: 16px; align-items: center; justify-content: center; height: 160px; background: #f8fafc; border-radius: 8px;">
      <PPButton @click="showDefault = true">Default Bottom Sheet</PPButton>
      <PPButton variant="secondary" @click="showBlur = true">Blur Backdrop</PPButton>
    </div>

    <!-- Default Bottom Sheet -->
    <PPBottomSheet v-model="showDefault" title="Settings">
      <div style="padding: 16px;">
        <p style="margin-bottom: 24px; color: #475569;">Configure your preferences below.</p>
        <div style="display: flex; flex-direction: column; gap: 12px;">
          <PPButton variant="outline" block @click="showDefault = false">Option 1</PPButton>
          <PPButton variant="outline" block @click="showDefault = false">Option 2</PPButton>
        </div>
      </div>
    </PPBottomSheet>

    <!-- Blur Backdrop Bottom Sheet -->
    <PPBottomSheet v-model="showBlur" backdropType="blur">
      <div style="padding: 24px; text-align: center;">
        <h3 style="margin-top: 0; color: #1e293b;">Blurred Background</h3>
        <p style="color: #64748b; margin-bottom: 32px;">This sheet uses a blurred backdrop for a frosted glass effect.</p>
        <PPButton block @click="showBlur = false">Close</PPButton>
      </div>
    </PPBottomSheet>

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block" style="background: #1e293b; color: #e2e8f0; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPButton @click="isOpen = true"&gt;Open Sheet&lt;/PPButton&gt;

  &lt;PPBottomSheet v-model="isOpen" backdropType="blur"&gt;
    &lt;div style="padding: 24px;"&gt;
      &lt;h3&gt;Sheet Content&lt;/h3&gt;
      &lt;p&gt;This is a sliding bottom sheet.&lt;/p&gt;
    &lt;/div&gt;
  &lt;/PPBottomSheet&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPBottomSheet, PPButton } from '@phanna/ui-framework';

const isOpen = ref(false);
&lt;/script&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-bottom-sheet-backdrop: /* value */;
  --pp-bottom-sheet-backdrop-black: /* value */;
  --pp-bottom-sheet-backdrop-blur-bg: /* value */;
  --pp-bottom-sheet-bg: /* value */;
  --pp-bottom-sheet-handle-color: /* value */;
  --pp-bottom-sheet-radius: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPBottomSheet, PPButton } from '@phanna/ui-framework';

const showDefault = ref(false);
const showBlur = ref(false);
<\/script>
`)])],-1))],64))}});export{C as _};
