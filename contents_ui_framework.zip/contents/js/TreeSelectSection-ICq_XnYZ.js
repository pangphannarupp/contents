import{bN as r}from"./AccountCardSection-DXixqG3L.js";import{d as m,o as p,j as c,l as e,a as o,u as n,A as s,y as g,k as v,F as b,p as u}from"../vendors/vendor-ah_eQdvw.js";const f={class:"component-section"},x={style:{"margin-top":"40px"}},h={class:"demo-box",style:{padding:"40px",background:"#f8fafc","border-radius":"12px",display:"flex","flex-direction":"column","align-items":"center",gap:"20px"}},y={style:{width:"320px"}},S={key:0,style:{"font-size":"14px",color:"#64748b"}},D={style:{"margin-top":"40px"}},V={class:"demo-box",style:{padding:"40px",background:"#f8fafc","border-radius":"12px",display:"flex","flex-direction":"column",gap:"20px"}},P={style:{width:"320px",margin:"0 auto"}},T={style:{width:"320px",margin:"0 auto"}},k={style:{width:"320px",margin:"0 auto"}},w={style:{"margin-top":"40px"}},I={class:"demo-box",style:{padding:"40px",background:"#f8fafc","border-radius":"12px",display:"flex","flex-direction":"column",gap:"20px"}},C={style:{width:"320px",margin:"0 auto"}},F={style:{width:"320px",margin:"0 auto"}},M=m({__name:"TreeSelectSection",setup(B){const t=u(void 0),d=u(void 0),i=[{id:"corp",label:"Corporate",children:[{id:"hr",label:"Human Resources"},{id:"fin",label:"Finance"},{id:"leg",label:"Legal"}]},{id:"prod",label:"Product",children:[{id:"eng",label:"Engineering",children:[{id:"fe",label:"Frontend"},{id:"be",label:"Backend"},{id:"qa",label:"Quality Assurance"}]},{id:"des",label:"Design"},{id:"pm",label:"Product Management"}]},{id:"sales",label:"Sales & Marketing",children:[{id:"mkt",label:"Marketing"},{id:"bd",label:"Business Development"},{id:"sales-us",label:"US Sales"},{id:"sales-eu",label:"EU Sales"}]}];return(E,l)=>(p(),c(b,null,[e("div",f,[l[13]||(l[13]=e("h2",null,"Tree Select",-1)),l[14]||(l[14]=e("p",null,"A form component that combines a dropdown with a hierarchical tree structure for selecting complex, nested data.",-1)),e("div",x,[l[7]||(l[7]=e("h3",null,"Basic Tree Select",-1)),l[8]||(l[8]=e("p",null,"A simple tree select allowing selection of a single node from a hierarchy.",-1)),e("div",h,[e("div",y,[o(n(r),{modelValue:t.value,"onUpdate:modelValue":l[0]||(l[0]=a=>t.value=a),data:i,placeholder:"Select a department...",label:"Department",clearable:!0},null,8,["modelValue"])]),t.value?(p(),c("p",S,[l[6]||(l[6]=s("Selected ID: ",-1)),e("strong",null,g(t.value),1)])):v("",!0)]),l[9]||(l[9]=e("div",{class:"code-block",style:{"margin-top":"20px"}},[e("pre",null,[e("code",null,`
<template>
  <PPTreeSelect 
    v-model="selectedId" 
    :data="treeData" 
    placeholder="Select a department..."
    label="Department"
    :clearable="true"
  />
</template>

<script setup>
import { ref } from 'vue';

const selectedId = ref(null);
const treeData = [
  {
    id: 'corp',
    label: 'Corporate',
    children: [
      { id: 'hr', label: 'Human Resources' },
      { id: 'fin', label: 'Finance' },
      { id: 'leg', label: 'Legal' }
    ]
  },
  {
    id: 'prod',
    label: 'Product',
    children: [
      { id: 'eng', label: 'Engineering' },
      { id: 'des', label: 'Design' },
      { id: 'pm', label: 'Product Management' }
    ]
  }
];
<\/script>
        `)])],-1))]),e("div",D,[l[10]||(l[10]=e("h3",null,"Design Variants",-1)),l[11]||(l[11]=e("p",null,[s("Tree Select supports the same variants as other input fields: "),e("code",null,"outline"),s(" (default), "),e("code",null,"filled"),s(", and "),e("code",null,"flushed"),s(".")],-1)),e("div",V,[e("div",P,[o(n(r),{modelValue:d.value,"onUpdate:modelValue":l[1]||(l[1]=a=>d.value=a),data:i,variant:"outline",placeholder:"Outline variant (Default)"},null,8,["modelValue"])]),e("div",T,[o(n(r),{modelValue:d.value,"onUpdate:modelValue":l[2]||(l[2]=a=>d.value=a),data:i,variant:"filled",placeholder:"Filled variant"},null,8,["modelValue"])]),e("div",k,[o(n(r),{modelValue:d.value,"onUpdate:modelValue":l[3]||(l[3]=a=>d.value=a),data:i,variant:"flushed",placeholder:"Flushed variant"},null,8,["modelValue"])])])]),e("div",w,[l[12]||(l[12]=e("h3",null,"States",-1)),e("div",I,[e("div",C,[o(n(r),{modelValue:t.value,"onUpdate:modelValue":l[4]||(l[4]=a=>t.value=a),data:i,disabled:"",label:"Disabled State",placeholder:"You cannot select this"},null,8,["modelValue"])]),e("div",F,[o(n(r),{modelValue:t.value,"onUpdate:modelValue":l[5]||(l[5]=a=>t.value=a),data:i,error:"Please select a valid department",label:"Error State"},null,8,["modelValue"])])])]),l[15]||(l[15]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
  --pp-text-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),l[16]||(l[16]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Tree Select</h2>
    <p>A form component that combines a dropdown with a hierarchical tree structure for selecting complex, nested data.</p>

    <!-- Basic Tree Select -->
    <div style="margin-top: 40px;">
      <h3>Basic Tree Select</h3>
      <p>A simple tree select allowing selection of a single node from a hierarchy.</p>
      
      <div class="demo-box" style="padding: 40px; background: #f8fafc; border-radius: 12px; display: flex; flex-direction: column; align-items: center; gap: 20px;">
        <div style="width: 320px;">
          <PPTreeSelect 
            v-model="selectedDepartmentId" 
            :data="departmentTree" 
            placeholder="Select a department..."
            label="Department"
            :clearable="true"
          />
        </div>
        <p v-if="selectedDepartmentId" style="font-size: 14px; color: #64748b;">Selected ID: <strong>{{ selectedDepartmentId }}</strong></p>
      </div>

      <div class="code-block" style="margin-top: 20px;">
        <pre><code>
&lt;template&gt;
  &lt;PPTreeSelect 
    v-model="selectedId" 
    :data="treeData" 
    placeholder="Select a department..."
    label="Department"
    :clearable="true"
  /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';

const selectedId = ref(null);
const treeData = [
  {
    id: 'corp',
    label: 'Corporate',
    children: [
      { id: 'hr', label: 'Human Resources' },
      { id: 'fin', label: 'Finance' },
      { id: 'leg', label: 'Legal' }
    ]
  },
  {
    id: 'prod',
    label: 'Product',
    children: [
      { id: 'eng', label: 'Engineering' },
      { id: 'des', label: 'Design' },
      { id: 'pm', label: 'Product Management' }
    ]
  }
];
&lt;/script&gt;
        </code></pre>
      </div>
    </div>

    <!-- Variants -->
    <div style="margin-top: 40px;">
      <h3>Design Variants</h3>
      <p>Tree Select supports the same variants as other input fields: <code>outline</code> (default), <code>filled</code>, and <code>flushed</code>.</p>
      
      <div class="demo-box" style="padding: 40px; background: #f8fafc; border-radius: 12px; display: flex; flex-direction: column; gap: 20px;">
        <div style="width: 320px; margin: 0 auto;">
          <PPTreeSelect 
            v-model="selectedVariantId" 
            :data="departmentTree" 
            variant="outline"
            placeholder="Outline variant (Default)"
          />
        </div>
        <div style="width: 320px; margin: 0 auto;">
          <PPTreeSelect 
            v-model="selectedVariantId" 
            :data="departmentTree" 
            variant="filled"
            placeholder="Filled variant"
          />
        </div>
        <div style="width: 320px; margin: 0 auto;">
          <PPTreeSelect 
            v-model="selectedVariantId" 
            :data="departmentTree" 
            variant="flushed"
            placeholder="Flushed variant"
          />
        </div>
      </div>
    </div>

    <!-- Disabled & Error States -->
    <div style="margin-top: 40px;">
      <h3>States</h3>
      
      <div class="demo-box" style="padding: 40px; background: #f8fafc; border-radius: 12px; display: flex; flex-direction: column; gap: 20px;">
        <div style="width: 320px; margin: 0 auto;">
          <PPTreeSelect 
            v-model="selectedDepartmentId" 
            :data="departmentTree" 
            disabled
            label="Disabled State"
            placeholder="You cannot select this"
          />
        </div>
        <div style="width: 320px; margin: 0 auto;">
          <PPTreeSelect 
            v-model="selectedDepartmentId" 
            :data="departmentTree" 
            error="Please select a valid department"
            label="Error State"
          />
        </div>
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
  --pp-text-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPTreeSelect } from '@phanna/ui-framework';

const selectedDepartmentId = ref<string | undefined>(undefined);
const selectedVariantId = ref<string | undefined>(undefined);

const departmentTree = [
  {
    id: 'corp',
    label: 'Corporate',
    children: [
      { id: 'hr', label: 'Human Resources' },
      { id: 'fin', label: 'Finance' },
      { id: 'leg', label: 'Legal' }
    ]
  },
  {
    id: 'prod',
    label: 'Product',
    children: [
      { 
        id: 'eng', 
        label: 'Engineering',
        children: [
          { id: 'fe', label: 'Frontend' },
          { id: 'be', label: 'Backend' },
          { id: 'qa', label: 'Quality Assurance' }
        ]
      },
      { id: 'des', label: 'Design' },
      { id: 'pm', label: 'Product Management' }
    ]
  },
  {
    id: 'sales',
    label: 'Sales & Marketing',
    children: [
      { id: 'mkt', label: 'Marketing' },
      { id: 'bd', label: 'Business Development' },
      { id: 'sales-us', label: 'US Sales' },
      { id: 'sales-eu', label: 'EU Sales' }
    ]
  }
];
<\/script>
`)])],-1))],64))}});export{M as _};
