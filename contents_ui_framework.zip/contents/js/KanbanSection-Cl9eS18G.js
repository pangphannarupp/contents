import{aK as l}from"./AccountCardSection-DXixqG3L.js";import{d as h,o as s,j as r,l as e,a as p,u as m,A as u,w as x,n as f,y as o,F as v,z as y,p as b}from"../vendors/vendor-ah_eQdvw.js";import{_ as w}from"./App-D7rwXoHs.js";const C={class:"component-section"},B={class:"demo-box"},k={class:"demo-content"},K={class:"demo-box"},S={class:"demo-content"},_={class:"custom-card"},D={class:"card-header"},P={class:"card-date"},I={class:"card-desc"},V={class:"card-footer"},U={class:"avatar-group"},z=["src"],O={class:"card-comments"},j=h({__name:"KanbanSection",setup(A){const d=b([{id:"col-1",title:"To Do",cards:[{id:1,text:"Research competitors"},{id:2,text:"Design database schema"},{id:3,text:"Create wireframes"}]},{id:"col-2",title:"In Progress",cards:[{id:4,text:"Setup project repo"},{id:5,text:"Implement authentication"}]},{id:"col-3",title:"Done",cards:[{id:6,text:"Write product requirements"},{id:7,text:"Initial meeting with client"}]}]),i=b([{id:"backlog",title:"Backlog",cards:[{id:101,title:"Fix responsive layout on mobile",description:"The navigation bar overlaps with content on screens smaller than 375px.",priority:"high",date:"Oct 12",users:["alice","bob"],comments:3},{id:102,title:"Update dependencies",description:"Upgrade Vue to 3.4 and Vite to v5.",priority:"low",date:"Oct 15",users:["charlie"],comments:0}]},{id:"review",title:"In Review",cards:[{id:103,title:"Add Drag and Drop Kanban Board",description:"Implement a fully featured Kanban board component with animations.",priority:"medium",date:"Oct 14",users:["dave","eve"],comments:12}]}]),g=n=>{console.log("Card moved!",n)};return(n,a)=>(s(),r(v,null,[e("div",C,[a[7]||(a[7]=e("h2",null,"Drag-and-Drop Kanban Board",-1)),a[8]||(a[8]=e("p",null,"A beautiful, fully interactive Kanban board for project management and state flows. Drag cards within columns or across different columns natively.",-1)),e("div",B,[a[2]||(a[2]=e("h3",null,"Basic Kanban Board",-1)),a[3]||(a[3]=e("p",{class:"helper-text"},"Using the default card layout.",-1)),e("div",k,[p(m(l),{modelValue:d.value,"onUpdate:modelValue":a[0]||(a[0]=t=>d.value=t),onMoveCard:g},null,8,["modelValue"])]),a[4]||(a[4]=e("pre",{class:"code-block"},[e("code",null,`<PPKanbanBoard 
  v-model="basicBoard" 
  @move-card="handleCardMove"
/>`)],-1))]),e("div",K,[a[5]||(a[5]=e("h3",null,"Custom Cards (via Slots)",-1)),a[6]||(a[6]=e("p",{class:"helper-text"},[u("You can completely replace the UI of the card by using the "),e("code",null,"#card"),u(" slot.")],-1)),e("div",S,[p(m(l),{modelValue:i.value,"onUpdate:modelValue":a[1]||(a[1]=t=>i.value=t)},{card:x(({card:t})=>[e("div",_,[e("div",D,[e("span",{class:f(["card-tag",t.priority])},o(t.priority),3),e("span",P,o(t.date),1)]),e("h4",null,o(t.title),1),e("p",I,o(t.description),1),e("div",V,[e("div",U,[(s(!0),r(v,null,y(t.users,c=>(s(),r("img",{key:c,src:`https://i.pravatar.cc/150?u=${c}`,class:"card-avatar"},null,8,z))),128))]),e("span",O,"💬 "+o(t.comments),1)])])]),_:1},8,["modelValue"])])]),a[9]||(a[9]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),a[10]||(a[10]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Drag-and-Drop Kanban Board</h2>
    <p>A beautiful, fully interactive Kanban board for project management and state flows. Drag cards within columns or across different columns natively.</p>

    <!-- Basic Kanban Board -->
    <div class="demo-box">
      <h3>Basic Kanban Board</h3>
      <p class="helper-text">Using the default card layout.</p>
      
      <div class="demo-content">
        <PPKanbanBoard 
          v-model="basicBoard" 
          @move-card="handleCardMove"
        />
      </div>

      <pre class="code-block" v-pre><code>&lt;PPKanbanBoard 
  v-model="basicBoard" 
  @move-card="handleCardMove"
/&gt;</code></pre>
    </div>

    <!-- Custom Cards -->
    <div class="demo-box">
      <h3>Custom Cards (via Slots)</h3>
      <p class="helper-text">You can completely replace the UI of the card by using the <code>#card</code> slot.</p>
      
      <div class="demo-content">
        <PPKanbanBoard v-model="customBoard">
          <template #card="{ card }">
            <div class="custom-card">
              <div class="card-header">
                <span class="card-tag" :class="card.priority">{{ card.priority }}</span>
                <span class="card-date">{{ card.date }}</span>
              </div>
              <h4>{{ card.title }}</h4>
              <p class="card-desc">{{ card.description }}</p>
              <div class="card-footer">
                <div class="avatar-group">
                  <img v-for="user in card.users" :key="user" :src="\`https://i.pravatar.cc/150?u=\${user}\`" class="card-avatar" />
                </div>
                <span class="card-comments">💬 {{ card.comments }}</span>
              </div>
            </div>
          </template>
        </PPKanbanBoard>
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPKanbanBoard } from '@phanna/ui-framework';

const basicBoard = ref([
  {
    id: 'col-1',
    title: 'To Do',
    cards: [
      { id: 1, text: 'Research competitors' },
      { id: 2, text: 'Design database schema' },
      { id: 3, text: 'Create wireframes' }
    ]
  },
  {
    id: 'col-2',
    title: 'In Progress',
    cards: [
      { id: 4, text: 'Setup project repo' },
      { id: 5, text: 'Implement authentication' }
    ]
  },
  {
    id: 'col-3',
    title: 'Done',
    cards: [
      { id: 6, text: 'Write product requirements' },
      { id: 7, text: 'Initial meeting with client' }
    ]
  }
]);

const customBoard = ref([
  {
    id: 'backlog',
    title: 'Backlog',
    cards: [
      { 
        id: 101, 
        title: 'Fix responsive layout on mobile',
        description: 'The navigation bar overlaps with content on screens smaller than 375px.',
        priority: 'high',
        date: 'Oct 12',
        users: ['alice', 'bob'],
        comments: 3
      },
      { 
        id: 102, 
        title: 'Update dependencies',
        description: 'Upgrade Vue to 3.4 and Vite to v5.',
        priority: 'low',
        date: 'Oct 15',
        users: ['charlie'],
        comments: 0
      }
    ]
  },
  {
    id: 'review',
    title: 'In Review',
    cards: [
      { 
        id: 103, 
        title: 'Add Drag and Drop Kanban Board',
        description: 'Implement a fully featured Kanban board component with animations.',
        priority: 'medium',
        date: 'Oct 14',
        users: ['dave', 'eve'],
        comments: 12
      }
    ]
  }
]);

const handleCardMove = (payload: any) => {
  console.log('Card moved!', payload);
};
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
}
.helper-text {
  font-size: 13px;
  color: #666;
  margin-bottom: 16px;
}
.code-block {
  background: #282c34;
  color: #abb2bf;
  padding: 16px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 14px;
  line-height: 1.5;
  margin-top: 24px;
}

/* Custom Card Styles */
.custom-card {
  background: white;
  padding: 16px;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
  border: 1px solid #e5e7eb;
}

.card-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.card-tag {
  font-size: 11px;
  text-transform: uppercase;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 4px;
}

.card-tag.high { background: #fee2e2; color: #991b1b; }
.card-tag.medium { background: #fef3c7; color: #92400e; }
.card-tag.low { background: #d1fae5; color: #065f46; }

.card-date {
  font-size: 12px;
  color: #6b7280;
}

.custom-card h4 {
  margin: 0 0 8px 0;
  font-size: 15px;
  color: #111827;
}

.card-desc {
  font-size: 13px;
  color: #4b5563;
  margin: 0 0 16px 0;
  line-height: 1.4;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.avatar-group {
  display: flex;
}

.card-avatar {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  border: 2px solid white;
  margin-left: -8px;
}

.card-avatar:first-child {
  margin-left: 0;
}

.card-comments {
  font-size: 12px;
  color: #6b7280;
}
</style>
`)])],-1))],64))}}),R=w(j,[["__scopeId","data-v-879f470b"]]);export{R as K};
