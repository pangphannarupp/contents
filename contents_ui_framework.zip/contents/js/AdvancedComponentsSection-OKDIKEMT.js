import{d as v,o as m,j as u,l as t,a as o,u as a,y as g,V as f,a1 as P,w as d,F as c,z as x,v as y,p as r}from"../vendors/vendor-ah_eQdvw.js";import{d as b,h,T as w,R as C,N as k,j as A,t as S,l as M,O as R,f as U,w as T,D as V,F as E,U as z}from"./AccountCardSection-DXixqG3L.js";import{_ as I}from"./App-D7rwXoHs.js";const D={class:"component-section"},W={style:{"margin-top":"40px"}},Q={class:"demo-box",style:{padding:"40px",background:"#f8fafc","border-radius":"12px"}},L={style:{"margin-top":"40px"}},j={class:"demo-box"},$={style:{"margin-top":"12px","font-size":"13px",color:"#64748b"}},B={style:{"margin-top":"40px"}},G={class:"demo-box",style:{"max-width":"400px"}},q={style:{"margin-top":"40px"}},O={class:"demo-box"},F={style:{"margin-top":"40px"}},N={class:"demo-box"},H={style:{"margin-bottom":"16px","max-width":"300px"}},Y={style:{"margin-top":"40px"}},J={class:"demo-box"},K={style:{"margin-top":"40px"}},X={class:"demo-box"},Z={style:{"margin-top":"40px"}},_={class:"demo-box",style:{height:"300px"}},tt={style:{"margin-top":"40px"}},et={class:"demo-box"},ot={style:{"margin-top":"40px"}},at={class:"demo-box"},it={style:{"margin-top":"40px"}},rt={class:"demo-box"},st={style:{"margin-top":"40px"}},lt={class:"demo-box"},pt={style:{"margin-top":"40px"}},dt={class:"demo-box"},nt={style:{"margin-top":"40px"}},mt={class:"demo-box",style:{display:"flex","align-items":"center","justify-content":"center",padding:"40px"}},ut=v({__name:"AdvancedComponentsSection",setup(gt){const s=r(["Vue","TypeScript"]),n=r(""),l=r("https://github.com"),p=r(!1);return(ct,e)=>(m(),u(c,null,[t("div",D,[e[44]||(e[44]=t("h2",null,"Advanced Data & Media Components",-1)),e[45]||(e[45]=t("p",null,"A collection of complex, interactive components including E-commerce cards, rich inputs, canvas drawings, and media tools.",-1)),t("div",W,[e[5]||(e[5]=t("h3",null,"Animated Credit Card Input (PPCreditCard)",-1)),e[6]||(e[6]=t("p",null,"A 3D flipping credit card UI that updates automatically as the user types.",-1)),t("div",Q,[o(a(b))]),e[7]||(e[7]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPCreditCard />
</template>

<script setup>
import { PPCreditCard } from '@phanna/ui-framework';
<\/script>`)])],-1))]),t("div",L,[e[8]||(e[8]=t("h3",null,"Tag Input (PPTagInput)",-1)),e[9]||(e[9]=t("p",null,"Type a word and press Enter to create a deletable chip/tag.",-1)),t("div",j,[o(a(h),{modelValue:s.value,"onUpdate:modelValue":e[0]||(e[0]=i=>s.value=i),placeholder:"Add some skills..."},null,8,["modelValue"]),t("p",$,"Current Tags: "+g(s.value.join(", ")),1)]),e[10]||(e[10]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPTagInput v-model="tags" placeholder="Add some skills..." />
</template>

<script setup>
import { ref } from 'vue';
import { PPTagInput } from '@phanna/ui-framework';

const tags = ref(['Vue', 'TypeScript']);
<\/script>`)])],-1))]),t("div",B,[e[11]||(e[11]=t("h3",null,"Password Strength Meter (PPPasswordStrength)",-1)),e[12]||(e[12]=t("p",null,"Provides visual feedback on password complexity rules.",-1)),t("div",G,[o(a(w),{modelValue:n.value,"onUpdate:modelValue":e[1]||(e[1]=i=>n.value=i)},null,8,["modelValue"])]),e[13]||(e[13]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPPasswordStrength v-model="password" />
</template>

<script setup>
import { ref } from 'vue';
import { PPPasswordStrength } from '@phanna/ui-framework';

const password = ref('');
<\/script>`)])],-1))]),t("div",q,[e[14]||(e[14]=t("h3",null,"Audio Waveform (PPAudioWave)",-1)),e[15]||(e[15]=t("p",null,"A visual representation of playing audio, similar to voice notes.",-1)),t("div",O,[o(a(C))]),e[16]||(e[16]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPAudioWave :bars="30" />
</template>

<script setup>
import { PPAudioWave } from '@phanna/ui-framework';
<\/script>`)])],-1))]),t("div",F,[e[17]||(e[17]=t("h3",null,"QR Code Generator (PPQRCode)",-1)),e[18]||(e[18]=t("p",null,"Generates a scanable QR code for a string.",-1)),t("div",N,[t("div",H,[f(t("input",{type:"text","onUpdate:modelValue":e[2]||(e[2]=i=>l.value=i),style:{width:"100%",padding:"8px","border-radius":"4px",border:"1px solid #ccc"},placeholder:"Enter URL to encode"},null,512),[[P,l.value]])]),o(a(k),{value:l.value,size:150,downloadable:""},null,8,["value"])]),e[19]||(e[19]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPQRCode value="https://github.com" :size="150" downloadable />
</template>

<script setup>
import { PPQRCode } from '@phanna/ui-framework';
<\/script>`)])],-1))]),t("div",Y,[e[20]||(e[20]=t("h3",null,"Product Image Magnifier (PPMagnifier)",-1)),e[21]||(e[21]=t("p",null,"Hover over the image to inspect it with a magnifying glass lens.",-1)),t("div",J,[o(a(A),{src:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",alt:"Watch"})]),e[22]||(e[22]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPMagnifier 
    src="https://images.unsplash.com/photo-1523275335684.jpg" 
    :zoom="2.5" 
    :lensSize="120" 
  />
</template>

<script setup>
import { PPMagnifier } from '@phanna/ui-framework';
<\/script>`)])],-1))]),t("div",K,[e[23]||(e[23]=t("h3",null,"Whiteboard / Draw Canvas (PPDrawCanvas)",-1)),e[24]||(e[24]=t("p",null,"An interactive drawing pad with color picking and erasing.",-1)),t("div",X,[o(a(S))]),e[25]||(e[25]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPDrawCanvas :width="600" :height="400" />
</template>

<script setup>
import { PPDrawCanvas } from '@phanna/ui-framework';
<\/script>`)])],-1))]),t("div",Z,[e[28]||(e[28]=t("h3",null,"Resizable Splitter (PPSplitter)",-1)),e[29]||(e[29]=t("p",null,"A drag-and-drop resizable split pane.",-1)),t("div",_,[o(a(M),{direction:"horizontal",initialSplit:50},{primary:d(()=>[...e[26]||(e[26]=[t("div",{style:{padding:"20px",background:"#e0f2fe",height:"100%"}},"Left Pane",-1)])]),secondary:d(()=>[...e[27]||(e[27]=[t("div",{style:{padding:"20px",background:"#fce7f3",height:"100%"}},"Right Pane",-1)])]),_:1})]),e[30]||(e[30]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPSplitter direction="horizontal" :initialSplit="50">
    <template #primary>
      <div>Left Pane</div>
    </template>
    <template #secondary>
      <div>Right Pane</div>
    </template>
  </PPSplitter>
</template>

<script setup>
import { PPSplitter } from '@phanna/ui-framework';
<\/script>`)])],-1))]),t("div",tt,[e[31]||(e[31]=t("h3",null,"Masonry Grid Layout (PPMasonry)",-1)),e[32]||(e[32]=t("p",null,"A Pinterest-style staggered grid layout.",-1)),t("div",et,[o(a(R),{columns:3,gap:16},{default:d(()=>[(m(),u(c,null,x(9,i=>t("div",{key:i,class:"masonry-item",style:y({height:`${Math.floor(Math.random()*150)+100}px`})}," Item "+g(i),5)),64))]),_:1})]),e[33]||(e[33]=t("div",{style:{"margin-top":"16px"}},[t("h4",null,"Usage Example"),t("pre",{class:"code-block",style:{background:"#f8fafc",padding:"16px","border-radius":"8px","overflow-x":"auto"}},[t("code",null,`<template>
  <PPMasonry :columns="3" :gap="16">
    <div v-for="item in items" :key="item.id">
      {{ item.content }}
    </div>
  </PPMasonry>
</template>

<script setup>
import { PPMasonry } from '@phanna/ui-framework';
const items = [...];
<\/script>`)])],-1))]),t("div",ot,[e[34]||(e[34]=t("h3",null,"Camera Capture (PPCameraCapture)",-1)),e[35]||(e[35]=t("p",null,"A camera viewer that captures photos using the device camera.",-1)),t("div",at,[o(a(U),{height:"400"})])]),t("div",it,[e[36]||(e[36]=t("h3",null,"Audio Recorder (PPAudioRecorder)",-1)),e[37]||(e[37]=t("p",null,"An interactive microphone recorder that outputs audio blobs.",-1)),t("div",rt,[o(a(T))])]),t("div",st,[e[38]||(e[38]=t("h3",null,"Map Viewer (PPMapViewer)",-1)),e[39]||(e[39]=t("p",null,"A map interface that renders dynamic markers.",-1)),t("div",lt,[o(a(V),{markers:[{top:"50%",left:"50%",label:"Current Location"}]})])]),t("div",pt,[e[40]||(e[40]=t("h3",null,"Video Player (PPVideoPlayer)",-1)),e[41]||(e[41]=t("p",null,"A custom styled video player with timeline and speed controls.",-1)),t("div",dt,[o(a(E),{src:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"})])]),t("div",nt,[e[42]||(e[42]=t("h3",null,"Confetti (PPConfetti)",-1)),e[43]||(e[43]=t("p",null,"A celebratory micro-interaction component.",-1)),t("div",mt,[t("button",{onClick:e[3]||(e[3]=i=>p.value=!0),style:{padding:"12px 24px",background:"#3b82f6",color:"white",border:"none","border-radius":"8px","font-weight":"bold",cursor:"pointer"}}," Celebrate! "),o(a(z),{active:p.value,"onUpdate:active":e[4]||(e[4]=i=>p.value=i)},null,8,["active"])])]),e[46]||(e[46]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[47]||(e[47]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Advanced Data & Media Components</h2>
    <p>A collection of complex, interactive components including E-commerce cards, rich inputs, canvas drawings, and media tools.</p>

    <!-- 1. Credit Card -->
    <div style="margin-top: 40px;">
      <h3>Animated Credit Card Input (PPCreditCard)</h3>
      <p>A 3D flipping credit card UI that updates automatically as the user types.</p>
      <div class="demo-box" style="padding: 40px; background: #f8fafc; border-radius: 12px;">
        <PPCreditCard />
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPCreditCard /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPCreditCard } from '@phanna/ui-framework';
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 2. Tag Input -->
    <div style="margin-top: 40px;">
      <h3>Tag Input (PPTagInput)</h3>
      <p>Type a word and press Enter to create a deletable chip/tag.</p>
      <div class="demo-box">
        <PPTagInput v-model="tags" placeholder="Add some skills..." />
        <p style="margin-top: 12px; font-size: 13px; color: #64748b;">Current Tags: {{ tags.join(', ') }}</p>
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPTagInput v-model="tags" placeholder="Add some skills..." /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPTagInput } from '@phanna/ui-framework';

const tags = ref(['Vue', 'TypeScript']);
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 3. Password Strength -->
    <div style="margin-top: 40px;">
      <h3>Password Strength Meter (PPPasswordStrength)</h3>
      <p>Provides visual feedback on password complexity rules.</p>
      <div class="demo-box" style="max-width: 400px;">
        <PPPasswordStrength v-model="password" />
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPPasswordStrength v-model="password" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPPasswordStrength } from '@phanna/ui-framework';

const password = ref('');
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 4. Audio Wave -->
    <div style="margin-top: 40px;">
      <h3>Audio Waveform (PPAudioWave)</h3>
      <p>A visual representation of playing audio, similar to voice notes.</p>
      <div class="demo-box">
        <PPAudioWave />
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPAudioWave :bars="30" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPAudioWave } from '@phanna/ui-framework';
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 5. QR Code -->
    <div style="margin-top: 40px;">
      <h3>QR Code Generator (PPQRCode)</h3>
      <p>Generates a scanable QR code for a string.</p>
      <div class="demo-box">
        <div style="margin-bottom: 16px; max-width: 300px;">
          <input type="text" v-model="qrText" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;" placeholder="Enter URL to encode" />
        </div>
        <PPQRCode :value="qrText" :size="150" downloadable />
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPQRCode value="https://github.com" :size="150" downloadable /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPQRCode } from '@phanna/ui-framework';
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 7. Magnifier -->
    <div style="margin-top: 40px;">
      <h3>Product Image Magnifier (PPMagnifier)</h3>
      <p>Hover over the image to inspect it with a magnifying glass lens.</p>
      <div class="demo-box">
        <PPMagnifier src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Watch" />
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPMagnifier 
    src="https://images.unsplash.com/photo-1523275335684.jpg" 
    :zoom="2.5" 
    :lensSize="120" 
  /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPMagnifier } from '@phanna/ui-framework';
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 8. Canvas -->
    <div style="margin-top: 40px;">
      <h3>Whiteboard / Draw Canvas (PPDrawCanvas)</h3>
      <p>An interactive drawing pad with color picking and erasing.</p>
      <div class="demo-box">
        <PPDrawCanvas />
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPDrawCanvas :width="600" :height="400" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPDrawCanvas } from '@phanna/ui-framework';
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 9. Splitter -->
    <div style="margin-top: 40px;">
      <h3>Resizable Splitter (PPSplitter)</h3>
      <p>A drag-and-drop resizable split pane.</p>
      <div class="demo-box" style="height: 300px;">
        <PPSplitter direction="horizontal" :initialSplit="50">
          <template #primary>
            <div style="padding: 20px; background: #e0f2fe; height: 100%;">Left Pane</div>
          </template>
          <template #secondary>
            <div style="padding: 20px; background: #fce7f3; height: 100%;">Right Pane</div>
          </template>
        </PPSplitter>
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPSplitter direction="horizontal" :initialSplit="50"&gt;
    &lt;template #primary&gt;
      &lt;div&gt;Left Pane&lt;/div&gt;
    &lt;/template&gt;
    &lt;template #secondary&gt;
      &lt;div&gt;Right Pane&lt;/div&gt;
    &lt;/template&gt;
  &lt;/PPSplitter&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPSplitter } from '@phanna/ui-framework';
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 6. Masonry Grid -->
    <div style="margin-top: 40px;">
      <h3>Masonry Grid Layout (PPMasonry)</h3>
      <p>A Pinterest-style staggered grid layout.</p>
      <div class="demo-box">
        <PPMasonry :columns="3" :gap="16">
          <div v-for="i in 9" :key="i" class="masonry-item" :style="{ height: \`\${Math.floor(Math.random() * 150) + 100}px\` }">
            Item {{ i }}
          </div>
        </PPMasonry>
      </div>
      <div style="margin-top: 16px;">
        <h4>Usage Example</h4>
        <pre v-pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPMasonry :columns="3" :gap="16"&gt;
    &lt;div v-for="item in items" :key="item.id"&gt;
      {{ item.content }}
    &lt;/div&gt;
  &lt;/PPMasonry&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPMasonry } from '@phanna/ui-framework';
const items = [...];
&lt;/script&gt;</code></pre>
      </div>
    </div>

    <!-- 10. Camera Capture -->
    <div style="margin-top: 40px;">
      <h3>Camera Capture (PPCameraCapture)</h3>
      <p>A camera viewer that captures photos using the device camera.</p>
      <div class="demo-box">
        <PPCameraCapture height="400" />
      </div>
    </div>

    <!-- 11. Audio Recorder -->
    <div style="margin-top: 40px;">
      <h3>Audio Recorder (PPAudioRecorder)</h3>
      <p>An interactive microphone recorder that outputs audio blobs.</p>
      <div class="demo-box">
        <PPAudioRecorder />
      </div>
    </div>

    <!-- 12. Map Viewer -->
    <div style="margin-top: 40px;">
      <h3>Map Viewer (PPMapViewer)</h3>
      <p>A map interface that renders dynamic markers.</p>
      <div class="demo-box">
        <PPMapViewer :markers="[{ top: '50%', left: '50%', label: 'Current Location' }]" />
      </div>
    </div>

    <!-- 13. Video Player -->
    <div style="margin-top: 40px;">
      <h3>Video Player (PPVideoPlayer)</h3>
      <p>A custom styled video player with timeline and speed controls.</p>
      <div class="demo-box">
        <PPVideoPlayer src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" />
      </div>
    </div>

    <!-- 14. Confetti -->
    <div style="margin-top: 40px;">
      <h3>Confetti (PPConfetti)</h3>
      <p>A celebratory micro-interaction component.</p>
      <div class="demo-box" style="display: flex; align-items: center; justify-content: center; padding: 40px;">
        <button 
          @click="showConfetti = true" 
          style="padding: 12px 24px; background: #3b82f6; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;"
        >
          Celebrate!
        </button>
        <PPConfetti v-model:active="showConfetti" />
      </div>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { 
  PPCreditCard, 
  PPTagInput, 
  PPPasswordStrength, 
  PPAudioWave, 
  PPQRCode, 
  PPMasonry, 
  PPMagnifier, 
  PPDrawCanvas,
  PPSplitter,
  PPCameraCapture,
  PPAudioRecorder,
  PPMapViewer,
  PPVideoPlayer,
  PPConfetti
} from '@phanna/ui-framework';

const tags = ref(['Vue', 'TypeScript']);
const password = ref('');
const qrText = ref('https://github.com');
const showConfetti = ref(false);
<\/script>

<style scoped>
.masonry-item {
  background: #3b82f6;
  color: white;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
}
</style>
`)])],-1))],64))}}),xt=I(ut,[["__scopeId","data-v-1bcde269"]]);export{xt as A};
