import{d as t,j as o}from"./index-BgEvt14v.js";const r=t(o.jsx("path",{d:"M10 6 8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"}));export{r as C};
