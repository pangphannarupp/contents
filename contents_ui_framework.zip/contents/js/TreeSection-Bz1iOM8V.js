import{bM as d}from"./AccountCardSection-DXixqG3L.js";import{d as m,o as p,j as u,l as e,a as n,u as i,y as b,k as g,F as k,p as v,aL as l,c1 as s}from"../vendors/vendor-ah_eQdvw.js";import{_ as f}from"./App-D7rwXoHs.js";const x={class:"component-section"},h={class:"demo-box"},y={class:"demo-content"},P={class:"demo-box"},T={class:"demo-content"},L={class:"demo-box"},C={class:"demo-content",style:{background:"white"}},N={class:"demo-box"},O={class:"demo-content",style:{padding:"0",overflow:"hidden",background:"white",border:"1px solid #e0e0e0"}},S={key:0,style:{"margin-top":"16px","font-size":"14px",color:"#666"}},D=m({__name:"TreeSection",setup(w){const r=v(""),a=v([{id:1,label:"Level 1 - 1",icon:s,children:[{id:4,label:"Level 2 - 1-1",icon:l},{id:5,label:"Level 2 - 1-2",icon:s,children:[{id:9,label:"Level 3 - 1-2-1",icon:l},{id:10,label:"Level 3 - 1-2-2",icon:l}]}]},{id:2,label:"Level 1 - 2",icon:s,children:[{id:6,label:"Level 2 - 2-1",icon:l},{id:7,label:"Level 2 - 2-2",icon:l}]},{id:3,label:"Level 1 - 3",icon:l}]),t=c=>{r.value=c.label};return(c,o)=>(p(),u(k,null,[e("div",x,[o[8]||(o[8]=e("h2",null,"Tree",-1)),o[9]||(o[9]=e("p",null,"A component for displaying hierarchical data in a tree structure.",-1)),e("div",h,[o[0]||(o[0]=e("h3",null,"Standard Tree",-1)),e("div",y,[n(i(d),{data:a.value,onNodeClick:t,variant:"standard"},null,8,["data"])]),o[1]||(o[1]=e("pre",{class:"code-block"},[e("code",null,'<PPTree :data="treeData" variant="standard" />')],-1))]),e("div",P,[o[2]||(o[2]=e("h3",null,"Boxed Tree",-1)),e("div",T,[n(i(d),{data:a.value,onNodeClick:t,variant:"boxed"},null,8,["data"])]),o[3]||(o[3]=e("pre",{class:"code-block"},[e("code",null,'<PPTree :data="treeData" variant="boxed" />')],-1))]),e("div",L,[o[4]||(o[4]=e("h3",null,"Lined Tree",-1)),e("div",C,[n(i(d),{data:a.value,onNodeClick:t,variant:"lined"},null,8,["data"])]),o[5]||(o[5]=e("pre",{class:"code-block"},[e("code",null,'<PPTree :data="treeData" variant="lined" />')],-1))]),e("div",N,[o[6]||(o[6]=e("h3",null,"Zebra Tree",-1)),e("div",O,[n(i(d),{data:a.value,onNodeClick:t,variant:"zebra"},null,8,["data"])]),o[7]||(o[7]=e("pre",{class:"code-block"},[e("code",null,'<PPTree :data="treeData" variant="zebra" />')],-1)),r.value?(p(),u("div",S," Selected: "+b(r.value),1)):g("",!0)]),o[10]||(o[10]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
  --pp-text-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[11]||(o[11]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Tree</h2>
    <p>A component for displaying hierarchical data in a tree structure.</p>

    <div class="demo-box">
      <h3>Standard Tree</h3>
      <div class="demo-content">
        <PPTree :data="treeData" @node-click="handleNodeClick" variant="standard" />
      </div>
      <pre class="code-block"><code>&lt;PPTree :data="treeData" variant="standard" /&gt;</code></pre>
    </div>

    <div class="demo-box">
      <h3>Boxed Tree</h3>
      <div class="demo-content">
        <PPTree :data="treeData" @node-click="handleNodeClick" variant="boxed" />
      </div>
      <pre class="code-block"><code>&lt;PPTree :data="treeData" variant="boxed" /&gt;</code></pre>
    </div>

    <div class="demo-box">
      <h3>Lined Tree</h3>
      <div class="demo-content" style="background: white;">
        <PPTree :data="treeData" @node-click="handleNodeClick" variant="lined" />
      </div>
      <pre class="code-block"><code>&lt;PPTree :data="treeData" variant="lined" /&gt;</code></pre>
    </div>

    <div class="demo-box">
      <h3>Zebra Tree</h3>
      <div class="demo-content" style="padding: 0; overflow: hidden; background: white; border: 1px solid #e0e0e0;">
        <PPTree :data="treeData" @node-click="handleNodeClick" variant="zebra" />
      </div>
      <pre class="code-block"><code>&lt;PPTree :data="treeData" variant="zebra" /&gt;</code></pre>

      <div v-if="clickedNode" style="margin-top: 16px; font-size: 14px; color: #666;">
        Selected: {{ clickedNode }}
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
  --pp-text-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPTree } from '@phanna/ui-framework';
import { folderOutline, documentOutline } from 'ionicons/icons';

const clickedNode = ref('');

const treeData = ref([
  {
    id: 1,
    label: 'Level 1 - 1',
    icon: folderOutline,
    children: [
      {
        id: 4,
        label: 'Level 2 - 1-1',
        icon: documentOutline
      },
      {
        id: 5,
        label: 'Level 2 - 1-2',
        icon: folderOutline,
        children: [
          {
            id: 9,
            label: 'Level 3 - 1-2-1',
            icon: documentOutline
          },
          {
            id: 10,
            label: 'Level 3 - 1-2-2',
            icon: documentOutline
          }
        ]
      }
    ]
  },
  {
    id: 2,
    label: 'Level 1 - 2',
    icon: folderOutline,
    children: [
      {
        id: 6,
        label: 'Level 2 - 2-1',
        icon: documentOutline
      },
      {
        id: 7,
        label: 'Level 2 - 2-2',
        icon: documentOutline
      }
    ]
  },
  {
    id: 3,
    label: 'Level 1 - 3',
    icon: documentOutline
  }
]);

const handleNodeClick = (node: any) => {
  clickedNode.value = node.label;
};
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 4px;
}
</style>
`)])],-1))],64))}}),A=f(D,[["__scopeId","data-v-33d3e69a"]]);export{A as T};
