import{b6 as s,b7 as u}from"./AccountCardSection-DXixqG3L.js";import{d as g,o as i,j as c,l as t,a as l,w as o,u as n,A as a,y as m,F as v,p as d}from"../vendors/vendor-ah_eQdvw.js";import{_ as b}from"./App-D7rwXoHs.js";const S={class:"guide-section"},P={class:"demo-box"},f={style:{"margin-top":"16px",padding:"16px",background:"white","border-radius":"8px"}},y=g({__name:"ScrollSegmentSection",setup(B){const r=d("tab1");return(x,e)=>(i(),c(v,null,[t("div",S,[e[9]||(e[9]=t("h2",null,"Scroll Segment",-1)),e[10]||(e[10]=t("p",null,"A horizontally scrollable segment control for navigating between many categories.",-1)),e[11]||(e[11]=t("h3",null,"Basic Usage",-1)),t("div",P,[l(n(u),{modelValue:r.value,"onUpdate:modelValue":e[0]||(e[0]=p=>r.value=p)},{default:o(()=>[l(n(s),{value:"tab1"},{default:o(()=>[...e[1]||(e[1]=[a("Overview",-1)])]),_:1}),l(n(s),{value:"tab2"},{default:o(()=>[...e[2]||(e[2]=[a("Analytics",-1)])]),_:1}),l(n(s),{value:"tab3"},{default:o(()=>[...e[3]||(e[3]=[a("Reports",-1)])]),_:1}),l(n(s),{value:"tab4"},{default:o(()=>[...e[4]||(e[4]=[a("Notifications",-1)])]),_:1}),l(n(s),{value:"tab5"},{default:o(()=>[...e[5]||(e[5]=[a("Settings",-1)])]),_:1}),l(n(s),{value:"tab6"},{default:o(()=>[...e[6]||(e[6]=[a("Billing",-1)])]),_:1}),l(n(s),{value:"tab7"},{default:o(()=>[...e[7]||(e[7]=[a("Team",-1)])]),_:1})]),_:1},8,["modelValue"]),t("div",f,[e[8]||(e[8]=a(" Currently viewing: ",-1)),t("strong",null,m(r.value),1)])]),e[12]||(e[12]=t("pre",{class:"code-block"},[t("code",null,`<PPScrollSegment v-model="activeTab">
  <PPScrollSegmentButton value="tab1">Overview</PPScrollSegmentButton>
  <PPScrollSegmentButton value="tab2">Analytics</PPScrollSegmentButton>
  <PPScrollSegmentButton value="tab3">Reports</PPScrollSegmentButton>
  <!-- Add as many tabs as you need -->
</PPScrollSegment>`)],-1)),e[13]||(e[13]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-background-alt: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-variant: /* value */;
  --pp-scroll-segment-bg: /* value */;
  --pp-scroll-segment-border-radius: /* value */;
  --pp-scroll-segment-btn-active-bg: /* value */;
  --pp-scroll-segment-btn-active-border-color: /* value */;
  --pp-scroll-segment-btn-active-color: /* value */;
  --pp-scroll-segment-btn-bg: /* value */;
  --pp-scroll-segment-btn-border-color: /* value */;
  --pp-scroll-segment-btn-color: /* value */;
  --pp-scroll-segment-btn-font-size: /* value */;
  --pp-scroll-segment-btn-padding: /* value */;
  --pp-scroll-segment-btn-radius: /* value */;
  --pp-scroll-segment-btn-shadow: /* value */;
  --pp-scroll-segment-gap: /* value */;
  --pp-scroll-segment-margin-bottom: /* value */;
  --pp-scroll-segment-padding: /* value */;
  --pp-segment-bg: /* value */;
  --pp-segment-border-color: /* value */;
  --pp-segment-btn-active-bg: /* value */;
  --pp-segment-btn-active-shadow: /* value */;
  --pp-segment-padding: /* value */;
  --pp-segment-radius: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[14]||(e[14]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="guide-section">
    <h2>Scroll Segment</h2>
    <p>A horizontally scrollable segment control for navigating between many categories.</p>

    <h3>Basic Usage</h3>
    <div class="demo-box">
      <PPScrollSegment v-model="activeTab">
        <PPScrollSegmentButton value="tab1">Overview</PPScrollSegmentButton>
        <PPScrollSegmentButton value="tab2">Analytics</PPScrollSegmentButton>
        <PPScrollSegmentButton value="tab3">Reports</PPScrollSegmentButton>
        <PPScrollSegmentButton value="tab4">Notifications</PPScrollSegmentButton>
        <PPScrollSegmentButton value="tab5">Settings</PPScrollSegmentButton>
        <PPScrollSegmentButton value="tab6">Billing</PPScrollSegmentButton>
        <PPScrollSegmentButton value="tab7">Team</PPScrollSegmentButton>
      </PPScrollSegment>
      
      <div style="margin-top: 16px; padding: 16px; background: white; border-radius: 8px;">
        Currently viewing: <strong>{{ activeTab }}</strong>
      </div>
    </div>

    <pre class="code-block"><code>&lt;PPScrollSegment v-model="activeTab"&gt;
  &lt;PPScrollSegmentButton value="tab1"&gt;Overview&lt;/PPScrollSegmentButton&gt;
  &lt;PPScrollSegmentButton value="tab2"&gt;Analytics&lt;/PPScrollSegmentButton&gt;
  &lt;PPScrollSegmentButton value="tab3"&gt;Reports&lt;/PPScrollSegmentButton&gt;
  &lt;!-- Add as many tabs as you need --&gt;
&lt;/PPScrollSegment&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-background-alt: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-variant: /* value */;
  --pp-scroll-segment-bg: /* value */;
  --pp-scroll-segment-border-radius: /* value */;
  --pp-scroll-segment-btn-active-bg: /* value */;
  --pp-scroll-segment-btn-active-border-color: /* value */;
  --pp-scroll-segment-btn-active-color: /* value */;
  --pp-scroll-segment-btn-bg: /* value */;
  --pp-scroll-segment-btn-border-color: /* value */;
  --pp-scroll-segment-btn-color: /* value */;
  --pp-scroll-segment-btn-font-size: /* value */;
  --pp-scroll-segment-btn-padding: /* value */;
  --pp-scroll-segment-btn-radius: /* value */;
  --pp-scroll-segment-btn-shadow: /* value */;
  --pp-scroll-segment-gap: /* value */;
  --pp-scroll-segment-margin-bottom: /* value */;
  --pp-scroll-segment-padding: /* value */;
  --pp-segment-bg: /* value */;
  --pp-segment-border-color: /* value */;
  --pp-segment-btn-active-bg: /* value */;
  --pp-segment-btn-active-shadow: /* value */;
  --pp-segment-padding: /* value */;
  --pp-segment-radius: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPScrollSegment, PPScrollSegmentButton } from '@phanna/ui-framework';

const activeTab = ref('tab1');
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),A=b(y,[["__scopeId","data-v-45f4f788"]]);export{A as S};
