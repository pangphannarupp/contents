import{bA as a}from"./AccountCardSection-DXixqG3L.js";import{d as P,o as d,j as c,l as e,a as r,w as o,u as s,F as p}from"../vendors/vendor-ah_eQdvw.js";const u={class:"guide-section"},m={class:"variant-group"},g={class:"component-demo",style:{padding:"0",background:"transparent","border-radius":"12px",overflow:"hidden",border:"1px solid #eee",transform:"translateZ(0)",isolation:"isolate"}},y=P({__name:"SwipeActionsSection",setup(b){const i=l=>console.log("Setup: "+l);return(l,t)=>(d(),c(p,null,[e("div",u,[t[9]||(t[9]=e("h2",null,"Swipe Actions (List Items)",-1)),e("div",m,[t[6]||(t[6]=e("h3",null,"Swipe Left & Right",-1)),t[7]||(t[7]=e("p",{class:"custom-guide"},"Swipe horizontally to reveal actions. Supports rubber-banding physics.",-1)),e("div",g,[r(s(a),{style:{"border-bottom":"1px solid #eee"}},{left:o(()=>[e("div",{style:{background:"#28ba62"},onClick:t[0]||(t[0]=n=>i("Pinned!"))}," Pin ")]),right:o(()=>[e("div",{style:{background:"#ffc409",color:"#333"},onClick:t[1]||(t[1]=n=>i("Edited!"))}," Edit "),e("div",{style:{background:"#eb445a"},onClick:t[2]||(t[2]=n=>i("Deleted!"))}," Delete ")]),default:o(()=>[t[4]||(t[4]=e("div",{style:{padding:"16px",background:"white"}},[e("h4",{style:{margin:"0",color:"#333"}},"Swipe me both ways"),e("p",{style:{margin:"4px 0 0",color:"#666","font-size":"14px"}},"I have actions on both sides!")],-1))]),_:1}),r(s(a),null,{right:o(()=>[e("div",{style:{background:"#eb445a"},onClick:t[3]||(t[3]=n=>i("Deleted!"))}," Delete ")]),default:o(()=>[t[5]||(t[5]=e("div",{style:{padding:"16px",background:"white"}},[e("h4",{style:{margin:"0",color:"#333"}},"Swipe me left only"),e("p",{style:{margin:"4px 0 0",color:"#666","font-size":"14px"}},"Only a delete button on the right.")],-1))]),_:1})]),t[8]||(t[8]=e("pre",{class:"code-block"},[e("code",null,`<PPSwipeItem>
  <!-- Left actions (revealed by swiping right) -->
  <template #left>
    <div style="background: #28ba62;" @click="pin">Pin</div>
  </template>

  <!-- Right actions (revealed by swiping left) -->
  <template #right>
    <div style="background: #eb445a;" @click="remove">Delete</div>
  </template>
  
  <!-- Main Content -->
  <div class="content">
    <h4>Swipe me</h4>
  </div>
</PPSwipeItem>`)],-1))]),t[10]||(t[10]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[11]||(t[11]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Swipe Actions (List Items)</h2>
        <div class="variant-group">
          <h3>Swipe Left & Right</h3>
          <p class="custom-guide">Swipe horizontally to reveal actions. Supports rubber-banding physics.</p>
          <div class="component-demo" style="padding: 0; background: transparent; border-radius: 12px; overflow: hidden; border: 1px solid #eee; transform: translateZ(0); isolation: isolate;">
            <PPSwipeItem style="border-bottom: 1px solid #eee;">
              <template #left>
                <div style="background: #28ba62;" @click="alertVal('Pinned!')">
                  Pin
                </div>
              </template>
              <template #right>
                <div style="background: #ffc409; color: #333;" @click="alertVal('Edited!')">
                  Edit
                </div>
                <div style="background: #eb445a;" @click="alertVal('Deleted!')">
                  Delete
                </div>
              </template>
              <div style="padding: 16px; background: white;">
                <h4 style="margin: 0; color: #333;">Swipe me both ways</h4>
                <p style="margin: 4px 0 0; color: #666; font-size: 14px;">I have actions on both sides!</p>
              </div>
            </PPSwipeItem>
            
            <PPSwipeItem>
              <template #right>
                <div style="background: #eb445a;" @click="alertVal('Deleted!')">
                  Delete
                </div>
              </template>
              <div style="padding: 16px; background: white;">
                <h4 style="margin: 0; color: #333;">Swipe me left only</h4>
                <p style="margin: 4px 0 0; color: #666; font-size: 14px;">Only a delete button on the right.</p>
              </div>
            </PPSwipeItem>
          </div>
          <pre class="code-block"><code>&lt;PPSwipeItem&gt;
  &lt;!-- Left actions (revealed by swiping right) --&gt;
  &lt;template #left&gt;
    &lt;div style="background: #28ba62;" @click="pin"&gt;Pin&lt;/div&gt;
  &lt;/template&gt;

  &lt;!-- Right actions (revealed by swiping left) --&gt;
  &lt;template #right&gt;
    &lt;div style="background: #eb445a;" @click="remove"&gt;Delete&lt;/div&gt;
  &lt;/template&gt;
  
  &lt;!-- Main Content --&gt;
  &lt;div class="content"&gt;
    &lt;h4&gt;Swipe me&lt;/h4&gt;
  &lt;/div&gt;
&lt;/PPSwipeItem&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{y as _};
