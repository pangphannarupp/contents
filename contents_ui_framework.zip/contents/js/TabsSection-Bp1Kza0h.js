import{aT as n,aU as s,bB as f,bC as P,aS as u}from"./AccountCardSection-DXixqG3L.js";import{d as m,o as y,j as x,l,a as e,w as t,u as o,A as d,F as w,p as r}from"../vendors/vendor-ah_eQdvw.js";import{_ as c}from"./App-D7rwXoHs.js";const k={class:"guide-section"},S={class:"demo-box"},V={class:"demo-box"},L={class:"demo-box"},A={style:{background:"#f1f5f9",padding:"4px","border-radius":"12px",width:"fit-content"}},C={class:"demo-box"},D={class:"demo-box"},z=m({__name:"TabsSection",setup(O){const b=r("today"),v=r("today"),T=r("hourly"),p=r("all"),g=r("code");return(U,a)=>(y(),x(w,null,[l("div",k,[a[32]||(a[32]=l("h2",null,"Tabs & TabBar",-1)),a[33]||(a[33]=l("p",null,"A flexible tab component for organizing content. Supports different visual variants including pills and segmented styles, as seen in iOS and modern web apps.",-1)),a[34]||(a[34]=l("h3",null,"Standard Tabs",-1)),l("div",S,[e(o(u),{modelValue:b.value,"onUpdate:modelValue":a[0]||(a[0]=i=>b.value=i)},{default:t(()=>[e(o(n),null,{default:t(()=>[e(o(s),{value:"today"},{default:t(()=>[...a[5]||(a[5]=[d("Today",-1)])]),_:1}),e(o(s),{value:"tomorrow"},{default:t(()=>[...a[6]||(a[6]=[d("Tomorrow",-1)])]),_:1}),e(o(s),{value:"10days"},{default:t(()=>[...a[7]||(a[7]=[d("10 Days",-1)])]),_:1})]),_:1}),a[11]||(a[11]=l("div",{style:{height:"16px"}},null,-1)),e(o(f),null,{default:t(()=>[e(o(P),{value:"today"},{default:t(()=>[...a[8]||(a[8]=[l("div",{style:{padding:"16px",background:"white","border-radius":"8px"}},"☀️ Today's Forecast: Sunny, 28°C",-1)])]),_:1}),e(o(P),{value:"tomorrow"},{default:t(()=>[...a[9]||(a[9]=[l("div",{style:{padding:"16px",background:"white","border-radius":"8px"}},"🌧️ Tomorrow's Forecast: Rainy, 22°C",-1)])]),_:1}),e(o(P),{value:"10days"},{default:t(()=>[...a[10]||(a[10]=[l("div",{style:{padding:"16px",background:"white","border-radius":"8px"}},"📅 10-Day Outlook: Mostly cloudy.",-1)])]),_:1})]),_:1})]),_:1},8,["modelValue"])]),a[35]||(a[35]=l("div",{class:"usage-block",style:{"margin-top":"16px"}},[l("pre",{style:{background:"#1f2937",color:"#f8f8f2",padding:"16px","border-radius":"8px","overflow-x":"auto","font-size":"14px"}},[l("code",null,`<PPTabs v-model="activeTab">
  <PPTabList>
    <PPTab value="today">Today</PPTab>
    <PPTab value="tomorrow">Tomorrow</PPTab>
  </PPTabList>
  
  <PPTabPanels>
    <PPTabPanel value="today">...</PPTabPanel>
    <PPTabPanel value="tomorrow">...</PPTabPanel>
  </PPTabPanels>
</PPTabs>`)])],-1)),a[36]||(a[36]=l("h3",null,"Pills Variant (Scrollable)",-1)),a[37]||(a[37]=l("p",null,[d("Using "),l("code",null,'variant="pills"'),d(" and "),l("code",null,"scrollable"),d(" on the TabList.")],-1)),l("div",V,[e(o(u),{modelValue:v.value,"onUpdate:modelValue":a[1]||(a[1]=i=>v.value=i),variant:"pills"},{default:t(()=>[e(o(n),{scrollable:""},{default:t(()=>[e(o(s),{value:"today"},{default:t(()=>[...a[12]||(a[12]=[d("Today",-1)])]),_:1}),e(o(s),{value:"aug01"},{default:t(()=>[...a[13]||(a[13]=[d("01 Aug",-1)])]),_:1}),e(o(s),{value:"aug02"},{default:t(()=>[...a[14]||(a[14]=[d("02 Aug",-1)])]),_:1}),e(o(s),{value:"aug03"},{default:t(()=>[...a[15]||(a[15]=[d("03 Aug",-1)])]),_:1}),e(o(s),{value:"aug04"},{default:t(()=>[...a[16]||(a[16]=[d("04 Aug",-1)])]),_:1}),e(o(s),{value:"aug05"},{default:t(()=>[...a[17]||(a[17]=[d("05 Aug",-1)])]),_:1})]),_:1}),a[21]||(a[21]=l("div",{style:{height:"16px"}},null,-1)),e(o(f),null,{default:t(()=>[e(o(P),{value:"today"},{default:t(()=>[...a[18]||(a[18]=[l("div",{style:{padding:"16px",background:"white","border-radius":"8px"}},"Today content...",-1)])]),_:1}),e(o(P),{value:"aug01"},{default:t(()=>[...a[19]||(a[19]=[l("div",{style:{padding:"16px",background:"white","border-radius":"8px"}},"Aug 01 content...",-1)])]),_:1}),e(o(P),{value:"aug02"},{default:t(()=>[...a[20]||(a[20]=[l("div",{style:{padding:"16px",background:"white","border-radius":"8px"}},"Aug 02 content...",-1)])]),_:1})]),_:1})]),_:1},8,["modelValue"])]),a[38]||(a[38]=l("div",{class:"usage-block",style:{"margin-top":"16px"}},[l("pre",{style:{background:"#1f2937",color:"#f8f8f2",padding:"16px","border-radius":"8px","overflow-x":"auto","font-size":"14px"}},[l("code",null,`<PPTabs v-model="activeTab" variant="pills">
  <PPTabList scrollable>
    <PPTab value="1">Tab 1</PPTab>
    <PPTab value="2">Tab 2</PPTab>
  </PPTabList>
  <PPTabPanels>...</PPTabPanels>
</PPTabs>`)])],-1)),a[39]||(a[39]=l("h3",null,"Segmented Variant",-1)),l("div",L,[l("div",A,[e(o(u),{modelValue:T.value,"onUpdate:modelValue":a[2]||(a[2]=i=>T.value=i),variant:"segmented"},{default:t(()=>[e(o(n),null,{default:t(()=>[e(o(s),{value:"hourly"},{default:t(()=>[...a[22]||(a[22]=[d("Hourly",-1)])]),_:1}),e(o(s),{value:"daily"},{default:t(()=>[...a[23]||(a[23]=[d("Daily",-1)])]),_:1}),e(o(s),{value:"details"},{default:t(()=>[...a[24]||(a[24]=[d("Details",-1)])]),_:1})]),_:1})]),_:1},8,["modelValue"])])]),a[40]||(a[40]=l("div",{class:"usage-block",style:{"margin-top":"16px"}},[l("pre",{style:{background:"#1f2937",color:"#f8f8f2",padding:"16px","border-radius":"8px","overflow-x":"auto","font-size":"14px"}},[l("code",null,`<PPTabs v-model="activeTab" variant="segmented">
  <PPTabList>
    <PPTab value="hourly">Hourly</PPTab>
    <PPTab value="daily">Daily</PPTab>
  </PPTabList>
</PPTabs>`)])],-1)),a[41]||(a[41]=l("h3",null,"Outlined Variant",-1)),l("div",C,[e(o(u),{modelValue:p.value,"onUpdate:modelValue":a[3]||(a[3]=i=>p.value=i),variant:"outlined"},{default:t(()=>[e(o(n),{scrollable:""},{default:t(()=>[e(o(s),{value:"all"},{default:t(()=>[...a[25]||(a[25]=[d("All",-1)])]),_:1}),e(o(s),{value:"unread"},{default:t(()=>[...a[26]||(a[26]=[d("Unread",-1)])]),_:1}),e(o(s),{value:"drafts"},{default:t(()=>[...a[27]||(a[27]=[d("Drafts",-1)])]),_:1}),e(o(s),{value:"sent"},{default:t(()=>[...a[28]||(a[28]=[d("Sent",-1)])]),_:1})]),_:1})]),_:1},8,["modelValue"])]),a[42]||(a[42]=l("h3",null,"Minimal Variant",-1)),l("div",D,[e(o(u),{modelValue:g.value,"onUpdate:modelValue":a[4]||(a[4]=i=>g.value=i),variant:"minimal"},{default:t(()=>[e(o(n),null,{default:t(()=>[e(o(s),{value:"code"},{default:t(()=>[...a[29]||(a[29]=[d("Code",-1)])]),_:1}),e(o(s),{value:"issues"},{default:t(()=>[...a[30]||(a[30]=[d("Issues",-1)])]),_:1}),e(o(s),{value:"pulls"},{default:t(()=>[...a[31]||(a[31]=[d("Pull Requests",-1)])]),_:1})]),_:1})]),_:1},8,["modelValue"])]),a[43]||(a[43]=l("div",{class:"variant-group"},[l("h3",null,"Customizing CSS"),l("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),l("pre",{class:"code-block"},[l("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),a[44]||(a[44]=l("div",{class:"variant-group",style:{"margin-top":"40px"}},[l("h3",null,"Full Page Source Code"),l("p",{class:"custom-guide"},"Complete source code for this section."),l("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[l("code",null,`<template>
  <div class="guide-section">
    <h2>Tabs & TabBar</h2>
    <p>A flexible tab component for organizing content. Supports different visual variants including pills and segmented styles, as seen in iOS and modern web apps.</p>

    <h3>Standard Tabs</h3>
    <div class="demo-box">
      <PPTabs v-model="activeTab1">
        <PPTabList>
          <PPTab value="today">Today</PPTab>
          <PPTab value="tomorrow">Tomorrow</PPTab>
          <PPTab value="10days">10 Days</PPTab>
        </PPTabList>
        <div style="height: 16px;"></div>
        <PPTabPanels>
          <PPTabPanel value="today">
            <div style="padding: 16px; background: white; border-radius: 8px;">☀️ Today's Forecast: Sunny, 28°C</div>
          </PPTabPanel>
          <PPTabPanel value="tomorrow">
            <div style="padding: 16px; background: white; border-radius: 8px;">🌧️ Tomorrow's Forecast: Rainy, 22°C</div>
          </PPTabPanel>
          <PPTabPanel value="10days">
            <div style="padding: 16px; background: white; border-radius: 8px;">📅 10-Day Outlook: Mostly cloudy.</div>
          </PPTabPanel>
        </PPTabPanels>
      </PPTabs>
    </div>
    <div class="usage-block" style="margin-top: 16px;">
      <pre style="background: #1f2937; color: #f8f8f2; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 14px;"><code>&lt;PPTabs v-model="activeTab"&gt;
  &lt;PPTabList&gt;
    &lt;PPTab value="today"&gt;Today&lt;/PPTab&gt;
    &lt;PPTab value="tomorrow"&gt;Tomorrow&lt;/PPTab&gt;
  &lt;/PPTabList&gt;
  
  &lt;PPTabPanels&gt;
    &lt;PPTabPanel value="today"&gt;...&lt;/PPTabPanel&gt;
    &lt;PPTabPanel value="tomorrow"&gt;...&lt;/PPTabPanel&gt;
  &lt;/PPTabPanels&gt;
&lt;/PPTabs&gt;</code></pre>
    </div>
    
    <h3>Pills Variant (Scrollable)</h3>
    <p>Using <code>variant="pills"</code> and <code>scrollable</code> on the TabList.</p>
    <div class="demo-box">
      <PPTabs v-model="activeTab2" variant="pills">
        <PPTabList scrollable>
          <PPTab value="today">Today</PPTab>
          <PPTab value="aug01">01 Aug</PPTab>
          <PPTab value="aug02">02 Aug</PPTab>
          <PPTab value="aug03">03 Aug</PPTab>
          <PPTab value="aug04">04 Aug</PPTab>
          <PPTab value="aug05">05 Aug</PPTab>
        </PPTabList>
        <div style="height: 16px;"></div>
        <PPTabPanels>
          <PPTabPanel value="today">
            <div style="padding: 16px; background: white; border-radius: 8px;">Today content...</div>
          </PPTabPanel>
          <PPTabPanel value="aug01">
            <div style="padding: 16px; background: white; border-radius: 8px;">Aug 01 content...</div>
          </PPTabPanel>
          <PPTabPanel value="aug02">
            <div style="padding: 16px; background: white; border-radius: 8px;">Aug 02 content...</div>
          </PPTabPanel>
        </PPTabPanels>
      </PPTabs>
    </div>
    <div class="usage-block" style="margin-top: 16px;">
      <pre style="background: #1f2937; color: #f8f8f2; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 14px;"><code>&lt;PPTabs v-model="activeTab" variant="pills"&gt;
  &lt;PPTabList scrollable&gt;
    &lt;PPTab value="1"&gt;Tab 1&lt;/PPTab&gt;
    &lt;PPTab value="2"&gt;Tab 2&lt;/PPTab&gt;
  &lt;/PPTabList&gt;
  &lt;PPTabPanels&gt;...&lt;/PPTabPanels&gt;
&lt;/PPTabs&gt;</code></pre>
    </div>

    <h3>Segmented Variant</h3>
    <div class="demo-box">
      <div style="background: #f1f5f9; padding: 4px; border-radius: 12px; width: fit-content;">
        <PPTabs v-model="activeTab3" variant="segmented">
          <PPTabList>
            <PPTab value="hourly">Hourly</PPTab>
            <PPTab value="daily">Daily</PPTab>
            <PPTab value="details">Details</PPTab>
          </PPTabList>
        </PPTabs>
      </div>
    </div>
    <div class="usage-block" style="margin-top: 16px;">
      <pre style="background: #1f2937; color: #f8f8f2; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 14px;"><code>&lt;PPTabs v-model="activeTab" variant="segmented"&gt;
  &lt;PPTabList&gt;
    &lt;PPTab value="hourly"&gt;Hourly&lt;/PPTab&gt;
    &lt;PPTab value="daily"&gt;Daily&lt;/PPTab&gt;
  &lt;/PPTabList&gt;
&lt;/PPTabs&gt;</code></pre>
    </div>

    <h3>Outlined Variant</h3>
    <div class="demo-box">
      <PPTabs v-model="activeTab4" variant="outlined">
        <PPTabList scrollable>
          <PPTab value="all">All</PPTab>
          <PPTab value="unread">Unread</PPTab>
          <PPTab value="drafts">Drafts</PPTab>
          <PPTab value="sent">Sent</PPTab>
        </PPTabList>
      </PPTabs>
    </div>

    <h3>Minimal Variant</h3>
    <div class="demo-box">
      <PPTabs v-model="activeTab5" variant="minimal">
        <PPTabList>
          <PPTab value="code">Code</PPTab>
          <PPTab value="issues">Issues</PPTab>
          <PPTab value="pulls">Pull Requests</PPTab>
        </PPTabList>
      </PPTabs>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPTabs, PPTabList, PPTab, PPTabPanels, PPTabPanel } from '@phanna/ui-framework';

const activeTab1 = ref('today');
const activeTab2 = ref('today');
const activeTab3 = ref('hourly');
const activeTab4 = ref('all');
const activeTab5 = ref('code');
<\/script>

<style scoped>
.guide-section {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.demo-box {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 24px;
  background: #f9fafb;
}
</style>
`)])],-1))],64))}}),M=c(z,[["__scopeId","data-v-cdcb0f01"]]);export{M as T};
