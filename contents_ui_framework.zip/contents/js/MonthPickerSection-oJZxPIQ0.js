import{aZ as h,a_ as u,P as m,a$ as v,b0 as f}from"./AccountCardSection-DXixqG3L.js";import{d as k,o as b,j as S,l as o,A as t,a as l,u as a,w as g,F as M,p as P}from"../vendors/vendor-ah_eQdvw.js";const C={class:"guide-section"},y={class:"variant-group"},x={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},I={class:"variant-group"},O={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},w={class:"variant-group"},B={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},A={class:"variant-group"},R={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},V={class:"variant-group"},T={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},N=k({__name:"MonthPickerSection",setup(K){const c=P(null),r=P(!1),d=P(!1),s=p=>console.log("Setup: "+p);return(p,e)=>(b(),S(M,null,[o("div",C,[e[28]||(e[28]=o("h2",null,"13. Month Picker",-1)),o("div",y,[e[11]||(e[11]=o("h3",null,"Input Wrapper",-1)),e[12]||(e[12]=o("p",{class:"custom-guide"},[o("strong",null,"Component:"),t(),o("code",null,"<PPMonthPickerInput>")],-1)),o("div",x,[l(a(h),{modelValue:c.value,"onUpdate:modelValue":e[0]||(e[0]=n=>c.value=n)},null,8,["modelValue"])]),e[13]||(e[13]=o("pre",{class:"code-block"},[o("code",null,'<PPMonthPickerInput v-model="month" />')],-1))]),o("div",I,[e[14]||(e[14]=o("h3",null,"Standard Selection",-1)),e[15]||(e[15]=o("p",{class:"custom-guide"},[o("strong",null,"Props:"),t(),o("code",null,"config={ selectionMode: 'Single' }")],-1)),o("div",O,[l(a(u),{onMonthSelected:e[1]||(e[1]=n=>s("Selected Month: "+n.month+"/"+n.year))})]),e[16]||(e[16]=o("pre",{class:"code-block"},[o("code",null,'<PPMonthPicker @month-selected="onSelect" />')],-1))]),o("div",w,[e[17]||(e[17]=o("h3",null,"Range Selection",-1)),e[18]||(e[18]=o("p",{class:"custom-guide"},[o("strong",null,"Props:"),t(),o("code",null,"config={ selectionMode: 'Range' }")],-1)),o("div",B,[l(a(u),{config:{selectionMode:"Range"},onRangeSelected:e[2]||(e[2]=(n,i)=>s("Range: "+(n?n.month+"/"+n.year:"")+" to "+(i?i.month+"/"+i.year:"")))})]),e[19]||(e[19]=o("pre",{class:"code-block"},[o("code",null,`<PPMonthPicker :config="{ selectionMode: 'Range' }" />`)],-1))]),o("div",A,[e[21]||(e[21]=o("h3",null,"Month Picker Bottom Sheet",-1)),e[22]||(e[22]=o("p",{class:"custom-guide"},[o("strong",null,"Component:"),t(),o("code",null,"<PPMonthPickerSheet>")],-1)),o("div",R,[l(a(m),{onClick:e[3]||(e[3]=n=>r.value=!0)},{default:g(()=>[...e[20]||(e[20]=[t("Open Month Sheet",-1)])]),_:1}),l(a(v),{modelValue:r.value,"onUpdate:modelValue":e[4]||(e[4]=n=>r.value=n),title:"Select a Month",showActionButtons:!0,onConfirm:e[5]||(e[5]=n=>{s("Confirmed: "+(n?n.month+"/"+n.year:"")),r.value=!1}),onCancel:e[6]||(e[6]=n=>r.value=!1)},null,8,["modelValue"])]),e[23]||(e[23]=o("pre",{class:"code-block"},[o("code",null,'<PPMonthPickerSheet v-model="isOpen" />')],-1))]),o("div",V,[e[25]||(e[25]=o("h3",null,"Month Picker Island Popup",-1)),e[26]||(e[26]=o("p",{class:"custom-guide"},[o("strong",null,"Component:"),t(),o("code",null,"<PPMonthPickerIsland>")],-1)),o("div",T,[l(a(m),{onClick:e[7]||(e[7]=n=>d.value=!0)},{default:g(()=>[...e[24]||(e[24]=[t("Open Month Picker Island",-1)])]),_:1}),l(a(f),{modelValue:d.value,"onUpdate:modelValue":e[8]||(e[8]=n=>d.value=n),showActionButtons:!0,onConfirm:e[9]||(e[9]=n=>{s("Confirmed Month: "+(n?n.month+"/"+n.year:"none")),d.value=!1}),onCancel:e[10]||(e[10]=n=>d.value=!1)},null,8,["modelValue"])]),e[27]||(e[27]=o("pre",{class:"code-block"},[o("code",null,'<PPMonthPickerIsland v-model="isOpen" />')],-1))]),e[29]||(e[29]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-danger-color: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[30]||(e[30]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
<div class="guide-section">
        <h2>13. Month Picker</h2>

        <div class="variant-group">
          <h3>Standard Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Single' }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPMonthPicker 
              @month-selected="s => alertVal('Selected Month: ' + s.month + '/' + s.year)"
            />
          </div>
          <pre class="code-block"><code>&lt;PPMonthPicker @month-selected="onSelect" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Range Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Range' }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPMonthPicker 
              :config="{ selectionMode: 'Range' }"
              @range-selected="(start, end) => alertVal('Range: ' + (start ? start.month + '/' + start.year : '') + ' to ' + (end ? end.month + '/' + end.year : ''))"
            />
          </div>
          <pre class="code-block"><code>&lt;PPMonthPicker :config="{ selectionMode: 'Range' }" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Month Picker Bottom Sheet</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPMonthPickerSheet&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showMonthPickerSheet = true">Open Month Sheet</PPButton>
            <PPMonthPickerSheet 
              v-model="showMonthPickerSheet"
              title="Select a Month"
              :showActionButtons="true"
              @confirm="(s) => { alertVal('Confirmed: ' + (s ? s.month + '/' + s.year : '')); showMonthPickerSheet = false; }"
              @cancel="showMonthPickerSheet = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPMonthPickerSheet v-model="isOpen" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Month Picker Island Popup</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPMonthPickerIsland&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showMonthPickerIsland = true">Open Month Picker Island</PPButton>
            <PPMonthPickerIsland 
              v-model="showMonthPickerIsland"
              :showActionButtons="true"
              @confirm="s => { alertVal('Confirmed Month: ' + (s ? s.month + '/' + s.year : 'none')); showMonthPickerIsland = false; }"
              @cancel="showMonthPickerIsland = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPMonthPickerIsland v-model="isOpen" /&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-danger-color: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
const monthModel = ref(null);

const showMonthPickerSheet = ref(false);

const showMonthPickerIsland = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem , PPMonthPickerInput } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{N as _};
