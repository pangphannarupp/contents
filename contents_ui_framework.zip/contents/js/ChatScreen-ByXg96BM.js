import{a2 as c,a3 as m,b as u,c as p}from"./AccountCardSection-DXixqG3L.js";import{d as C,o as d,j as l,l as t,L as h,a as s,u as n,F as g,z as f,w as b,E as x,aT as V,aV as _,aB as w,aW as P,aH as B,aX as k,aI as M,p as y}from"../vendors/vendor-ah_eQdvw.js";import{_ as L}from"./App-D7rwXoHs.js";const I={class:"component-section"},S={style:{display:"flex",gap:"32px","flex-wrap":"wrap","justify-content":"center","margin-top":"32px"}},z={class:"phone-mockup light-mode"},N={class:"chat-header"},F={class:"chat-list"},O={class:"bottom-nav-container"},U={class:"phone-mockup dark-mode"},A={class:"chat-header"},H={class:"chat-list"},T={class:"bottom-nav-container"},j=C({__name:"ChatScreen",setup(D){const i=y("chats"),o=y(""),r=[{label:"Chats",value:"chats",icon:w,activeIcon:_},{label:"Contacts",value:"contacts",icon:B,activeIcon:P},{label:"Settings",value:"settings",icon:M,activeIcon:k}],v=[{id:1,name:"Bryan",message:"What do you think?",time:"4:30 PM",unread:2,avatar:"https://i.pravatar.cc/150?u=bryan"},{id:2,name:"Kari",message:"Looks great!",time:"4:23 PM",unread:1,avatar:"https://i.pravatar.cc/150?u=kari"},{id:3,name:"Diana",message:"Lunch on Monday?",time:"4:12 PM",unread:0,avatar:"https://i.pravatar.cc/150?u=diana"},{id:4,name:"Ben",message:"You sent a photo.",time:"3:58 PM",unread:0,avatar:"https://i.pravatar.cc/150?u=ben"},{id:5,name:"Naomi",message:"Naomi sent a photo.",time:"3:31 PM",unread:0,avatar:"https://i.pravatar.cc/150?u=naomi"},{id:6,name:"Alicia",message:"See you at 8.",time:"3:30 PM",unread:0,avatar:"https://i.pravatar.cc/150?u=alicia"}];return(E,e)=>(d(),l("div",I,[e[6]||(e[6]=t("h2",null,"Chat Application Template",-1)),e[7]||(e[7]=t("p",null,"A full chat interface utilizing search, avatars, badges, floating action button, and bottom navigation.",-1)),t("div",S,[t("div",z,[e[4]||(e[4]=h('<div class="status-bar" data-v-0d2e49ad><span class="time" data-v-0d2e49ad>9:30</span><div class="status-icons" data-v-0d2e49ad><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" data-v-0d2e49ad><path d="M12 21L1 3h22L12 21z" data-v-0d2e49ad></path></svg><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" data-v-0d2e49ad><path d="M2 22h20V2L2 22z" data-v-0d2e49ad></path></svg><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" data-v-0d2e49ad><path d="M22 4v16a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z" data-v-0d2e49ad></path></svg></div></div>',1)),t("div",N,[s(n(c),{modelValue:o.value,"onUpdate:modelValue":e[0]||(e[0]=a=>o.value=a),placeholder:"Search"},null,8,["modelValue"])]),t("div",F,[(d(),l(g,null,f(v,a=>s(n(m),{key:a.id,name:a.name,avatar:a.avatar,time:a.time,message:a.message,unread:a.unread},null,8,["name","avatar","time","message","unread"])),64))]),s(n(u),{style:{bottom:"88px",right:"16px"},color:"primary"},{icon:b(()=>[s(n(x),{icon:n(V)},null,8,["icon"])]),_:1}),t("div",O,[s(n(p),{modelValue:i.value,"onUpdate:modelValue":e[1]||(e[1]=a=>i.value=a),variant:"material",items:r},null,8,["modelValue"])])]),t("div",U,[e[5]||(e[5]=h('<div class="status-bar" data-v-0d2e49ad><span class="time" data-v-0d2e49ad>9:30</span><div class="status-icons" data-v-0d2e49ad><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" data-v-0d2e49ad><path d="M12 21L1 3h22L12 21z" data-v-0d2e49ad></path></svg><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" data-v-0d2e49ad><path d="M2 22h20V2L2 22z" data-v-0d2e49ad></path></svg><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" data-v-0d2e49ad><path d="M22 4v16a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z" data-v-0d2e49ad></path></svg></div></div>',1)),t("div",A,[s(n(c),{modelValue:o.value,"onUpdate:modelValue":e[2]||(e[2]=a=>o.value=a),placeholder:"Search"},null,8,["modelValue"])]),t("div",H,[(d(),l(g,null,f(v,a=>s(n(m),{key:a.id,name:a.name,avatar:a.avatar,time:a.time,message:a.message,unread:a.unread},null,8,["name","avatar","time","message","unread"])),64))]),s(n(u),{style:{bottom:"88px",right:"16px"},color:"primary"},{icon:b(()=>[s(n(x),{icon:n(V)},null,8,["icon"])]),_:1}),t("div",T,[s(n(p),{modelValue:i.value,"onUpdate:modelValue":e[3]||(e[3]=a=>i.value=a),variant:"material",items:r},null,8,["modelValue"])])])]),e[8]||(e[8]=t("div",{class:"usage-section"},[t("h3",null,"Code Usage"),t("pre",{class:"code-block"},[t("code",null,`
<template>
  <div class="chat-screen">
    <!-- Header & Search -->
    <div class="chat-header">
      <PPSearch v-model="searchQuery" placeholder="Search" />
    </div>

    <!-- Chat List -->
    <div class="chat-list">
      <PPChatItem 
        v-for="chat in chats" 
        :key="chat.id"
        :name="chat.name"
        :avatar="chat.avatar"
        :time="chat.time"
        :message="chat.message"
        :unread="chat.unread"
      />
    </div>

    <!-- Floating Action Button -->
    <PPFab style="bottom: 88px; right: 16px;" color="primary">
      <template #icon>
        <ion-icon :icon="pencilOutline" />
      </template>
    </PPFab>

    <!-- Bottom Navigation -->
    <PPBottomNav 
      v-model="activeTab"
      variant="material"
      :items="navItems"
    />
  </div>
</template>
      `)])],-1))]))}}),X=L(j,[["__scopeId","data-v-0d2e49ad"]]);export{X as C};
