import{d as f,o as x,j as y,l as n,a as e,w as i,u as t,A as c,E as a,bb as A,ar as S,M as I,az as g,aA as O,a7 as h,bc as F,aD as v,aI as C,a8 as P,b9 as k,F as B,p as w}from"../vendors/vendor-ah_eQdvw.js";import{ax as p,ay as r,b as l,P as d}from"./AccountCardSection-DXixqG3L.js";import{_ as T}from"./App-D7rwXoHs.js";const L={class:"guide-section"},D={class:"variant-group"},E={class:"component-demo",style:{"min-height":"400px",position:"relative"}},_={style:{position:"absolute",top:"20px",right:"20px",width:"100px",height:"100px",background:"linear-gradient(45deg, #f093fb 0%, #f5576c 100%)","border-radius":"12px",display:"flex","align-items":"center","justify-content":"center"}},R={style:{"padding-bottom":"20px",position:"relative","z-index":"10"}},N={class:"variant-group"},K={class:"component-demo",style:{"min-height":"400px",position:"relative"}},V={class:"variant-group"},M={class:"component-demo",style:{"min-height":"400px",position:"relative",overflow:"hidden",transform:"translateZ(0)"}},z={style:{padding:"60px 40px",color:"white",display:"flex","flex-direction":"column","align-items":"center","justify-content":"center",height:"100%","text-align":"center"}},G={style:{"margin-top":"40px",display:"flex",gap:"16px"}},Y=f({__name:"FabSection",setup(j){const u=m=>console.log("Setup: "+m),s=w(!0);return(m,o)=>(x(),y(B,null,[n("div",L,[o[18]||(o[18]=n("h2",null,"Floating Action Button (FAB)",-1)),n("div",D,[o[7]||(o[7]=n("h3",null,"Standard FAB & Speed Dial",-1)),n("div",E,[e(t(l),{position:"bottom-right",variant:"solid",color:"primary"},{list:i(()=>[e(t(p),{side:"top"},{default:i(()=>[e(t(r),{color:"primary",onClick:o[0]||(o[0]=b=>u("Action 1"))},{default:i(()=>[...o[3]||(o[3]=[c("1",-1)])]),_:1}),e(t(r),{color:"danger",onClick:o[1]||(o[1]=b=>u("Action 2"))},{default:i(()=>[...o[4]||(o[4]=[c("2",-1)])]),_:1})]),_:1})]),_:1}),e(t(l),{position:"bottom-left",color:"secondary",extended:s.value},{default:i(()=>[...o[5]||(o[5]=[c(" Extended FAB ",-1)])]),_:1},8,["extended"]),e(t(l),{position:"center",variant:"gradient",style:{"margin-top":"-120px"}},{icon:i(()=>[e(t(a),{icon:t(A)},null,8,["icon"])]),_:1}),e(t(l),{position:"center",variant:"soft",style:{"margin-left":"-100px","margin-top":"40px"}},{icon:i(()=>[e(t(a),{icon:t(S)},null,8,["icon"])]),_:1}),e(t(l),{position:"center",variant:"outline",style:{"margin-left":"100px","margin-top":"40px"}},{icon:i(()=>[e(t(a),{icon:t(I)},null,8,["icon"])]),_:1}),n("div",_,[e(t(l),{position:"center",variant:"glass",style:{position:"relative",top:"0",left:"0",transform:"none"}},{icon:i(()=>[e(t(a),{icon:t(g)},null,8,["icon"])]),_:1})]),n("div",R,[e(t(d),{onClick:o[2]||(o[2]=b=>s.value=!s.value)},{default:i(()=>[...o[6]||(o[6]=[c("Toggle Extended FAB",-1)])]),_:1})])]),o[8]||(o[8]=n("pre",{class:"code-block"},[n("code",null,`<PPFab position="bottom-right">
  <template #list>
    <PPFabList side="top">
      <PPFabAction color="primary" @click="doSomething">1</PPFabAction>
    </PPFabList>
  </template>
</PPFab>

<PPFab position="bottom-left" color="secondary" :extended="isExtended">
  Extended FAB
</PPFab>`)],-1))]),n("div",N,[o[10]||(o[10]=n("h3",null,"Circle Speed Dial",-1)),n("div",K,[o[9]||(o[9]=n("p",{style:{"text-align":"center","margin-bottom":"24px",color:"#6b7280"}},"Click the center FAB to see the actions expand in a circle.",-1)),e(t(l),{position:"center",color:"primary"},{icon:i(()=>[e(t(a),{icon:t(P)},null,8,["icon"])]),list:i(()=>[e(t(p),{side:"circle",circleRadius:80},{default:i(()=>[e(t(r),{color:"primary"},{default:i(()=>[e(t(a),{icon:t(O)},null,8,["icon"])]),_:1}),e(t(r),{color:"danger"},{default:i(()=>[e(t(a),{icon:t(h)},null,8,["icon"])]),_:1}),e(t(r),{color:"secondary"},{default:i(()=>[e(t(a),{icon:t(F)},null,8,["icon"])]),_:1}),e(t(r),{color:"light"},{default:i(()=>[e(t(a),{icon:t(v)},null,8,["icon"])]),_:1}),e(t(r),{color:"light"},{default:i(()=>[e(t(a),{icon:t(C)},null,8,["icon"])]),_:1})]),_:1})]),_:1}),e(t(l),{position:"bottom-right",color:"danger"},{icon:i(()=>[e(t(a),{icon:t(P)},null,8,["icon"])]),list:i(()=>[e(t(p),{side:"circle",circleStartAngle:-90,circleEndAngle:0,circleRadius:90},{default:i(()=>[e(t(r),{color:"light"},{default:i(()=>[e(t(a),{icon:t(g)},null,8,["icon"])]),_:1}),e(t(r),{color:"light"},{default:i(()=>[e(t(a),{icon:t(k)},null,8,["icon"])]),_:1}),e(t(r),{color:"light"},{default:i(()=>[e(t(a),{icon:t(v)},null,8,["icon"])]),_:1})]),_:1})]),_:1})]),o[11]||(o[11]=n("pre",{class:"code-block"},[n("code",null,`<!-- Full Circle Speed Dial -->
<PPFab position="center">
  <template #list>
    <PPFabList side="circle" :circleRadius="80">
      <PPFabAction>1</PPFabAction>
      <PPFabAction>2</PPFabAction>
      <PPFabAction>3</PPFabAction>
      <PPFabAction>4</PPFabAction>
    </PPFabList>
  </template>
</PPFab>

<!-- Quarter/Semi Circle Speed Dial -->
<PPFab position="bottom-right">
  <template #list>
    <PPFabList side="circle" :circleStartAngle="-90" :circleEndAngle="0" :circleRadius="90">
      <PPFabAction>1</PPFabAction>
      <PPFabAction>2</PPFabAction>
      <PPFabAction>3</PPFabAction>
    </PPFabList>
  </template>
</PPFab>`)],-1))]),n("div",V,[o[16]||(o[16]=n("h3",null,"Shapes and Morph Animation",-1)),n("div",M,[e(t(l),{position:"top-right",color:"danger",shape:"rounded"},{icon:i(()=>[e(t(a),{icon:t(h)},null,8,["icon"])]),_:1}),e(t(l),{position:"top-left",color:"secondary",shape:"square"},{icon:i(()=>[e(t(a),{icon:t(F)},null,8,["icon"])]),_:1}),e(t(l),{position:"center",color:"primary",morph:""},{icon:i(()=>[e(t(a),{icon:t(P)},null,8,["icon"])]),"morph-content":i(()=>[n("div",z,[o[14]||(o[14]=n("h2",{style:{color:"white","margin-bottom":"16px","font-size":"32px"}},"Create New Item",-1)),o[15]||(o[15]=n("p",{style:{"font-size":"18px","max-width":"400px","line-height":"1.5"}},"This is the fullscreen morph content. The button expands to fill the entire screen, and you can render anything you need right here!",-1)),n("div",G,[e(t(d),{variant:"soft",style:{background:"rgba(255,255,255,0.2)",color:"white"}},{default:i(()=>[...o[12]||(o[12]=[c("Save Draft",-1)])]),_:1}),e(t(d),{variant:"secondary",style:{background:"white",color:"var(--pp-primary-variant, #1a2a5e)"}},{default:i(()=>[...o[13]||(o[13]=[c("Publish Now",-1)])]),_:1})])])]),_:1})]),o[17]||(o[17]=n("pre",{class:"code-block"},[n("code",null,`<!-- Different Shapes -->
<PPFab shape="circle"></PPFab>
<PPFab shape="rounded"></PPFab>
<PPFab shape="square"></PPFab>

<!-- Morph Animation -->
<PPFab morph color="primary">
  <template #icon>
    <IonIcon :icon="addOutline" />
  </template>
  <template #morph-content>
    <div class="fullscreen-content">...</div>
  </template>
</PPFab>`)],-1))]),o[19]||(o[19]=n("div",{class:"variant-group"},[n("h3",null,"Customizing CSS"),n("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),n("pre",{class:"code-block"},[n("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[20]||(o[20]=n("div",{class:"variant-group",style:{"margin-top":"40px"}},[n("h3",null,"Full Page Source Code"),n("p",{class:"custom-guide"},"Complete source code for this section."),n("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[n("code",null,`<template>
<div class="guide-section">
        <h2>Floating Action Button (FAB)</h2>
        <div class="variant-group">
          <h3>Standard FAB & Speed Dial</h3>
          <div class="component-demo" style="min-height: 400px; position: relative;">
            
            <!-- Standard -->
            <PPFab position="bottom-right" variant="solid" color="primary">
              <template #list>
                <PPFabList side="top">
                  <PPFabAction color="primary" @click="alertVal('Action 1')">1</PPFabAction>
                  <PPFabAction color="danger" @click="alertVal('Action 2')">2</PPFabAction>
                </PPFabList>
              </template>
            </PPFab>
            
            <!-- Extended -->
            <PPFab position="bottom-left" color="secondary" :extended="isExtended">
              Extended FAB
            </PPFab>

            <!-- Gradient Variant -->
            <PPFab position="center" variant="gradient" style="margin-top: -120px;">
              <template #icon>
                <IonIcon :icon="rocketOutline" />
              </template>
            </PPFab>

            <!-- Soft Variant -->
            <PPFab position="center" variant="soft" style="margin-left: -100px; margin-top: 40px;">
              <template #icon>
                <IonIcon :icon="layersOutline" />
              </template>
            </PPFab>

            <!-- Outline Variant -->
            <PPFab position="center" variant="outline" style="margin-left: 100px; margin-top: 40px;">
              <template #icon>
                <IonIcon :icon="searchOutline" />
              </template>
            </PPFab>

            <!-- Glass Variant -->
            <!-- Glass looks best on an image or pattern, but we'll demonstrate it here -->
            <div style="position: absolute; top: 20px; right: 20px; width: 100px; height: 100px; background: linear-gradient(45deg, #f093fb 0%, #f5576c 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
              <PPFab position="center" variant="glass" style="position: relative; top: 0; left: 0; transform: none;">
                <template #icon>
                  <IonIcon :icon="chatbubbleOutline" />
                </template>
              </PPFab>
            </div>
            
            <div style="padding-bottom: 20px; position: relative; z-index: 10;">
              <PPButton @click="isExtended = !isExtended">Toggle Extended FAB</PPButton>
            </div>
          </div>
          <pre class="code-block"><code>&lt;PPFab position="bottom-right"&gt;
  &lt;template #list&gt;
    &lt;PPFabList side="top"&gt;
      &lt;PPFabAction color="primary" @click="doSomething"&gt;1&lt;/PPFabAction&gt;
    &lt;/PPFabList&gt;
  &lt;/template&gt;
&lt;/PPFab&gt;

&lt;PPFab position="bottom-left" color="secondary" :extended="isExtended"&gt;
  Extended FAB
&lt;/PPFab&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Circle Speed Dial</h3>
          <div class="component-demo" style="min-height: 400px; position: relative;">
            <p style="text-align: center; margin-bottom: 24px; color: #6b7280;">Click the center FAB to see the actions expand in a circle.</p>

            <!-- Full Circle Speed Dial -->
            <PPFab position="center" color="primary">
              <template #icon>
                <IonIcon :icon="addOutline" />
              </template>
              <template #list>
                <PPFabList side="circle" :circleRadius="80">
                  <PPFabAction color="primary"><IonIcon :icon="shareOutline" /></PPFabAction>
                  <PPFabAction color="danger"><IonIcon :icon="trashOutline" /></PPFabAction>
                  <PPFabAction color="secondary"><IonIcon :icon="documentTextOutline" /></PPFabAction>
                  <PPFabAction color="light"><IonIcon :icon="personOutline" /></PPFabAction>
                  <PPFabAction color="light"><IonIcon :icon="settingsOutline" /></PPFabAction>
                </PPFabList>
              </template>
            </PPFab>
            
            <!-- Semi-Circle Speed Dial (Top) -->
            <PPFab position="bottom-right" color="danger">
              <template #icon>
                <IonIcon :icon="addOutline" />
              </template>
              <template #list>
                <!-- A top semi-circle uses angles from -90 to 90. -->
                <PPFabList side="circle" :circleStartAngle="-90" :circleEndAngle="0" :circleRadius="90">
                  <PPFabAction color="light"><IonIcon :icon="chatbubbleOutline" /></PPFabAction>
                  <PPFabAction color="light"><IonIcon :icon="phonePortraitOutline" /></PPFabAction>
                  <PPFabAction color="light"><IonIcon :icon="personOutline" /></PPFabAction>
                </PPFabList>
              </template>
            </PPFab>

          </div>
          <pre class="code-block"><code>&lt;!-- Full Circle Speed Dial --&gt;
&lt;PPFab position="center"&gt;
  &lt;template #list&gt;
    &lt;PPFabList side="circle" :circleRadius="80"&gt;
      &lt;PPFabAction&gt;1&lt;/PPFabAction&gt;
      &lt;PPFabAction&gt;2&lt;/PPFabAction&gt;
      &lt;PPFabAction&gt;3&lt;/PPFabAction&gt;
      &lt;PPFabAction&gt;4&lt;/PPFabAction&gt;
    &lt;/PPFabList&gt;
  &lt;/template&gt;
&lt;/PPFab&gt;

&lt;!-- Quarter/Semi Circle Speed Dial --&gt;
&lt;PPFab position="bottom-right"&gt;
  &lt;template #list&gt;
    &lt;PPFabList side="circle" :circleStartAngle="-90" :circleEndAngle="0" :circleRadius="90"&gt;
      &lt;PPFabAction&gt;1&lt;/PPFabAction&gt;
      &lt;PPFabAction&gt;2&lt;/PPFabAction&gt;
      &lt;PPFabAction&gt;3&lt;/PPFabAction&gt;
    &lt;/PPFabList&gt;
  &lt;/template&gt;
&lt;/PPFab&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Shapes and Morph Animation</h3>
          <div class="component-demo" style="min-height: 400px; position: relative; overflow: hidden; transform: translateZ(0);">
            
            <!-- Rounded Shape -->
            <PPFab position="top-right" color="danger" shape="rounded">
              <template #icon>
                <IonIcon :icon="trashOutline" />
              </template>
            </PPFab>
            
            <!-- Square Shape -->
            <PPFab position="top-left" color="secondary" shape="square">
              <template #icon>
                <IonIcon :icon="documentTextOutline" />
              </template>
            </PPFab>

            <!-- Morph Animation to Full Screen -->
            <PPFab position="center" color="primary" morph>
              <template #icon>
                <IonIcon :icon="addOutline" />
              </template>
              <template #morph-content>
                <div style="padding: 60px 40px; color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; text-align: center;">
                  <h2 style="color: white; margin-bottom: 16px; font-size: 32px;">Create New Item</h2>
                  <p style="font-size: 18px; max-width: 400px; line-height: 1.5;">This is the fullscreen morph content. The button expands to fill the entire screen, and you can render anything you need right here!</p>
                  
                  <div style="margin-top: 40px; display: flex; gap: 16px;">
                     <PPButton variant="soft" style="background: rgba(255,255,255,0.2); color: white;">Save Draft</PPButton>
                     <PPButton variant="secondary" style="background: white; color: var(--pp-primary-variant, #1a2a5e);">Publish Now</PPButton>
                  </div>
                </div>
              </template>
            </PPFab>

          </div>
          <pre class="code-block"><code>&lt;!-- Different Shapes --&gt;
&lt;PPFab shape="circle"&gt;&lt;/PPFab&gt;
&lt;PPFab shape="rounded"&gt;&lt;/PPFab&gt;
&lt;PPFab shape="square"&gt;&lt;/PPFab&gt;

&lt;!-- Morph Animation --&gt;
&lt;PPFab morph color="primary"&gt;
  &lt;template #icon&gt;
    &lt;IonIcon :icon="addOutline" /&gt;
  &lt;/template&gt;
  &lt;template #morph-content&gt;
    &lt;div class="fullscreen-content"&gt;...&lt;/div&gt;
  &lt;/template&gt;
&lt;/PPFab&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const alertVal = (type: string) => console.log('Setup: ' + type);
const isExtended = ref(true);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>

<style scoped>
.guide-section {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.component-demo {
  position: relative;
  min-height: 200px;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 24px;
  background: #f9fafb;
  overflow: hidden;
}
</style>
`)])],-1))],64))}}),Q=T(Y,[["__scopeId","data-v-6a08bb32"]]);export{Q as F};
