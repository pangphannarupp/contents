import{bk as l}from"./AccountCardSection-DXixqG3L.js";import{d as p,o as m,j as u,l as t,a as i,u as r,L as g,F as v,p as c}from"../vendors/vendor-ah_eQdvw.js";const f={class:"component-section"},b={style:{"margin-top":"32px","margin-bottom":"64px"}},x={class:"demo-box",style:{display:"flex",gap:"40px","align-items":"center","justify-content":"center",height:"150px",background:"#f8fafc","border-radius":"12px",border:"1px dashed #cbd5e1"}},P=p({__name:"ReactionPickerSection",setup(k){const s=c(null),a=c("love"),d=n=>{console.log("Selected reaction:",n)};return(n,e)=>(m(),u(v,null,[t("div",f,[e[4]||(e[4]=t("h2",null,"Facebook-like Reactions (Stickers)",-1)),e[5]||(e[5]=t("p",null,'A fun, animated reaction picker component that mimics the famous Facebook "Like" button behavior. Perfect for social feeds or interactive feedback.',-1)),t("div",b,[t("div",x,[t("div",null,[e[2]||(e[2]=t("p",{style:{"font-size":"13px",color:"#64748b","margin-bottom":"8px","text-align":"center"}},"Hover over the button!",-1)),i(r(l),{modelValue:s.value,"onUpdate:modelValue":e[0]||(e[0]=o=>s.value=o),onChange:d},null,8,["modelValue"])]),t("div",null,[e[3]||(e[3]=t("p",{style:{"font-size":"13px",color:"#64748b","margin-bottom":"8px","text-align":"center"}},"Already selected state",-1)),i(r(l),{modelValue:a.value,"onUpdate:modelValue":e[1]||(e[1]=o=>a.value=o)},null,8,["modelValue"])])])]),e[6]||(e[6]=g(`<div style="margin-top:40px;"><h3>Usage Example</h3><pre class="code-block" style="background:#f8fafc;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;!-- Basic Usage --&gt;
  &lt;PPReactionPicker v-model=&quot;selectedReaction&quot; /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from &#39;vue&#39;;
import { PPReactionPicker } from &#39;@phanna/ui-framework&#39;;

// Will hold &#39;like&#39;, &#39;love&#39;, &#39;haha&#39;, &#39;wow&#39;, &#39;sad&#39;, &#39;angry&#39; or null
const selectedReaction = ref(null);
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[7]||(e[7]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Facebook-like Reactions (Stickers)</h2>
    <p>A fun, animated reaction picker component that mimics the famous Facebook "Like" button behavior. Perfect for social feeds or interactive feedback.</p>

    <div style="margin-top: 32px; margin-bottom: 64px;">
      <div class="demo-box" style="display: flex; gap: 40px; align-items: center; justify-content: center; height: 150px; background: #f8fafc; border-radius: 12px; border: 1px dashed #cbd5e1;">
        
        <div>
          <p style="font-size: 13px; color: #64748b; margin-bottom: 8px; text-align: center;">Hover over the button!</p>
          <PPReactionPicker v-model="reaction1" @change="onChange" />
        </div>

        <div>
          <p style="font-size: 13px; color: #64748b; margin-bottom: 8px; text-align: center;">Already selected state</p>
          <PPReactionPicker v-model="reaction2" />
        </div>

      </div>
    </div>

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      
      <pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;!-- Basic Usage --&gt;
  &lt;PPReactionPicker v-model="selectedReaction" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { PPReactionPicker } from '@phanna/ui-framework';

// Will hold 'like', 'love', 'haha', 'wow', 'sad', 'angry' or null
const selectedReaction = ref(null);
&lt;/script&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPReactionPicker } from '@phanna/ui-framework';

const reaction1 = ref<string | null>(null);
const reaction2 = ref<string | null>('love');

const onChange = (val: string | null) => {
  console.log('Selected reaction:', val);
};
<\/script>
`)])],-1))],64))}});export{P as _};
