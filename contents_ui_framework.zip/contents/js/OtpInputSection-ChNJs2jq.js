import{ba as a}from"./AccountCardSection-DXixqG3L.js";import{d as l,o as n,j as p,l as o,a as i,u as r,y as d,F as c,p as u}from"../vendors/vendor-ah_eQdvw.js";import{_ as m}from"./App-D7rwXoHs.js";const g={class:"guide-section"},v={class:"demo-box"},f={style:{"margin-top":"16px","font-family":"monospace"}},y=l({__name:"OtpInputSection",setup(b){const t=u("");return(x,e)=>(n(),p(c,null,[o("div",g,[e[1]||(e[1]=o("h2",null,"OTP Input",-1)),e[2]||(e[2]=o("p",null,"A specialized input component for One-Time Passwords.",-1)),e[3]||(e[3]=o("h3",null,"OTP Input (6-digit)",-1)),o("div",v,[i(r(a),{modelValue:t.value,"onUpdate:modelValue":e[0]||(e[0]=s=>t.value=s),length:6},null,8,["modelValue"]),o("div",f,"Value: "+d(t.value),1)]),e[4]||(e[4]=o("pre",{class:"code-block"},[o("code",null,'<PPOtpInput v-model="otp" :length="6" />')],-1)),e[5]||(e[5]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[6]||(e[6]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="guide-section">
    <h2>OTP Input</h2>
    <p>A specialized input component for One-Time Passwords.</p>

    <h3>OTP Input (6-digit)</h3>
    <div class="demo-box">
      <PPOtpInput v-model="otpVal" :length="6" />
      <div style="margin-top: 16px; font-family: monospace;">Value: {{ otpVal }}</div>
    </div>
    <pre class="code-block"><code>&lt;PPOtpInput v-model="otp" :length="6" /&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPOtpInput } from '@phanna/ui-framework';

const otpVal = ref('');
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
.code-block {
  background: #1f2937;
  color: #e5e7eb;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  font-family: 'Fira Code', Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
  font-size: 14px;
  line-height: 1.5;
  margin: 0;
}
</style>
`)])],-1))],64))}}),S=m(y,[["__scopeId","data-v-130d490b"]]);export{S as O};
