import{d as ee,o as E,j,l as e,v as i,V as n,bj as S,A as s,bk as B,a1 as w,k as I,y as g,a as d,u as p,F as oe,p as a,m as M}from"../vendors/vendor-ah_eQdvw.js";import{aL as te,aM as le,aN as ae,aO as ie,aP as ne,aQ as se,aR as re}from"./AccountCardSection-DXixqG3L.js";import{_ as de}from"./App-D7rwXoHs.js";const pe={class:"guide-section"},ue={style:{"margin-bottom":"24px",display:"flex","flex-wrap":"wrap",gap:"16px","align-items":"center"}},me={style:{"margin-bottom":"24px",position:"relative"}},ge={key:0,src:"https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1000&auto=format&fit=crop",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%","object-fit":"cover","border-radius":"8px","z-index":"0",opacity:"0.8"}},ce={style:{position:"relative","z-index":"1","text-align":"center","font-size":"24px","margin-bottom":"24px","font-family":"monospace",color:"white"}},ve={style:{position:"relative","z-index":"1","max-width":"400px",margin:"0 auto"}},he={class:"demo-box"},fe={style:{"margin-bottom":"24px"}},be={style:{"margin-bottom":"24px",display:"flex","flex-wrap":"wrap",gap:"16px","align-items":"center"}},ye={style:{"margin-bottom":"24px",position:"relative"}},xe={key:0,src:"https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1000&auto=format&fit=crop",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%","object-fit":"cover","border-radius":"8px","z-index":"0",opacity:"0.8"}},ke={style:{position:"relative","z-index":"1","min-height":"48px",border:"1px solid #ccc","border-radius":"6px",padding:"12px","font-size":"24px",background:"#fff",color:"#000","margin-bottom":"16px","font-family":"'Suwannaphum', 'Hanuman', sans-serif"}},Pe={style:{position:"relative","z-index":"1"}},Ce={style:{"margin-bottom":"24px",display:"flex","flex-wrap":"wrap",gap:"16px","align-items":"center"}},Ve={style:{"margin-bottom":"24px",position:"relative"}},Ke={key:0,src:"https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1000&auto=format&fit=crop",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%","object-fit":"cover","border-radius":"8px","z-index":"0",opacity:"0.8"}},Ee={style:{position:"relative","z-index":"1","min-height":"48px",border:"1px solid #ccc","border-radius":"6px",padding:"12px","font-size":"24px",background:"#fff",color:"#000","margin-bottom":"16px"}},je={style:{position:"relative","z-index":"1"}},ze={class:"demo-box"},De={style:{"margin-bottom":"24px"}},Te={style:{"text-align":"center","font-size":"24px","margin-bottom":"24px","font-family":"monospace"}},Se={class:"demo-box"},Be={style:{"margin-bottom":"24px"}},we={style:{"text-align":"right","font-size":"24px","margin-bottom":"24px","font-family":"monospace",border:"1px solid #ccc",padding:"12px","border-radius":"6px"}},Ie={class:"demo-box"},Me={style:{"margin-bottom":"24px"}},Le={style:{"text-align":"center","font-size":"32px","margin-bottom":"24px","min-height":"48px"}},Ge=ee({__name:"KeypadsSection",setup(Ae){const c=a(""),z=a(!1),b=a("default"),y=a(""),r=M(()=>z.value?"light":"dark"),L=l=>{l==="backspace"?c.value=c.value.slice(0,-1):c.value.length<10&&(c.value+=l)},G=l=>console.log("Secure Input:",l),A=()=>console.log("Secure Delete"),v=a(""),D=a(!1),x=a("default"),k=a(""),u=M(()=>D.value?"light":"dark"),F=l=>{v.value+=l},N=()=>{v.value=v.value.slice(0,-1)},U=()=>{v.value+=`
`},q=()=>{alert("Emoji button clicked!")},h=a(""),T=a(!1),P=a("default"),C=a(""),m=M(()=>T.value?"light":"dark"),O=l=>{h.value+=l},$=()=>{h.value=h.value.slice(0,-1)},Y=()=>{h.value+=`
`},H=()=>{alert("Emoji button clicked!")},f=a(""),Q=l=>{l==="backspace"?f.value=f.value.slice(0,-1):f.value+=l},R=()=>alert(`Calling ${f.value}...`),V=a(""),W=l=>V.value+=l,J=()=>V.value=V.value.slice(0,-1),K=a(""),X=l=>K.value+=l,Z=()=>{K.value=K.value.slice(0,-2)},_=()=>alert("Back button clicked (return to text keyboard)!");return(l,o)=>(E(),j(oe,null,[e("div",pe,[o[31]||(o[31]=e("h2",null,"Keypads & Security",-1)),o[32]||(o[32]=e("p",null,"Secure input methods for PINs and amounts.",-1)),o[33]||(o[33]=e("h3",null,"Standard Keypad",-1)),e("div",{class:"demo-box",style:i({backgroundColor:r.value==="light"?"#f5f7f9":"#000000",borderColor:r.value==="light"?"#e5e7eb":"#333"})},[e("div",ue,[e("label",{style:i({color:r.value==="light"?"#000":"#fff"})},[n(e("input",{type:"checkbox","onUpdate:modelValue":o[0]||(o[0]=t=>z.value=t)},null,512),[[S,z.value]]),o[12]||(o[12]=s(" Light Theme ",-1))],4),e("label",{style:i({color:r.value==="light"?"#000":"#fff"})},[o[14]||(o[14]=s(" Variant: ",-1)),n(e("select",{"onUpdate:modelValue":o[1]||(o[1]=t=>b.value=t),style:{"margin-left":"4px",padding:"4px","border-radius":"4px"}},[...o[13]||(o[13]=[e("option",{value:"default"},"Default",-1),e("option",{value:"flat"},"Flat",-1),e("option",{value:"glass"},"Glass",-1)])],512),[[B,b.value]])],4),e("label",{style:i({color:r.value==="light"?"#000":"#fff"})},[o[15]||(o[15]=s(" BG Color: ",-1)),n(e("input",{type:"color","onUpdate:modelValue":o[2]||(o[2]=t=>y.value=t),style:{"margin-left":"4px","vertical-align":"middle"}},null,512),[[w,y.value]]),e("button",{onClick:o[3]||(o[3]=t=>y.value=""),style:{"margin-left":"4px",padding:"2px 6px","font-size":"12px","border-radius":"4px"}},"Clear")],4)]),e("div",me,[b.value==="glass"?(E(),j("img",ge)):I("",!0),e("div",ce,[e("div",{style:i({color:r.value==="light"?"#000":"#fff"})},g(c.value||"Enter Amount"),5)]),e("div",ve,[d(p(te),{theme:r.value,variant:b.value,backgroundColor:y.value,onPress:L},null,8,["theme","variant","backgroundColor"])])]),o[16]||(o[16]=e("pre",{class:"code-block",style:{margin:"0",position:"relative","z-index":"1"}},[e("code",null,'<PPKeypad theme="{{ keypadTheme }}" variant="{{ keypadVariant }}" backgroundColor="{{ keypadBgColor }}" @press="onPress" />')],-1))],4),o[34]||(o[34]=e("h3",null,"Secure Keyboard",-1)),o[35]||(o[35]=e("p",null,"A randomized keyboard layout to prevent keylogging/screen tracking.",-1)),e("div",he,[e("div",fe,[d(p(le),{onInput:G,onDelete:A})]),o[17]||(o[17]=e("pre",{class:"code-block",style:{margin:"0"}},[e("code",null,'<PPSecureKeyboard @input="onInput" @delete="onDelete" />')],-1))]),o[36]||(o[36]=e("h3",null,"Khmer Keyboard",-1)),o[37]||(o[37]=e("p",null,"A full-featured virtual keyboard for the Khmer language.",-1)),e("div",{class:"demo-box",style:i({backgroundColor:m.value==="light"?"#f5f7f9":"#000000",borderColor:m.value==="light"?"#e5e7eb":"#333"})},[e("div",be,[e("label",{style:i({color:m.value==="light"?"#000":"#fff"})},[n(e("input",{type:"checkbox","onUpdate:modelValue":o[4]||(o[4]=t=>T.value=t)},null,512),[[S,T.value]]),o[18]||(o[18]=s(" Light Theme ",-1))],4),e("label",{style:i({color:m.value==="light"?"#000":"#fff"})},[o[20]||(o[20]=s(" Variant: ",-1)),n(e("select",{"onUpdate:modelValue":o[5]||(o[5]=t=>P.value=t),style:{"margin-left":"4px",padding:"4px","border-radius":"4px"}},[...o[19]||(o[19]=[e("option",{value:"default"},"Default",-1),e("option",{value:"flat"},"Flat",-1),e("option",{value:"glass"},"Glass",-1)])],512),[[B,P.value]])],4),e("label",{style:i({color:m.value==="light"?"#000":"#fff"})},[o[21]||(o[21]=s(" BG Color: ",-1)),n(e("input",{type:"color","onUpdate:modelValue":o[6]||(o[6]=t=>C.value=t),style:{"margin-left":"4px","vertical-align":"middle"}},null,512),[[w,C.value]]),e("button",{onClick:o[7]||(o[7]=t=>C.value=""),style:{"margin-left":"4px",padding:"2px 6px","font-size":"12px","border-radius":"4px"}},"Clear")],4)]),e("div",ye,[P.value==="glass"?(E(),j("img",xe)):I("",!0),e("div",ke,g(h.value||"..."),1),e("div",Pe,[d(p(ae),{theme:m.value,variant:P.value,backgroundColor:C.value,onInput:O,onDelete:$,onEnter:Y,onEmoji:H},null,8,["theme","variant","backgroundColor"])])]),o[22]||(o[22]=e("pre",{class:"code-block",style:{margin:"0",position:"relative","z-index":"1"}},[e("code",null,'<PPKhmerKeyboard theme="{{ khmerTheme }}" variant="{{ khmerVariant }}" backgroundColor="{{ khmerBgColor }}" @input="onInput" @delete="onDelete" @enter="onEnter" @emoji="onEmoji" />')],-1))],4),o[38]||(o[38]=e("h3",null,"English Keyboard",-1)),o[39]||(o[39]=e("p",null,"A standard QWERTY English keyboard layout.",-1)),e("div",{class:"demo-box",style:i({backgroundColor:u.value==="light"?"#f5f7f9":"#000000",borderColor:u.value==="light"?"#e5e7eb":"#333"})},[e("div",Ce,[e("label",{style:i({color:u.value==="light"?"#000":"#fff"})},[n(e("input",{type:"checkbox","onUpdate:modelValue":o[8]||(o[8]=t=>D.value=t)},null,512),[[S,D.value]]),o[23]||(o[23]=s(" Light Theme ",-1))],4),e("label",{style:i({color:u.value==="light"?"#000":"#fff"})},[o[25]||(o[25]=s(" Variant: ",-1)),n(e("select",{"onUpdate:modelValue":o[9]||(o[9]=t=>x.value=t),style:{"margin-left":"4px",padding:"4px","border-radius":"4px"}},[...o[24]||(o[24]=[e("option",{value:"default"},"Default",-1),e("option",{value:"flat"},"Flat",-1),e("option",{value:"glass"},"Glass",-1)])],512),[[B,x.value]])],4),e("label",{style:i({color:u.value==="light"?"#000":"#fff"})},[o[26]||(o[26]=s(" BG Color: ",-1)),n(e("input",{type:"color","onUpdate:modelValue":o[10]||(o[10]=t=>k.value=t),style:{"margin-left":"4px","vertical-align":"middle"}},null,512),[[w,k.value]]),e("button",{onClick:o[11]||(o[11]=t=>k.value=""),style:{"margin-left":"4px",padding:"2px 6px","font-size":"12px","border-radius":"4px"}},"Clear")],4)]),e("div",Ve,[x.value==="glass"?(E(),j("img",Ke)):I("",!0),e("div",Ee,g(v.value||"..."),1),e("div",je,[d(p(ie),{theme:u.value,variant:x.value,backgroundColor:k.value,onInput:F,onDelete:N,onEnter:U,onEmoji:q},null,8,["theme","variant","backgroundColor"])])]),o[27]||(o[27]=e("pre",{class:"code-block",style:{margin:"0",position:"relative","z-index":"1"}},[e("code",null,'<PPEnglishKeyboard theme="{{ englishTheme }}" variant="{{ englishVariant }}" backgroundColor="{{ englishBgColor }}" @input="onInput" @delete="onDelete" @enter="onEnter" @emoji="onEmoji" />')],-1))],4),o[40]||(o[40]=e("h3",null,"Phone Keyboard",-1)),e("div",ze,[e("div",De,[e("div",Te,g(f.value||"Enter Number"),1),d(p(ne),{onPress:Q,onCall:R})]),o[28]||(o[28]=e("pre",{class:"code-block",style:{margin:"0"}},[e("code",null,'<PPPhoneKeyboard @press="onPress" @call="onCall" />')],-1))]),o[41]||(o[41]=e("h3",null,"Math Keyboard",-1)),e("div",Se,[e("div",Be,[e("div",we,g(V.value||"0"),1),d(p(se),{onInput:W,onDelete:J})]),o[29]||(o[29]=e("pre",{class:"code-block",style:{margin:"0"}},[e("code",null,'<PPMathKeyboard @input="onInput" @delete="onDelete" />')],-1))]),o[42]||(o[42]=e("h3",null,"Emoji Keyboard",-1)),e("div",Ie,[e("div",Me,[e("div",Le,g(K.value),1),d(p(re),{onInput:X,onDelete:Z,onBack:_})]),o[30]||(o[30]=e("pre",{class:"code-block",style:{margin:"0"}},[e("code",null,'<PPEmojiKeyboard @input="onInput" @delete="onDelete" @back="onBack" />')],-1))]),o[43]||(o[43]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-keypad-bg: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[44]||(o[44]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Keypads & Security</h2>
    <p>Secure input methods for PINs and amounts.</p>

    <h3>Standard Keypad</h3>
    <div class="demo-box" :style="{ backgroundColor: keypadTheme === 'light' ? '#f5f7f9' : '#000000', borderColor: keypadTheme === 'light' ? '#e5e7eb' : '#333' }">
      <div style="margin-bottom: 24px; display: flex; flex-wrap: wrap; gap: 16px; align-items: center;">
        <label :style="{ color: keypadTheme === 'light' ? '#000' : '#fff' }">
          <input type="checkbox" v-model="isKeypadLightMode" /> Light Theme
        </label>
        
        <label :style="{ color: keypadTheme === 'light' ? '#000' : '#fff' }">
          Variant:
          <select v-model="keypadVariant" style="margin-left: 4px; padding: 4px; border-radius: 4px;">
            <option value="default">Default</option>
            <option value="flat">Flat</option>
            <option value="glass">Glass</option>
          </select>
        </label>

        <label :style="{ color: keypadTheme === 'light' ? '#000' : '#fff' }">
          BG Color:
          <input type="color" v-model="keypadBgColor" style="margin-left: 4px; vertical-align: middle;" />
          <button @click="keypadBgColor = ''" style="margin-left: 4px; padding: 2px 6px; font-size: 12px; border-radius: 4px;">Clear</button>
        </label>
      </div>
      <div style="margin-bottom: 24px; position: relative;">
        <!-- Demo background image just to show off glass effect -->
        <img v-if="keypadVariant === 'glass'" src="https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1000&auto=format&fit=crop" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; border-radius: 8px; z-index: 0; opacity: 0.8;" />
        
        <div style="position: relative; z-index: 1; text-align: center; font-size: 24px; margin-bottom: 24px; font-family: monospace; color: white;">
          <div :style="{ color: keypadTheme === 'light' ? '#000' : '#fff' }">{{ keypadValue || 'Enter Amount' }}</div>
        </div>
        <div style="position: relative; z-index: 1; max-width: 400px; margin: 0 auto;">
          <PPKeypad 
            :theme="keypadTheme" 
            :variant="keypadVariant"
            :backgroundColor="keypadBgColor"
            @press="onKeypadPress" 
          />
        </div>
      </div>
      <pre class="code-block" style="margin: 0; position: relative; z-index: 1;"><code>&lt;PPKeypad theme="{{ keypadTheme }}" variant="{{ keypadVariant }}" backgroundColor="{{ keypadBgColor }}" @press="onPress" /&gt;</code></pre>
    </div>

    <h3>Secure Keyboard</h3>
    <p>A randomized keyboard layout to prevent keylogging/screen tracking.</p>
    <div class="demo-box">
      <div style="margin-bottom: 24px;">
        <PPSecureKeyboard @input="onSecureInput" @delete="onSecureDelete" />
      </div>
      <pre class="code-block" style="margin: 0;"><code>&lt;PPSecureKeyboard @input="onInput" @delete="onDelete" /&gt;</code></pre>
    </div>

    <h3>Khmer Keyboard</h3>
    <p>A full-featured virtual keyboard for the Khmer language.</p>
    <div class="demo-box" :style="{ backgroundColor: khmerTheme === 'light' ? '#f5f7f9' : '#000000', borderColor: khmerTheme === 'light' ? '#e5e7eb' : '#333' }">
      <div style="margin-bottom: 24px; display: flex; flex-wrap: wrap; gap: 16px; align-items: center;">
        <label :style="{ color: khmerTheme === 'light' ? '#000' : '#fff' }">
          <input type="checkbox" v-model="isKhmerLightMode" /> Light Theme
        </label>
        
        <label :style="{ color: khmerTheme === 'light' ? '#000' : '#fff' }">
          Variant:
          <select v-model="khmerVariant" style="margin-left: 4px; padding: 4px; border-radius: 4px;">
            <option value="default">Default</option>
            <option value="flat">Flat</option>
            <option value="glass">Glass</option>
          </select>
        </label>

        <label :style="{ color: khmerTheme === 'light' ? '#000' : '#fff' }">
          BG Color:
          <input type="color" v-model="khmerBgColor" style="margin-left: 4px; vertical-align: middle;" />
          <button @click="khmerBgColor = ''" style="margin-left: 4px; padding: 2px 6px; font-size: 12px; border-radius: 4px;">Clear</button>
        </label>
      </div>
      <div style="margin-bottom: 24px; position: relative;">
        <!-- Demo background image just to show off glass effect -->
        <img v-if="khmerVariant === 'glass'" src="https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1000&auto=format&fit=crop" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; border-radius: 8px; z-index: 0; opacity: 0.8;" />
        
        <div style="position: relative; z-index: 1; min-height: 48px; border: 1px solid #ccc; border-radius: 6px; padding: 12px; font-size: 24px; background: #fff; color: #000; margin-bottom: 16px; font-family: 'Suwannaphum', 'Hanuman', sans-serif;">
          {{ khmerValue || '...' }}
        </div>
        
        <div style="position: relative; z-index: 1;">
          <PPKhmerKeyboard 
            :theme="khmerTheme" 
            :variant="khmerVariant"
            :backgroundColor="khmerBgColor"
            @input="onKhmerInput" 
            @delete="onKhmerDelete" 
            @enter="onKhmerEnter" 
            @emoji="onKhmerEmoji"
          />
        </div>
      </div>
      <pre class="code-block" style="margin: 0; position: relative; z-index: 1;"><code>&lt;PPKhmerKeyboard theme="{{ khmerTheme }}" variant="{{ khmerVariant }}" backgroundColor="{{ khmerBgColor }}" @input="onInput" @delete="onDelete" @enter="onEnter" @emoji="onEmoji" /&gt;</code></pre>
    </div>

    <h3>English Keyboard</h3>
    <p>A standard QWERTY English keyboard layout.</p>
    <div class="demo-box" :style="{ backgroundColor: englishTheme === 'light' ? '#f5f7f9' : '#000000', borderColor: englishTheme === 'light' ? '#e5e7eb' : '#333' }">
      <div style="margin-bottom: 24px; display: flex; flex-wrap: wrap; gap: 16px; align-items: center;">
        <label :style="{ color: englishTheme === 'light' ? '#000' : '#fff' }">
          <input type="checkbox" v-model="isEnglishLightMode" /> Light Theme
        </label>
        
        <label :style="{ color: englishTheme === 'light' ? '#000' : '#fff' }">
          Variant:
          <select v-model="englishVariant" style="margin-left: 4px; padding: 4px; border-radius: 4px;">
            <option value="default">Default</option>
            <option value="flat">Flat</option>
            <option value="glass">Glass</option>
          </select>
        </label>

        <label :style="{ color: englishTheme === 'light' ? '#000' : '#fff' }">
          BG Color:
          <input type="color" v-model="englishBgColor" style="margin-left: 4px; vertical-align: middle;" />
          <button @click="englishBgColor = ''" style="margin-left: 4px; padding: 2px 6px; font-size: 12px; border-radius: 4px;">Clear</button>
        </label>
      </div>
      <div style="margin-bottom: 24px; position: relative;">
        <!-- Demo background image just to show off glass effect -->
        <img v-if="englishVariant === 'glass'" src="https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1000&auto=format&fit=crop" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; border-radius: 8px; z-index: 0; opacity: 0.8;" />
        
        <div style="position: relative; z-index: 1; min-height: 48px; border: 1px solid #ccc; border-radius: 6px; padding: 12px; font-size: 24px; background: #fff; color: #000; margin-bottom: 16px;">
          {{ englishValue || '...' }}
        </div>
        
        <div style="position: relative; z-index: 1;">
          <PPEnglishKeyboard 
            :theme="englishTheme" 
            :variant="englishVariant"
            :backgroundColor="englishBgColor"
            @input="onEnglishInput" 
            @delete="onEnglishDelete" 
            @enter="onEnglishEnter" 
            @emoji="onEnglishEmoji"
          />
        </div>
      </div>
      <pre class="code-block" style="margin: 0; position: relative; z-index: 1;"><code>&lt;PPEnglishKeyboard theme="{{ englishTheme }}" variant="{{ englishVariant }}" backgroundColor="{{ englishBgColor }}" @input="onInput" @delete="onDelete" @enter="onEnter" @emoji="onEmoji" /&gt;</code></pre>
    </div>

    <h3>Phone Keyboard</h3>
    <div class="demo-box">
      <div style="margin-bottom: 24px;">
        <div style="text-align: center; font-size: 24px; margin-bottom: 24px; font-family: monospace;">
          {{ phoneValue || 'Enter Number' }}
        </div>
        <PPPhoneKeyboard @press="onPhonePress" @call="onPhoneCall" />
      </div>
      <pre class="code-block" style="margin: 0;"><code>&lt;PPPhoneKeyboard @press="onPress" @call="onCall" /&gt;</code></pre>
    </div>

    <h3>Math Keyboard</h3>
    <div class="demo-box">
      <div style="margin-bottom: 24px;">
        <div style="text-align: right; font-size: 24px; margin-bottom: 24px; font-family: monospace; border: 1px solid #ccc; padding: 12px; border-radius: 6px;">
          {{ mathValue || '0' }}
        </div>
        <PPMathKeyboard @input="onMathInput" @delete="onMathDelete" />
      </div>
      <pre class="code-block" style="margin: 0;"><code>&lt;PPMathKeyboard @input="onInput" @delete="onDelete" /&gt;</code></pre>
    </div>

    <h3>Emoji Keyboard</h3>
    <div class="demo-box">
      <div style="margin-bottom: 24px;">
        <div style="text-align: center; font-size: 32px; margin-bottom: 24px; min-height: 48px;">
          {{ emojiValue }}
        </div>
        <PPEmojiKeyboard @input="onEmojiInput" @delete="onEmojiDelete" @back="onEmojiBack" />
      </div>
      <pre class="code-block" style="margin: 0;"><code>&lt;PPEmojiKeyboard @input="onInput" @delete="onDelete" @back="onBack" /&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-keypad-bg: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { PPKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPEnglishKeyboard, PPPhoneKeyboard, PPMathKeyboard, PPEmojiKeyboard } from '@phanna/ui-framework';

const keypadValue = ref('');
const isKeypadLightMode = ref(false);
const keypadVariant = ref<'default' | 'flat' | 'glass'>('default');
const keypadBgColor = ref('');
const keypadTheme = computed(() => isKeypadLightMode.value ? 'light' : 'dark');

const onKeypadPress = (val: string) => {
  if (val === 'backspace') {
    keypadValue.value = keypadValue.value.slice(0, -1);
  } else if (keypadValue.value.length < 10) {
    keypadValue.value += val;
  }
};

const onSecureInput = (val: string) => console.log('Secure Input:', val);
const onSecureDelete = () => console.log('Secure Delete');

const englishValue = ref('');
const isEnglishLightMode = ref(false);
const englishVariant = ref<'default' | 'flat' | 'glass'>('default');
const englishBgColor = ref('');
const englishTheme = computed(() => isEnglishLightMode.value ? 'light' : 'dark');

const onEnglishInput = (val: string) => {
  englishValue.value += val;
};
const onEnglishDelete = () => {
  englishValue.value = englishValue.value.slice(0, -1);
};
const onEnglishEnter = () => {
  englishValue.value += '\\n';
};
const onEnglishEmoji = () => {
  alert('Emoji button clicked!');
};

const khmerValue = ref('');
const isKhmerLightMode = ref(false);
const khmerVariant = ref<'default' | 'flat' | 'glass'>('default');
const khmerBgColor = ref('');
const khmerTheme = computed(() => isKhmerLightMode.value ? 'light' : 'dark');

const onKhmerInput = (val: string) => {
  khmerValue.value += val;
};
const onKhmerDelete = () => {
  khmerValue.value = khmerValue.value.slice(0, -1);
};
const onKhmerEnter = () => {
  khmerValue.value += '\\n';
};
const onKhmerEmoji = () => {
  alert('Emoji button clicked!');
};

const phoneValue = ref('');
const onPhonePress = (val: string) => {
  if (val === 'backspace') {
    phoneValue.value = phoneValue.value.slice(0, -1);
  } else {
    phoneValue.value += val;
  }
};
const onPhoneCall = () => alert(\`Calling \${phoneValue.value}...\`);

const mathValue = ref('');
const onMathInput = (val: string) => mathValue.value += val;
const onMathDelete = () => mathValue.value = mathValue.value.slice(0, -1);

const emojiValue = ref('');
const onEmojiInput = (val: string) => emojiValue.value += val;
const onEmojiDelete = () => {
  // Simple delete, might have issues with surrogate pairs but okay for demo
  emojiValue.value = emojiValue.value.slice(0, -2); 
};
const onEmojiBack = () => alert('Back button clicked (return to text keyboard)!');
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),qe=de(Ge,[["__scopeId","data-v-76a657a6"]]);export{qe as K};
