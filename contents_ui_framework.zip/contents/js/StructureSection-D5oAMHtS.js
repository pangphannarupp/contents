import{bo as f,bp as O,ae as A,P as r}from"./AccountCardSection-DXixqG3L.js";import{d as w,Q as m,o as T,j as V,l as t,a as n,w as l,u as a,A as i,F as I,p as s}from"../vendors/vendor-ah_eQdvw.js";const N={class:"guide-section"},F={class:"variant-group"},U={class:"component-demo",style:{background:"#f4f5f8",padding:"20px","border-radius":"12px"}},K={class:"variant-group"},M={class:"component-demo",style:{background:"#f4f5f8",padding:"20px","border-radius":"12px",height:"180px"}},D={class:"variant-group"},H={class:"component-demo",style:{background:"#f4f5f8",padding:"20px","border-radius":"12px"}},R={class:"variant-group"},Y={class:"component-demo",style:{background:"var(--pp-primary, #003399)",padding:"20px","border-radius":"12px"}},L={class:"variant-group"},E={class:"component-demo"},$={style:{padding:"16px","text-align":"center"}},G={class:"variant-group"},W={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"8px"}},q=w({__name:"StructureSection",setup(z){const S=s("opt1"),B=s([{label:"Option 1",value:"opt1"},{label:"Option 2",value:"opt2"},{label:"Option 3",value:"opt3"}]),y=s("opt1"),p=s(!1),h=s("default"),d=P=>{h.value=P,p.value=!0},u=s(!1),c=s(!1),g=s(!1),v=P=>console.log("Setup: "+P);return(P,e)=>{const k=m("PPAnimatedSegment"),x=m("PPUserProfile"),C=m("PPBottomSheet"),b=m("PPBiometricSheet");return T(),V(I,null,[t("div",N,[e[43]||(e[43]=t("h2",null,"7. Structural Components",-1)),t("div",F,[e[16]||(e[16]=t("h3",null,"PPSegment (Toggle)",-1)),t("div",U,[n(a(O),{modelValue:y.value,"onUpdate:modelValue":e[0]||(e[0]=o=>y.value=o),style:{"--pp-segment-bg":"white"}},{default:l(()=>[n(a(f),{value:"opt1"},{default:l(()=>[...e[14]||(e[14]=[i("Option 1",-1)])]),_:1}),n(a(f),{value:"opt2"},{default:l(()=>[...e[15]||(e[15]=[i("Option 2",-1)])]),_:1})]),_:1},8,["modelValue"])]),e[17]||(e[17]=t("pre",{class:"code-block"},[t("code",null,`<PPSegment v-model="val">
  <PPSegmentButton value="1">Tab 1</PPSegmentButton>
</PPSegment>`)],-1))]),t("div",K,[e[21]||(e[21]=t("h3",null,"PPAnimatedSegment",-1)),e[22]||(e[22]=t("p",{class:"custom-guide"},"Wraps PPSegment to provide smooth animated transitions between content sections.",-1)),t("div",M,[n(k,{modelValue:S.value,"onUpdate:modelValue":e[1]||(e[1]=o=>S.value=o),segments:B.value},{"segment-opt1":l(()=>[...e[18]||(e[18]=[t("div",{style:{padding:"16px",background:"white","border-radius":"8px","margin-top":"16px","box-shadow":"0 2px 8px rgba(0,0,0,0.05)"}},[t("h4",{style:{"margin-top":"0"}},"Option 1 Content"),t("p",{style:{"margin-bottom":"0"}},"This content slides in smoothly!")],-1)])]),"segment-opt2":l(()=>[...e[19]||(e[19]=[t("div",{style:{padding:"16px",background:"white","border-radius":"8px","margin-top":"16px","box-shadow":"0 2px 8px rgba(0,0,0,0.05)"}},[t("h4",{style:{"margin-top":"0"}},"Option 2 Content"),t("p",{style:{"margin-bottom":"0"}},"Here is some different content.")],-1)])]),"segment-opt3":l(()=>[...e[20]||(e[20]=[t("div",{style:{padding:"16px",background:"white","border-radius":"8px","margin-top":"16px","box-shadow":"0 2px 8px rgba(0,0,0,0.05)"}},[t("h4",{style:{"margin-top":"0"}},"Option 3 Content"),t("p",{style:{"margin-bottom":"0"}},"And even more content.")],-1)])]),_:1},8,["modelValue","segments"])]),e[23]||(e[23]=t("pre",{class:"code-block"},[t("code",null,`<PPAnimatedSegment v-model="val" :segments="segments">
  <template #segment-opt1>...</template>
</PPAnimatedSegment>`)],-1))]),t("div",D,[e[24]||(e[24]=t("h3",null,"PPCompanySelector",-1)),t("div",H,[n(a(A),{companyName:"CHOKCHEY FINANCE PLC",companyType:"Individual"})]),e[25]||(e[25]=t("pre",{class:"code-block"},[t("code",null,`<PPCompanySelector 
  companyName="CHOKCHEY" 
  companyType="Individual" 
/>`)],-1))]),t("div",R,[e[26]||(e[26]=t("h3",null,"PPUserProfile",-1)),t("div",Y,[n(x,{userName:"SOM MONYROTTANA",role:"Master User",isVerified:!0})]),e[27]||(e[27]=t("pre",{class:"code-block"},[t("code",null,`<PPUserProfile 
  userName="Name" 
  role="Master User" 
  :isVerified="true" 
/>`)],-1))]),t("div",L,[e[34]||(e[34]=t("h3",null,"PPBottomSheet (Action Menu)",-1)),e[35]||(e[35]=t("p",{class:"custom-guide",style:{"margin-bottom":"8px"}},[t("strong",null,"Props:"),i(),t("code",null,"title"),i(", "),t("code",null,"modelValue"),i(", "),t("code",null,"backdropType")],-1)),t("div",E,[n(a(r),{variant:"secondary",onClick:e[2]||(e[2]=o=>d("default")),style:{"margin-right":"8px","margin-bottom":"8px"}},{default:l(()=>[...e[28]||(e[28]=[i("Default Backdrop",-1)])]),_:1}),n(a(r),{variant:"secondary",onClick:e[3]||(e[3]=o=>d("blur")),style:{"margin-right":"8px","margin-bottom":"8px"}},{default:l(()=>[...e[29]||(e[29]=[i("Blur Backdrop",-1)])]),_:1}),n(a(r),{variant:"secondary",onClick:e[4]||(e[4]=o=>d("clear")),style:{"margin-right":"8px","margin-bottom":"8px"}},{default:l(()=>[...e[30]||(e[30]=[i("Clear Backdrop",-1)])]),_:1}),n(a(r),{variant:"secondary",onClick:e[5]||(e[5]=o=>d("black")),style:{"margin-right":"8px","margin-bottom":"8px"}},{default:l(()=>[...e[31]||(e[31]=[i("Black Backdrop",-1)])]),_:1}),n(C,{modelValue:p.value,"onUpdate:modelValue":e[7]||(e[7]=o=>p.value=o),title:"Select Action",backdropType:h.value},{default:l(()=>[t("div",$,[e[33]||(e[33]=t("p",null,"This is the content inside the bottom sheet.",-1)),n(a(r),{variant:"primary",block:"",onClick:e[6]||(e[6]=o=>p.value=!1)},{default:l(()=>[...e[32]||(e[32]=[i("Close",-1)])]),_:1})])]),_:1},8,["modelValue","backdropType"])]),e[36]||(e[36]=t("pre",{class:"code-block"},[t("code",null,'<PPBottomSheet v-model="isOpen" backdropType="blur" title="Select Action">...</PPBottomSheet>')],-1))]),t("div",G,[e[40]||(e[40]=t("h3",null,"PPBiometricSheet",-1)),e[41]||(e[41]=t("p",{class:"custom-guide",style:{"margin-bottom":"8px"}},[t("strong",null,"Props:"),i(),t("code",null,"type"),i(" ('both', 'face', 'fingerprint')")],-1)),t("div",W,[n(a(r),{variant:"outline",onClick:e[8]||(e[8]=o=>u.value=!0)},{default:l(()=>[...e[37]||(e[37]=[i("Open Biometric (Both)",-1)])]),_:1}),n(a(r),{variant:"outline",onClick:e[9]||(e[9]=o=>c.value=!0)},{default:l(()=>[...e[38]||(e[38]=[i("Open Biometric (Face ID)",-1)])]),_:1}),n(a(r),{variant:"outline",onClick:e[10]||(e[10]=o=>g.value=!0)},{default:l(()=>[...e[39]||(e[39]=[i("Open Biometric (Fingerprint ID)",-1)])]),_:1}),n(b,{modelValue:u.value,"onUpdate:modelValue":e[11]||(e[11]=o=>u.value=o),type:"both",onSetup:v},null,8,["modelValue"]),n(b,{modelValue:c.value,"onUpdate:modelValue":e[12]||(e[12]=o=>c.value=o),type:"face",onSetup:v},null,8,["modelValue"]),n(b,{modelValue:g.value,"onUpdate:modelValue":e[13]||(e[13]=o=>g.value=o),type:"fingerprint",onSetup:v},null,8,["modelValue"])]),e[42]||(e[42]=t("pre",{class:"code-block"},[t("code",null,`<PPBiometricSheet 
  v-model="isOpen" 
  type="both" 
  @setup="handleSetup" 
/>`)],-1))]),e[44]||(e[44]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[45]||(e[45]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>7. Structural Components</h2>

        <div class="variant-group">
          <h3>PPSegment (Toggle)</h3>
          <div class="component-demo" style="background: #f4f5f8; padding: 20px; border-radius: 12px;">
            <PPSegment v-model="segmentVal" style="--pp-segment-bg: white;">
              <PPSegmentButton value="opt1">Option 1</PPSegmentButton>
              <PPSegmentButton value="opt2">Option 2</PPSegmentButton>
            </PPSegment>
          </div>
          <pre class="code-block"><code>&lt;PPSegment v-model="val"&gt;
  &lt;PPSegmentButton value="1"&gt;Tab 1&lt;/PPSegmentButton&gt;
&lt;/PPSegment&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPAnimatedSegment</h3>
          <p class="custom-guide">Wraps PPSegment to provide smooth animated transitions between content sections.</p>
          <div class="component-demo" style="background: #f4f5f8; padding: 20px; border-radius: 12px; height: 180px;">
            <PPAnimatedSegment v-model="animatedSegmentVal" :segments="animatedSegments">
              <template #segment-opt1>
                <div style="padding: 16px; background: white; border-radius: 8px; margin-top: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                  <h4 style="margin-top:0;">Option 1 Content</h4>
                  <p style="margin-bottom:0;">This content slides in smoothly!</p>
                </div>
              </template>
              <template #segment-opt2>
                <div style="padding: 16px; background: white; border-radius: 8px; margin-top: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                  <h4 style="margin-top:0;">Option 2 Content</h4>
                  <p style="margin-bottom:0;">Here is some different content.</p>
                </div>
              </template>
              <template #segment-opt3>
                <div style="padding: 16px; background: white; border-radius: 8px; margin-top: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                  <h4 style="margin-top:0;">Option 3 Content</h4>
                  <p style="margin-bottom:0;">And even more content.</p>
                </div>
              </template>
            </PPAnimatedSegment>
          </div>
          <pre class="code-block"><code>&lt;PPAnimatedSegment v-model="val" :segments="segments"&gt;
  &lt;template #segment-opt1&gt;...&lt;/template&gt;
&lt;/PPAnimatedSegment&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPCompanySelector</h3>
          <div class="component-demo" style="background: #f4f5f8; padding: 20px; border-radius: 12px;">
            <PPCompanySelector companyName="CHOKCHEY FINANCE PLC" companyType="Individual" />
          </div>
          <pre class="code-block"><code>&lt;PPCompanySelector 
  companyName="CHOKCHEY" 
  companyType="Individual" 
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPUserProfile</h3>
          <div class="component-demo" style="background: var(--pp-primary, #003399); padding: 20px; border-radius: 12px;">
            <PPUserProfile userName="SOM MONYROTTANA" role="Master User" :isVerified="true" />
          </div>
          <pre class="code-block"><code>&lt;PPUserProfile 
  userName="Name" 
  role="Master User" 
  :isVerified="true" 
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPBottomSheet (Action Menu)</h3>
          <p class="custom-guide" style="margin-bottom: 8px;"><strong>Props:</strong> <code>title</code>, <code>modelValue</code>, <code>backdropType</code></p>
          <div class="component-demo">
            <PPButton variant="secondary" @click="openSheet('default')" style="margin-right: 8px; margin-bottom: 8px;">Default Backdrop</PPButton>
            <PPButton variant="secondary" @click="openSheet('blur')" style="margin-right: 8px; margin-bottom: 8px;">Blur Backdrop</PPButton>
            <PPButton variant="secondary" @click="openSheet('clear')" style="margin-right: 8px; margin-bottom: 8px;">Clear Backdrop</PPButton>
            <PPButton variant="secondary" @click="openSheet('black')" style="margin-right: 8px; margin-bottom: 8px;">Black Backdrop</PPButton>
            
            <!-- We render the sheet locally for the demo -->
            <PPBottomSheet v-model="showBottomSheet" title="Select Action" :backdropType="currentBackdrop">
              <div style="padding: 16px; text-align: center;">
                <p>This is the content inside the bottom sheet.</p>
                <PPButton variant="primary" block @click="showBottomSheet = false">Close</PPButton>
              </div>
            </PPBottomSheet>
          </div>
          <pre class="code-block"><code>&lt;PPBottomSheet v-model="isOpen" backdropType="blur" title="Select Action"&gt;...&lt;/PPBottomSheet&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPBiometricSheet</h3>
          <p class="custom-guide" style="margin-bottom: 8px;"><strong>Props:</strong> <code>type</code> ('both', 'face', 'fingerprint')</p>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 8px;">
            <PPButton variant="outline" @click="showBioBoth = true">Open Biometric (Both)</PPButton>
            <PPButton variant="outline" @click="showBioFace = true">Open Biometric (Face ID)</PPButton>
            <PPButton variant="outline" @click="showBioFinger = true">Open Biometric (Fingerprint ID)</PPButton>
            
            <PPBiometricSheet v-model="showBioBoth" type="both" @setup="alertVal" />
            <PPBiometricSheet v-model="showBioFace" type="face" @setup="alertVal" />
            <PPBiometricSheet v-model="showBioFinger" type="fingerprint" @setup="alertVal" />
          </div>
          <pre class="code-block"><code>&lt;PPBiometricSheet 
  v-model="isOpen" 
  type="both" 
  @setup="handleSetup" 
/&gt;</code></pre>
        </div>


      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const animatedSegmentVal = ref('opt1');

const animatedSegments = ref([
  { label: 'Option 1', value: 'opt1' },
  { label: 'Option 2', value: 'opt2' },
  { label: 'Option 3', value: 'opt3' }
]);

const segmentVal = ref('opt1');

const showBottomSheet = ref(false);
const currentBackdrop = ref('default');

const openSheet = (type: string) => {
  currentBackdrop.value = type;
  showBottomSheet.value = true;
};

const showBioBoth = ref(false);

const showBioFace = ref(false);

const showBioFinger = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64)}}});export{q as _};
