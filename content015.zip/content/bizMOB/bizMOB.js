/**
 * bizMOB client interface
 *
 * @class	bizMOB
 * @version 4.0.0
 * @author	mobile C&C
 */
var bizMOB = new Object();

bizMOB.servicename = "bizMOB";

bizMOB.FStorage = {};

/**
 * Config Set
 */
bizMOB.setConfig = function (sClassName, oParam) {
    bizMOB[sClassName].config = Object.assign({}, window.bizMOBCore[sClassName].config, oParam);
};

/**
 * Config Get
 */
bizMOB.getConfig = function (sClassName) {
    return bizMOB[sClassName].config;
};

/**
 * Core Gateway
 *
 * @param {String} sClassName
 * @param {String} sMethod
 * @param {Array} aRequired
 * @param {Object} oParam
 */
bizMOB.gateway = function (sClassName, sMethod, oParam, aRequired) {
    if (bizMOB.Module.checkParam(oParam, aRequired)) {
        try {
            return bizMOB[sClassName][sMethod](oParam);
        } catch (error) {
            var call = oParam._fCallback || oParam.callback || null;
            bizMOB.gateway("Module", "logger", { _sService: sClassName, _sAction: sMethod, _sLogType: "W", _sMessage: "This feature is not supported on web mode. - " + sClassName + "." + sMethod });
            if (call && typeof call === "function") {
                call();
            }
        }
    } else {
        return false;
    }
};

bizMOB.Device = new Object();
bizMOB.Device.Info = {};

bizMOB.Localization = new Object();

bizMOB.Localization.localeInfo = {
    en: "en-US", // United State
    ja: "ja-JP", // Japen
    ko: "ko-KR", // Korea
    zh: "zh-CN", // China
    km: "km-KH" // Cambodia
};

// Script ready
(function () {
    var $bizMOB = window.bizMOBCore.DeviceManager.isApp() ? window.bizMOBCore : window.bizMOBWebCore;
    bizMOB = { ...bizMOB, ...$bizMOB };
    bizMOB.gateway("Module", "logger", { _sService: "bizMOB", _sAction: "ready", _sLogType: "I", _sMessage: "bizMOB"+" script is ready." });
})();
