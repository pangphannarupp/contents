import{b6 as l,b7 as a,b8 as r}from"./AccountCardSection-DXixqG3L.js";import{d,o as c,j as u,l as t,a as o,w as n,u as s,A as i,F as m}from"../vendors/vendor-ah_eQdvw.js";const p={class:"guide-section"},g={class:"variant-group"},S={class:"component-demo",style:{background:"#f4f5f8",padding:"20px","border-radius":"12px","max-width":"400px"}},P={class:"variant-group"},v={class:"component-demo",style:{background:"#f4f5f8",padding:"20px","border-radius":"12px"}},f={style:{background:"white","border-radius":"12px",overflow:"hidden","box-shadow":"0 4px 12px rgba(0,0,0,0.05)","max-width":"400px"}},w=d({__name:"NotificationsSection",setup(h){return(y,e)=>(c(),u(m,null,[t("div",p,[e[10]||(e[10]=t("h2",null,"Notifications & Scrolling",-1)),t("div",g,[e[5]||(e[5]=t("h3",null,"PPScrollSegment",-1)),t("div",S,[o(s(a),null,{default:n(()=>[o(s(l),{isActive:!0},{default:n(()=>[...e[0]||(e[0]=[i("All (20)",-1)])]),_:1}),o(s(l),null,{default:n(()=>[...e[1]||(e[1]=[i("Unread (5)",-1)])]),_:1}),o(s(l),null,{default:n(()=>[...e[2]||(e[2]=[i("Payments (2)",-1)])]),_:1}),o(s(l),null,{default:n(()=>[...e[3]||(e[3]=[i("Announcements (13)",-1)])]),_:1}),o(s(l),null,{default:n(()=>[...e[4]||(e[4]=[i("Security (0)",-1)])]),_:1})]),_:1})]),e[6]||(e[6]=t("pre",{class:"code-block"},[t("code",null,`<PPScrollSegment>
  <PPScrollSegmentButton :isActive="true">All (20)</PPScrollSegmentButton>
  <PPScrollSegmentButton>Unread (5)</PPScrollSegmentButton>
</PPScrollSegment>`)],-1))]),t("div",P,[e[9]||(e[9]=t("h3",null,"PPNotificationItem",-1)),t("div",v,[t("div",f,[o(s(r),{title:"The Bank",description:"Set up fast payments now, easy transfer, and payment anytime, anywhere. Scan KHQR...",timestamp:"29 SEP, 2026 7:41:42 PM",unread:!0},{icon:n(()=>[...e[7]||(e[7]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2"},[t("path",{d:"M11 5L6 9H2v6h4l5 4V5z"}),t("path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"})],-1)])]),_:1}),o(s(r),{title:"Account",description:"242.50 USD is deposited into 00100 001 0005517.",timestamp:"02 SEP, 2026 8:12:12 AM"},{icon:n(()=>[...e[8]||(e[8]=[t("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2"},[t("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"}),t("path",{d:"M12 12h.01"}),t("path",{d:"M16 12h.01"}),t("path",{d:"M8 12h.01"})],-1)])]),_:1})])])]),e[11]||(e[11]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[12]||(e[12]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>Notifications & Scrolling</h2>

        <div class="variant-group">
          <h3>PPScrollSegment</h3>
          <div class="component-demo" style="background: #f4f5f8; padding: 20px; border-radius: 12px; max-width: 400px;">
            <PPScrollSegment>
              <PPScrollSegmentButton :isActive="true">All (20)</PPScrollSegmentButton>
              <PPScrollSegmentButton>Unread (5)</PPScrollSegmentButton>
              <PPScrollSegmentButton>Payments (2)</PPScrollSegmentButton>
              <PPScrollSegmentButton>Announcements (13)</PPScrollSegmentButton>
              <PPScrollSegmentButton>Security (0)</PPScrollSegmentButton>
            </PPScrollSegment>
          </div>
          <pre class="code-block"><code>&lt;PPScrollSegment&gt;
  &lt;PPScrollSegmentButton :isActive="true"&gt;All (20)&lt;/PPScrollSegmentButton&gt;
  &lt;PPScrollSegmentButton&gt;Unread (5)&lt;/PPScrollSegmentButton&gt;
&lt;/PPScrollSegment&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPNotificationItem</h3>
          <div class="component-demo" style="background: #f4f5f8; padding: 20px; border-radius: 12px;">
            <div style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05); max-width: 400px;">
              <PPNotificationItem 
                title="The Bank" 
                description="Set up fast payments now, easy transfer, and payment anytime, anywhere. Scan KHQR..." 
                timestamp="29 SEP, 2026 7:41:42 PM" 
                :unread="true"
              >
                <template #icon>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
                </template>
              </PPNotificationItem>

              <PPNotificationItem 
                title="Account" 
                description="242.50 USD is deposited into 00100 001 0005517." 
                timestamp="02 SEP, 2026 8:12:12 AM"
              >
                <template #icon>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M12 12h.01"/><path d="M16 12h.01"/><path d="M8 12h.01"/></svg>
                </template>
              </PPNotificationItem>
            </div>
          </div>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPScrollSegment, PPScrollSegmentButton, PPNotificationItem } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{w as _};
