import{be as P}from"./AccountCardSection-DXixqG3L.js";import{d as c,o as n,j as i,l as e,a as d,w as u,F as l,z as p,y as m,u as h}from"../vendors/vendor-ah_eQdvw.js";const g={class:"guide-section"},v={class:"variant-group"},f={class:"component-demo",style:{height:"300px",padding:"0","border-radius":"12px",overflow:"hidden",position:"relative",border:"1px solid #ddd"}},b={style:{padding:"16px"}},k=c({__name:"PullRefreshSection",setup(C){const s=o=>alert(o),a=o=>{setTimeout(()=>{s("Refresh Complete!"),o()},1500)};return(o,t)=>(n(),i(l,null,[e("div",g,[t[3]||(t[3]=e("h2",null,"Pull to Refresh",-1)),e("div",v,[t[0]||(t[0]=e("h3",null,"Interactive Refresher",-1)),t[1]||(t[1]=e("p",{class:"custom-guide"},"Drag the list down inside this container to trigger a refresh!",-1)),e("div",f,[d(h(P),{onRefresh:a},{default:u(()=>[e("div",b,[(n(),i(l,null,p(15,r=>e("div",{key:r,style:{padding:"16px","border-bottom":"1px solid #eee",background:"white"}}," Item "+m(r)+" in the scrollable list ",1)),64))])]),_:1})]),t[2]||(t[2]=e("pre",{class:"code-block"},[e("code",null,`<PPPullToRefresh @refresh="handleRefresh">
  <div class="content">
    <!-- Your scrollable content here -->
    <div v-for="i in 15" :key="i">Item {{ i }}</div>
  </div>
</PPPullToRefresh>

<script setup>
const handleRefresh = (complete) => {
  // Perform async refresh action
  setTimeout(() => {
    complete(); // Call complete() when finished
  }, 1500);
};
<\/script>`)],-1))]),t[4]||(t[4]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[5]||(t[5]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Pull to Refresh</h2>
        <div class="variant-group">
          <h3>Interactive Refresher</h3>
          <p class="custom-guide">Drag the list down inside this container to trigger a refresh!</p>
          <div class="component-demo" style="height: 300px; padding: 0; border-radius: 12px; overflow: hidden; position: relative; border: 1px solid #ddd;">
            <PPPullToRefresh @refresh="handleRefresh">
              <div style="padding: 16px;">
                <div v-for="i in 15" :key="i" style="padding: 16px; border-bottom: 1px solid #eee; background: white;">
                  Item {{ i }} in the scrollable list
                </div>
              </div>
            </PPPullToRefresh>
          </div>
          <pre v-pre class="code-block"><code>&lt;PPPullToRefresh @refresh="handleRefresh"&gt;
  &lt;div class="content"&gt;
    &lt;!-- Your scrollable content here --&gt;
    &lt;div v-for="i in 15" :key="i"&gt;Item {{ i }}&lt;/div&gt;
  &lt;/div&gt;
&lt;/PPPullToRefresh&gt;

&lt;script setup&gt;
const handleRefresh = (complete) =&gt; {
  // Perform async refresh action
  setTimeout(() =&gt; {
    complete(); // Call complete() when finished
  }, 1500);
};
&lt;/script&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
const alertVal = (msg: any) => alert(msg);
import { ref, computed } from 'vue';

const handleRefresh = (complete: () => void) => {
  setTimeout(() => {
    alertVal('Refresh Complete!');
    complete();
  }, 1500);
};



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{k as _};
