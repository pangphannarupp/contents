import{Q as o}from"./AccountCardSection-DXixqG3L.js";import{d as l,o as i,j as t,l as e,a as r,u as a,F as c}from"../vendors/vendor-ah_eQdvw.js";import{_ as p}from"./App-D7rwXoHs.js";const n={class:"guide-section"},u={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"24px"}},d={style:{display:"flex",gap:"32px","flex-wrap":"wrap"}},g=l({__name:"ProgressGaugeSection",setup(m){return(f,s)=>(i(),t(c,null,[e("div",n,[s[1]||(s[1]=e("h2",null,"Progress Gauge",-1)),s[2]||(s[2]=e("p",null,"A circular gauge to display progress or completion percentage.",-1)),s[3]||(s[3]=e("h3",null,"Basic Usage",-1)),e("div",u,[e("div",d,[r(a(o),{value:25,size:120,color:"#3880ff"}),r(a(o),{value:75,size:120,color:"#2dd36f"}),r(a(o),{value:100,size:120,color:"#eb445a"})]),s[0]||(s[0]=e("pre",{class:"code-block",style:{margin:"0"}},[e("code",null,`<PPProgressGauge :value="25" :size="120" color="#3880ff" />
<PPProgressGauge :value="75" :size="120" color="#2dd36f" />
<PPProgressGauge :value="100" :size="120" color="#eb445a" />`)],-1))]),s[4]||(s[4]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-light: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),s[5]||(s[5]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Progress Gauge</h2>
    <p>A circular gauge to display progress or completion percentage.</p>

    <h3>Basic Usage</h3>
    <div class="demo-box" style="display: flex; flex-direction: column; gap: 24px;">
      <div style="display: flex; gap: 32px; flex-wrap: wrap;">
        <PPProgressGauge :value="25" :size="120" color="#3880ff" />
        <PPProgressGauge :value="75" :size="120" color="#2dd36f" />
        <PPProgressGauge :value="100" :size="120" color="#eb445a" />
      </div>
      <pre class="code-block" style="margin: 0;"><code>&lt;PPProgressGauge :value="25" :size="120" color="#3880ff" /&gt;
&lt;PPProgressGauge :value="75" :size="120" color="#2dd36f" /&gt;
&lt;PPProgressGauge :value="100" :size="120" color="#eb445a" /&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-light: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPProgressGauge } from '@phanna/ui-framework';
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),x=p(g,[["__scopeId","data-v-584a4d34"]]);export{x as P};
