import{bK as l}from"./AccountCardSection-DXixqG3L.js";import{d as c,o as g,j as m,l as t,a,w as n,A as P,u as r,F as p,p as i}from"../vendors/vendor-ah_eQdvw.js";const v={class:"guide-section"},h={class:"variant-group"},C={class:"component-demo",style:{display:"flex",gap:"8px"}},k=c({__name:"ToggleButtonSection",setup(S){const s=i(!1),u=i(!0),d=i(!1);return(b,e)=>(g(),m(p,null,[t("div",v,[e[8]||(e[8]=t("h2",null,"1.6 Toggle Button",-1)),t("div",h,[e[6]||(e[6]=t("h3",null,"Toggle Button Variants",-1)),t("div",C,[a(r(l),{modelValue:s.value,"onUpdate:modelValue":e[0]||(e[0]=o=>s.value=o),variant:"solid"},{default:n(()=>[...e[3]||(e[3]=[P("Solid",-1)])]),_:1},8,["modelValue"]),a(r(l),{modelValue:u.value,"onUpdate:modelValue":e[1]||(e[1]=o=>u.value=o),variant:"outline"},{default:n(()=>[...e[4]||(e[4]=[P("Outline",-1)])]),_:1},8,["modelValue"]),a(r(l),{modelValue:d.value,"onUpdate:modelValue":e[2]||(e[2]=o=>d.value=o),variant:"text"},{default:n(()=>[...e[5]||(e[5]=[P("Text",-1)])]),_:1},8,["modelValue"])]),e[7]||(e[7]=t("pre",{class:"code-block"},[t("code",null,'<PPToggleButton v-model="active" variant="outline">Toggle</PPToggleButton>')],-1))]),e[9]||(e[9]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[10]||(e[10]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>1.6 Toggle Button</h2>

        <div class="variant-group">
          <h3>Toggle Button Variants</h3>
          <div class="component-demo" style="display: flex; gap: 8px;">
            <PPToggleButton v-model="toggleVal1" variant="solid">Solid</PPToggleButton>
            <PPToggleButton v-model="toggleVal2" variant="outline">Outline</PPToggleButton>
            <PPToggleButton v-model="toggleVal3" variant="text">Text</PPToggleButton>
          </div>
          <pre class="code-block"><code>&lt;PPToggleButton v-model="active" variant="outline"&gt;Toggle&lt;/PPToggleButton&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const toggleVal1 = ref(false);

const toggleVal2 = ref(true);

const toggleVal3 = ref(false);



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{k as _};
