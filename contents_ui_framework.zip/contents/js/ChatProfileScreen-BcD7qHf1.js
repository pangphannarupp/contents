import{d as c,o as r,j as p,l as s,a as i,w as l,A as d,y as u,u as a,aP as v,aQ as m,aT as f,aO as _,aU as P,aS as g,E as e,M as h,aE as C,n as b,p as O}from"../vendors/vendor-ah_eQdvw.js";import{P as B,a as t,Z as k,a0 as x}from"./AccountCardSection-DXixqG3L.js";import{_ as M}from"./App-D7rwXoHs.js";const w={class:"screen-preview-container"},y={class:"header-actions"},I={class:"chat-profile-screen"},V={class:"profile-scroll-area"},S={class:"profile-info"},z={class:"avatar-wrapper"},A={class:"actions-group"},N={class:"action-item"},D={class:"action-item"},E={class:"action-item"},T={class:"more-actions-section"},U={class:"action-list"},j={class:"list-item"},F={class:"list-item"},L={class:"list-item"},Q=c({__name:"ChatProfileScreen",setup(Z){const o=O(!1);return($,n)=>(r(),p("div",w,[s("div",y,[i(a(B),{variant:"primary",size:"small",onClick:n[0]||(n[0]=q=>o.value=!o.value)},{default:l(()=>[d(" Toggle "+u(o.value?"Light":"Dark")+" Mode ",1)]),_:1})]),s("div",{class:b(["phone-mockup",{"dark-mode":o.value}])},[s("div",I,[i(a(k),{class:"transparent-appbar"},{left:l(()=>[i(a(t),{icon:a(m),color:"transparent",class:"header-icon-btn"},null,8,["icon"])]),right:l(()=>[i(a(t),{icon:a(v),color:"transparent",class:"header-icon-btn"},null,8,["icon"])]),_:1}),s("div",V,[s("div",S,[s("div",z,[i(a(x),{src:"https://i.pravatar.cc/150?img=5",name:"Cindy",size:"xl",class:"profile-avatar"})]),n[1]||(n[1]=s("h2",{class:"profile-name"},"Cindy",-1)),n[2]||(n[2]=s("p",{class:"profile-phone"},"+14844533842",-1))]),s("div",A,[s("div",N,[i(a(t),{icon:a(f),class:"action-icon-btn"},null,8,["icon"]),n[3]||(n[3]=s("span",{class:"action-label"},"Message",-1))]),s("div",D,[i(a(t),{icon:a(_),class:"action-icon-btn"},null,8,["icon"]),n[4]||(n[4]=s("span",{class:"action-label"},"Call",-1))]),s("div",E,[i(a(t),{icon:a(P),class:"action-icon-btn"},null,8,["icon"]),n[5]||(n[5]=s("span",{class:"action-label"},"Mute",-1))])]),s("div",T,[n[9]||(n[9]=s("h3",{class:"section-title"},"More actions",-1)),s("div",U,[s("div",j,[i(a(e),{icon:a(g),class:"list-icon"},null,8,["icon"]),n[6]||(n[6]=s("span",{class:"list-text"},"View media",-1))]),s("div",F,[i(a(e),{icon:a(h),class:"list-icon"},null,8,["icon"]),n[7]||(n[7]=s("span",{class:"list-text"},"Search in conversation",-1))]),s("div",L,[i(a(e),{icon:a(C),class:"list-icon"},null,8,["icon"]),n[8]||(n[8]=s("span",{class:"list-text"},"Notifications",-1))])])])]),n[10]||(n[10]=s("div",{class:"home-indicator"},null,-1))])],2),n[11]||(n[11]=s("div",{class:"usage-section"},[s("h3",null,"Code Usage"),s("pre",{class:"code-block"},[s("code",null,`
<template>
  <div class="chat-profile-screen">
    <PPAppBar class="transparent-appbar">
      <template #left>
        <PPIconButton :icon="arrowBackOutline" color="transparent" />
      </template>
      <template #right>
        <PPIconButton :icon="ellipsisVerticalOutline" color="transparent" />
      </template>
    </PPAppBar>
    
    <div class="profile-info">
      <PPAvatar src="..." name="Cindy" size="xl" />
      <h2>Cindy</h2>
      <p>+14844533842</p>
    </div>

    <div class="actions-group">
      <div class="action-item">
        <PPIconButton :icon="pencilOutline" />
        <span>Message</span>
      </div>
      <!-- Call and Mute buttons -->
    </div>
  </div>
</template>
      `)])],-1))]))}}),K=M(Q,[["__scopeId","data-v-b56c6ea0"]]);export{K as C};
