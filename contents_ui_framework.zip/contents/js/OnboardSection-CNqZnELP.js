import{b9 as n}from"./AccountCardSection-DXixqG3L.js";import{d as l,o as r,j as a,l as e,a as c,bb as p,c4 as d,c5 as u,u as m,F as g}from"../vendors/vendor-ah_eQdvw.js";import{_ as b}from"./App-D7rwXoHs.js";const f={class:"guide-section"},v={class:"demo-box onboard-demo"},y=l({__name:"OnboardSection",setup(h){const t=[{title:"Welcome to UI Framework",description:"Build modern applications with our comprehensive suite of components.",icon:p},{title:"Beautiful Design",description:"Every component is carefully crafted to look great right out of the box.",icon:d},{title:"Fast & Responsive",description:"Optimized for performance across all devices and screen sizes.",icon:u}],s=()=>{console.log("User skipped onboarding")},i=()=>{console.log("User completed onboarding")};return(O,o)=>(r(),a(g,null,[e("div",f,[o[0]||(o[0]=e("h2",null,"Onboarding",-1)),o[1]||(o[1]=e("p",null,"A step-by-step swipeable interface for introducing users to the application.",-1)),o[2]||(o[2]=e("h3",null,"Standard Onboarding",-1)),e("div",v,[c(m(n),{steps:t,onSkip:s,onComplete:i})]),o[3]||(o[3]=e("pre",{class:"code-block",style:{"margin-top":"24px"}},[e("code",null,`<PPOnboard 
  :steps="[
    { title: 'Welcome', description: 'Start your journey', icon: globeOutline },
    { title: 'Secure', description: 'Your data is safe', icon: lockClosedOutline }
  ]"
  @skip="onSkip"
  @complete="onComplete"
/>`)],-1)),o[4]||(o[4]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[5]||(o[5]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Onboarding</h2>
    <p>A step-by-step swipeable interface for introducing users to the application.</p>

    <h3>Standard Onboarding</h3>
    <div class="demo-box onboard-demo">
      <PPOnboard 
        :steps="onboardSteps" 
        @skip="handleSkip"
        @complete="handleComplete"
      />
    </div>
    
    <pre class="code-block" style="margin-top: 24px;"><code>&lt;PPOnboard 
  :steps="[
    { title: 'Welcome', description: 'Start your journey', icon: globeOutline },
    { title: 'Secure', description: 'Your data is safe', icon: lockClosedOutline }
  ]"
  @skip="onSkip"
  @complete="onComplete"
/&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPOnboard } from '@phanna/ui-framework';
import { rocketOutline, colorPaletteOutline, flashOutline } from 'ionicons/icons';

const onboardSteps = [
  {
    title: 'Welcome to UI Framework',
    description: 'Build modern applications with our comprehensive suite of components.',
    icon: rocketOutline
  },
  {
    title: 'Beautiful Design',
    description: 'Every component is carefully crafted to look great right out of the box.',
    icon: colorPaletteOutline
  },
  {
    title: 'Fast & Responsive',
    description: 'Optimized for performance across all devices and screen sizes.',
    icon: flashOutline
  }
];

const handleSkip = () => {
  console.log('User skipped onboarding');
};

const handleComplete = () => {
  console.log('User completed onboarding');
};
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; background: #f9fafb; }
.onboard-demo { height: 600px; max-width: 400px; margin: 0 auto; position: relative; }
</style>
`)])],-1))],64))}}),C=b(y,[["__scopeId","data-v-1a7b8b43"]]);export{C as O};
