import{d as y,o as C,j as V,l as o,a,aV as h,aB as f,bZ as S,bc as B,b_ as O,az as w,bn as T,aD as A,u as l,bD as I,a8 as N,b$ as x,bF as M,F as D,p as n}from"../vendors/vendor-ah_eQdvw.js";import{c as i}from"./AccountCardSection-DXixqG3L.js";const F={class:"guide-section"},L={class:"variant-group"},U={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px"}},K={class:"variant-group"},R={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px"}},H={class:"variant-group"},Y={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px"}},G={class:"variant-group"},z={class:"component-demo",style:{position:"relative",overflow:"hidden",height:"160px",background:"#f0f2f5"}},E={class:"variant-group"},j={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px"}},Z={class:"variant-group"},$={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px"}},q={class:"variant-group"},J={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px","background-color":"#2c2c36"}},Q={class:"variant-group"},W={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px","background-color":"#f9f9fc"}},X={class:"variant-group"},_={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px","background-color":"#1a1a1a"}},ee={class:"variant-group"},oe={class:"component-demo",style:{position:"relative",overflow:"hidden","padding-bottom":"20px","background-color":"#ffffff"}},ie=y({__name:"M3NavSection",setup(te){const d=n("home"),r=n("home"),v=n("home"),c=n("home"),u=n("home"),m=n("home"),p=n("home"),P=n("home"),b=n("home"),g=n("home"),s=[{label:"Home",value:"home",icon:f,activeIcon:h},{label:"History",value:"history",icon:B,activeIcon:S},{label:"Messages",value:"messages",icon:w,activeIcon:O},{label:"Profile",value:"profile",icon:A,activeIcon:T}],k=[{label:"Home",value:"home",icon:f,activeIcon:h},{label:"Rewards",value:"rewards",icon:I,activeIcon:I},{label:"Order",value:"order",icon:N,isAction:!0},{label:"Scan",value:"scan",icon:x},{label:"My Order",value:"myorder",icon:M}];return(ae,e)=>(C(),V(D,null,[o("div",F,[e[40]||(e[40]=o("h2",null,"Bottom Navigation",-1)),e[41]||(e[41]=o("p",{class:"guide-desc"},"Modern bottom navigation bars with multiple styles and variants.",-1)),o("div",L,[e[10]||(e[10]=o("h3",null,"Material 3 (Default)",-1)),e[11]||(e[11]=o("p",{class:"guide-desc"},"The standard MD3 style with pill indicators.",-1)),o("div",U,[a(l(i),{modelValue:d.value,"onUpdate:modelValue":e[0]||(e[0]=t=>d.value=t),variant:"material",items:s},null,8,["modelValue"])]),e[12]||(e[12]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="material"
  :items="navItems"
/>`)],-1))]),o("div",K,[e[13]||(e[13]=o("h3",null,"Classic",-1)),e[14]||(e[14]=o("p",{class:"guide-desc"},"A traditional style with icons and text stacked vertically.",-1)),o("div",R,[a(l(i),{modelValue:r.value,"onUpdate:modelValue":e[1]||(e[1]=t=>r.value=t),variant:"classic",items:s},null,8,["modelValue"])]),e[15]||(e[15]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="classic"
  :items="navItems"
/>`)],-1))]),o("div",H,[e[16]||(e[16]=o("h3",null,"Shift",-1)),e[17]||(e[17]=o("p",{class:"guide-desc"},"A dynamic shifting style where only the active item shows its label.",-1)),o("div",Y,[a(l(i),{modelValue:v.value,"onUpdate:modelValue":e[2]||(e[2]=t=>v.value=t),variant:"shift",items:s},null,8,["modelValue"])]),e[18]||(e[18]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="shift"
  :items="navItems"
/>`)],-1))]),o("div",G,[e[19]||(e[19]=o("h3",null,"Floating",-1)),e[20]||(e[20]=o("p",{class:"guide-desc"},"A modern floating island navigation bar.",-1)),o("div",z,[a(l(i),{modelValue:c.value,"onUpdate:modelValue":e[3]||(e[3]=t=>c.value=t),variant:"floating",items:s},null,8,["modelValue"])]),e[21]||(e[21]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="floating"
  :items="navItems"
/>`)],-1))]),o("div",E,[e[22]||(e[22]=o("h3",null,"Dot (Animated)",-1)),e[23]||(e[23]=o("p",{class:"guide-desc"},"A smooth sliding dot indicator with icon bounce.",-1)),o("div",j,[a(l(i),{modelValue:u.value,"onUpdate:modelValue":e[4]||(e[4]=t=>u.value=t),variant:"dot",items:s},null,8,["modelValue"])]),e[24]||(e[24]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="dot"
  :items="navItems"
/>`)],-1))]),o("div",Z,[e[25]||(e[25]=o("h3",null,"Bubble (Animated)",-1)),e[26]||(e[26]=o("p",{class:"guide-desc"},"A springy popping bubble indicator.",-1)),o("div",$,[a(l(i),{modelValue:m.value,"onUpdate:modelValue":e[5]||(e[5]=t=>m.value=t),variant:"bubble",items:s},null,8,["modelValue"])]),e[27]||(e[27]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="bubble"
  :items="navItems"
/>`)],-1))]),o("div",q,[e[28]||(e[28]=o("h3",null,"Magic Line (Animated)",-1)),e[29]||(e[29]=o("p",{class:"guide-desc"},"A glowing line sliding across a sleek dark background.",-1)),o("div",J,[a(l(i),{modelValue:p.value,"onUpdate:modelValue":e[6]||(e[6]=t=>p.value=t),variant:"magic-line",items:s},null,8,["modelValue"])]),e[30]||(e[30]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="magic-line"
  :items="navItems"
/>`)],-1))]),o("div",Q,[e[31]||(e[31]=o("h3",null,"Curved (The Cutout)",-1)),e[32]||(e[32]=o("p",{class:"guide-desc"},"The active item pops up into a floating circle above the navigation bar.",-1)),o("div",W,[a(l(i),{modelValue:P.value,"onUpdate:modelValue":e[7]||(e[7]=t=>P.value=t),variant:"curved",items:s},null,8,["modelValue"])]),e[33]||(e[33]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="curved"
  :items="navItems"
/>`)],-1))]),o("div",X,[e[34]||(e[34]=o("h3",null,"Cutout (Action FAB)",-1)),e[35]||(e[35]=o("p",{class:"guide-desc"},"A centered elevated action button with a curved cutout behind it.",-1)),o("div",_,[a(l(i),{modelValue:g.value,"onUpdate:modelValue":e[8]||(e[8]=t=>g.value=t),variant:"cutout",items:k},null,8,["modelValue"])]),e[36]||(e[36]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="cutout"
  :items="navItemsCutout"
/>`)],-1))]),o("div",ee,[e[37]||(e[37]=o("h3",null,"Pill Slide (Segmented Control)",-1)),e[38]||(e[38]=o("p",{class:"guide-desc"},"A continuous pill shape with a solid background sliding behind the active item.",-1)),o("div",oe,[a(l(i),{modelValue:b.value,"onUpdate:modelValue":e[9]||(e[9]=t=>b.value=t),variant:"pill-slide",items:s},null,8,["modelValue"])]),e[39]||(e[39]=o("pre",{class:"code-block"},[o("code",null,`<PPBottomNav 
  v-model="currentTab"
  variant="pill-slide"
  :items="navItems"
/>`)],-1))]),e[42]||(e[42]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[43]||(e[43]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
<div class="guide-section">
        <h2>Bottom Navigation</h2>
        <p class="guide-desc">Modern bottom navigation bars with multiple styles and variants.</p>

        <div class="variant-group">
          <h3>Material 3 (Default)</h3>
          <p class="guide-desc">The standard MD3 style with pill indicators.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px;">
            <PPBottomNav 
              v-model="navValMaterial"
              variant="material"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="material"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Classic</h3>
          <p class="guide-desc">A traditional style with icons and text stacked vertically.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px;">
            <PPBottomNav 
              v-model="navValClassic"
              variant="classic"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="classic"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Shift</h3>
          <p class="guide-desc">A dynamic shifting style where only the active item shows its label.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px;">
            <PPBottomNav 
              v-model="navValShift"
              variant="shift"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="shift"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Floating</h3>
          <p class="guide-desc">A modern floating island navigation bar.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; height: 160px; background: #f0f2f5;">
            <PPBottomNav 
              v-model="navValFloating"
              variant="floating"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="floating"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Dot (Animated)</h3>
          <p class="guide-desc">A smooth sliding dot indicator with icon bounce.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px;">
            <PPBottomNav 
              v-model="navValDot"
              variant="dot"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="dot"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Bubble (Animated)</h3>
          <p class="guide-desc">A springy popping bubble indicator.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px;">
            <PPBottomNav 
              v-model="navValBubble"
              variant="bubble"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="bubble"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Magic Line (Animated)</h3>
          <p class="guide-desc">A glowing line sliding across a sleek dark background.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px; background-color: #2c2c36;">
            <PPBottomNav 
              v-model="navValMagicLine"
              variant="magic-line"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="magic-line"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Curved (The Cutout)</h3>
          <p class="guide-desc">The active item pops up into a floating circle above the navigation bar.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px; background-color: #f9f9fc;">
            <PPBottomNav 
              v-model="navValCurved"
              variant="curved"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="curved"
  :items="navItems"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Cutout (Action FAB)</h3>
          <p class="guide-desc">A centered elevated action button with a curved cutout behind it.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px; background-color: #1a1a1a;">
            <PPBottomNav 
              v-model="navValCutout"
              variant="cutout"
              :items="navItemsCutout"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="cutout"
  :items="navItemsCutout"
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Pill Slide (Segmented Control)</h3>
          <p class="guide-desc">A continuous pill shape with a solid background sliding behind the active item.</p>
          <div class="component-demo" style="position: relative; overflow: hidden; padding-bottom: 20px; background-color: #ffffff;">
            <PPBottomNav 
              v-model="navValPillSlide"
              variant="pill-slide"
              :items="navItems"
            />
          </div>
          <pre class="code-block"><code>&lt;PPBottomNav 
  v-model="currentTab"
  variant="pill-slide"
  :items="navItems"
/&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const navValMaterial = ref('home');
const navValClassic = ref('home');
const navValShift = ref('home');
const navValFloating = ref('home');
const navValDot = ref('home');
const navValBubble = ref('home');
const navValMagicLine = ref('home');
const navValCurved = ref('home');
const navValPillSlide = ref('home');
const navValCutout = ref('home');

const navItems = [
  { label: 'Home', value: 'home', icon: homeOutline, activeIcon: home },
  { label: 'History', value: 'history', icon: documentTextOutline, activeIcon: documentText },
  { label: 'Messages', value: 'messages', icon: chatbubbleOutline, activeIcon: chatbubble },
  { label: 'Profile', value: 'profile', icon: personOutline, activeIcon: person }
];

const navItemsCutout = [
  { label: 'Home', value: 'home', icon: homeOutline, activeIcon: home },
  { label: 'Rewards', value: 'rewards', icon: cardOutline, activeIcon: cardOutline },
  { label: 'Order', value: 'order', icon: addOutline, isAction: true },
  { label: 'Scan', value: 'scan', icon: scanOutline },
  { label: 'My Order', value: 'myorder', icon: cartOutline }
];

import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline, scanOutline, cartOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{ie as _};
