import{bc as c,aL as g,bd as h,aM as y,aN as b}from"./AccountCardSection-DXixqG3L.js";import{d as f,o as k,j as S,l as e,L as x,a as t,u as r,A as i,y as d,F as K,p as P}from"../vendors/vendor-ah_eQdvw.js";const C={class:"guide-section"},I={class:"variant-group"},D={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd",padding:"40px","border-radius":"12px",display:"flex","flex-direction":"column",gap:"20px"}},T={class:"variant-group"},O={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},w={style:{padding:"16px","text-align":"center",color:"#666"}},A={class:"variant-group"},V={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},N={style:{padding:"16px","text-align":"center",color:"#666","font-size":"18px"}},E={class:"variant-group"},B={class:"component-section",id:"pp-secure-keyboard"},R={class:"demo-container bg-dark",style:{position:"relative",overflow:"visible"}},z={class:"mb-4",style:{color:"white"}},L={class:"text-xl tracking-widest font-mono"},Y={class:"component-section",id:"pp-khmer-keyboard"},F={class:"demo-container bg-dark",style:{position:"relative",overflow:"visible"}},M={class:"mb-4",style:{color:"white"}},Q={class:"text-xl tracking-widest font-mono"},U=f({__name:"PinSecuritySection",setup(G){const u=s=>{s==="backspace"?n.value=n.value.slice(0,-1):n.value+=s},a=P(""),p=s=>{s==="backspace"?l.value=l.value.slice(0,-1):s==="enter"?console.log("Enter pressed"):l.value+=s},m=s=>{s==="backspace"?a.value=a.value.slice(0,-1):s==="enter"?console.log("Enter pressed"):a.value+=s},n=P(""),l=P("None"),v=s=>{l.value=s};return(s,o)=>(k(),S(K,null,[e("div",C,[o[18]||(o[18]=e("h2",null,"8. PIN Security Components",-1)),e("div",I,[o[0]||(o[0]=x('<h3>PPPinDots</h3><p class="custom-guide"><strong>Props:</strong> <code>length</code>, <code>value</code>, <code>error</code>, <code>errorText</code>, <code>success</code></p>',2)),e("div",D,[t(r(c),{length:6,value:"123"}),t(r(c),{length:6,value:"12345",error:!0}),t(r(c),{length:6,value:"123456",success:!0})]),o[1]||(o[1]=e("pre",{class:"code-block"},[e("code",null,`<PPPinDots :length="6" value="123" />
<PPPinDots :length="6" value="123" :error="true" />
<PPPinDots :length="6" value="123456" :success="true" />`)],-1))]),e("div",T,[o[3]||(o[3]=e("h3",null,"PPKeypad",-1)),o[4]||(o[4]=e("p",{class:"custom-guide"},[e("strong",null,"Events:"),i(),e("code",null,"@press"),i(" (emits value string or 'backspace')")],-1)),e("div",O,[t(r(g),{onPress:v}),e("div",w,[o[2]||(o[2]=i(" Last Pressed: ",-1)),e("strong",null,d(l.value),1)])]),o[5]||(o[5]=e("pre",{class:"code-block"},[e("code",null,'<PPKeypad @press="handlePress" />')],-1))]),e("div",A,[o[7]||(o[7]=e("h3",null,"Secure Keypad",-1)),o[8]||(o[8]=e("p",{class:"custom-guide"},"A randomized secure keypad with a shield icon. The numbers shuffle every time the component mounts to prevent shoulder-surfing!",-1)),e("div",V,[e("div",N,[o[6]||(o[6]=i(" Secure PIN: ",-1)),e("strong",null,d(n.value||"Enter PIN"),1)]),t(r(h),{onPress:u})]),o[9]||(o[9]=e("pre",{class:"code-block"},[e("code",null,'<PPSecureKeypad @press="handleSecureKeypadPress" />')],-1))]),e("div",E,[o[16]||(o[16]=e("h3",null,"Secure Virtual Keyboard",-1)),o[17]||(o[17]=e("p",{class:"custom-guide"},"A full randomized QWERTY-style secure keyboard (dark theme).",-1)),e("div",B,[o[11]||(o[11]=e("h2",null,"PPSecureKeyboard",-1)),o[12]||(o[12]=e("p",null,"A full randomized QWERTY keyboard with custom layouts.",-1)),e("div",R,[e("div",z,[o[10]||(o[10]=e("div",{class:"text-sm text-gray-400"},"English Input",-1)),e("div",L,d(l.value||"Tap to type"),1)]),t(r(y),{onPress:p})])]),e("div",Y,[o[14]||(o[14]=e("h2",null,"PPKhmerKeyboard",-1)),o[15]||(o[15]=e("p",null,"A full randomized Khmer (NiDA) keyboard with custom layouts.",-1)),e("div",F,[e("div",M,[o[13]||(o[13]=e("div",{class:"text-sm text-gray-400"},"Khmer Input",-1)),e("div",Q,d(a.value||"Tap to type"),1)]),t(r(b),{onPress:m})])])]),o[19]||(o[19]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[20]||(o[20]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>8. PIN Security Components</h2>

        <div class="variant-group">
          <h3>PPPinDots</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>length</code>, <code>value</code>, <code>error</code>, <code>errorText</code>, <code>success</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; padding: 40px; border-radius: 12px; display: flex; flex-direction: column; gap: 20px;">
            <PPPinDots :length="6" value="123" />
            <PPPinDots :length="6" value="12345" :error="true" />
            <PPPinDots :length="6" value="123456" :success="true" />
          </div>
          <pre class="code-block"><code>&lt;PPPinDots :length="6" value="123" /&gt;
&lt;PPPinDots :length="6" value="123" :error="true" /&gt;
&lt;PPPinDots :length="6" value="123456" :success="true" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>PPKeypad</h3>
          <p class="custom-guide"><strong>Events:</strong> <code>@press</code> (emits value string or 'backspace')</p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <!-- Render keypad live -->
            <PPKeypad @press="handlePress" />
            <div style="padding: 16px; text-align: center; color: #666;">
              Last Pressed: <strong>{{ keypadDemoVal }}</strong>
            </div>
          </div>
          <pre class="code-block"><code>&lt;PPKeypad @press="handlePress" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Secure Keypad</h3>
          <p class="custom-guide">A randomized secure keypad with a shield icon. The numbers shuffle every time the component mounts to prevent shoulder-surfing!</p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <div style="padding: 16px; text-align: center; color: #666; font-size: 18px;">
              Secure PIN: <strong>{{ secureKeypadVal || 'Enter PIN' }}</strong>
            </div>
            <PPSecureKeypad @press="handleSecureKeypadPress" />
          </div>
          <pre class="code-block"><code>&lt;PPSecureKeypad @press="handleSecureKeypadPress" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Secure Virtual Keyboard</h3>
          <p class="custom-guide">A full randomized QWERTY-style secure keyboard (dark theme).</p>
          <div class="component-section" id="pp-secure-keyboard">
            <h2>PPSecureKeyboard</h2>
            <p>A full randomized QWERTY keyboard with custom layouts.</p>
            <div class="demo-container bg-dark" style="position: relative; overflow: visible;">
              <div class="mb-4" style="color: white;">
                <div class="text-sm text-gray-400">English Input</div>
                <div class="text-xl tracking-widest font-mono">{{ keypadDemoVal || 'Tap to type' }}</div>
              </div>
              <PPSecureKeyboard @press="handleKeyboardPress" />
            </div>
          </div>

          <!-- Secure Khmer Keyboard -->
          <div class="component-section" id="pp-khmer-keyboard">
            <h2>PPKhmerKeyboard</h2>
            <p>A full randomized Khmer (NiDA) keyboard with custom layouts.</p>
            <div class="demo-container bg-dark" style="position: relative; overflow: visible;">
              <div class="mb-4" style="color: white;">
                <div class="text-sm text-gray-400">Khmer Input</div>
                <div class="text-xl tracking-widest font-mono">{{ khmerDemoVal || 'Tap to type' }}</div>
              </div>
              <PPKhmerKeyboard @press="handleKhmerPress" />
            </div>
          </div>
        </div>

      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const handleSecureKeypadPress = (v: string) => {
  if (v === 'backspace') {
    secureKeypadVal.value = secureKeypadVal.value.slice(0, -1);
  } else {
    secureKeypadVal.value += v;
  }
};

const khmerDemoVal = ref('');

const handleKeyboardPress = (v: string) => {
  if (v === 'backspace') {
    keypadDemoVal.value = keypadDemoVal.value.slice(0, -1);
  } else if (v === 'enter') {
    console.log('Enter pressed');
  } else {
    keypadDemoVal.value += v;
  }
};

const handleKhmerPress = (v: string) => {
  if (v === 'backspace') {
    khmerDemoVal.value = khmerDemoVal.value.slice(0, -1);
  } else if (v === 'enter') {
    console.log('Enter pressed');
  } else {
    khmerDemoVal.value += v;
  }
};

const secureKeypadVal = ref('');

const keypadDemoVal = ref('None');

const handlePress = (v: string) => {
  keypadDemoVal.value = v;
};



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{U as _};
