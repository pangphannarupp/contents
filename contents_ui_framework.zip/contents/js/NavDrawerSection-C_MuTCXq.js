import{P as c,b1 as u}from"./AccountCardSection-DXixqG3L.js";import{d,o as m,j as p,l as t,a as r,w as v,A as g,u as l,F as h,p as i}from"../vendors/vendor-ah_eQdvw.js";const b={class:"guide-section"},C={class:"variant-group"},S={class:"component-demo"},O=d({__name:"NavDrawerSection",setup(k){const a=i(!1),P=i([{label:"Inbox",active:!0,badge:"3"},{label:"Sent"},{label:"Drafts"}]),s=n=>console.log("Setup: "+n);return(n,e)=>(m(),p(h,null,[t("div",b,[e[7]||(e[7]=t("h2",null,"17. Navigation Drawer (Material 3)",-1)),t("div",C,[e[4]||(e[4]=t("h3",null,"Interactive Demo",-1)),e[5]||(e[5]=t("p",{class:"custom-guide"},"Click the button to slide open the navigation drawer.",-1)),t("div",S,[r(l(c),{onClick:e[0]||(e[0]=o=>a.value=!0)},{default:v(()=>[...e[3]||(e[3]=[g("Open Left Menu",-1)])]),_:1}),r(l(u),{modelValue:a.value,"onUpdate:modelValue":e[1]||(e[1]=o=>a.value=o),title:"App Menu",items:P.value,onItemClick:e[2]||(e[2]=o=>s("Selected: "+o.label))},null,8,["modelValue","items"])]),e[6]||(e[6]=t("pre",{class:"code-block"},[t("code",null,`<PPNavigationDrawer 
  v-model="isDrawerOpen" 
  title="App Menu" 
  :items="menuItems" 
/>`)],-1))]),e[8]||(e[8]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[9]||(e[9]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>17. Navigation Drawer (Material 3)</h2>

        <div class="variant-group">
          <h3>Interactive Demo</h3>
          <p class="custom-guide">Click the button to slide open the navigation drawer.</p>
          <div class="component-demo">
            <PPButton @click="showNavDrawer = true">Open Left Menu</PPButton>

            <PPNavigationDrawer 
              v-model="showNavDrawer" 
              title="App Menu" 
              :items="navDrawerItems" 
              @item-click="val => alertVal('Selected: ' + val.label)"
            />
          </div>
          <pre class="code-block"><code>&lt;PPNavigationDrawer 
  v-model="isDrawerOpen" 
  title="App Menu" 
  :items="menuItems" 
/&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const showNavDrawer = ref(false);

const navDrawerItems = ref([
  { label: 'Inbox', active: true, badge: '3' },
  { label: 'Sent' },
  { label: 'Drafts' }
]);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{O as _};
