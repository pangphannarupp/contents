import{bP as v,bQ as f,P as u,bR as k,bS as b,bT as S}from"./AccountCardSection-DXixqG3L.js";import{d as Y,o as C,j as h,l as o,A as l,a as n,u as t,w as c,F as y,p as P}from"../vendors/vendor-ah_eQdvw.js";const x={class:"guide-section"},I={class:"variant-group"},O={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},w={class:"variant-group"},A={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},B={class:"variant-group"},V={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},R={class:"variant-group"},T={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},M={class:"variant-group"},K={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},F={class:"variant-group"},L={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},G=Y({__name:"YearPickerSection",setup(N){const p=P(null),a=P(!1),s=P(!1),d=P(!1),i=m=>console.log("Setup: "+m);return(m,e)=>(C(),h(y,null,[o("div",x,[e[36]||(e[36]=o("h2",null,"13.5. Year Picker",-1)),o("div",I,[e[15]||(e[15]=o("h3",null,"Input Wrapper",-1)),e[16]||(e[16]=o("p",{class:"custom-guide"},[o("strong",null,"Component:"),l(),o("code",null,"<PPYearPickerInput>")],-1)),o("div",O,[n(t(v),{modelValue:p.value,"onUpdate:modelValue":e[0]||(e[0]=r=>p.value=r)},null,8,["modelValue"])]),e[17]||(e[17]=o("pre",{class:"code-block"},[o("code",null,'<PPYearPickerInput v-model="year" />')],-1))]),o("div",w,[e[18]||(e[18]=o("h3",null,"Standard Selection",-1)),e[19]||(e[19]=o("p",{class:"custom-guide"},[o("strong",null,"Props:"),l(),o("code",null,"config={ selectionMode: 'Single' }")],-1)),o("div",A,[n(t(f),{onYearSelected:e[1]||(e[1]=r=>i("Selected Year: "+r.year))})]),e[20]||(e[20]=o("pre",{class:"code-block"},[o("code",null,'<PPYearPicker @year-selected="onSelect" />')],-1))]),o("div",B,[e[21]||(e[21]=o("h3",null,"Range Selection",-1)),e[22]||(e[22]=o("p",{class:"custom-guide"},[o("strong",null,"Props:"),l(),o("code",null,"config={ selectionMode: 'Range' }")],-1)),o("div",V,[n(t(f),{config:{selectionMode:"Range"},onRangeSelected:e[2]||(e[2]=(r,g)=>i("Range: "+(r?r.year:"")+" to "+(g?g.year:"")))})]),e[23]||(e[23]=o("pre",{class:"code-block"},[o("code",null,`<PPYearPicker :config="{ selectionMode: 'Range' }" />`)],-1))]),o("div",R,[e[25]||(e[25]=o("h3",null,"Year Picker Bottom Sheet",-1)),e[26]||(e[26]=o("p",{class:"custom-guide"},[o("strong",null,"Component:"),l(),o("code",null,"<PPYearPickerSheet>")],-1)),o("div",T,[n(t(u),{onClick:e[3]||(e[3]=r=>a.value=!0)},{default:c(()=>[...e[24]||(e[24]=[l("Open Year Sheet",-1)])]),_:1}),n(t(k),{modelValue:a.value,"onUpdate:modelValue":e[4]||(e[4]=r=>a.value=r),title:"Select a Year",showActionButtons:!0,onConfirm:e[5]||(e[5]=r=>{i("Confirmed: "+(r?r.year:"")),a.value=!1}),onCancel:e[6]||(e[6]=r=>a.value=!1)},null,8,["modelValue"])]),e[27]||(e[27]=o("pre",{class:"code-block"},[o("code",null,'<PPYearPickerSheet v-model="isOpen" />')],-1))]),o("div",M,[e[29]||(e[29]=o("h3",null,"Year Picker Island Popup",-1)),e[30]||(e[30]=o("p",{class:"custom-guide"},[o("strong",null,"Component:"),l(),o("code",null,"<PPYearPickerIsland>")],-1)),o("div",K,[n(t(u),{onClick:e[7]||(e[7]=r=>d.value=!0)},{default:c(()=>[...e[28]||(e[28]=[l("Open Year Picker Island",-1)])]),_:1}),n(t(b),{modelValue:d.value,"onUpdate:modelValue":e[8]||(e[8]=r=>d.value=r),showActionButtons:!0,onConfirm:e[9]||(e[9]=r=>{i("Confirmed Year: "+(r?r.year:"none")),d.value=!1}),onCancel:e[10]||(e[10]=r=>d.value=!1)},null,8,["modelValue"])]),e[31]||(e[31]=o("pre",{class:"code-block"},[o("code",null,'<PPYearPickerIsland v-model="isOpen" />')],-1))]),o("div",F,[e[33]||(e[33]=o("h3",null,"Year Picker Alert",-1)),e[34]||(e[34]=o("p",{class:"custom-guide"},[o("strong",null,"Component:"),l(),o("code",null,"<PPYearPickerAlert>")],-1)),o("div",L,[n(t(u),{onClick:e[11]||(e[11]=r=>s.value=!0)},{default:c(()=>[...e[32]||(e[32]=[l("Open Year Alert",-1)])]),_:1}),n(t(S),{modelValue:s.value,"onUpdate:modelValue":e[12]||(e[12]=r=>s.value=r),title:"Select a Year",showActionButtons:!0,onConfirm:e[13]||(e[13]=r=>{i("Confirmed: "+(r?r.year:"")),s.value=!1}),onCancel:e[14]||(e[14]=r=>s.value=!1)},null,8,["modelValue"])]),e[35]||(e[35]=o("pre",{class:"code-block"},[o("code",null,'<PPYearPickerAlert v-model="isOpen" />')],-1))]),e[37]||(e[37]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-radius: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[38]||(e[38]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
<div class="guide-section">
        <h2>13.5. Year Picker</h2>

        <div class="variant-group">
          <h3>Standard Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Single' }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPYearPicker 
              @year-selected="s => alertVal('Selected Year: ' + s.year)"
            />
          </div>
          <pre class="code-block"><code>&lt;PPYearPicker @year-selected="onSelect" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Range Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Range' }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPYearPicker 
              :config="{ selectionMode: 'Range' }"
              @range-selected="(start, end) => alertVal('Range: ' + (start ? start.year : '') + ' to ' + (end ? end.year : ''))"
            />
          </div>
          <pre class="code-block"><code>&lt;PPYearPicker :config="{ selectionMode: 'Range' }" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Year Picker Bottom Sheet</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPYearPickerSheet&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showYearPickerSheet = true">Open Year Sheet</PPButton>
            <PPYearPickerSheet 
              v-model="showYearPickerSheet"
              title="Select a Year"
              :showActionButtons="true"
              @confirm="(s) => { alertVal('Confirmed: ' + (s ? s.year : '')); showYearPickerSheet = false; }"
              @cancel="showYearPickerSheet = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPYearPickerSheet v-model="isOpen" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Year Picker Island Popup</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPYearPickerIsland&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showYearPickerIsland = true">Open Year Picker Island</PPButton>
            <PPYearPickerIsland 
              v-model="showYearPickerIsland"
              :showActionButtons="true"
              @confirm="s => { alertVal('Confirmed Year: ' + (s ? s.year : 'none')); showYearPickerIsland = false; }"
              @cancel="showYearPickerIsland = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPYearPickerIsland v-model="isOpen" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Year Picker Alert</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPYearPickerAlert&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showYearPickerAlert = true">Open Year Alert</PPButton>
            <PPYearPickerAlert 
              v-model="showYearPickerAlert"
              title="Select a Year"
              :showActionButtons="true"
              @confirm="(s) => { alertVal('Confirmed: ' + (s ? s.year : '')); showYearPickerAlert = false; }"
              @cancel="showYearPickerAlert = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPYearPickerAlert v-model="isOpen" /&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-radius: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
const yearModel = ref(null);

const showYearPickerSheet = ref(false);

const showYearPickerAlert = ref(false);

const showYearPickerIsland = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem , PPYearPickerInput } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{G as _};
