import{d as v,o as f,j as y,l as o,a as t,w as u,A as c,u as n,ax as d,F as C,p}from"../vendors/vendor-ah_eQdvw.js";import{E as b,_ as x,m as O}from"./AccountCardSection-DXixqG3L.js";import{_ as h}from"./App-D7rwXoHs.js";const L={class:"guide-section"},k={class:"demo-box"},P={class:"demo-box"},A={class:"demo-box"},D=v({__name:"ActionSheetsSection",setup($){const l=p(!1),a=p(!1),r=p(!1),g=s=>console.log("Country:",s),S=s=>console.log("Language:",s),m=s=>console.log("Sort:",s);return(s,e)=>(f(),y(C,null,[o("div",L,[e[9]||(e[9]=o("h2",null,"Action Sheets",-1)),e[10]||(e[10]=o("p",null,"A collection of specific action sheets used across the application.",-1)),e[11]||(e[11]=o("h3",null,"Country Code Sheet",-1)),o("div",k,[t(n(d),{onClick:e[0]||(e[0]=i=>l.value=!0)},{default:u(()=>[...e[6]||(e[6]=[c("Select Country",-1)])]),_:1}),t(n(b),{"is-open":l.value,onDidDismiss:e[1]||(e[1]=i=>l.value=!1),onSelect:g},null,8,["is-open"])]),e[12]||(e[12]=o("h3",null,"Language Sheet",-1)),o("div",P,[t(n(d),{onClick:e[2]||(e[2]=i=>a.value=!0)},{default:u(()=>[...e[7]||(e[7]=[c("Select Language",-1)])]),_:1}),t(n(x),{"is-open":a.value,onDidDismiss:e[3]||(e[3]=i=>a.value=!1),onSelect:S},null,8,["is-open"])]),e[13]||(e[13]=o("h3",null,"Sort Sheet",-1)),o("div",A,[t(n(d),{onClick:e[4]||(e[4]=i=>r.value=!0)},{default:u(()=>[...e[8]||(e[8]=[c("Sort Options",-1)])]),_:1}),t(n(O),{"is-open":r.value,onDidDismiss:e[5]||(e[5]=i=>r.value=!1),onSelect:m},null,8,["is-open"])]),e[14]||(e[14]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[15]||(e[15]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="guide-section">
    <h2>Action Sheets</h2>
    <p>A collection of specific action sheets used across the application.</p>

    <h3>Country Code Sheet</h3>
    <div class="demo-box">
      <ion-button @click="isCountryOpen = true">Select Country</ion-button>
      <PPCountryCodeSheet
        :is-open="isCountryOpen"
        @did-dismiss="isCountryOpen = false"
        @select="onCountrySelect"
      />
    </div>

    <h3>Language Sheet</h3>
    <div class="demo-box">
      <ion-button @click="isLanguageOpen = true">Select Language</ion-button>
      <PPLanguageSheet
        :is-open="isLanguageOpen"
        @did-dismiss="isLanguageOpen = false"
        @select="onLanguageSelect"
      />
    </div>

    <h3>Sort Sheet</h3>
    <div class="demo-box">
      <ion-button @click="isSortOpen = true">Sort Options</ion-button>
      <PPSortSheet
        :is-open="isSortOpen"
        @did-dismiss="isSortOpen = false"
        @select="onSortSelect"
      />
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { IonButton } from '@ionic/vue';
import { PPCountryCodeSheet, PPLanguageSheet, PPSortSheet } from '@phanna/ui-framework';

const isCountryOpen = ref(false);
const isLanguageOpen = ref(false);
const isSortOpen = ref(false);

const onCountrySelect = (code: any) => console.log('Country:', code);
const onLanguageSelect = (lang: any) => console.log('Language:', lang);
const onSortSelect = (sort: any) => console.log('Sort:', sort);
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),F=h(D,[["__scopeId","data-v-6c8a7229"]]);export{F as A};
