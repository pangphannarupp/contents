var $=Object.defineProperty;var z=(o,n,a)=>n in o?$(o,n,{enumerable:!0,configurable:!0,writable:!0,value:a}):o[n]=a;var P=(o,n,a)=>z(o,typeof n!="symbol"?n+"":n,a);import{o as F,q as v,P as C,p as H,r as E,C as U}from"./AccountCardSection-DXixqG3L.js";import{d as W,o as G,j as q,l as t,A as i,a as u,u as p,w as S,y as Z,L as J,F as Q,m as X,p as b}from"../vendors/vendor-ah_eQdvw.js";const _={1:"១កើត",2:"២កើត",3:"៣កើត",4:"៤កើត",5:"៥កើត",6:"៦កើត",7:"៧កើត",8:"៨កើត",9:"៩កើត",10:"១០កើត",11:"១១កើត",12:"១២កើត",13:"១៣កើត",14:"១៤កើត",15:"១៥កើត",16:"១រោច",17:"២រោច",18:"៣រោច",19:"៤រោច",20:"៥រោច",21:"៦រោច",22:"៧រោច",23:"៨រោច",24:"៩រោច",25:"១០រោច",26:"១១រោច",27:"១២រោច",28:"១៣រោច",29:"១៤រោច",30:"១៥រោច"},k={0:"០",1:"១",2:"២",3:"៣",4:"៤",5:"៥",6:"៦",7:"៧",8:"៨",9:"៩"},ee=["មិគសិរ","បុស្ស","មាឃ","ផល្គុន","ចេត្រ","ពិសាខ","ជេស្ឋ","អាសាឍ","ស្រាពណ៍","ភទ្របទ","អស្សុជ","កត្តិក"],te=["មិគសិរ","បុស្ស","មាឃ","ផល្គុន","ចេត្រ","ពិសាខ","ជេស្ឋ","បឋមាសាឍ","ទុតិយាសាឍ","ស្រាពណ៍","ភទ្របទ","អស្សុជ","កត្តិក"],oe=["ជូត","ឆ្លូវ","ខាល","ថោះ","រោង","ម្សាញ់","មមី","មមែ","វក","រកា","ច","កុរ"],ne=["ឯកស័ក","ទោស័ក","ត្រីស័ក","ចត្វាស័ក","បញ្ចស័ក","ឆស័ក","សប្តស័ក","អដ្ឋស័ក","នព្វស័ក","សំរឹទ្ធិស័ក"];function w(o,n){let a=o;for(const[r,s]of Object.entries(n))a=a.replace(new RegExp(r,"g"),s);return a}function ae(o){return o%4===0&&o%100!==0||o%400===0}function re(o){return ae(o)?366:365}function A(o,n,a){const r=new Date(a,n-1,o,0,0,0,0),s=new Date(a,0,1,0,0,0,0),d=r.getTime()-s.getTime();return Math.floor(d/864e5)}function I(o){return o+544}function L(o){return Math.floor((I(o)*292207+499)/800)+4}function O(o){return(11*L(o)+25)%692}function K(o){const n=L(o);return(Math.floor((11*n+25)/692)+n+29)%30}function le(o){return 800-(I(o)*292207+499)%800<=207}function M(o){const n=O(o),a=K(o);let r=a>=25||a<=5,s=!1;return le(o)?s=n<=126:n<=137&&(s=O(o+1)!==0),a===25&&K(o+1)===5&&(r=!1),a===24&&K(o+1)===6&&(r=!0),r&&s?3:r?1:s?2:0}function D(o){const n=M(o);return n===3||n===1?"leap-month":n===2||M(o-1)===3?"leap-day":"normal"}function se(o){const n=D(o);return n==="leap-month"?384:n==="leap-day"?355:354}function f(o,n){const a=D(n)==="leap-month"?13:12;return((o-1)%a+a)%a+1}function de(o,n){const a=f(o,n);return D(n)==="leap-month"?te[a-1]:ee[a-1]}function y(o,n){const a=f(o,n),r=D(n);return r==="leap-month"?a===8||a===9||(a>9?a-1:a)%2===0?30:29:a===7?r==="leap-day"?30:29:a%2===0?30:29}function T(o){let n=2,a=1;for(let r=1900;r<o;r++){for(a+=re(r)-se(r);a>y(n,r);)a-=y(n,r),n=f(n+1,r);for(;a<=0;)n=f(n-1,r),a+=y(n,r)}return[n,a]}function Y(o,n,a,r){let s=o,d=n;for(let c=0;c<r;c++)d+=1,d>y(s,a)&&(d=1,s=f(s+1,a));return[s,d]}function ie(o){let r=new Date(o,3,10,0,0,0,0);const s=new Date(o,4,31,0,0,0,0);for(;r.getTime()<=s.getTime();){const d=T(o),c=A(r.getDate(),r.getMonth()+1,o),m=Y(d[0],d[1],o,c);if(m[0]===6&&m[1]===16)return new Date(r);r.setDate(r.getDate()+1)}return new Date(o,4,15,0,0,0,0)}function ce(o){return oe[((o-2020)%12+12)%12]}function ue(o){return ne[((o-2019)%10+10)%10]}class pe{constructor(n,a,r){P(this,"day");P(this,"month");P(this,"year");if(n instanceof Date)this.day=n.getDate(),this.month=n.getMonth()+1,this.year=n.getFullYear();else if(typeof n=="number"&&typeof a=="number"&&typeof r=="number")this.day=n,this.month=a,this.year=r;else{const s=new Date;this.day=s.getDate(),this.month=s.getMonth()+1,this.year=s.getFullYear()}}toLunar(){const n=T(this.year),a=A(this.day,this.month,this.year),r=Y(n[0],n[1],this.year,a),s=de(r[0],this.year),d=r[1],c=new Date(this.year,this.month-1,this.day,0,0,0,0),m=this.month>4||this.month===4&&this.day>=14?this.year:this.year-1,e=ce(m),l=ue(m),g=ie(this.year);let x=this.year+543;c.getTime()>=g.getTime()&&(x=this.year+544);const h=x,B=w(h.toString(),k),R=h-621,j=h-1181,V=w(R.toString(),k),N=w(j.toString(),k);return{lunarDay:_[d.toString()]||"",lunarMonth:s,lunarYear:B,zodiacYear:e,stem:l,lunarDayNumber:d,ms:V,cs:N,lunarYearInt:h}}}const me={class:"guide-section"},ge={class:"variant-group"},fe={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},he={class:"variant-group"},Pe={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},ve={class:"variant-group"},be={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},ye={class:"variant-group"},De={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},Ce={class:"variant-group"},Se={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden"}},ke={class:"variant-group"},we={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},Ke={class:"variant-group"},xe={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},Oe={class:"variant-group"},Me={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},Ae={class:"variant-group"},Ie={class:"component-demo",style:{background:"#f4f6f9",padding:"20px","border-radius":"12px","font-size":"16px"}},Be=W({__name:"CalendarKhmerSection",setup(o){const n=X(()=>{const e=new pe().toLunar();return`${e.lunarDay} ខែ${e.lunarMonth} ឆ្នាំ${e.zodiacYear} ${e.stem} ព.ស. ${e.lunarYear}`}),a=b(null),r=b(!1),s=b(!1),d=b(!1),c=m=>console.log("Setup: "+m);return(m,e)=>(G(),q(Q,null,[t("div",me,[e[48]||(e[48]=t("h2",null,"11. Khmer Calendar",-1)),t("div",ge,[e[17]||(e[17]=t("h3",null,"Input Wrapper",-1)),e[18]||(e[18]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),i(),t("code",null,"<PPKhmerDatePicker>")],-1)),t("div",fe,[u(p(F),{modelValue:a.value,"onUpdate:modelValue":e[0]||(e[0]=l=>a.value=l)},null,8,["modelValue"])]),e[19]||(e[19]=t("pre",{class:"code-block"},[t("code",null,'<PPKhmerDatePicker v-model="date" />')],-1))]),t("div",he,[e[20]||(e[20]=t("h3",null,"Standard Selection",-1)),e[21]||(e[21]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),i(),t("code",null,"config={ selectionMode: 'Single' }"),i(" (default)")],-1)),t("div",Pe,[u(p(v),{onDateSelected:e[1]||(e[1]=l=>c("Selected Date: "+l.date.toLocaleDateString()+`
Khmer Date: `+l.fullText))})]),e[22]||(e[22]=t("pre",{class:"code-block"},[t("code",null,'<PPKhmerCalendar @date-selected="onSelect" />')],-1))]),t("div",ve,[e[23]||(e[23]=t("h3",null,"Range Selection & Limits",-1)),e[24]||(e[24]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),i(),t("code",null,"config={ selectionMode: 'Range', minDate: ..., maxDate: ... }")],-1)),t("div",be,[u(p(v),{config:{selectionMode:"Range",minDate:new Date(new Date().getFullYear(),new Date().getMonth(),1),maxDate:new Date(new Date().getFullYear(),new Date().getMonth()+1,0)},onRangeSelected:e[2]||(e[2]=(l,g)=>c("Range: "+(l?l.date.toLocaleDateString():"")+" to "+(g?g.date.toLocaleDateString():"")))},null,8,["config"])]),e[25]||(e[25]=t("pre",{class:"code-block"},[t("code",null,`<PPKhmerCalendar :config="{ selectionMode: 'Range', minDate, maxDate }" />`)],-1))]),t("div",ye,[e[26]||(e[26]=t("h3",null,"Week Selection",-1)),e[27]||(e[27]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),i(),t("code",null,"config={ selectionMode: 'Week' }")],-1)),t("div",De,[u(p(v),{config:{selectionMode:"Week"},onRangeSelected:e[3]||(e[3]=(l,g)=>c("Week: "+(l?l.date.toLocaleDateString():"")+" to "+(g?g.date.toLocaleDateString():"")))})]),e[28]||(e[28]=t("pre",{class:"code-block"},[t("code",null,`<PPKhmerCalendar :config="{ selectionMode: 'Week' }" />`)],-1))]),t("div",Ce,[e[29]||(e[29]=t("h3",null,"Hide Header Controls",-1)),e[30]||(e[30]=t("p",{class:"custom-guide"},[t("strong",null,"Props:"),i(),t("code",null,"hideHeaderPicker"),i(", "),t("code",null,"hideNavButtons")],-1)),t("div",Se,[u(p(v),{"hide-header-picker":!0,"hide-nav-buttons":!0,onDateSelected:e[4]||(e[4]=l=>c("Selected Date: "+l.date.toLocaleDateString()+`
Khmer Date: `+l.fullText))})]),e[31]||(e[31]=t("pre",{class:"code-block"},[t("code",null,'<PPKhmerCalendar :hide-header-picker="true" :hide-nav-buttons="true" />')],-1))]),t("div",ke,[e[33]||(e[33]=t("h3",null,"Calendar Bottom Sheet",-1)),e[34]||(e[34]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),i(),t("code",null,"<PPKhmerCalendarSheet>")],-1)),t("div",we,[u(p(C),{onClick:e[5]||(e[5]=l=>r.value=!0)},{default:S(()=>[...e[32]||(e[32]=[i("Open Calendar Sheet",-1)])]),_:1}),u(p(H),{modelValue:r.value,"onUpdate:modelValue":e[6]||(e[6]=l=>r.value=l),title:"Select a Date",showActionButtons:!0,onConfirm:e[7]||(e[7]=l=>{c("Confirmed: "+(l?l.date.toLocaleDateString():"")),r.value=!1}),onCancel:e[8]||(e[8]=l=>r.value=!1)},null,8,["modelValue"])]),e[35]||(e[35]=t("pre",{class:"code-block"},[t("code",null,'<PPKhmerCalendarSheet v-model="isOpen" />')],-1))]),t("div",Ke,[e[37]||(e[37]=t("h3",null,"Calendar Alert Popup",-1)),e[38]||(e[38]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),i(),t("code",null,"<PPKhmerCalendarAlert>")],-1)),t("div",xe,[u(p(C),{onClick:e[9]||(e[9]=l=>s.value=!0)},{default:S(()=>[...e[36]||(e[36]=[i("Open Calendar Alert",-1)])]),_:1}),u(p(E),{modelValue:s.value,"onUpdate:modelValue":e[10]||(e[10]=l=>s.value=l),title:"Select a Date",showActionButtons:!0,onConfirm:e[11]||(e[11]=l=>{c("Confirmed: "+(l?l.date.toLocaleDateString():"")),s.value=!1}),onCancel:e[12]||(e[12]=l=>s.value=!1)},null,8,["modelValue"])]),e[39]||(e[39]=t("pre",{class:"code-block"},[t("code",null,'<PPKhmerCalendarAlert v-model="isOpen" />')],-1))]),t("div",Oe,[e[41]||(e[41]=t("h3",null,"Calendar Island Popup",-1)),e[42]||(e[42]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),i(),t("code",null,"<PPKhmerCalendarIsland>")],-1)),t("div",Me,[u(p(C),{onClick:e[13]||(e[13]=l=>d.value=!0)},{default:S(()=>[...e[40]||(e[40]=[i("Open Calendar Island",-1)])]),_:1}),u(p(U),{modelValue:d.value,"onUpdate:modelValue":e[14]||(e[14]=l=>d.value=l),title:"Select a Date",showActionButtons:!0,onConfirm:e[15]||(e[15]=l=>{c("Confirmed: "+(l?l.date.toLocaleDateString():"")),d.value=!1}),onCancel:e[16]||(e[16]=l=>d.value=!1)},null,8,["modelValue"])]),e[43]||(e[43]=t("pre",{class:"code-block"},[t("code",null,'<PPKhmerCalendarIsland v-model="isOpen" />')],-1))]),t("div",Ae,[e[45]||(e[45]=t("h3",null,"Direct TS Utility Access (KhmerDate.ts)",-1)),e[46]||(e[46]=t("p",{class:"custom-guide"},[i("You can import the raw "),t("code",null,"KhmerDate.ts"),i(" file directly from the framework's dist folder. This allows developers to read or modify the unminified business logic directly in their own build process!")],-1)),t("div",Ie,[e[44]||(e[44]=t("strong",null,"Today is:",-1)),i(" "+Z(n.value),1)]),e[47]||(e[47]=t("pre",{class:"code-block"},[t("code",null,"import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';\n\nconst khmerDate = new KhmerDate();\nconst dateObj = khmerDate.toLunar();\nconsole.log(`${dateObj.lunarDay} ខែ${dateObj.lunarMonth} ឆ្នាំ${dateObj.zodiacYear}`);")],-1))]),e[49]||(e[49]=J(`<div class="variant-group"><h3>Customizing KhmerDate.ts in Your Project Scope</h3><div class="guide-intro" style="background:#fff8e1;border-left-color:#fbbc05;"><strong>Best Practice:</strong> Modifying files directly inside <code>node_modules</code> is an anti-pattern because your changes will be erased during the next package installation. Since the framework provides the unminified <code>KhmerDate.ts</code>, you can easily copy it into your own project and apply specific business logic. </div><ol class="custom-guide" style="padding-left:20px;margin-bottom:24px;"><li style="margin-bottom:12px;"><strong>Locate the source file:</strong> Find the unminified TypeScript file at <code>node_modules/@phanna/ui-framework/dist/KhmerDate.ts</code>. </li><li style="margin-bottom:12px;"><strong>Copy to your project:</strong> Copy the file into a utility directory in your local source code (e.g., <code>src/utils/KhmerDate.ts</code>). </li><li style="margin-bottom:12px;"><strong>Apply customizations:</strong> Edit your local copy to modify date calculations, override string formats, or inject your custom business logic. </li><li style="margin-bottom:12px;"><strong>Update imports:</strong> Point your application&#39;s imports to your newly customized local file. </li></ol><pre class="code-block"><code>// ❌ Instead of importing from the framework:
// import { KhmerDate } from &#39;@phanna/ui-framework/dist/KhmerDate&#39;;

// ✅ Import your locally customized version:
import { KhmerDate } from &#39;@/utils/KhmerDate&#39;;

const khmerDate = new KhmerDate();
const dateObj = khmerDate.toLunar();
// Now executes YOUR specific business logic!</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-special-color: /* value */;
  --pp-calendar-subtitle-color: /* value */;
  --pp-calendar-subtitle-text: /* value */;
  --pp-calendar-sunday-color: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-danger-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[50]||(e[50]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>11. Khmer Calendar</h2>

        <div class="variant-group">
          <h3>Standard Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Single' }</code> (default)</p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPKhmerCalendar 
              @date-selected="s => alertVal('Selected Date: ' + s.date.toLocaleDateString() + '\\nKhmer Date: ' + s.fullText)"
            />
          </div>
          <pre class="code-block"><code>&lt;PPKhmerCalendar @date-selected="onSelect" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Range Selection & Limits</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Range', minDate: ..., maxDate: ... }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPKhmerCalendar 
              :config="{ 
                selectionMode: 'Range', 
                minDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1), 
                maxDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0) 
              }"
              @range-selected="(start, end) => alertVal('Range: ' + (start ? start.date.toLocaleDateString() : '') + ' to ' + (end ? end.date.toLocaleDateString() : ''))"
            />
          </div>
          <pre class="code-block"><code>&lt;PPKhmerCalendar :config="{ selectionMode: 'Range', minDate, maxDate }" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Week Selection</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>config={ selectionMode: 'Week' }</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPKhmerCalendar 
              :config="{ selectionMode: 'Week' }"
              @range-selected="(start, end) => alertVal('Week: ' + (start ? start.date.toLocaleDateString() : '') + ' to ' + (end ? end.date.toLocaleDateString() : ''))"
            />
          </div>
          <pre class="code-block"><code>&lt;PPKhmerCalendar :config="{ selectionMode: 'Week' }" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Hide Header Controls</h3>
          <p class="custom-guide"><strong>Props:</strong> <code>hideHeaderPicker</code>, <code>hideNavButtons</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden;">
            <PPKhmerCalendar 
              :hide-header-picker="true"
              :hide-nav-buttons="true"
              @date-selected="s => alertVal('Selected Date: ' + s.date.toLocaleDateString() + '\\nKhmer Date: ' + s.fullText)"
            />
          </div>
          <pre class="code-block"><code>&lt;PPKhmerCalendar :hide-header-picker="true" :hide-nav-buttons="true" /&gt;</code></pre>
        </div>



        <div class="variant-group">
          <h3>Calendar Bottom Sheet</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPKhmerCalendarSheet&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showCalendarSheet = true">Open Calendar Sheet</PPButton>
            <PPKhmerCalendarSheet 
              v-model="showCalendarSheet"
              title="Select a Date"
              :showActionButtons="true"
              @confirm="(d) => { alertVal('Confirmed: ' + (d ? d.date.toLocaleDateString() : '')); showCalendarSheet = false; }"
              @cancel="showCalendarSheet = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPKhmerCalendarSheet v-model="isOpen" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Calendar Alert Popup</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPKhmerCalendarAlert&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showAlertCalendar = true">Open Calendar Alert</PPButton>
            <PPKhmerCalendarAlert 
              v-model="showAlertCalendar"
              title="Select a Date"
              :showActionButtons="true"
              @confirm="(d) => { alertVal('Confirmed: ' + (d ? d.date.toLocaleDateString() : '')); showAlertCalendar = false; }"
              @cancel="showAlertCalendar = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPKhmerCalendarAlert v-model="isOpen" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Calendar Island Popup</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPKhmerCalendarIsland&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showKhmerCalendarIsland = true">Open Calendar Island</PPButton>
            <PPKhmerCalendarIsland 
              v-model="showKhmerCalendarIsland"
              title="Select a Date"
              :showActionButtons="true"
              @confirm="(d) => { alertVal('Confirmed: ' + (d ? d.date.toLocaleDateString() : '')); showKhmerCalendarIsland = false; }"
              @cancel="showKhmerCalendarIsland = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPKhmerCalendarIsland v-model="isOpen" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Direct TS Utility Access (KhmerDate.ts)</h3>
          <p class="custom-guide">You can import the raw <code>KhmerDate.ts</code> file directly from the framework's dist folder. This allows developers to read or modify the unminified business logic directly in their own build process!</p>
          <div class="component-demo" style="background: #f4f6f9; padding: 20px; border-radius: 12px; font-size: 16px;">
            <strong>Today is:</strong> {{ khmerDateDemo }}
          </div>
          <pre class="code-block" v-pre><code>import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';

const khmerDate = new KhmerDate();
const dateObj = khmerDate.toLunar();
console.log(\`\${dateObj.lunarDay} ខែ\${dateObj.lunarMonth} ឆ្នាំ\${dateObj.zodiacYear}\`);</code></pre>
        </div>

        <div class="variant-group">
          <h3>Customizing KhmerDate.ts in Your Project Scope</h3>
          <div class="guide-intro" style="background: #fff8e1; border-left-color: #fbbc05;">
            <strong>Best Practice:</strong> Modifying files directly inside <code>node_modules</code> is an anti-pattern because your changes will be erased during the next package installation. Since the framework provides the unminified <code>KhmerDate.ts</code>, you can easily copy it into your own project and apply specific business logic.
          </div>
          
          <ol class="custom-guide" style="padding-left: 20px; margin-bottom: 24px;">
            <li style="margin-bottom: 12px;">
              <strong>Locate the source file:</strong> Find the unminified TypeScript file at <code>node_modules/@phanna/ui-framework/dist/KhmerDate.ts</code>.
            </li>
            <li style="margin-bottom: 12px;">
              <strong>Copy to your project:</strong> Copy the file into a utility directory in your local source code (e.g., <code>src/utils/KhmerDate.ts</code>).
            </li>
            <li style="margin-bottom: 12px;">
              <strong>Apply customizations:</strong> Edit your local copy to modify date calculations, override string formats, or inject your custom business logic.
            </li>
            <li style="margin-bottom: 12px;">
              <strong>Update imports:</strong> Point your application's imports to your newly customized local file.
            </li>
          </ol>

          <pre class="code-block" v-pre><code>// ❌ Instead of importing from the framework:
// import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';

// ✅ Import your locally customized version:
import { KhmerDate } from '@/utils/KhmerDate';

const khmerDate = new KhmerDate();
const dateObj = khmerDate.toLunar();
// Now executes YOUR specific business logic!</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-cell-height: /* value */;
  --pp-calendar-day-disabled-opacity: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-selected-text: /* value */;
  --pp-calendar-special-color: /* value */;
  --pp-calendar-subtitle-color: /* value */;
  --pp-calendar-subtitle-text: /* value */;
  --pp-calendar-sunday-color: /* value */;
  --pp-calendar-text: /* value */;
  --pp-calendar-today-border: /* value */;
  --pp-calendar-wheel-active: /* value */;
  --pp-calendar-wheel-text: /* value */;
  --pp-danger-color: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const khmerDateDemo = computed(() => {
  const khmerDate = new KhmerDate();
  const dateObj = khmerDate.toLunar();
  return \`\${dateObj.lunarDay} ខែ\${dateObj.lunarMonth} ឆ្នាំ\${dateObj.zodiacYear} \${dateObj.stem} ព.ស. \${dateObj.lunarYear}\`;
});const showCalendarSheet = ref(false);

const showAlertCalendar = ref(false);

const showKhmerCalendarIsland = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{Be as _};
