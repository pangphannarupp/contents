import{bL as s}from"./AccountCardSection-DXixqG3L.js";import{d as c,p as l,o as g,j as f,l as t,a as r,u as i,F as y}from"../vendors/vendor-ah_eQdvw.js";import{_ as b}from"./App-D7rwXoHs.js";const S={class:"guide-section"},T={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"48px"}},P={class:"demo-box"},x=c({__name:"TransferListSection",setup(L){const o=l((()=>{const n=[];for(let e=1;e<=10;e++)n.push({key:e.toString(),label:`Item ${e}`,disabled:e%4===0});return n})()),d=l(["1","3"]),u=l(["1","3"]),v=l(["1","3"]),m=l(["1","3"]),p=l(["1","3"]);return(n,e)=>(g(),f(y,null,[t("div",S,[e[9]||(e[9]=t("h2",null,"Transfer List",-1)),e[10]||(e[10]=t("p",null,"A component for moving items between two lists.",-1)),e[11]||(e[11]=t("h3",null,"Variants",-1)),t("div",T,[t("div",null,[e[5]||(e[5]=t("h4",{style:{"margin-bottom":"16px"}},"Outlined (Default)",-1)),r(i(s),{modelValue:u.value,"onUpdate:modelValue":e[0]||(e[0]=a=>u.value=a),data:o.value,titles:["Source","Target"],variant:"outlined"},null,8,["modelValue","data"])]),t("div",null,[e[6]||(e[6]=t("h4",{style:{"margin-bottom":"16px"}},"Filled",-1)),r(i(s),{modelValue:v.value,"onUpdate:modelValue":e[1]||(e[1]=a=>v.value=a),data:o.value,titles:["Source","Target"],variant:"filled"},null,8,["modelValue","data"])]),t("div",null,[e[7]||(e[7]=t("h4",{style:{"margin-bottom":"16px"}},"Soft (Tonal)",-1)),r(i(s),{modelValue:m.value,"onUpdate:modelValue":e[2]||(e[2]=a=>m.value=a),data:o.value,titles:["Source","Target"],variant:"soft"},null,8,["modelValue","data"])]),t("div",null,[e[8]||(e[8]=t("h4",{style:{"margin-bottom":"16px"}},"Elevated (3D)",-1)),r(i(s),{modelValue:p.value,"onUpdate:modelValue":e[3]||(e[3]=a=>p.value=a),data:o.value,titles:["Source","Target"],variant:"elevated"},null,8,["modelValue","data"])])]),e[12]||(e[12]=t("pre",{class:"code-block"},[t("code",null,`<PPTransferList variant="outlined" ... />
<PPTransferList variant="filled" ... />
<PPTransferList variant="soft" ... />
<PPTransferList variant="elevated" ... />`)],-1)),e[13]||(e[13]=t("h3",null,"Vertical Layout",-1)),t("div",P,[r(i(s),{modelValue:d.value,"onUpdate:modelValue":e[4]||(e[4]=a=>d.value=a),data:o.value,titles:["Source","Target"],direction:"vertical"},null,8,["modelValue","data"])]),e[14]||(e[14]=t("pre",{class:"code-block"},[t("code",null,`<PPTransferList
  v-model="targetKeys"
  :data="dataSource"
  :titles="['Source', 'Target']"
  direction="vertical"
/>`)],-1)),e[15]||(e[15]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[16]||(e[16]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="guide-section">
    <h2>Transfer List</h2>
    <p>A component for moving items between two lists.</p>

    <h3>Variants</h3>
    <div class="demo-box" style="display: flex; flex-direction: column; gap: 48px;">
      
      <!-- Outlined -->
      <div>
        <h4 style="margin-bottom: 16px;">Outlined (Default)</h4>
        <PPTransferList
          v-model="targetKeysOutlined"
          :data="dataSource"
          :titles="['Source', 'Target']"
          variant="outlined"
        />
      </div>

      <!-- Filled -->
      <div>
        <h4 style="margin-bottom: 16px;">Filled</h4>
        <PPTransferList
          v-model="targetKeysFilled"
          :data="dataSource"
          :titles="['Source', 'Target']"
          variant="filled"
        />
      </div>

      <!-- Soft -->
      <div>
        <h4 style="margin-bottom: 16px;">Soft (Tonal)</h4>
        <PPTransferList
          v-model="targetKeysSoft"
          :data="dataSource"
          :titles="['Source', 'Target']"
          variant="soft"
        />
      </div>

      <!-- Elevated -->
      <div>
        <h4 style="margin-bottom: 16px;">Elevated (3D)</h4>
        <PPTransferList
          v-model="targetKeysElevated"
          :data="dataSource"
          :titles="['Source', 'Target']"
          variant="elevated"
        />
      </div>

    </div>
    <pre class="code-block"><code>&lt;PPTransferList variant="outlined" ... /&gt;
&lt;PPTransferList variant="filled" ... /&gt;
&lt;PPTransferList variant="soft" ... /&gt;
&lt;PPTransferList variant="elevated" ... /&gt;</code></pre>
    
    <h3>Vertical Layout</h3>
    <div class="demo-box">
      <PPTransferList
        v-model="targetKeys"
        :data="dataSource"
        :titles="['Source', 'Target']"
        direction="vertical"
      />
    </div>
    <pre class="code-block"><code>&lt;PPTransferList
  v-model="targetKeys"
  :data="dataSource"
  :titles="['Source', 'Target']"
  direction="vertical"
/&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPTransferList } from '@phanna/ui-framework';

const generateData = () => {
  const data = [];
  for (let i = 1; i <= 10; i++) {
    data.push({
      key: i.toString(),
      label: \`Item \${i}\`,
      disabled: i % 4 === 0
    });
  }
  return data;
};

const dataSource = ref(generateData());
const targetKeys = ref<string[]>(['1', '3']);
const targetKeysOutlined = ref<string[]>(['1', '3']);
const targetKeysFilled = ref<string[]>(['1', '3']);
const targetKeysSoft = ref<string[]>(['1', '3']);
const targetKeysElevated = ref<string[]>(['1', '3']);
<\/script>

<style scoped>
.guide-section {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.demo-box {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 24px;
  background: #f9fafb;
}
</style>
`)])],-1))],64))}}),C=b(x,[["__scopeId","data-v-d7fff2d8"]]);export{C as T};
