import{an as k,ao as g,P as m,ap as R,aq as h}from"./AccountCardSection-DXixqG3L.js";import{d as b,o as f,j as C,l as t,A as n,a,u as l,w as v,F as D,p as i}from"../vendors/vendor-ah_eQdvw.js";const S={class:"guide-section"},y={class:"variant-group"},A={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},O={class:"variant-group"},I={class:"component-demo"},V={class:"variant-group"},w={class:"component-demo"},x={class:"variant-group"},B={class:"component-demo"},T={class:"variant-group"},K={class:"component-demo"},L=b({__name:"DateRangeSection",setup(N){const u=i(null),d=i(!1),P=i(!1),r=i({start:null,end:null,presetId:void 0}),p=i({start:null,end:null,presetId:void 0}),s=c=>{console.log("Date range applied:",c)};return(c,e)=>(f(),C(D,null,[t("div",S,[e[26]||(e[26]=t("h2",null,"PPDateRangePicker",-1)),e[27]||(e[27]=t("p",{class:"guide-desc"},"A date range picker for desktop with presets and a double-month calendar view.",-1)),t("div",y,[e[8]||(e[8]=t("h3",null,"Input Wrapper",-1)),e[9]||(e[9]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),n(),t("code",null,"<PPDateRangePickerInput>")],-1)),t("div",A,[a(l(k),{modelValue:u.value,"onUpdate:modelValue":e[0]||(e[0]=o=>u.value=o)},null,8,["modelValue"])]),e[10]||(e[10]=t("pre",{class:"code-block"},[t("code",null,'<PPDateRangePickerInput v-model="dateRange" />')],-1))]),t("div",O,[e[11]||(e[11]=t("h3",null,"Desktop Usage",-1)),e[12]||(e[12]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),n(),t("code",null,"<PPDateRangePicker>")],-1)),t("div",I,[a(l(g),{modelValue:r.value,"onUpdate:modelValue":e[1]||(e[1]=o=>r.value=o),onApply:s},null,8,["modelValue"])]),e[13]||(e[13]=t("pre",{class:"code-block"},[t("code",null,'<PPDateRangePicker v-model="dateRange" />')],-1))]),t("div",V,[e[14]||(e[14]=t("h3",null,"Hide Header Controls",-1)),e[15]||(e[15]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),n(),t("code",null,"<PPDateRangePicker>"),n(" with "),t("code",null,"hide-header-picker"),n(" and "),t("code",null,"hide-nav-buttons")],-1)),t("div",w,[a(l(g),{modelValue:p.value,"onUpdate:modelValue":e[2]||(e[2]=o=>p.value=o),"hide-header-picker":!0,"hide-nav-buttons":!0,onApply:s},null,8,["modelValue"])]),e[16]||(e[16]=t("pre",{class:"code-block"},[t("code",null,'<PPDateRangePicker v-model="dateRange" :hide-header-picker="true" :hide-nav-buttons="true" />')],-1))]),t("div",x,[e[18]||(e[18]=t("h3",null,"Alert Overlay",-1)),e[19]||(e[19]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),n(),t("code",null,"<PPDateRangePickerAlert>")],-1)),t("div",B,[a(l(m),{onClick:e[3]||(e[3]=o=>P.value=!0),variant:"primary"},{default:v(()=>[...e[17]||(e[17]=[n("Open Date Range Picker Alert",-1)])]),_:1}),a(l(R),{modelValue:P.value,"onUpdate:modelValue":e[4]||(e[4]=o=>P.value=o),initialValue:r.value,onConfirm:s},null,8,["modelValue","initialValue"])]),e[20]||(e[20]=t("pre",{class:"code-block"},[t("code",null,'<PPDateRangePickerAlert v-model="isOpen" :initialValue="dateRange" @confirm="onConfirm" />')],-1))]),t("div",T,[e[23]||(e[23]=t("h3",null,"Bottom Sheet",-1)),e[24]||(e[24]=t("p",{class:"custom-guide"},[t("strong",null,"Component:"),n(),t("code",null,"<PPDateRangePickerSheet>")],-1)),t("div",K,[a(l(m),{onClick:e[5]||(e[5]=o=>d.value=!0),variant:"primary"},{default:v(()=>[...e[21]||(e[21]=[n("Open Date Range Picker Sheet",-1)])]),_:1}),a(l(h),{visible:d.value,"onUpdate:visible":e[6]||(e[6]=o=>d.value=o),modelValue:r.value,"onUpdate:modelValue":e[7]||(e[7]=o=>r.value=o),onApply:s},null,8,["visible","modelValue"]),e[22]||(e[22]=t("div",{style:{"margin-top":"16px",padding:"12px",background:"#f3f4f6","border-radius":"8px"}},[t("strong",null,"Selected Range:"),t("pre",null,"{{ JSON.stringify(dateRangeVal, null, 2) }}")],-1))]),e[25]||(e[25]=t("pre",{class:"code-block"},[t("code",null,'<PPDateRangePickerSheet v-model:visible="isOpen" v-model="dateRange" @apply="onApply" />')],-1))]),e[28]||(e[28]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[29]||(e[29]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
<div class="guide-section">
        <h2>PPDateRangePicker</h2>
        <p class="guide-desc">A date range picker for desktop with presets and a double-month calendar view.</p>
        <div class="variant-group">
          <h3>Desktop Usage</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPDateRangePicker&gt;</code></p>
          <div class="component-demo">
            <PPDateRangePicker 
              v-model="dateRangeVal"
              @apply="onDateRangeApply"
            />
          </div>
          <pre class="code-block"><code>&lt;PPDateRangePicker v-model="dateRange" /&gt;</code></pre>
        </div>
        <div class="variant-group">
          <h3>Hide Header Controls</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPDateRangePicker&gt;</code> with <code>hide-header-picker</code> and <code>hide-nav-buttons</code></p>
          <div class="component-demo">
            <PPDateRangePicker 
              v-model="dateRangeVal2"
              :hide-header-picker="true"
              :hide-nav-buttons="true"
              @apply="onDateRangeApply"
            />
          </div>
          <pre class="code-block"><code>&lt;PPDateRangePicker v-model="dateRange" :hide-header-picker="true" :hide-nav-buttons="true" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Alert Overlay</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPDateRangePickerAlert&gt;</code></p>
          <div class="component-demo">
            <PPButton @click="showDateRangePickerAlert = true" variant="primary">Open Date Range Picker Alert</PPButton>
            <PPDateRangePickerAlert 
              v-model="showDateRangePickerAlert"
              :initialValue="dateRangeVal"
              @confirm="onDateRangeApply"
            />
          </div>
          <pre class="code-block"><code>&lt;PPDateRangePickerAlert v-model="isOpen" :initialValue="dateRange" @confirm="onConfirm" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Bottom Sheet</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPDateRangePickerSheet&gt;</code></p>
          <div class="component-demo">
            <PPButton @click="showDateRangePickerSheet = true" variant="primary">Open Date Range Picker Sheet</PPButton>
            <PPDateRangePickerSheet 
              v-model:visible="showDateRangePickerSheet"
              v-model="dateRangeVal"
              @apply="onDateRangeApply"
            />
            
            <div style="margin-top: 16px; padding: 12px; background: #f3f4f6; border-radius: 8px;">
              <strong>Selected Range:</strong> 
              <pre>{{ JSON.stringify(dateRangeVal, null, 2) }}</pre>
            </div>
          </div>
          <pre class="code-block"><code>&lt;PPDateRangePickerSheet v-model:visible="isOpen" v-model="dateRange" @apply="onApply" /&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
const dateRangeModel = ref(null);

const showDateRangePickerSheet = ref(false);

const showDateRangePickerAlert = ref(false);

const dateRangeVal = ref({ start: null, end: null, presetId: undefined });
const dateRangeVal2 = ref({ start: null, end: null, presetId: undefined });

const onDateRangeApply = (val: any) => {
  console.log('Date range applied:', val);
};



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPDateRangePicker, PPDateRangePickerAlert, PPDateRangePickerSheet, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem , PPDateRangePickerInput } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{L as _};
