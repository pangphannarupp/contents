import{bD as b,bE as T,P as c,bF as C,bG as S,bH as V}from"./AccountCardSection-DXixqG3L.js";import{d as h,o as x,j as I,l,A as t,a as n,u as i,w as v,F as A,p as a}from"../vendors/vendor-ah_eQdvw.js";const O={class:"guide-section"},y={class:"variant-group"},w={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},B={class:"variant-group"},K={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",overflow:"hidden",padding:"16px"}},F={class:"variant-group"},R={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},U={class:"variant-group"},D={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},L={class:"variant-group"},N={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},G=h({__name:"TimePickerSection",setup(M){const f=a(null),g=a("13:45"),u=a("12:00"),m=a("12:00"),r=a(!1),p=a("09:30"),d=a(!1),s=a(!1),P=k=>console.log("Setup: "+k);return(k,e)=>(x(),I(A,null,[l("div",O,[e[36]||(e[36]=l("h2",null,"14. Time Picker",-1)),l("div",y,[e[18]||(e[18]=l("h3",null,"Input Wrapper",-1)),e[19]||(e[19]=l("p",{class:"custom-guide"},[l("strong",null,"Component:"),t(),l("code",null,"<PPTimePickerInput>")],-1)),l("div",w,[n(i(b),{modelValue:f.value,"onUpdate:modelValue":e[0]||(e[0]=o=>f.value=o)},null,8,["modelValue"])]),e[20]||(e[20]=l("pre",{class:"code-block"},[l("code",null,'<PPTimePickerInput v-model="time" />')],-1))]),l("div",B,[e[21]||(e[21]=l("h3",null,"Standard Time Picker",-1)),e[22]||(e[22]=l("p",{class:"custom-guide"},[l("strong",null,"Component:"),t(),l("code",null,"<PPTimePicker>")],-1)),l("div",K,[n(i(T),{modelValue:g.value,"onUpdate:modelValue":e[1]||(e[1]=o=>g.value=o),onChange:e[2]||(e[2]=o=>P("Selected Time: "+o))},null,8,["modelValue"])]),e[23]||(e[23]=l("pre",{class:"code-block"},[l("code",null,'<PPTimePicker v-model="timeVal" />')],-1))]),l("div",F,[e[25]||(e[25]=l("h3",null,"Time Picker Bottom Sheet",-1)),e[26]||(e[26]=l("p",{class:"custom-guide"},[l("strong",null,"Component:"),t(),l("code",null,"<PPTimePickerSheet>")],-1)),l("div",R,[n(i(c),{onClick:e[3]||(e[3]=o=>r.value=!0)},{default:v(()=>[...e[24]||(e[24]=[t("Open Time Sheet",-1)])]),_:1}),n(i(C),{modelValue:r.value,"onUpdate:modelValue":e[4]||(e[4]=o=>r.value=o),timeValue:u.value,"onUpdate:timeValue":e[5]||(e[5]=o=>u.value=o),title:"Select a Time",showActionButtons:!0,onConfirm:e[6]||(e[6]=()=>{P("Confirmed Time: "+u.value),r.value=!1}),onCancel:e[7]||(e[7]=o=>r.value=!1)},null,8,["modelValue","timeValue"])]),e[27]||(e[27]=l("pre",{class:"code-block"},[l("code",null,'<PPTimePickerSheet v-model="isOpen" v-model:timeValue="val" />')],-1))]),l("div",U,[e[29]||(e[29]=l("h3",null,"Time Picker Island Popup",-1)),e[30]||(e[30]=l("p",{class:"custom-guide"},[l("strong",null,"Component:"),t(),l("code",null,"<PPTimePickerIsland>")],-1)),l("div",D,[n(i(c),{onClick:e[8]||(e[8]=o=>s.value=!0)},{default:v(()=>[...e[28]||(e[28]=[t("Open Time Picker Island",-1)])]),_:1}),n(i(S),{modelValue:s.value,"onUpdate:modelValue":e[9]||(e[9]=o=>s.value=o),timeValue:m.value,"onUpdate:timeValue":e[10]||(e[10]=o=>m.value=o),showActionButtons:!0,onConfirm:e[11]||(e[11]=()=>{P("Confirmed Time: "+m.value),s.value=!1}),onCancel:e[12]||(e[12]=o=>s.value=!1)},null,8,["modelValue","timeValue"])]),e[31]||(e[31]=l("pre",{class:"code-block"},[l("code",null,'<PPTimePickerIsland v-model="isOpen" v-model:timeValue="val" />')],-1))]),l("div",L,[e[33]||(e[33]=l("h3",null,"Time Picker Alert",-1)),e[34]||(e[34]=l("p",{class:"custom-guide"},[l("strong",null,"Component:"),t(),l("code",null,"<PPTimePickerAlert>")],-1)),l("div",N,[n(i(c),{onClick:e[13]||(e[13]=o=>d.value=!0)},{default:v(()=>[...e[32]||(e[32]=[t("Open Time Alert",-1)])]),_:1}),n(i(V),{modelValue:d.value,"onUpdate:modelValue":e[14]||(e[14]=o=>d.value=o),timeValue:p.value,"onUpdate:timeValue":e[15]||(e[15]=o=>p.value=o),title:"Select a Time",onConfirm:e[16]||(e[16]=()=>{P("Confirmed Time: "+p.value),d.value=!1}),onCancel:e[17]||(e[17]=o=>d.value=!1)},null,8,["modelValue","timeValue"])]),e[35]||(e[35]=l("pre",{class:"code-block"},[l("code",null,'<PPTimePickerAlert v-model="isOpen" v-model:timeValue="val" />')],-1))]),e[37]||(e[37]=l("div",{class:"variant-group"},[l("h3",null,"Customizing CSS"),l("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),l("pre",{class:"code-block"},[l("code",null,`/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-radius: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-island-bg: /* value */;
  --pp-island-color: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[38]||(e[38]=l("div",{class:"variant-group",style:{"margin-top":"40px"}},[l("h3",null,"Full Page Source Code"),l("p",{class:"custom-guide"},"Complete source code for this section."),l("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[l("code",null,`<template>
<div class="guide-section">
        <h2>14. Time Picker</h2>

        <div class="variant-group">
          <h3>Standard Time Picker</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPTimePicker&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; overflow: hidden; padding: 16px;">
            <PPTimePicker 
              v-model="timeVal"
              @change="(v) => alertVal('Selected Time: ' + v)"
            />
          </div>
          <pre class="code-block"><code>&lt;PPTimePicker v-model="timeVal" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Time Picker Bottom Sheet</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPTimePickerSheet&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showTimePickerSheet = true">Open Time Sheet</PPButton>
            <PPTimePickerSheet 
              v-model="showTimePickerSheet"
              v-model:timeValue="timeSheetVal"
              title="Select a Time"
              :showActionButtons="true"
              @confirm="() => { alertVal('Confirmed Time: ' + timeSheetVal); showTimePickerSheet = false; }"
              @cancel="showTimePickerSheet = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPTimePickerSheet v-model="isOpen" v-model:timeValue="val" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Time Picker Island Popup</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPTimePickerIsland&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showTimePickerIsland = true">Open Time Picker Island</PPButton>
            <PPTimePickerIsland 
              v-model="showTimePickerIsland"
              v-model:timeValue="timeIslandVal"
              :showActionButtons="true"
              @confirm="() => { alertVal('Confirmed Time: ' + timeIslandVal); showTimePickerIsland = false; }"
              @cancel="showTimePickerIsland = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPTimePickerIsland v-model="isOpen" v-model:timeValue="val" /&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Time Picker Alert</h3>
          <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPTimePickerAlert&gt;</code></p>
          <div class="component-demo" style="background: #ffffff; border: 1px solid #ddd; border-radius: 12px; padding: 20px;">
            <PPButton @click="showTimePickerAlert = true">Open Time Alert</PPButton>
            <PPTimePickerAlert 
              v-model="showTimePickerAlert"
              v-model:timeValue="timeAlertVal"
              title="Select a Time"
              @confirm="() => { alertVal('Confirmed Time: ' + timeAlertVal); showTimePickerAlert = false; }"
              @cancel="showTimePickerAlert = false"
            />
          </div>
          <pre class="code-block"><code>&lt;PPTimePickerAlert v-model="isOpen" v-model:timeValue="val" /&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-bg: /* value */;
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-calendar-radius: /* value */;
  --pp-calendar-range-bg: /* value */;
  --pp-calendar-selected-bg: /* value */;
  --pp-calendar-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-island-bg: /* value */;
  --pp-island-color: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
const timeModel = ref(null);

const timeVal = ref('13:45');

const timeSheetVal = ref('12:00');

const timeIslandVal = ref('12:00');

const showTimePickerSheet = ref(false);

const timeAlertVal = ref('09:30');

const showTimePickerAlert = ref(false);

const showTimePickerIsland = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem , PPTimePickerInput } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{G as _};
