import{aX as n,aY as p}from"./AccountCardSection-DXixqG3L.js";import{d as u,o as c,j as m,l as e,a,u as i,A as t,F as v,p as d}from"../vendors/vendor-ah_eQdvw.js";import{_ as f}from"./App-D7rwXoHs.js";const h={class:"component-section"},x={class:"demo-box"},y={class:"demo-content"},b={class:"demo-box"},g={class:"demo-content"},w={class:"demo-box"},P={class:"demo-content"},q=u({__name:"MathEditorSection",setup(E){const r=d("x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}"),l=d("\\int_{0}^{\\infty} e^{-x^2} dx = \\frac{\\sqrt{\\pi}}{2}");return(M,o)=>(c(),m(v,null,[e("div",h,[o[12]||(o[12]=e("h2",null,"Math Editor",-1)),o[13]||(o[13]=e("p",null,"A zero-bundle-size LaTeX math editor that dynamically loads KaTeX for lightning-fast rendering.",-1)),e("div",x,[o[2]||(o[2]=e("h3",null,"Basic Editor with Live Preview",-1)),o[3]||(o[3]=e("p",{class:"helper-text"},"Type LaTeX or use the toolbar to insert symbols.",-1)),e("div",y,[a(i(n),{modelValue:r.value,"onUpdate:modelValue":o[0]||(o[0]=s=>r.value=s),placeholder:"Enter your LaTeX equation here..."},null,8,["modelValue"])]),o[4]||(o[4]=e("div",{class:"output-preview"},[e("h4",null,"Raw LaTeX:"),e("pre",null,[e("code",null,"{{ equation }}")])],-1)),o[5]||(o[5]=e("pre",{class:"code-block"},[e("code",null,`<PPMathEditor 
  v-model="equation" 
  placeholder="Enter your LaTeX equation here..."
/>`)],-1))]),e("div",b,[o[6]||(o[6]=e("h3",null,"Complex Equation Example",-1)),e("div",g,[a(i(n),{modelValue:l.value,"onUpdate:modelValue":o[1]||(o[1]=s=>l.value=s)},null,8,["modelValue"])])]),e("div",w,[o[9]||(o[9]=e("h3",null,"Math Preview Only",-1)),o[10]||(o[10]=e("p",{class:"helper-text"},[t("If you just want to render equations without an editor, use "),e("code",null,"PPMathPreview"),t(".")],-1)),e("div",P,[o[7]||(o[7]=t(" Inline math preview: ",-1)),a(i(p),{equation:"\\sum_{i=1}^{\\infty} \\frac{1}{n^s}",displayMode:!1}),o[8]||(o[8]=t(" works perfectly! ",-1))]),o[11]||(o[11]=e("pre",{class:"code-block"},[e("code",null,'<PPMathPreview equation="\\sum_{i=1}^{\\infty} \\frac{1}{n^s}" :displayMode="false" />')],-1))]),o[14]||(o[14]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[15]||(o[15]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Math Editor</h2>
    <p>A zero-bundle-size LaTeX math editor that dynamically loads KaTeX for lightning-fast rendering.</p>

    <!-- Basic Math Editor -->
    <div class="demo-box">
      <h3>Basic Editor with Live Preview</h3>
      <p class="helper-text">Type LaTeX or use the toolbar to insert symbols.</p>
      
      <div class="demo-content">
        <PPMathEditor 
          v-model="equation" 
          placeholder="Enter your LaTeX equation here..."
        />
      </div>

      <div class="output-preview">
        <h4>Raw LaTeX:</h4>
        <pre><code>{{ equation }}</code></pre>
      </div>

      <pre class="code-block" v-pre><code>&lt;PPMathEditor 
  v-model="equation" 
  placeholder="Enter your LaTeX equation here..."
/&gt;</code></pre>
    </div>

    <!-- Complex Example -->
    <div class="demo-box">
      <h3>Complex Equation Example</h3>
      <div class="demo-content">
        <PPMathEditor 
          v-model="complexEquation" 
        />
      </div>
    </div>

    <!-- Math Preview Only -->
    <div class="demo-box">
      <h3>Math Preview Only</h3>
      <p class="helper-text">If you just want to render equations without an editor, use <code>PPMathPreview</code>.</p>
      
      <div class="demo-content">
        Inline math preview: 
        <PPMathPreview equation="\\sum_{i=1}^{\\infty} \\frac{1}{n^s}" :displayMode="false" />
        works perfectly!
      </div>

      <pre class="code-block" v-pre><code>&lt;PPMathPreview equation="\\sum_{i=1}^{\\infty} \\frac{1}{n^s}" :displayMode="false" /&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPMathEditor, PPMathPreview } from '@phanna/ui-framework';

const equation = ref('x = \\\\frac{-b \\\\pm \\\\sqrt{b^2-4ac}}{2a}');
const complexEquation = ref('\\\\int_{0}^{\\\\infty} e^{-x^2} dx = \\\\frac{\\\\sqrt{\\\\pi}}{2}');
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
}
.helper-text {
  font-size: 13px;
  color: #666;
  margin-bottom: 16px;
}
.code-block {
  background: #282c34;
  color: #abb2bf;
  padding: 16px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 14px;
  line-height: 1.5;
  margin-top: 24px;
}

.output-preview {
  margin-top: 24px;
  padding: 16px;
  background: #f5f7fa;
  border-left: 4px solid #003399;
  border-radius: 4px;
}

.output-preview h4 {
  margin-top: 0;
  margin-bottom: 12px;
  font-size: 14px;
  color: #333;
}

.output-preview pre {
  margin: 0;
  white-space: pre-wrap;
  word-wrap: break-word;
  font-family: monospace;
  font-size: 13px;
  color: #d63384;
}
</style>
`)])],-1))],64))}}),C=f(q,[["__scopeId","data-v-1ac92242"]]);export{C as M};
