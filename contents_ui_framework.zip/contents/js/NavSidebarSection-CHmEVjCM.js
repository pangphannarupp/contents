import{d as u,o as g,j as v,l as t,a,w as s,aB as b,aH as h,bc as f,aI as x,u as l,L as y,F as S,p as n}from"../vendors/vendor-ah_eQdvw.js";import{af as d}from"./AccountCardSection-DXixqG3L.js";import{_ as P}from"./App-D7rwXoHs.js";const k={class:"component-section"},O={class:"demo-grid"},N={class:"demo-box",style:{height:"600px",padding:"0",border:"1px solid #e2e8f0"}},w={class:"demo-box",style:{height:"600px",padding:"0",background:"#f1f5f9",border:"1px solid #e2e8f0"}},C={class:"demo-box",style:{height:"600px",padding:"0",border:"1px solid #e2e8f0"}},V={class:"demo-box",style:{height:"600px",padding:"0",border:"1px solid #e2e8f0"}},M=u({__name:"NavSidebarSection",setup(I){const r=n("home"),m=n("home"),p=n("home"),c=n("home"),o=[{groupLabel:"Main",items:[{id:"home",label:"Dashboard",icon:b},{id:"users",label:"Users",icon:h}]},{groupLabel:"Management",items:[{id:"docs",label:"Documents",icon:f,children:[{id:"invoices",label:"Invoices"},{id:"reports",label:"Reports"}]},{id:"settings",label:"Settings",icon:x}]}];return(z,e)=>(g(),v(S,null,[t("div",k,[e[8]||(e[8]=t("h2",null,"Sidebar Navigation",-1)),e[9]||(e[9]=t("p",null,"A highly customizable sidebar navigation component with support for multiple themes, variants, nested items, and collapsible states.",-1)),t("div",O,[t("div",N,[a(l(d),{modelValue:r.value,"onUpdate:modelValue":e[0]||(e[0]=i=>r.value=i),items:o,theme:"dark",variant:"indicator"},{header:s(()=>[...e[4]||(e[4]=[t("div",{style:{"font-size":"18px","font-weight":"bold",color:"white"}},"Dark Indicator",-1)])]),_:1},8,["modelValue"])]),t("div",w,[a(l(d),{modelValue:m.value,"onUpdate:modelValue":e[1]||(e[1]=i=>m.value=i),items:o,theme:"light",variant:"pill"},{header:s(()=>[...e[5]||(e[5]=[t("div",{style:{"font-size":"18px","font-weight":"bold",color:"#1e293b"}},"Light Pill",-1)])]),_:1},8,["modelValue"])]),t("div",C,[a(l(d),{modelValue:p.value,"onUpdate:modelValue":e[2]||(e[2]=i=>p.value=i),items:o,theme:"dark",variant:"indicator",collapsed:!0},{header:s(()=>[...e[6]||(e[6]=[t("div",{style:{"font-size":"18px","font-weight":"bold",color:"white"}},"A",-1)])]),_:1},8,["modelValue"])]),t("div",V,[a(l(d),{modelValue:c.value,"onUpdate:modelValue":e[3]||(e[3]=i=>c.value=i),items:o,theme:"light",variant:"m3-rail"},{header:s(()=>[...e[7]||(e[7]=[t("div",{style:{"font-size":"18px","font-weight":"bold",color:"#1e293b"}},"M3",-1)])]),_:1},8,["modelValue"])])]),e[10]||(e[10]=y(`<div style="margin-top:40px;" data-v-6ad0bced><h3 data-v-6ad0bced>Usage Example</h3><pre class="code-block" style="background:#f8fafc;padding:16px;border-radius:8px;overflow-x:auto;" data-v-6ad0bced><code data-v-6ad0bced>&lt;template&gt;
  &lt;PPSidebarNavigation
    v-model=&quot;activeTab&quot;
    :items=&quot;sidebarMenu&quot;
    theme=&quot;dark&quot;
    variant=&quot;pill&quot;
    :collapsed=&quot;isCollapsed&quot;
  &gt;
    &lt;template #header&gt;
      &lt;h2&gt;Logo&lt;/h2&gt;
    &lt;/template&gt;
  &lt;/PPSidebarNavigation&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from &#39;vue&#39;;
import { homeOutline, settingsOutline } from &#39;ionicons/icons&#39;;
import { PPSidebarNavigation } from &#39;@phanna/ui-framework&#39;;

const activeTab = ref(&#39;home&#39;);
const isCollapsed = ref(false);

const sidebarMenu = [
  {
    groupLabel: &#39;Main&#39;,
    items: [
      { id: &#39;home&#39;, label: &#39;Dashboard&#39;, icon: homeOutline },
      { id: &#39;settings&#39;, label: &#39;Settings&#39;, icon: settingsOutline }
    ]
  }
];
&lt;/script&gt;</code></pre></div><div class="variant-group" data-v-6ad0bced><h3 data-v-6ad0bced>Customizing CSS</h3><p class="custom-guide" data-v-6ad0bced>You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block" data-v-6ad0bced><code data-v-6ad0bced>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[11]||(e[11]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Sidebar Navigation</h2>
    <p>A highly customizable sidebar navigation component with support for multiple themes, variants, nested items, and collapsible states.</p>

    <!-- Variants -->
    <div class="demo-grid">
      <!-- Dark Indicator -->
      <div class="demo-box" style="height: 600px; padding: 0; border: 1px solid #e2e8f0;">
        <PPSidebarNavigation
          v-model="active1"
          :items="menuItems"
          theme="dark"
          variant="indicator"
        >
          <template #header>
            <div style="font-size: 18px; font-weight: bold; color: white;">Dark Indicator</div>
          </template>
        </PPSidebarNavigation>
      </div>

      <!-- Light Pill -->
      <div class="demo-box" style="height: 600px; padding: 0; background: #f1f5f9; border: 1px solid #e2e8f0;">
        <PPSidebarNavigation
          v-model="active2"
          :items="menuItems"
          theme="light"
          variant="pill"
        >
          <template #header>
            <div style="font-size: 18px; font-weight: bold; color: #1e293b;">Light Pill</div>
          </template>
        </PPSidebarNavigation>
      </div>
      
      <!-- Collapsed -->
      <div class="demo-box" style="height: 600px; padding: 0; border: 1px solid #e2e8f0;">
        <PPSidebarNavigation
          v-model="active3"
          :items="menuItems"
          theme="dark"
          variant="indicator"
          :collapsed="true"
        >
          <template #header>
            <div style="font-size: 18px; font-weight: bold; color: white;">A</div>
          </template>
        </PPSidebarNavigation>
      </div>
      <!-- M3 Rail -->
      <div class="demo-box" style="height: 600px; padding: 0; border: 1px solid #e2e8f0;">
        <PPSidebarNavigation
          v-model="active4"
          :items="menuItems"
          theme="light"
          variant="m3-rail"
        >
          <template #header>
            <div style="font-size: 18px; font-weight: bold; color: #1e293b;">M3</div>
          </template>
        </PPSidebarNavigation>
      </div>
    </div>

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPSidebarNavigation
    v-model="activeTab"
    :items="sidebarMenu"
    theme="dark"
    variant="pill"
    :collapsed="isCollapsed"
  &gt;
    &lt;template #header&gt;
      &lt;h2&gt;Logo&lt;/h2&gt;
    &lt;/template&gt;
  &lt;/PPSidebarNavigation&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { homeOutline, settingsOutline } from 'ionicons/icons';
import { PPSidebarNavigation } from '@phanna/ui-framework';

const activeTab = ref('home');
const isCollapsed = ref(false);

const sidebarMenu = [
  {
    groupLabel: 'Main',
    items: [
      { id: 'home', label: 'Dashboard', icon: homeOutline },
      { id: 'settings', label: 'Settings', icon: settingsOutline }
    ]
  }
];
&lt;/script&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { homeOutline, settingsOutline, peopleOutline, documentTextOutline } from 'ionicons/icons';
import { PPSidebarNavigation } from '@phanna/ui-framework';

const active1 = ref('home');
const active2 = ref('home');
const active3 = ref('home');
const active4 = ref('home');

const menuItems = [
  {
    groupLabel: 'Main',
    items: [
      { id: 'home', label: 'Dashboard', icon: homeOutline },
      { id: 'users', label: 'Users', icon: peopleOutline },
    ]
  },
  {
    groupLabel: 'Management',
    items: [
      { 
        id: 'docs', 
        label: 'Documents', 
        icon: documentTextOutline,
        children: [
          { id: 'invoices', label: 'Invoices' },
          { id: 'reports', label: 'Reports' }
        ]
      },
      { id: 'settings', label: 'Settings', icon: settingsOutline }
    ]
  }
];
<\/script>

<style scoped>
.demo-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 24px;
  margin-top: 24px;
}
</style>
`)])],-1))],64))}}),D=P(M,[["__scopeId","data-v-6ad0bced"]]);export{D as N};
