import{c as s,j as t}from"../main.js";const e=s(t.jsx("path",{d:"M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"}),"Check");export{e as C};
