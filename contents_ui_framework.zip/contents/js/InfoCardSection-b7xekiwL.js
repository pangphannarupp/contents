import{aH as s}from"./AccountCardSection-DXixqG3L.js";import{d as i,o as l,j as d,l as o,a as t,w as a,A as n,u as r,F as u}from"../vendors/vendor-ah_eQdvw.js";const p={class:"guide-section"},f={class:"variant-group"},c={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"16px"}},m={class:"variant-group"},g={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"16px"}},y={class:"variant-group"},v={class:"component-demo"},I=i({__name:"InfoCardSection",setup(P){return(C,e)=>(l(),d(u,null,[o("div",p,[e[14]||(e[14]=o("h2",null,"2. PPInfoCard Styles",-1)),o("div",f,[e[5]||(e[5]=o("h3",null,"Types (Soft Variant Default)",-1)),o("div",c,[t(r(s),{type:"info"},{default:a(()=>[...e[0]||(e[0]=[n("This is an informational message to guide the user.",-1)])]),_:1}),t(r(s),{type:"success"},{default:a(()=>[...e[1]||(e[1]=[n("Your changes have been saved successfully!",-1)])]),_:1}),t(r(s),{type:"warning"},{default:a(()=>[...e[2]||(e[2]=[n("Please review your inputs before proceeding.",-1)])]),_:1}),t(r(s),{type:"error"},{default:a(()=>[...e[3]||(e[3]=[n("There was a problem processing your request.",-1)])]),_:1}),t(r(s),{type:"neutral"},{default:a(()=>[...e[4]||(e[4]=[n("This is a neutral message for general context.",-1)])]),_:1})])]),o("div",m,[e[10]||(e[10]=o("h3",null,"Variants",-1)),o("div",g,[t(r(s),{type:"info",variant:"soft"},{default:a(()=>[...e[6]||(e[6]=[n("Soft Variant (Default) - Subtle background",-1)])]),_:1}),t(r(s),{type:"info",variant:"solid"},{default:a(()=>[...e[7]||(e[7]=[n("Solid Variant - High emphasis",-1)])]),_:1}),t(r(s),{type:"info",variant:"outline"},{default:a(()=>[...e[8]||(e[8]=[n("Outline Variant - Border only",-1)])]),_:1}),t(r(s),{type:"info",variant:"glass"},{default:a(()=>[...e[9]||(e[9]=[n("Glass Variant - Frosted glass effect",-1)])]),_:1})])]),o("div",y,[e[12]||(e[12]=o("h3",null,"Custom Styles",-1)),o("div",v,[t(r(s),{type:"info",backgroundColor:"#e8f5e9",textColor:"#2e7d32",iconColor:"#1b5e20",borderRadius:"24px"},{default:a(()=>[...e[11]||(e[11]=[n(" This is a fully customized success info card using explicit style props! ",-1)])]),_:1})]),e[13]||(e[13]=o("pre",{class:"code-block"},[o("code",null,`<PPInfoCard 
  type="info" 
  backgroundColor="#e8f5e9" 
  textColor="#2e7d32" 
  iconColor="#1b5e20" 
  borderRadius="24px"
>
  This is a fully customized success info card!
</PPInfoCard>`)],-1))]),e[15]||(e[15]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[16]||(e[16]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
<div class="guide-section">
        <h2>2. PPInfoCard Styles</h2>

        <div class="variant-group">
          <h3>Types (Soft Variant Default)</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 16px;">
            <PPInfoCard type="info">This is an informational message to guide the user.</PPInfoCard>
            <PPInfoCard type="success">Your changes have been saved successfully!</PPInfoCard>
            <PPInfoCard type="warning">Please review your inputs before proceeding.</PPInfoCard>
            <PPInfoCard type="error">There was a problem processing your request.</PPInfoCard>
            <PPInfoCard type="neutral">This is a neutral message for general context.</PPInfoCard>
          </div>
        </div>

        <div class="variant-group">
          <h3>Variants</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 16px;">
            <PPInfoCard type="info" variant="soft">Soft Variant (Default) - Subtle background</PPInfoCard>
            <PPInfoCard type="info" variant="solid">Solid Variant - High emphasis</PPInfoCard>
            <PPInfoCard type="info" variant="outline">Outline Variant - Border only</PPInfoCard>
            <PPInfoCard type="info" variant="glass">Glass Variant - Frosted glass effect</PPInfoCard>
          </div>
        </div>

        <div class="variant-group">
          <h3>Custom Styles</h3>
          <div class="component-demo">
            <PPInfoCard 
              type="info" 
              backgroundColor="#e8f5e9" 
              textColor="#2e7d32" 
              iconColor="#1b5e20" 
              borderRadius="24px"
            >
              This is a fully customized success info card using explicit style props!
            </PPInfoCard>
          </div>
          <pre class="code-block"><code>&lt;PPInfoCard 
  type="info" 
  backgroundColor="#e8f5e9" 
  textColor="#2e7d32" 
  iconColor="#1b5e20" 
  borderRadius="24px"
&gt;
  This is a fully customized success info card!
&lt;/PPInfoCard&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPInfoCard } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{I as _};
