import{a as e}from"./AccountCardSection-DXixqG3L.js";import{d as i,o as r,j as a,l as o,a as s,u as t,a7 as c,aE as l,be as d,F as u}from"../vendors/vendor-ah_eQdvw.js";const p={class:"guide-section"},m={class:"variant-group",style:{background:"#f4f5f8",padding:"16px","border-radius":"8px"}},g={class:"component-demo"},v={class:"variant-group",style:{background:"var(--pp-primary, #003399)",padding:"16px","border-radius":"8px",color:"white"}},b={class:"component-demo"},f={class:"variant-group",style:{background:"#f4f5f8",padding:"16px","border-radius":"8px"}},y={class:"component-demo"},x=i({__name:"IconButtonSection",setup(h){return(P,n)=>(r(),a(u,null,[o("div",p,[n[6]||(n[6]=o("h2",null,"5. PPIconButton Variants",-1)),o("div",m,[n[0]||(n[0]=o("h3",null,"Danger",-1)),o("div",g,[s(t(e),{color:"danger",icon:t(c)},null,8,["icon"])]),n[1]||(n[1]=o("pre",{class:"code-block"},[o("code",null,'<PPIconButton color="danger" :icon="trashOutline" />')],-1))]),o("div",v,[n[2]||(n[2]=o("h3",{style:{color:"white"}},"White (on dark backgrounds)",-1)),o("div",b,[s(t(e),{color:"white",badge:"",icon:t(l)},null,8,["icon"])]),n[3]||(n[3]=o("pre",{class:"code-block"},[o("code",null,'<PPIconButton color="white" badge :icon="notificationsOutline" />')],-1))]),o("div",f,[n[4]||(n[4]=o("h3",null,"Primary",-1)),o("div",y,[s(t(e),{color:"primary",icon:t(d)},null,8,["icon"])]),n[5]||(n[5]=o("pre",{class:"code-block"},[o("code",null,'<PPIconButton color="primary" :icon="squareOutline" />')],-1))]),n[7]||(n[7]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),n[8]||(n[8]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
<div class="guide-section">
        <h2>5. PPIconButton Variants</h2>
        
        <div class="variant-group" style="background: #f4f5f8; padding: 16px; border-radius: 8px;">
          <h3>Danger</h3>
          <div class="component-demo">
            <PPIconButton color="danger" :icon="trashOutline" />
          </div>
          <pre class="code-block"><code>&lt;PPIconButton color="danger" :icon="trashOutline" /&gt;</code></pre>
        </div>

        <div class="variant-group" style="background: var(--pp-primary, #003399); padding: 16px; border-radius: 8px; color: white;">
          <h3 style="color: white;">White (on dark backgrounds)</h3>
          <div class="component-demo">
            <PPIconButton color="white" badge :icon="notificationsOutline" />
          </div>
          <pre class="code-block"><code>&lt;PPIconButton color="white" badge :icon="notificationsOutline" /&gt;</code></pre>
        </div>

        <div class="variant-group" style="background: #f4f5f8; padding: 16px; border-radius: 8px;">
          <h3>Primary</h3>
          <div class="component-demo">
            <PPIconButton color="primary" :icon="squareOutline" />
          </div>
          <pre class="code-block"><code>&lt;PPIconButton color="primary" :icon="squareOutline" /&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { PPIconButton } from '@phanna/ui-framework';
import { trashOutline, notificationsOutline, squareOutline } from 'ionicons/icons';
<\/script>
`)])],-1))],64))}});export{x as _};
