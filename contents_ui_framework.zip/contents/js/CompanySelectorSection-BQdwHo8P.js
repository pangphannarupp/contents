import{ae as s}from"./AccountCardSection-DXixqG3L.js";import{d as a,o as n,j as r,l as e,a as c,u as t,F as l}from"../vendors/vendor-ah_eQdvw.js";import{_ as i}from"./App-D7rwXoHs.js";const p={class:"guide-section"},m={class:"demo-box"},d=a({__name:"CompanySelectorSection",setup(u){return(y,o)=>(n(),r(l,null,[e("div",p,[o[0]||(o[0]=e("h2",null,"Company Selector",-1)),o[1]||(o[1]=e("p",null,"A specialized dropdown for selecting companies or business entities.",-1)),o[2]||(o[2]=e("h3",null,"Basic Usage",-1)),e("div",m,[c(t(s),{companyName:"Acme Corp",companyType:"Technology",logoUrl:""})]),o[3]||(o[3]=e("pre",{class:"code-block"},[e("code",null,'<PPCompanySelector companyName="Acme Corp" companyType="Technology" logoUrl="" />')],-1)),o[4]||(o[4]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[5]||(o[5]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Company Selector</h2>
    <p>A specialized dropdown for selecting companies or business entities.</p>

    <h3>Basic Usage</h3>
    <div class="demo-box">
      <PPCompanySelector companyName="Acme Corp" companyType="Technology" logoUrl="" />
    </div>
    <pre class="code-block"><code>&lt;PPCompanySelector companyName="Acme Corp" companyType="Technology" logoUrl="" /&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPCompanySelector } from '@phanna/ui-framework';

const company = ref('');
const companies = [
  { id: '1', name: 'Acme Corp' },
  { id: '2', name: 'Stark Industries' },
  { id: '3', name: 'Wayne Enterprises' }
];
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),b=i(d,[["__scopeId","data-v-8e65cec8"]]);export{b as C};
