import{j as o}from"../main.js";import{c as r}from"./Toolbar.lf57bzbt.js";const s=r(o.jsx("path",{d:"M12 8V4l8 8-8 8v-4H4V8z"}),"Forward");export{s as F};
