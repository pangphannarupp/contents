import{P as d,x as f}from"./AccountCardSection-DXixqG3L.js";import{d as x,o as r,j as l,l as e,a as u,w as n,A as p,y as m,u as i,av as A,aw as C,c as R,F as S,p as g}from"../vendors/vendor-ah_eQdvw.js";const P={class:"guide-section"},B={class:"variant-group"},k={style:{display:"flex","justify-content":"space-between","align-items":"center","margin-bottom":"12px"}},M={class:"component-demo",style:{background:"#f4f6f9",padding:"20px","border-radius":"12px"}},h={style:{background:"white","border-radius":"8px",padding:"16px","margin-bottom":"8px",display:"flex","align-items":"center","justify-content":"space-between","box-shadow":"0 2px 4px rgba(0,0,0,0.05)"}},w={style:{display:"block","font-size":"16px",color:"#333"}},T=x({__name:"AccountReorderSection",setup(L){const a=g([{id:"acc1",name:"AAAAAAAA",number:"1-120-14335454-8",balance:12e6,currency:"USD",type:"Savings",isHidden:!1},{id:"acc2",name:"BBBBBBBB",number:"1-120-14335455-9",balance:50000.5,currency:"USD",type:"Savings",isHidden:!1},{id:"acc3",name:"CCCCCCCC",number:"1-120-14335456-0",balance:4e7,currency:"KHR",type:"Savings",isHidden:!0}]),s=g(!1),v=c=>console.log("Setup: "+c);return(c,t)=>(r(),l(S,null,[e("div",P,[t[8]||(t[8]=e("h2",null,"14. Account Reorder List",-1)),e("div",B,[e("div",k,[t[3]||(t[3]=e("h3",null,"Fully Custom Template",-1)),u(i(d),{size:"small",onClick:t[0]||(t[0]=o=>s.value=!s.value)},{default:n(()=>[p(m(s.value?"Done":"Sort by"),1)]),_:1})]),t[6]||(t[6]=e("p",{class:"custom-guide"},"You can completely replace the internal cards with your own custom HTML while retaining the drag-to-reorder logic.",-1)),e("div",M,[u(i(f),{accounts:a.value,isReorderMode:s.value,"onUpdate:accounts":t[2]||(t[2]=o=>a.value=o)},{item:n(({item:o,dragListeners:y,isReorderMode:b})=>[e("div",h,[e("div",null,[e("strong",w,"Custom: "+m(o.accountName||o.name),1),t[4]||(t[4]=e("span",{style:{color:"#666","font-size":"14px"}},"Description",-1))]),b?(r(),l("div",A({key:0,style:{background:"#eef2f6",padding:"8px","border-radius":"4px",cursor:"grab",color:"#555"}},C(y,!0))," Hold to Drag ",16)):(r(),R(i(d),{key:1,size:"small",variant:"outline",onClick:t[1]||(t[1]=H=>v("Action on custom card"))},{default:n(()=>[...t[5]||(t[5]=[p("Action",-1)])]),_:1}))])]),_:1},8,["accounts","isReorderMode"])]),t[7]||(t[7]=e("pre",{class:"code-block"},[e("code",null,`<PPAccountReorderList 
  :accounts="accounts" 
  :isReorderMode="isReorderMode"
>
  <template #item="{ item, dragListeners, isReorderMode }">
    <div class="my-custom-card">
      <h4>{{ item.name }}</h4>
      <p>{{ item.balance }}</p>
      <div v-if="isReorderMode" v-on="dragListeners">
        Hold to Drag
      </div>
    </div>
  </template>
</PPAccountReorderList>`)],-1))]),t[9]||(t[9]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[10]||(t[10]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>14. Account Reorder List</h2>
        <div class="variant-group">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <h3>Fully Custom Template</h3>
            <PPButton size="small" @click="isReorderMode = !isReorderMode">
              {{ isReorderMode ? 'Done' : 'Sort by' }}
            </PPButton>
          </div>
          <p class="custom-guide">You can completely replace the internal cards with your own custom HTML while retaining the drag-to-reorder logic.</p>
          <div class="component-demo" style="background: #f4f6f9; padding: 20px; border-radius: 12px;">
            <PPAccountReorderList 
              :accounts="demoAccounts"
              :isReorderMode="isReorderMode"
              @update:accounts="newAccs => demoAccounts = newAccs"
            >
              <template #item="{ item, dragListeners, isReorderMode: reorderMode }">
                <div style="background: white; border-radius: 8px; padding: 16px; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                  <div>
                    <strong style="display: block; font-size: 16px; color: #333;">Custom: {{ item.accountName || item.name }}</strong>
                    <span style="color: #666; font-size: 14px;">Description</span>
                  </div>
                  <div 
                    v-if="reorderMode" 
                    style="background: #eef2f6; padding: 8px; border-radius: 4px; cursor: grab; color: #555;"
                    v-on="dragListeners"
                  >
                    Hold to Drag
                  </div>
                  <PPButton v-else size="small" variant="outline" @click="alertVal('Action on custom card')">Action</PPButton>
                </div>
              </template>
            </PPAccountReorderList>
          </div>
          <pre class="code-block" v-pre><code>&lt;PPAccountReorderList 
  :accounts="accounts" 
  :isReorderMode="isReorderMode"
&gt;
  &lt;template #item="{ item, dragListeners, isReorderMode }"&gt;
    &lt;div class="my-custom-card"&gt;
      &lt;h4&gt;{{ item.name }}&lt;/h4&gt;
      &lt;p&gt;{{ item.balance }}&lt;/p&gt;
      &lt;div v-if="isReorderMode" v-on="dragListeners"&gt;
        Hold to Drag
      &lt;/div&gt;
    &lt;/div&gt;
  &lt;/template&gt;
&lt;/PPAccountReorderList&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const demoAccounts = ref([
  { id: 'acc1', name: "AAAAAAAA", number: "1-120-14335454-8", balance: 12000000.00, currency: "USD" as const, type: "Savings", isHidden: false },
  { id: 'acc2', name: "BBBBBBBB", number: "1-120-14335455-9", balance: 50000.50, currency: "USD" as const, type: "Savings", isHidden: false },
  { id: 'acc3', name: "CCCCCCCC", number: "1-120-14335456-0", balance: 40000000, currency: "KHR" as const, type: "Savings", isHidden: true },
]);

const isReorderMode = ref(false);

const alertVal = (type: string) => console.log('Setup: ' + type);
// Search functionality

import { PPButton, PPAccountReorderList } from '@phanna/ui-framework';

<\/script>
`)])],-1))],64))}});export{T as _};
