import{P as e}from"./AccountCardSection-DXixqG3L.js";import{d as r,o as s,j as d,l as a,a as i,w as n,A as o,u as l,F as p}from"../vendors/vendor-ah_eQdvw.js";const u={class:"guide-section"},P={class:"variant-group"},g={class:"component-demo",style:{display:"flex","flex-wrap":"wrap",gap:"12px",padding:"24px"}},v={class:"variant-group"},m={class:"component-demo",style:{display:"flex","flex-wrap":"wrap","align-items":"center",gap:"16px",padding:"24px"}},B={class:"variant-group"},c={class:"component-demo",style:{display:"flex","flex-wrap":"wrap",gap:"12px",padding:"24px"}},f={class:"variant-group"},y={class:"component-demo",style:{display:"flex","flex-wrap":"wrap",gap:"12px",padding:"24px"}},x={class:"variant-group"},b={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"12px",padding:"24px"}},k={class:"variant-group"},S={class:"component-demo",style:{display:"flex",gap:"12px",padding:"24px"}},h=r({__name:"ButtonSection",setup(w){return(C,t)=>(s(),d(p,null,[a("div",u,[t[37]||(t[37]=a("h2",null,"Button Component",-1)),t[38]||(t[38]=a("p",{class:"custom-guide"},"A versatile button component supporting multiple variants, sizes, icons, and loading states.",-1)),a("div",P,[t[10]||(t[10]=a("h3",null,"Variants",-1)),a("div",g,[i(l(e),{variant:"primary"},{default:n(()=>[...t[0]||(t[0]=[o("Primary",-1)])]),_:1}),i(l(e),{variant:"secondary"},{default:n(()=>[...t[1]||(t[1]=[o("Secondary",-1)])]),_:1}),i(l(e),{variant:"success"},{default:n(()=>[...t[2]||(t[2]=[o("Success",-1)])]),_:1}),i(l(e),{variant:"danger"},{default:n(()=>[...t[3]||(t[3]=[o("Danger",-1)])]),_:1}),i(l(e),{variant:"outline"},{default:n(()=>[...t[4]||(t[4]=[o("Outline",-1)])]),_:1}),i(l(e),{variant:"outline-danger"},{default:n(()=>[...t[5]||(t[5]=[o("Outline Danger",-1)])]),_:1}),i(l(e),{variant:"ghost"},{default:n(()=>[...t[6]||(t[6]=[o("Ghost",-1)])]),_:1}),i(l(e),{variant:"gradient"},{default:n(()=>[...t[7]||(t[7]=[o("Gradient",-1)])]),_:1}),i(l(e),{variant:"elevated"},{default:n(()=>[...t[8]||(t[8]=[o("Elevated (3D)",-1)])]),_:1}),i(l(e),{variant:"soft"},{default:n(()=>[...t[9]||(t[9]=[o("Soft (Tonal)",-1)])]),_:1})]),t[11]||(t[11]=a("pre",{class:"code-block"},[a("code",null,`<PPButton variant="gradient">Gradient</PPButton>
<PPButton variant="elevated">Elevated</PPButton>
<PPButton variant="soft">Soft</PPButton>`)],-1))]),a("div",v,[t[16]||(t[16]=a("h3",null,"Sizes & Shapes",-1)),a("div",m,[i(l(e),{variant:"primary",size:"small"},{default:n(()=>[...t[12]||(t[12]=[o("Small",-1)])]),_:1}),i(l(e),{variant:"primary",size:"medium"},{default:n(()=>[...t[13]||(t[13]=[o("Medium",-1)])]),_:1}),i(l(e),{variant:"primary",size:"large"},{default:n(()=>[...t[14]||(t[14]=[o("Large",-1)])]),_:1}),i(l(e),{variant:"primary",rounded:""},{default:n(()=>[...t[15]||(t[15]=[o("Rounded",-1)])]),_:1})]),t[17]||(t[17]=a("pre",{class:"code-block"},[a("code",null,`<PPButton size="small">Small</PPButton>
<PPButton size="large" rounded>Large Rounded</PPButton>`)],-1))]),a("div",B,[t[22]||(t[22]=a("h3",null,"Icons",-1)),a("div",c,[i(l(e),{variant:"primary"},{iconLeft:n(()=>[...t[18]||(t[18]=[a("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"none",stroke:"currentColor","stroke-width":"2"},[a("path",{d:"M5 12h14M12 5l7 7-7 7"})],-1)])]),default:n(()=>[t[19]||(t[19]=o(" Send ",-1))]),_:1}),i(l(e),{variant:"outline"},{iconRight:n(()=>[...t[20]||(t[20]=[a("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"none",stroke:"currentColor","stroke-width":"2"},[a("circle",{cx:"12",cy:"12",r:"3"}),a("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"})],-1)])]),default:n(()=>[t[21]||(t[21]=o(" Settings ",-1))]),_:1})]),t[23]||(t[23]=a("pre",{class:"code-block"},[a("code",null,`<PPButton variant="primary">
  <template #iconLeft>
    <svg>...</svg>
  </template>
  Send
</PPButton>`)],-1))]),a("div",f,[t[27]||(t[27]=a("h3",null,"States",-1)),a("div",y,[i(l(e),{variant:"primary",loading:""},{default:n(()=>[...t[24]||(t[24]=[o("Saving...",-1)])]),_:1}),i(l(e),{variant:"success",loading:""},{default:n(()=>[...t[25]||(t[25]=[o("Verifying",-1)])]),_:1}),i(l(e),{variant:"outline",disabled:""},{default:n(()=>[...t[26]||(t[26]=[o("Disabled",-1)])]),_:1})]),t[28]||(t[28]=a("pre",{class:"code-block"},[a("code",null,`<PPButton loading>Saving...</PPButton>
<PPButton disabled>Disabled</PPButton>`)],-1))]),a("div",x,[t[31]||(t[31]=a("h3",null,"Block Buttons",-1)),a("div",b,[i(l(e),{variant:"primary",block:""},{default:n(()=>[...t[29]||(t[29]=[o("Primary Block",-1)])]),_:1}),i(l(e),{variant:"secondary",block:""},{default:n(()=>[...t[30]||(t[30]=[o("Secondary Block",-1)])]),_:1})]),t[32]||(t[32]=a("pre",{class:"code-block"},[a("code",null,'<PPButton variant="primary" block>Block Button</PPButton>')],-1))]),a("div",k,[t[34]||(t[34]=a("h3",null,"Customizing CSS",-1)),t[35]||(t[35]=a("p",{class:"custom-guide"},[o("You can override the button's appearance globally via CSS variables or by targeting the "),a("code",null,".pp-btn"),o(" class and its specific variant classes like "),a("code",null,".pp-btn-primary"),o(".")],-1)),t[36]||(t[36]=a("pre",{class:"code-block"},[a("code",null,`/* Override globally for all primary buttons */
:root {
  --pp-primary: #8b5cf6; /* Changes primary button background */
  --pp-primary-variant: #7c3aed; /* Changes hover state */
}

/* Or target specific buttons using scoped CSS or custom classes */
.my-custom-btn {
  background-color: #ff5722 !important;
  border-radius: 99px !important;
  box-shadow: 0 4px 6px rgba(255, 87, 34, 0.3);
}`)],-1)),a("div",S,[i(l(e),{class:"my-custom-btn",style:{"background-color":"#ff5722",color:"white","border-radius":"99px",border:"none",padding:"12px 24px",cursor:"pointer"}},{default:n(()=>[...t[33]||(t[33]=[o(" Custom Styled Button ",-1)])]),_:1})])])]),t[39]||(t[39]=a("div",{class:"variant-group",style:{"margin-top":"40px"}},[a("h3",null,"Full Page Source Code"),a("p",{class:"custom-guide"},"Complete source code for this section."),a("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[a("code",null,`<template>
<div class="guide-section">
        <h2>Button Component</h2>
        <p class="custom-guide">A versatile button component supporting multiple variants, sizes, icons, and loading states.</p>

        <div class="variant-group">
          <h3>Variants</h3>
          <div class="component-demo" style="display: flex; flex-wrap: wrap; gap: 12px; padding: 24px;">
            <PPButton variant="primary">Primary</PPButton>
            <PPButton variant="secondary">Secondary</PPButton>
            <PPButton variant="success">Success</PPButton>
            <PPButton variant="danger">Danger</PPButton>
            <PPButton variant="outline">Outline</PPButton>
            <PPButton variant="outline-danger">Outline Danger</PPButton>
            <PPButton variant="ghost">Ghost</PPButton>
            
            <PPButton variant="gradient">Gradient</PPButton>
            <PPButton variant="elevated">Elevated (3D)</PPButton>
            <PPButton variant="soft">Soft (Tonal)</PPButton>
          </div>
          <pre class="code-block"><code>&lt;PPButton variant="gradient"&gt;Gradient&lt;/PPButton&gt;
&lt;PPButton variant="elevated"&gt;Elevated&lt;/PPButton&gt;
&lt;PPButton variant="soft"&gt;Soft&lt;/PPButton&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Sizes & Shapes</h3>
          <div class="component-demo" style="display: flex; flex-wrap: wrap; align-items: center; gap: 16px; padding: 24px;">
            <PPButton variant="primary" size="small">Small</PPButton>
            <PPButton variant="primary" size="medium">Medium</PPButton>
            <PPButton variant="primary" size="large">Large</PPButton>
            <PPButton variant="primary" rounded>Rounded</PPButton>
          </div>
          <pre class="code-block"><code>&lt;PPButton size="small"&gt;Small&lt;/PPButton&gt;
&lt;PPButton size="large" rounded&gt;Large Rounded&lt;/PPButton&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Icons</h3>
          <div class="component-demo" style="display: flex; flex-wrap: wrap; gap: 12px; padding: 24px;">
            <PPButton variant="primary">
              <template #iconLeft>
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </template>
              Send
            </PPButton>
            <PPButton variant="outline">
              Settings
              <template #iconRight>
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
              </template>
            </PPButton>
          </div>
          <pre class="code-block"><code>&lt;PPButton variant="primary"&gt;
  &lt;template #iconLeft&gt;
    &lt;svg&gt;...&lt;/svg&gt;
  &lt;/template&gt;
  Send
&lt;/PPButton&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>States</h3>
          <div class="component-demo" style="display: flex; flex-wrap: wrap; gap: 12px; padding: 24px;">
            <PPButton variant="primary" loading>Saving...</PPButton>
            <PPButton variant="success" loading>Verifying</PPButton>
            <PPButton variant="outline" disabled>Disabled</PPButton>
          </div>
          <pre class="code-block"><code>&lt;PPButton loading&gt;Saving...&lt;/PPButton&gt;
&lt;PPButton disabled&gt;Disabled&lt;/PPButton&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Block Buttons</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 12px; padding: 24px;">
            <PPButton variant="primary" block>Primary Block</PPButton>
            <PPButton variant="secondary" block>Secondary Block</PPButton>
          </div>
          <pre class="code-block"><code>&lt;PPButton variant="primary" block&gt;Block Button&lt;/PPButton&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the button's appearance globally via CSS variables or by targeting the <code>.pp-btn</code> class and its specific variant classes like <code>.pp-btn-primary</code>.</p>
          <pre class="code-block"><code>/* Override globally for all primary buttons */
:root {
  --pp-primary: #8b5cf6; /* Changes primary button background */
  --pp-primary-variant: #7c3aed; /* Changes hover state */
}

/* Or target specific buttons using scoped CSS or custom classes */
.my-custom-btn {
  background-color: #ff5722 !important;
  border-radius: 99px !important;
  box-shadow: 0 4px 6px rgba(255, 87, 34, 0.3);
}</code></pre>
          <div class="component-demo" style="display: flex; gap: 12px; padding: 24px;">
            <PPButton class="my-custom-btn" style="background-color: #ff5722; color: white; border-radius: 99px; border: none; padding: 12px 24px; cursor: pointer;">
              Custom Styled Button
            </PPButton>
          </div>
        </div>
      </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPButton } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{h as _};
