import{bn as s}from"./AccountCardSection-DXixqG3L.js";import{d as x,o as i,j as l,l as e,a,w as d,F as r,z as n,y as p,u as c,L as g}from"../vendors/vendor-ah_eQdvw.js";import{_ as v}from"./App-D7rwXoHs.js";const u={class:"guide-section"},f={class:"demo-box"},b={style:{display:"flex",gap:"16px",padding:"16px"}},y={style:{"font-size":"14px",color:"#666"}},m={style:{display:"flex",gap:"24px","flex-wrap":"wrap"}},h={class:"demo-box",style:{flex:"1",height:"200px","min-width":"250px"}},S={style:{padding:"16px"}},P={class:"demo-box",style:{flex:"1",height:"200px","min-width":"250px"}},k={style:{padding:"16px"}},w=x({__name:"ScrollAreaSection",setup(z){return(A,o)=>(i(),l(r,null,[e("div",u,[o[4]||(o[4]=e("h2",null,"Scroll Area",-1)),o[5]||(o[5]=e("p",null,"A container that handles horizontal, vertical, or dual-axis scrolling with customized or hidden scrollbars.",-1)),o[6]||(o[6]=e("h3",null,"Horizontal Scrolling (Hide Scrollbar)",-1)),e("div",f,[a(c(s),{direction:"horizontal",hideScrollbar:"",style:{height:"120px"}},{default:d(()=>[e("div",b,[(i(),l(r,null,n(10,t=>e("div",{key:t,style:{width:"80px",height:"80px",background:"white","border-radius":"12px",display:"flex","flex-direction":"column","align-items":"center","justify-content":"center","box-shadow":"0 2px 8px rgba(0,0,0,0.05)","flex-shrink":"0"}},[e("div",y,p(t)+" PM",1),o[0]||(o[0]=e("div",{style:{"font-size":"24px",margin:"4px 0"}},"🌤️",-1)),o[1]||(o[1]=e("div",{style:{"font-size":"16px","font-weight":"600"}},"28°C",-1))])),64))])]),_:1})]),o[7]||(o[7]=e("div",{class:"usage-block",style:{"margin-top":"16px"}},[e("pre",{style:{background:"#1f2937",color:"#f8f8f2",padding:"16px","border-radius":"8px","overflow-x":"auto","font-size":"14px"}},[e("code",null,`<PPScrollArea direction="horizontal" hideScrollbar>
  <div style="display: flex; gap: 16px;">
    <!-- Your horizontal content items -->
  </div>
</PPScrollArea>`)])],-1)),o[8]||(o[8]=e("h3",null,"Vertical Scrolling (Mac & Thin variants)",-1)),e("div",m,[e("div",h,[o[2]||(o[2]=e("h4",{style:{"margin-top":"0","font-size":"14px"}},'scrollbar="mac"',-1)),a(c(s),{direction:"vertical",scrollbar:"mac",style:{background:"white","border-radius":"8px",border:"1px solid #e5e7eb"}},{default:d(()=>[e("div",S,[(i(),l(r,null,n(15,t=>e("div",{key:t,style:{padding:"12px","border-bottom":"1px solid #f3f4f6"}}," List Item "+p(t),1)),64))])]),_:1})]),e("div",P,[o[3]||(o[3]=e("h4",{style:{"margin-top":"0","font-size":"14px"}},'scrollbar="thin"',-1)),a(c(s),{direction:"vertical",scrollbar:"thin",style:{background:"white","border-radius":"8px",border:"1px solid #e5e7eb"}},{default:d(()=>[e("div",k,[(i(),l(r,null,n(15,t=>e("div",{key:t,style:{padding:"12px","border-bottom":"1px solid #f3f4f6"}}," List Item "+p(t),1)),64))])]),_:1})])]),o[9]||(o[9]=g(`<div class="usage-block" style="margin-top:16px;" data-v-fa58b1b9><pre style="background:#1f2937;color:#f8f8f2;padding:16px;border-radius:8px;overflow-x:auto;font-size:14px;" data-v-fa58b1b9><code data-v-fa58b1b9>&lt;PPScrollArea direction=&quot;vertical&quot;&gt;
  &lt;!-- Your long vertical content --&gt;
  &lt;div v-for=&quot;i in 15&quot; :key=&quot;i&quot;&gt;List Item {{ i }}&lt;/div&gt;
&lt;/PPScrollArea&gt;</code></pre></div><div class="variant-group" data-v-fa58b1b9><h3 data-v-fa58b1b9>Customizing CSS</h3><p class="custom-guide" data-v-fa58b1b9>You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block" data-v-fa58b1b9><code data-v-fa58b1b9>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),o[10]||(o[10]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Scroll Area</h2>
    <p>A container that handles horizontal, vertical, or dual-axis scrolling with customized or hidden scrollbars.</p>

    <h3>Horizontal Scrolling (Hide Scrollbar)</h3>
    <div class="demo-box">
      <PPScrollArea direction="horizontal" hideScrollbar style="height: 120px;">
        <div style="display: flex; gap: 16px; padding: 16px;">
          <div v-for="i in 10" :key="i" style="width: 80px; height: 80px; background: white; border-radius: 12px; display: flex; flex-direction: column; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(0,0,0,0.05); flex-shrink: 0;">
            <div style="font-size: 14px; color: #666;">{{ i }} PM</div>
            <div style="font-size: 24px; margin: 4px 0;">🌤️</div>
            <div style="font-size: 16px; font-weight: 600;">28°C</div>
          </div>
        </div>
      </PPScrollArea>
    </div>
    <div class="usage-block" style="margin-top: 16px;">
      <pre v-pre style="background: #1f2937; color: #f8f8f2; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 14px;"><code>&lt;PPScrollArea direction="horizontal" hideScrollbar&gt;
  &lt;div style="display: flex; gap: 16px;"&gt;
    &lt;!-- Your horizontal content items --&gt;
  &lt;/div&gt;
&lt;/PPScrollArea&gt;</code></pre>
    </div>

    <h3>Vertical Scrolling (Mac & Thin variants)</h3>
    <div style="display: flex; gap: 24px; flex-wrap: wrap;">
      
      <!-- Default Mac Style -->
      <div class="demo-box" style="flex: 1; height: 200px; min-width: 250px;">
        <h4 style="margin-top: 0; font-size: 14px;">scrollbar="mac"</h4>
        <PPScrollArea direction="vertical" scrollbar="mac" style="background: white; border-radius: 8px; border: 1px solid #e5e7eb;">
          <div style="padding: 16px;">
            <div v-for="i in 15" :key="i" style="padding: 12px; border-bottom: 1px solid #f3f4f6;">
              List Item {{ i }}
            </div>
          </div>
        </PPScrollArea>
      </div>

      <!-- Thin Style -->
      <div class="demo-box" style="flex: 1; height: 200px; min-width: 250px;">
        <h4 style="margin-top: 0; font-size: 14px;">scrollbar="thin"</h4>
        <PPScrollArea direction="vertical" scrollbar="thin" style="background: white; border-radius: 8px; border: 1px solid #e5e7eb;">
          <div style="padding: 16px;">
            <div v-for="i in 15" :key="i" style="padding: 12px; border-bottom: 1px solid #f3f4f6;">
              List Item {{ i }}
            </div>
          </div>
        </PPScrollArea>
      </div>
      
    </div>
    <div class="usage-block" style="margin-top: 16px;">
      <pre v-pre style="background: #1f2937; color: #f8f8f2; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 14px;"><code>&lt;PPScrollArea direction="vertical"&gt;
  &lt;!-- Your long vertical content --&gt;
  &lt;div v-for="i in 15" :key="i"&gt;List Item {{ i }}&lt;/div&gt;
&lt;/PPScrollArea&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPScrollArea } from '@phanna/ui-framework';
<\/script>

<style scoped>
.guide-section {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.demo-box {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 24px;
  background: #f9fafb;
}
</style>
`)])],-1))],64))}}),I=v(w,[["__scopeId","data-v-fa58b1b9"]]);export{I as S};
