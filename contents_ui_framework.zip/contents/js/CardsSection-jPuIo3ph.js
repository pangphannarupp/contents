import{z as a,G as i,W as r}from"./AccountCardSection-DXixqG3L.js";import{d,o as l,j as n,l as e,a as o,u as t,F as c}from"../vendors/vendor-ah_eQdvw.js";import{_ as p}from"./App-D7rwXoHs.js";const u={class:"guide-section"},m={class:"demo-box"},g={class:"demo-box"},f={class:"demo-box"},v=d({__name:"CardsSection",setup(y){return(C,s)=>(l(),n(c,null,[e("div",u,[s[0]||(s[0]=e("h2",null,"Cards Collection",-1)),s[1]||(s[1]=e("p",null,"Various specialized card components used to display user and account data.",-1)),s[2]||(s[2]=e("h3",null,"User Profile Card",-1)),e("div",m,[o(t(a),{userName:"John Doe",email:"john@example.com",avatarUrl:"https://i.pravatar.cc/150?u=a042581f4e29026704d"})]),s[3]||(s[3]=e("h3",null,"Verification Card",-1)),e("div",g,[o(t(i),{title:"Identity Verification",description:"Verify your identity to unlock all features.",status:"pending"})]),s[4]||(s[4]=e("h3",null,"Upgrade Card",-1)),e("div",f,[o(t(r),{title:"Upgrade to Pro",description:"Get access to premium features and unlimited storage.",price:"$9.99/mo"})]),s[5]||(s[5]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),s[6]||(s[6]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Cards Collection</h2>
    <p>Various specialized card components used to display user and account data.</p>

    <h3>User Profile Card</h3>
    <div class="demo-box">
      <PPUserProfile 
        userName="John Doe" 
        email="john@example.com" 
        avatarUrl="https://i.pravatar.cc/150?u=a042581f4e29026704d" 
      />
    </div>

    <h3>Verification Card</h3>
    <div class="demo-box">
      <PPVerificationCard 
        title="Identity Verification"
        description="Verify your identity to unlock all features."
        status="pending"
      />
    </div>

    <h3>Upgrade Card</h3>
    <div class="demo-box">
      <PPUpgradeCard 
        title="Upgrade to Pro"
        description="Get access to premium features and unlimited storage."
        price="$9.99/mo"
      />
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPUserProfile, PPVerificationCard, PPUpgradeCard } from '@phanna/ui-framework';
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; display: flex; flex-direction: column; gap: 16px; }
</style>
`)])],-1))],64))}}),P=p(v,[["__scopeId","data-v-311bf2b6"]]);export{P as C};
