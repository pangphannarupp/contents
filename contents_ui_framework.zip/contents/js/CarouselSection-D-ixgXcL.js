import{A as p,B as u}from"./AccountCardSection-DXixqG3L.js";import{d as g,o as a,j as d,l as e,a as r,w as s,F as n,z as c,u as l,v as m,y as i,c as h,p as y}from"../vendors/vendor-ah_eQdvw.js";import{_ as P}from"./App-D7rwXoHs.js";const x={class:"component-section"},b={class:"demo-box"},C={class:"demo-content"},f={class:"demo-box"},w={class:"demo-content"},S={class:"product-card"},k={class:"product-image"},I={class:"product-details"},A={class:"demo-box"},z={class:"demo-content"},_={class:"demo-box"},$={class:"demo-content"},V=g({__name:"CarouselSection",setup(D){const v=y([{id:1,title:"Analytics",desc:"View your data instantly",icon:"📊"},{id:2,title:"Cloud Sync",desc:"Secure reliable storage",icon:"☁️"},{id:3,title:"Security",desc:"Enterprise-grade protection",icon:"🔒"},{id:4,title:"Fast Pay",desc:"Zero transaction fees",icon:"💸"},{id:5,title:"Mobile App",desc:"Available on iOS/Android",icon:"📱"},{id:6,title:"Support",desc:"24/7 dedicated assistance",icon:"📞"}]);return(R,t)=>(a(),d(n,null,[e("div",x,[t[13]||(t[13]=e("h2",null,"Carousel",-1)),t[14]||(t[14]=e("p",null,"A highly performant touch-friendly slider component using native CSS scroll snapping. Supports autoplay, pagination, multi-item views, and multiple variants (standard, story, reel).",-1)),e("div",b,[t[0]||(t[0]=e("h3",null,"Standard Image Carousel",-1)),t[1]||(t[1]=e("p",{class:"helper-text"},"1 item per view, dots, arrows, and looping enabled.",-1)),e("div",C,[r(l(u),{variant:"standard",loop:!0,style:{"border-radius":"8px",overflow:"hidden","box-shadow":"0 4px 12px rgba(0,0,0,0.1)"}},{default:s(()=>[(a(),d(n,null,c(5,o=>r(l(p),{key:o},{default:s(()=>[e("div",{class:"slide-image-placeholder",style:m({background:`hsl(${o*60}, 70%, 50%)`})},[e("h2",null,"Slide "+i(o),1)],4)]),_:2},1024)),64))]),_:1})]),t[2]||(t[2]=e("pre",{class:"code-block"},[e("code",null,`<!-- variant can be 'standard' (default), 'story', or 'reel' -->
<PPCarousel variant="standard" :loop="true">
  <PPCarouselItem v-for="i in 5" :key="i">
    <!-- Your content here -->
  </PPCarouselItem>
</PPCarousel>`)],-1))]),e("div",f,[t[3]||(t[3]=e("h3",null,"Multi-Item Autoplay Slider",-1)),t[4]||(t[4]=e("p",{class:"helper-text"},"3 items per view with a 2000ms autoplay interval. (Pauses on hover)",-1)),e("div",w,[r(l(u),{itemsPerView:3,autoplay:!0,interval:2e3,gap:"16px",showDots:!1},{default:s(()=>[(a(!0),d(n,null,c(v.value,o=>(a(),h(l(p),{key:o.id},{default:s(()=>[e("div",S,[e("div",k,i(o.icon),1),e("div",I,[e("h4",null,i(o.title),1),e("p",null,i(o.desc),1)])])]),_:2},1024))),128))]),_:1})]),t[5]||(t[5]=e("pre",{class:"code-block"},[e("code",null,`<PPCarousel 
  :itemsPerView="3" 
  :autoplay="true" 
  :interval="2000" 
  gap="16px"
>
  <PPCarouselItem v-for="item in cards" :key="item.id">
    <div class="product-card">...</div>
  </PPCarouselItem>
</PPCarousel>`)],-1))]),e("div",A,[t[6]||(t[6]=e("h3",null,"Story Carousel",-1)),t[7]||(t[7]=e("p",{class:"helper-text"},"Instagram-style story carousel with progress bars.",-1)),e("div",z,[r(l(u),{variant:"story",autoplay:!0,interval:3e3,style:{"border-radius":"8px",overflow:"hidden","box-shadow":"0 4px 12px rgba(0,0,0,0.1)",width:"300px",height:"500px",margin:"0 auto"}},{default:s(()=>[(a(),d(n,null,c(3,o=>r(l(p),{key:`story-${o}`},{default:s(()=>[e("div",{class:"slide-image-placeholder full-height",style:m({background:`hsl(${o*80+100}, 70%, 50%)`})},[e("h2",null,"Story "+i(o),1)],4)]),_:2},1024)),64))]),_:1})]),t[8]||(t[8]=e("pre",{class:"code-block"},[e("code",null,`<PPCarousel variant="story" :autoplay="true" :interval="3000">
  <PPCarouselItem v-for="i in 3" :key="i">
    <!-- Story content here -->
  </PPCarouselItem>
</PPCarousel>`)],-1))]),e("div",_,[t[10]||(t[10]=e("h3",null,"Reel Carousel",-1)),t[11]||(t[11]=e("p",{class:"helper-text"},"TikTok-style vertical scrolling reel.",-1)),e("div",$,[r(l(u),{variant:"reel",showDots:!1,style:{"border-radius":"8px",overflow:"hidden","box-shadow":"0 4px 12px rgba(0,0,0,0.1)",width:"300px",height:"500px",margin:"0 auto"}},{default:s(()=>[(a(),d(n,null,c(4,o=>r(l(p),{key:`reel-${o}`},{default:s(()=>[e("div",{class:"slide-image-placeholder full-height",style:m({background:`hsl(${o*40+200}, 70%, 50%)`})},[e("div",null,[e("h2",null,"Reel "+i(o),1),t[9]||(t[9]=e("p",{style:{"font-size":"14px",opacity:"0.8"}},"Swipe up or down",-1))])],4)]),_:2},1024)),64))]),_:1})]),t[12]||(t[12]=e("pre",{class:"code-block"},[e("code",null,`<PPCarousel variant="reel" :showDots="false">
  <PPCarouselItem v-for="i in 4" :key="i">
    <!-- Reel content here -->
  </PPCarouselItem>
</PPCarousel>`)],-1))]),t[15]||(t[15]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[16]||(t[16]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Carousel</h2>
    <p>A highly performant touch-friendly slider component using native CSS scroll snapping. Supports autoplay, pagination, multi-item views, and multiple variants (standard, story, reel).</p>

    <!-- Standard Image Carousel -->
    <div class="demo-box">
      <h3>Standard Image Carousel</h3>
      <p class="helper-text">1 item per view, dots, arrows, and looping enabled.</p>
      <div class="demo-content">
        <PPCarousel variant="standard" :loop="true" style="border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
          <PPCarouselItem v-for="i in 5" :key="i">
            <div class="slide-image-placeholder" :style="{ background: \`hsl(\${i * 60}, 70%, 50%)\` }">
              <h2>Slide {{ i }}</h2>
            </div>
          </PPCarouselItem>
        </PPCarousel>
      </div>
      <pre class="code-block" v-pre><code>&lt;!-- variant can be 'standard' (default), 'story', or 'reel' --&gt;
&lt;PPCarousel variant="standard" :loop="true"&gt;
  &lt;PPCarouselItem v-for="i in 5" :key="i"&gt;
    &lt;!-- Your content here --&gt;
  &lt;/PPCarouselItem&gt;
&lt;/PPCarousel&gt;</code></pre>
    </div>

    <!-- Autoplay Cards Carousel -->
    <div class="demo-box">
      <h3>Multi-Item Autoplay Slider</h3>
      <p class="helper-text">3 items per view with a 2000ms autoplay interval. (Pauses on hover)</p>
      <div class="demo-content">
        <PPCarousel :itemsPerView="3" :autoplay="true" :interval="2000" gap="16px" :showDots="false">
          <PPCarouselItem v-for="item in cards" :key="item.id">
            <div class="product-card">
              <div class="product-image">{{ item.icon }}</div>
              <div class="product-details">
                <h4>{{ item.title }}</h4>
                <p>{{ item.desc }}</p>
              </div>
            </div>
          </PPCarouselItem>
        </PPCarousel>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPCarousel 
  :itemsPerView="3" 
  :autoplay="true" 
  :interval="2000" 
  gap="16px"
&gt;
  &lt;PPCarouselItem v-for="item in cards" :key="item.id"&gt;
    &lt;div class="product-card"&gt;...&lt;/div&gt;
  &lt;/PPCarouselItem&gt;
&lt;/PPCarousel&gt;</code></pre>
    </div>

    <!-- Story Carousel -->
    <div class="demo-box">
      <h3>Story Carousel</h3>
      <p class="helper-text">Instagram-style story carousel with progress bars.</p>
      <div class="demo-content">
        <PPCarousel variant="story" :autoplay="true" :interval="3000" style="border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 300px; height: 500px; margin: 0 auto;">
          <PPCarouselItem v-for="i in 3" :key="\`story-\${i}\`">
            <div class="slide-image-placeholder full-height" :style="{ background: \`hsl(\${i * 80 + 100}, 70%, 50%)\` }">
              <h2>Story {{ i }}</h2>
            </div>
          </PPCarouselItem>
        </PPCarousel>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPCarousel variant="story" :autoplay="true" :interval="3000"&gt;
  &lt;PPCarouselItem v-for="i in 3" :key="i"&gt;
    &lt;!-- Story content here --&gt;
  &lt;/PPCarouselItem&gt;
&lt;/PPCarousel&gt;</code></pre>
    </div>

    <!-- Reel Carousel -->
    <div class="demo-box">
      <h3>Reel Carousel</h3>
      <p class="helper-text">TikTok-style vertical scrolling reel.</p>
      <div class="demo-content">
        <PPCarousel variant="reel" :showDots="false" style="border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 300px; height: 500px; margin: 0 auto;">
          <PPCarouselItem v-for="i in 4" :key="\`reel-\${i}\`">
            <div class="slide-image-placeholder full-height" :style="{ background: \`hsl(\${i * 40 + 200}, 70%, 50%)\` }">
              <div>
                <h2>Reel {{ i }}</h2>
                <p style="font-size: 14px; opacity: 0.8">Swipe up or down</p>
              </div>
            </div>
          </PPCarouselItem>
        </PPCarousel>
      </div>
      <pre class="code-block" v-pre><code>&lt;PPCarousel variant="reel" :showDots="false"&gt;
  &lt;PPCarouselItem v-for="i in 4" :key="i"&gt;
    &lt;!-- Reel content here --&gt;
  &lt;/PPCarouselItem&gt;
&lt;/PPCarousel&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPCarousel, PPCarouselItem } from '@phanna/ui-framework';

const cards = ref([
  { id: 1, title: 'Analytics', desc: 'View your data instantly', icon: '📊' },
  { id: 2, title: 'Cloud Sync', desc: 'Secure reliable storage', icon: '☁️' },
  { id: 3, title: 'Security', desc: 'Enterprise-grade protection', icon: '🔒' },
  { id: 4, title: 'Fast Pay', desc: 'Zero transaction fees', icon: '💸' },
  { id: 5, title: 'Mobile App', desc: 'Available on iOS/Android', icon: '📱' },
  { id: 6, title: 'Support', desc: '24/7 dedicated assistance', icon: '📞' }
]);
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
}
.helper-text {
  font-size: 13px;
  color: #666;
  margin-bottom: 16px;
}
.code-block {
  background: #282c34;
  color: #abb2bf;
  padding: 16px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 14px;
  line-height: 1.5;
}

.slide-image-placeholder {
  width: 100%;
  height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 24px;
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
  text-align: center;
}

.slide-image-placeholder.full-height {
  height: 100%;
}

.product-card {
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  text-align: center;
  height: 100%;
  display: flex;
  flex-direction: column;
  transition: transform 0.2s, box-shadow 0.2s;
  cursor: pointer;
}
.product-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.06);
}
.product-image {
  font-size: 48px;
  margin-bottom: 16px;
}
.product-details h4 {
  margin: 0 0 8px 0;
  font-size: 16px;
  color: #333;
}
.product-details p {
  margin: 0;
  font-size: 13px;
  color: #666;
  line-height: 1.4;
}
</style>
`)])],-1))],64))}}),F=P(V,[["__scopeId","data-v-38d44b7e"]]);export{F as C};
