import{d as P,o as v,j as f,l as o,a as n,u as i,c0 as h,aM as x,aN as y,a9 as R,be as k,P as M,w as s,F as z,p as d}from"../vendors/vendor-ah_eQdvw.js";import{a as b,s as u,g as r,i as a,k as C,aX as B}from"./AccountCardSection-DXixqG3L.js";import{_ as w}from"./App-D7rwXoHs.js";const S={class:"guide-section"},T={class:"demo-box",style:{padding:"0",overflow:"hidden","border-radius":"8px",border:"1px solid #e5e7eb",background:"#f9fafb"}},O={class:"app-header"},$={class:"header-left"},q={class:"quick-actions"},G={class:"header-right"},I={class:"ribbon-groups"},E={class:"horizontal-group"},U={class:"horizontal-group"},V={class:"ribbon-groups"},A={class:"symbol-grid"},F={class:"symbol-grid"},j={class:"ribbon-groups"},D={class:"horizontal-group"},L={class:"horizontal-group"},N={class:"horizontal-group"},Z={class:"horizontal-group"},W={class:"horizontal-group"},Y={class:"ribbon-groups"},H={class:"horizontal-group"},X={class:"ribbon-groups"},J={class:"document-area"},K={class:"page-container"},Q=P({__name:"MicrosoftMathSection",setup(_){const p=d("home"),c=d("x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}"),g=d(null),l=m=>{c.value=c.value+" "+m};return(m,t)=>(v(),f(z,null,[o("div",S,[t[50]||(t[50]=o("h2",null,"Microsoft Math Editor",-1)),t[51]||(t[51]=o("p",null,"A complete Microsoft Word Equation Editor-style interface built using the Ribbon Menu and Math Editor components.",-1)),o("div",T,[o("div",O,[o("div",$,[t[33]||(t[33]=o("div",{class:"app-icon"},"∑",-1)),o("div",q,[n(i(b),{icon:i(h),variant:"ghost",color:"white"},null,8,["icon"]),n(i(b),{icon:i(x),variant:"ghost",color:"white"},null,8,["icon"]),n(i(b),{icon:i(y),variant:"ghost",color:"white"},null,8,["icon"])])]),t[34]||(t[34]=o("div",{class:"header-center"},[o("span",{class:"document-title"},"Equation1 - Microsoft Math")],-1)),o("div",G,[n(i(b),{icon:i(R),variant:"ghost",color:"white"},null,8,["icon"]),n(i(b),{icon:i(k),variant:"ghost",color:"white"},null,8,["icon"]),n(i(b),{icon:i(M),variant:"ghost",color:"white"},null,8,["icon"])])]),n(i(C),{modelValue:p.value,"onUpdate:modelValue":t[31]||(t[31]=e=>p.value=e)},{default:s(()=>[n(i(u),{id:"home",title:"HOME"},{default:s(()=>[o("div",I,[n(i(r),{title:"Clipboard"},{default:s(()=>[o("div",E,[n(i(a),{label:"Paste",size:"large"}),n(i(a),{label:"Copy",size:"large"})])]),_:1}),n(i(r),{title:"Tools"},{default:s(()=>[o("div",U,[n(i(a),{label:"Professional",size:"large"}),n(i(a),{label:"Linear",size:"large"}),n(i(a),{label:"Normal Text",size:"large"})])]),_:1})])]),_:1}),n(i(u),{id:"symbol",title:"SYMBOL"},{default:s(()=>[o("div",V,[n(i(r),{title:"Basic Math"},{default:s(()=>[o("div",A,[o("button",{class:"symbol-btn",onClick:t[0]||(t[0]=e=>l("\\pm"))},"±"),o("button",{class:"symbol-btn",onClick:t[1]||(t[1]=e=>l("\\infty"))},"∞"),o("button",{class:"symbol-btn",onClick:t[2]||(t[2]=e=>l("\\approx"))},"≈"),o("button",{class:"symbol-btn",onClick:t[3]||(t[3]=e=>l("\\neq"))},"≠"),o("button",{class:"symbol-btn",onClick:t[4]||(t[4]=e=>l("\\times"))},"×"),o("button",{class:"symbol-btn",onClick:t[5]||(t[5]=e=>l("\\div"))},"÷"),o("button",{class:"symbol-btn",onClick:t[6]||(t[6]=e=>l("!"))},"!"),o("button",{class:"symbol-btn",onClick:t[7]||(t[7]=e=>l("\\propto"))},"∝")])]),_:1}),n(i(r),{title:"Greek Letters"},{default:s(()=>[o("div",F,[o("button",{class:"symbol-btn",onClick:t[8]||(t[8]=e=>l("\\alpha"))},"α"),o("button",{class:"symbol-btn",onClick:t[9]||(t[9]=e=>l("\\beta"))},"β"),o("button",{class:"symbol-btn",onClick:t[10]||(t[10]=e=>l("\\gamma"))},"γ"),o("button",{class:"symbol-btn",onClick:t[11]||(t[11]=e=>l("\\pi"))},"π"),o("button",{class:"symbol-btn",onClick:t[12]||(t[12]=e=>l("\\Delta"))},"Δ"),o("button",{class:"symbol-btn",onClick:t[13]||(t[13]=e=>l("\\theta"))},"θ"),o("button",{class:"symbol-btn",onClick:t[14]||(t[14]=e=>l("\\Sigma"))},"Σ"),o("button",{class:"symbol-btn",onClick:t[15]||(t[15]=e=>l("\\Omega"))},"Ω")])]),_:1})])]),_:1}),n(i(u),{id:"structures",title:"STRUCTURES"},{default:s(()=>[o("div",j,[n(i(r),{title:"Fractions"},{default:s(()=>[o("div",D,[n(i(a),{label:"Fraction",size:"large",onClick:t[16]||(t[16]=e=>l("\\frac{x}{y}"))},{icon:s(()=>[...t[35]||(t[35]=[o("span",{class:"math-icon"},"½",-1)])]),_:1}),n(i(a),{label:"Stacked",size:"large",onClick:t[17]||(t[17]=e=>l("\\frac{a}{b}"))},{icon:s(()=>[...t[36]||(t[36]=[o("span",{class:"math-icon",style:{"font-size":"20px"}},"a/b",-1)])]),_:1})])]),_:1}),n(i(r),{title:"Scripts"},{default:s(()=>[o("div",L,[n(i(a),{label:"Superscript",size:"large",onClick:t[18]||(t[18]=e=>l("x^2"))},{icon:s(()=>[...t[37]||(t[37]=[o("span",{class:"math-icon"},"x²",-1)])]),_:1}),n(i(a),{label:"Subscript",size:"large",onClick:t[19]||(t[19]=e=>l("x_2"))},{icon:s(()=>[...t[38]||(t[38]=[o("span",{class:"math-icon"},"x₂",-1)])]),_:1})])]),_:1}),n(i(r),{title:"Radicals"},{default:s(()=>[o("div",N,[n(i(a),{label:"Square Root",size:"large",onClick:t[20]||(t[20]=e=>l("\\sqrt{x}"))},{icon:s(()=>[...t[39]||(t[39]=[o("span",{class:"math-icon"},"√x",-1)])]),_:1}),n(i(a),{label:"nth Root",size:"large",onClick:t[21]||(t[21]=e=>l("\\sqrt[n]{x}"))},{icon:s(()=>[...t[40]||(t[40]=[o("span",{class:"math-icon"},"ⁿ√x",-1)])]),_:1})])]),_:1}),n(i(r),{title:"Integration"},{default:s(()=>[o("div",Z,[n(i(a),{label:"Integral",size:"large",onClick:t[22]||(t[22]=e=>l("\\int"))},{icon:s(()=>[...t[41]||(t[41]=[o("span",{class:"math-icon"},"∫",-1)])]),_:1}),n(i(a),{label:"Double Integral",size:"large",onClick:t[23]||(t[23]=e=>l("\\iint"))},{icon:s(()=>[...t[42]||(t[42]=[o("span",{class:"math-icon"},"∬",-1)])]),_:1}),n(i(a),{label:"Triple Integral",size:"large",onClick:t[24]||(t[24]=e=>l("\\iiint"))},{icon:s(()=>[...t[43]||(t[43]=[o("span",{class:"math-icon"},"∭",-1)])]),_:1}),n(i(a),{label:"Contour Integral",size:"large",onClick:t[25]||(t[25]=e=>l("\\oint"))},{icon:s(()=>[...t[44]||(t[44]=[o("span",{class:"math-icon"},"∮",-1)])]),_:1})])]),_:1}),n(i(r),{title:"Summation"},{default:s(()=>[o("div",W,[n(i(a),{label:"Sum",size:"large",onClick:t[26]||(t[26]=e=>l("\\sum"))},{icon:s(()=>[...t[45]||(t[45]=[o("span",{class:"math-icon"},"∑",-1)])]),_:1}),n(i(a),{label:"Product",size:"large",onClick:t[27]||(t[27]=e=>l("\\prod"))},{icon:s(()=>[...t[46]||(t[46]=[o("span",{class:"math-icon"},"∏",-1)])]),_:1})])]),_:1})])]),_:1}),n(i(u),{id:"matrix",title:"MATRIX"},{default:s(()=>[o("div",Y,[n(i(r),{title:"Matrices"},{default:s(()=>[o("div",H,[n(i(a),{label:"Parentheses Matrix",size:"large",onClick:t[28]||(t[28]=e=>l("\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}"))},{icon:s(()=>[...t[47]||(t[47]=[o("span",{class:"math-icon"},"( )",-1)])]),_:1}),n(i(a),{label:"Square Matrix",size:"large",onClick:t[29]||(t[29]=e=>l("\\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix}"))},{icon:s(()=>[...t[48]||(t[48]=[o("span",{class:"math-icon"},"[ ]",-1)])]),_:1}),n(i(a),{label:"Determinant",size:"large",onClick:t[30]||(t[30]=e=>l("\\begin{vmatrix} a & b \\\\ c & d \\end{vmatrix}"))},{icon:s(()=>[...t[49]||(t[49]=[o("span",{class:"math-icon"},"| |",-1)])]),_:1})])]),_:1})])]),_:1}),n(i(u),{id:"view",title:"VIEW"},{default:s(()=>[o("div",X,[n(i(r),{title:"Zoom"},{default:s(()=>[n(i(a),{label:"Zoom In",size:"large"}),n(i(a),{label:"Zoom Out",size:"large"})]),_:1})])]),_:1})]),_:1},8,["modelValue"]),o("div",J,[o("div",K,[n(i(B),{ref_key:"mathEditorRef",ref:g,modelValue:c.value,"onUpdate:modelValue":t[32]||(t[32]=e=>c.value=e),placeholder:"Type your equation here...",showModeToggle:!1,hideToolbar:!0},null,8,["modelValue"])])])]),t[52]||(t[52]=o("div",{class:"variant-group"},[o("h3",null,"Customizing CSS"),o("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),o("pre",{class:"code-block"},[o("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[53]||(t[53]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="guide-section">
    <h2>Microsoft Math Editor</h2>
    <p>A complete Microsoft Word Equation Editor-style interface built using the Ribbon Menu and Math Editor components.</p>
    
    <div class="demo-box" style="padding: 0; overflow: hidden; border-radius: 8px; border: 1px solid #e5e7eb; background: #f9fafb;">
      <!-- App Header -->
      <div class="app-header">
        <div class="header-left">
          <div class="app-icon">∑</div>
          <div class="quick-actions">
            <PPIconButton :icon="saveOutline" variant="ghost" color="white" />
            <PPIconButton :icon="arrowUndoOutline" variant="ghost" color="white" />
            <PPIconButton :icon="arrowRedoOutline" variant="ghost" color="white" />
          </div>
        </div>
        <div class="header-center">
          <span class="document-title">Equation1 - Microsoft Math</span>
        </div>
        <div class="header-right">
          <PPIconButton :icon="removeOutline" variant="ghost" color="white" />
          <PPIconButton :icon="squareOutline" variant="ghost" color="white" />
          <PPIconButton :icon="closeOutline" variant="ghost" color="white" />
        </div>
      </div>

      <!-- Ribbon -->
      <PPRibbon v-model="activeTab">
        <PPRibbonTab id="home" title="HOME">
          <div class="ribbon-groups">
            <PPRibbonGroup title="Clipboard">
              <div class="horizontal-group">
                <PPRibbonButton label="Paste" size="large" />
                <PPRibbonButton label="Copy" size="large" />
              </div>
            </PPRibbonGroup>
            <PPRibbonGroup title="Tools">
              <div class="horizontal-group">
                <PPRibbonButton label="Professional" size="large" />
                <PPRibbonButton label="Linear" size="large" />
                <PPRibbonButton label="Normal Text" size="large" />
              </div>
            </PPRibbonGroup>
          </div>
        </PPRibbonTab>

        <PPRibbonTab id="symbol" title="SYMBOL">
           <div class="ribbon-groups">
            <PPRibbonGroup title="Basic Math">
              <div class="symbol-grid">
                <button class="symbol-btn" @click="insertMath('\\\\pm')">±</button>
                <button class="symbol-btn" @click="insertMath('\\\\infty')">∞</button>
                <button class="symbol-btn" @click="insertMath('\\\\approx')">≈</button>
                <button class="symbol-btn" @click="insertMath('\\\\neq')">≠</button>
                <button class="symbol-btn" @click="insertMath('\\\\times')">×</button>
                <button class="symbol-btn" @click="insertMath('\\\\div')">÷</button>
                <button class="symbol-btn" @click="insertMath('!')">!</button>
                <button class="symbol-btn" @click="insertMath('\\\\propto')">∝</button>
              </div>
            </PPRibbonGroup>
            <PPRibbonGroup title="Greek Letters">
              <div class="symbol-grid">
                <button class="symbol-btn" @click="insertMath('\\\\alpha')">α</button>
                <button class="symbol-btn" @click="insertMath('\\\\beta')">β</button>
                <button class="symbol-btn" @click="insertMath('\\\\gamma')">γ</button>
                <button class="symbol-btn" @click="insertMath('\\\\pi')">π</button>
                <button class="symbol-btn" @click="insertMath('\\\\Delta')">Δ</button>
                <button class="symbol-btn" @click="insertMath('\\\\theta')">θ</button>
                <button class="symbol-btn" @click="insertMath('\\\\Sigma')">Σ</button>
                <button class="symbol-btn" @click="insertMath('\\\\Omega')">Ω</button>
              </div>
            </PPRibbonGroup>
           </div>
        </PPRibbonTab>

        <PPRibbonTab id="structures" title="STRUCTURES">
           <div class="ribbon-groups">
            <PPRibbonGroup title="Fractions">
              <div class="horizontal-group">
                <PPRibbonButton label="Fraction" size="large" @click="insertMath('\\\\frac{x}{y}')">
                  <template #icon><span class="math-icon">½</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Stacked" size="large" @click="insertMath('\\\\frac{a}{b}')">
                  <template #icon><span class="math-icon" style="font-size: 20px;">a/b</span></template>
                </PPRibbonButton>
              </div>
            </PPRibbonGroup>
            
            <PPRibbonGroup title="Scripts">
              <div class="horizontal-group">
                <PPRibbonButton label="Superscript" size="large" @click="insertMath('x^2')">
                  <template #icon><span class="math-icon">x²</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Subscript" size="large" @click="insertMath('x_2')">
                  <template #icon><span class="math-icon">x₂</span></template>
                </PPRibbonButton>
              </div>
            </PPRibbonGroup>
            
            <PPRibbonGroup title="Radicals">
              <div class="horizontal-group">
                <PPRibbonButton label="Square Root" size="large" @click="insertMath('\\\\sqrt{x}')">
                  <template #icon><span class="math-icon">√x</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="nth Root" size="large" @click="insertMath('\\\\sqrt[n]{x}')">
                  <template #icon><span class="math-icon">ⁿ√x</span></template>
                </PPRibbonButton>
              </div>
            </PPRibbonGroup>

            <PPRibbonGroup title="Integration">
              <div class="horizontal-group">
                <PPRibbonButton label="Integral" size="large" @click="insertMath('\\\\int')">
                  <template #icon><span class="math-icon">∫</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Double Integral" size="large" @click="insertMath('\\\\iint')">
                  <template #icon><span class="math-icon">∬</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Triple Integral" size="large" @click="insertMath('\\\\iiint')">
                  <template #icon><span class="math-icon">∭</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Contour Integral" size="large" @click="insertMath('\\\\oint')">
                  <template #icon><span class="math-icon">∮</span></template>
                </PPRibbonButton>
              </div>
            </PPRibbonGroup>
            <PPRibbonGroup title="Summation">
              <div class="horizontal-group">
                <PPRibbonButton label="Sum" size="large" @click="insertMath('\\\\sum')">
                  <template #icon><span class="math-icon">∑</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Product" size="large" @click="insertMath('\\\\prod')">
                  <template #icon><span class="math-icon">∏</span></template>
                </PPRibbonButton>
              </div>
            </PPRibbonGroup>
           </div>
        </PPRibbonTab>

        <PPRibbonTab id="matrix" title="MATRIX">
           <div class="ribbon-groups">
            <PPRibbonGroup title="Matrices">
              <div class="horizontal-group">
                <PPRibbonButton label="Parentheses Matrix" size="large" @click="insertMath('\\\\begin{pmatrix} a & b \\\\\\\\ c & d \\\\end{pmatrix}')">
                  <template #icon><span class="math-icon">( )</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Square Matrix" size="large" @click="insertMath('\\\\begin{bmatrix} a & b \\\\\\\\ c & d \\\\end{bmatrix}')">
                  <template #icon><span class="math-icon">[ ]</span></template>
                </PPRibbonButton>
                <PPRibbonButton label="Determinant" size="large" @click="insertMath('\\\\begin{vmatrix} a & b \\\\\\\\ c & d \\\\end{vmatrix}')">
                  <template #icon><span class="math-icon">| |</span></template>
                </PPRibbonButton>
              </div>
            </PPRibbonGroup>
           </div>
        </PPRibbonTab>
        
        <PPRibbonTab id="view" title="VIEW">
           <div class="ribbon-groups">
            <PPRibbonGroup title="Zoom">
              <PPRibbonButton label="Zoom In" size="large" />
              <PPRibbonButton label="Zoom Out" size="large" />
            </PPRibbonGroup>
           </div>
        </PPRibbonTab>
      </PPRibbon>

      <!-- Main Content Area -->
      <div class="document-area">
        <div class="page-container">
          <PPMathEditor 
            ref="mathEditorRef"
            v-model="equationContent" 
            placeholder="Type your equation here..."
            :showModeToggle="false"
            :hideToolbar="true"
          />
        </div>
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { 
  saveOutline, arrowUndoOutline, arrowRedoOutline, 
  removeOutline, squareOutline, closeOutline
} from 'ionicons/icons';
import { 
  PPRibbon, PPRibbonTab, PPRibbonGroup, PPRibbonButton, PPIconButton, PPMathEditor
} from '@phanna/ui-framework';

const activeTab = ref('home');
const equationContent = ref('x = \\\\frac{-b \\\\pm \\\\sqrt{b^2-4ac}}{2a}');
const mathEditorRef = ref<any>(null);

const insertMath = (latex: string) => {
  // If the editor is focused or has a public method, we can call it. 
  // Otherwise, we just append to the model value as a simple fallback for the demo.
  equationContent.value = equationContent.value + ' ' + latex;
};
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { min-height: 500px; display: flex; flex-direction: column; }

.app-header {
  height: 48px;
  background-color: #003399; /* Word Blue */
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  color: white;
}

.header-left, .header-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.app-icon {
  width: 32px;
  height: 32px;
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-family: serif;
  font-size: 18px;
  margin-right: 8px;
}

.quick-actions {
  display: flex;
  gap: 4px;
}

.document-title {
  font-size: 14px;
  font-weight: 500;
}

.ribbon-tab-content {
  padding: 12px 16px;
}

.ribbon-groups {
  display: flex;
  gap: 16px;
  height: 100%;
}

.horizontal-group {
  display: flex;
  gap: 8px;
  height: 100%;
}

.symbol-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 4px;
  padding: 0 8px;
}

.symbol-btn {
  background: transparent;
  border: 1px solid transparent;
  border-radius: 4px;
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-family: serif;
  font-size: 14px;
  color: #374151;
}

.symbol-btn:hover {
  background: #f3f4f6;
  border-color: #e5e7eb;
}

.document-area {
  flex: 1;
  background-color: #f3f4f6;
  padding: 32px;
  display: flex;
  justify-content: center;
  overflow-y: auto;
}

.page-container {
  width: 100%;
  max-width: 800px;
  background: white;
  min-height: 400px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  padding: 48px;
}

.math-icon {
  font-family: 'Cambria Math', 'Times New Roman', serif;
  font-size: 24px;
  font-style: italic;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
`)])],-1))],64))}}),nt=w(Q,[["__scopeId","data-v-a4c3a3ba"]]);export{nt as M};
