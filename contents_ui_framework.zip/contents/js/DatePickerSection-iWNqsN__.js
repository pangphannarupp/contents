import{am as r}from"./AccountCardSection-DXixqG3L.js";import{d as m,o as c,j as u,l as e,a as n,u as i,p}from"../vendors/vendor-ah_eQdvw.js";import{_ as f}from"./App-D7rwXoHs.js";const g={class:"guide-section"},D={class:"variant-group"},x={class:"demo-box",style:{height:"350px",display:"flex","align-items":"flex-start","justify-content":"center","padding-top":"50px"}},v={style:{width:"300px"}},y={class:"variant-group"},P={class:"demo-box",style:{height:"350px",display:"flex","align-items":"flex-start","justify-content":"center","padding-top":"50px"}},k={style:{width:"300px"}},_=m({__name:"DatePickerSection",setup(S){const s=p(new Date),l=p(null),d=o=>`${o.getFullYear()}-${String(o.getMonth()+1).padStart(2,"0")}-${String(o.getDate()).padStart(2,"0")}`;return(o,t)=>(c(),u("div",g,[t[6]||(t[6]=e("h2",null,"26. Date Picker",-1)),e("div",D,[t[2]||(t[2]=e("div",{style:{display:"flex","justify-content":"space-between","align-items":"center","margin-bottom":"12px"}},[e("h3",null,"Basic Usage")],-1)),e("div",x,[e("div",v,[n(i(r),{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=a=>s.value=a),placeholder:"Select a Date"},null,8,["modelValue"])])]),t[3]||(t[3]=e("pre",{class:"code-block",style:{"margin-top":"16px"}},[e("code",null,`<template>
  <PPDatePicker v-model="selectedDate" placeholder="Select a Date" />
</template>

<script setup>
import { ref } from 'vue';
import { PPDatePicker } from '@phanna/ui-framework';

const selectedDate = ref(new Date());
<\/script>`)],-1))]),e("div",y,[t[4]||(t[4]=e("div",{style:{display:"flex","justify-content":"space-between","align-items":"center","margin-bottom":"12px"}},[e("h3",null,"Custom Format")],-1)),e("div",P,[e("div",k,[n(i(r),{modelValue:l.value,"onUpdate:modelValue":t[1]||(t[1]=a=>l.value=a),placeholder:"YYYY-MM-DD",format:d},null,8,["modelValue"])])]),t[5]||(t[5]=e("pre",{class:"code-block",style:{"margin-top":"16px"}},[e("code",null,`<template>
  <PPDatePicker 
    v-model="customDate" 
    placeholder="YYYY-MM-DD" 
    :format="customFormat"
  />
</template>

<script setup>
import { ref } from 'vue';
import { PPDatePicker } from '@phanna/ui-framework';

const customDate = ref(null);
const customFormat = (date) => {
  return \`\${date.getFullYear()}-\${String(date.getMonth() + 1).padStart(2, '0')}-\${String(date.getDate()).padStart(2, '0')}\`;
};
<\/script>`)],-1))])]))}}),w=f(_,[["__scopeId","data-v-eb4313a7"]]);export{w as D};
