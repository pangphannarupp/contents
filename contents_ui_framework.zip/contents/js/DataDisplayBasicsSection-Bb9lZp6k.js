import{d as c,o as m,j as g,l as o,a as i,u as e,aD as v,b8 as f,w as s,E as d,aE as P,aJ as x,A as a,a5 as y,L as b,F as C}from"../vendors/vendor-ah_eQdvw.js";import{a0 as n,ai as h,aj as r,ak as l,al as p}from"./AccountCardSection-DXixqG3L.js";const O={class:"component-section"},w={style:{"margin-top":"32px"}},z={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"24px"}},S={style:{display:"flex",gap:"16px","align-items":"center"}},D={style:{"margin-top":"32px"}},A={class:"demo-box",style:{display:"flex",gap:"32px","align-items":"center"}},B={style:{"margin-top":"32px"}},q={class:"demo-box",style:{display:"flex","flex-wrap":"wrap",gap:"12px"}},k={style:{"margin-top":"32px"}},I={class:"demo-box"},E={style:{display:"flex","align-items":"center","justify-content":"center",color:"#64748b",height:"40px"}},L=c({__name:"DataDisplayBasicsSection",setup(G){const u=[{name:"Adam"},{name:"Bob",bgColor:"#3b82f6",textColor:"white"},{name:"Charlie",bgColor:"#10b981",textColor:"white"},{name:"David"},{name:"Eve"}];return(U,t)=>(m(),g(C,null,[o("div",O,[t[20]||(t[20]=o("h2",null,"Data Display Basics",-1)),t[21]||(t[21]=o("p",null,"Essential components for displaying small pieces of information like tags, notifications, and user profiles.",-1)),o("div",w,[t[1]||(t[1]=o("h3",null,"Avatar & Avatar Group",-1)),t[2]||(t[2]=o("p",null,"Display user profiles with images, icons, or fallback initials.",-1)),o("div",z,[o("div",S,[i(e(n),{name:"John Doe",size:"lg"}),i(e(n),{name:"Alice Smith",size:"md",bgColor:"#3b82f6",textColor:"white"}),i(e(n),{icon:e(v),shape:"square",size:"sm",bgColor:"#10b981",textColor:"white"},null,8,["icon"]),i(e(n),{icon:e(f),shape:"rounded",size:"xs",bgColor:"#f59e0b",textColor:"white"},null,8,["icon"])]),o("div",null,[t[0]||(t[0]=o("p",{style:{"margin-bottom":"8px",color:"#64748b","font-size":"14px"}},"Avatar Group",-1)),i(e(h),{items:u,max:3,size:"lg"})])])]),o("div",D,[t[3]||(t[3]=o("h3",null,"Badges",-1)),t[4]||(t[4]=o("p",null,"Notification counts and status dots attached to elements.",-1)),o("div",A,[i(e(r),{value:5,color:"danger"},{default:s(()=>[i(e(d),{icon:e(P),style:{"font-size":"32px",color:"#475569"}},null,8,["icon"])]),_:1}),i(e(r),{value:99,max:10,color:"primary"},{default:s(()=>[i(e(d),{icon:e(x),style:{"font-size":"32px",color:"#475569"}},null,8,["icon"])]),_:1}),i(e(r),{dot:"",color:"success",placement:"top-right"},{default:s(()=>[i(e(n),{name:"Online User",size:"md"})]),_:1})])]),o("div",B,[t[11]||(t[11]=o("h3",null,"Chips",-1)),t[12]||(t[12]=o("p",null,"Compact elements representing an input, attribute, or action.",-1)),o("div",q,[i(e(l),{color:"primary",variant:"solid"},{default:s(()=>[...t[5]||(t[5]=[a("Solid Primary",-1)])]),_:1}),i(e(l),{color:"success",variant:"outline",closable:""},{default:s(()=>[...t[6]||(t[6]=[a("Outline Success",-1)])]),_:1}),i(e(l),{color:"warning",variant:"soft",icon:e(y)},{default:s(()=>[...t[7]||(t[7]=[a("Soft Warning",-1)])]),_:1},8,["icon"]),i(e(l),{color:"danger",variant:"solid",closable:""},{default:s(()=>[...t[8]||(t[8]=[a("Danger Closable",-1)])]),_:1}),i(e(l),{color:"info",size:"sm"},{default:s(()=>[...t[9]||(t[9]=[a("Small Info",-1)])]),_:1}),i(e(l),{color:"default",size:"lg"},{default:s(()=>[...t[10]||(t[10]=[a("Large Default",-1)])]),_:1})])]),o("div",k,[t[18]||(t[18]=o("h3",null,"Dividers",-1)),t[19]||(t[19]=o("p",null,"Separates content logically.",-1)),o("div",I,[t[16]||(t[16]=o("p",{style:{color:"#64748b"}},"Content above",-1)),i(e(p)),t[17]||(t[17]=o("p",{style:{color:"#64748b"}},"Content below",-1)),i(e(p),{variant:"dashed",color:"#3b82f6"},{default:s(()=>[...t[13]||(t[13]=[a("OR",-1)])]),_:1}),o("div",E,[t[14]||(t[14]=a(" Left ",-1)),i(e(p),{orientation:"vertical"}),t[15]||(t[15]=a(" Right ",-1))])])]),t[22]||(t[22]=b(`<div style="margin-top:40px;"><h3>Usage Example</h3><pre class="code-block" style="background:#f8fafc;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;div style=&quot;display: flex; gap: 16px;&quot;&gt;
    &lt;PPAvatar name=&quot;John Doe&quot; size=&quot;lg&quot; /&gt;
    
    &lt;PPBadge :value=&quot;5&quot; color=&quot;danger&quot;&gt;
      &lt;ion-icon :icon=&quot;notificationsOutline&quot; style=&quot;font-size: 32px;&quot; /&gt;
    &lt;/PPBadge&gt;

    &lt;PPChip color=&quot;primary&quot; variant=&quot;soft&quot; :icon=&quot;starOutline&quot;&gt;
      Premium
    &lt;/PPChip&gt;
  &lt;/div&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPAvatar, PPBadge, PPChip } from &#39;@phanna/ui-framework&#39;;
import { notificationsOutline, starOutline } from &#39;ionicons/icons&#39;;
import { IonIcon } from &#39;@ionic/vue&#39;;
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),t[23]||(t[23]=o("div",{class:"variant-group",style:{"margin-top":"40px"}},[o("h3",null,"Full Page Source Code"),o("p",{class:"custom-guide"},"Complete source code for this section."),o("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[o("code",null,`<template>
  <div class="component-section">
    <h2>Data Display Basics</h2>
    <p>Essential components for displaying small pieces of information like tags, notifications, and user profiles.</p>

    <!-- Avatars -->
    <div style="margin-top: 32px;">
      <h3>Avatar & Avatar Group</h3>
      <p>Display user profiles with images, icons, or fallback initials.</p>
      
      <div class="demo-box" style="display: flex; flex-direction: column; gap: 24px;">
        <div style="display: flex; gap: 16px; align-items: center;">
          <PPAvatar name="John Doe" size="lg" />
          <PPAvatar name="Alice Smith" size="md" bgColor="#3b82f6" textColor="white" />
          <PPAvatar :icon="personOutline" shape="square" size="sm" bgColor="#10b981" textColor="white" />
          <PPAvatar :icon="starOutline" shape="rounded" size="xs" bgColor="#f59e0b" textColor="white" />
        </div>
        
        <div>
          <p style="margin-bottom: 8px; color: #64748b; font-size: 14px;">Avatar Group</p>
          <PPAvatarGroup :items="avatarGroupItems" :max="3" size="lg" />
        </div>
      </div>
    </div>

    <!-- Badges -->
    <div style="margin-top: 32px;">
      <h3>Badges</h3>
      <p>Notification counts and status dots attached to elements.</p>
      
      <div class="demo-box" style="display: flex; gap: 32px; align-items: center;">
        <PPBadge :value="5" color="danger">
          <ion-icon :icon="notificationsOutline" style="font-size: 32px; color: #475569;" />
        </PPBadge>
        
        <PPBadge :value="99" :max="10" color="primary">
          <ion-icon :icon="mailOutline" style="font-size: 32px; color: #475569;" />
        </PPBadge>

        <PPBadge dot color="success" placement="top-right">
          <PPAvatar name="Online User" size="md" />
        </PPBadge>
      </div>
    </div>

    <!-- Chips -->
    <div style="margin-top: 32px;">
      <h3>Chips</h3>
      <p>Compact elements representing an input, attribute, or action.</p>
      
      <div class="demo-box" style="display: flex; flex-wrap: wrap; gap: 12px;">
        <PPChip color="primary" variant="solid">Solid Primary</PPChip>
        <PPChip color="success" variant="outline" closable>Outline Success</PPChip>
        <PPChip color="warning" variant="soft" :icon="warningOutline">Soft Warning</PPChip>
        <PPChip color="danger" variant="solid" closable>Danger Closable</PPChip>
        <PPChip color="info" size="sm">Small Info</PPChip>
        <PPChip color="default" size="lg">Large Default</PPChip>
      </div>
    </div>

    <!-- Dividers -->
    <div style="margin-top: 32px;">
      <h3>Dividers</h3>
      <p>Separates content logically.</p>
      
      <div class="demo-box">
        <p style="color: #64748b;">Content above</p>
        <PPDivider />
        <p style="color: #64748b;">Content below</p>
        
        <PPDivider variant="dashed" color="#3b82f6">OR</PPDivider>
        
        <div style="display: flex; align-items: center; justify-content: center; color: #64748b; height: 40px;">
          Left <PPDivider orientation="vertical" /> Right
        </div>
      </div>
    </div>

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;div style="display: flex; gap: 16px;"&gt;
    &lt;PPAvatar name="John Doe" size="lg" /&gt;
    
    &lt;PPBadge :value="5" color="danger"&gt;
      &lt;ion-icon :icon="notificationsOutline" style="font-size: 32px;" /&gt;
    &lt;/PPBadge&gt;

    &lt;PPChip color="primary" variant="soft" :icon="starOutline"&gt;
      Premium
    &lt;/PPChip&gt;
  &lt;/div&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPAvatar, PPBadge, PPChip } from '@phanna/ui-framework';
import { notificationsOutline, starOutline } from 'ionicons/icons';
import { IonIcon } from '@ionic/vue';
&lt;/script&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { notificationsOutline, mailOutline, personOutline, starOutline, warningOutline } from 'ionicons/icons';
import { PPAvatar, PPAvatarGroup, PPBadge, PPChip, PPDivider } from '@phanna/ui-framework';
import { IonIcon } from '@ionic/vue';

const avatarGroupItems = [
  { name: 'Adam' },
  { name: 'Bob', bgColor: '#3b82f6', textColor: 'white' },
  { name: 'Charlie', bgColor: '#10b981', textColor: 'white' },
  { name: 'David' },
  { name: 'Eve' }
];
<\/script>
`)])],-1))],64))}});export{L as _};
