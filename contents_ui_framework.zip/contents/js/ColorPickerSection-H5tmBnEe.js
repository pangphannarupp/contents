import{a9 as v,aa as P,P as c,ab as C,ac as g,ad as k}from"./AccountCardSection-DXixqG3L.js";import{d as f,o as b,j as S,l as e,a as t,u as s,A as n,v as x,y as V,w as p,F as y,p as a}from"../vendors/vendor-ah_eQdvw.js";import{_ as h}from"./App-D7rwXoHs.js";const w={class:"guide-section"},A={class:"demo-box"},I={style:{"margin-top":"16px"}},O={class:"variant-group"},B={class:"component-demo",style:{background:"#ffffff",border:"1px solid #ddd","border-radius":"12px",padding:"20px"}},T={class:"variant-group"},U={class:"demo-box"},H={class:"variant-group"},z={class:"demo-box"},E={class:"variant-group"},F={class:"demo-box"},M=f({__name:"ColorPickerSection",setup(N){const m=a(null),r=a("#3880ff"),d=a(!1),i=a(!1),u=a(!1);return(W,o)=>(b(),S(y,null,[e("div",w,[o[27]||(o[27]=e("h2",null,"Color Picker",-1)),o[28]||(o[28]=e("p",null,"A color picker component that allows users to select colors using HEX, RGB, or HSL.",-1)),o[29]||(o[29]=e("h3",null,"Basic Usage",-1)),e("div",A,[t(s(v),{modelValue:r.value,"onUpdate:modelValue":o[0]||(o[0]=l=>r.value=l)},null,8,["modelValue"]),e("div",I,[o[11]||(o[11]=n(" Selected Color: ",-1)),e("span",{style:x({color:r.value,fontWeight:"bold"})},V(r.value),5)])]),o[30]||(o[30]=e("pre",{class:"code-block"},[e("code",null,'<PPColorPicker v-model="color" />')],-1)),e("div",O,[o[12]||(o[12]=e("h3",null,"Input Wrapper",-1)),o[13]||(o[13]=e("p",{class:"custom-guide"},[e("strong",null,"Component:"),n(),e("code",null,"<PPColorPickerInput>")],-1)),e("div",B,[t(s(P),{modelValue:m.value,"onUpdate:modelValue":o[1]||(o[1]=l=>m.value=l)},null,8,["modelValue"])]),o[14]||(o[14]=e("pre",{class:"code-block"},[e("code",null,'<PPColorPickerInput v-model="color" />')],-1))]),e("div",T,[o[16]||(o[16]=e("h3",null,"Color Picker Sheet",-1)),o[17]||(o[17]=e("p",{class:"custom-guide"},[e("strong",null,"Component:"),n(),e("code",null,"<PPColorPickerSheet>")],-1)),e("div",U,[t(s(c),{onClick:o[2]||(o[2]=l=>d.value=!0)},{default:p(()=>[...o[15]||(o[15]=[n("Open Color Sheet",-1)])]),_:1}),t(s(C),{modelValue:d.value,"onUpdate:modelValue":o[3]||(o[3]=l=>d.value=l),colorValue:r.value,"onUpdate:colorValue":o[4]||(o[4]=l=>r.value=l),title:"Select a Theme Color"},null,8,["modelValue","colorValue"])]),o[18]||(o[18]=e("pre",{class:"code-block"},[e("code",null,'<PPColorPickerSheet v-model="isOpen" v-model:colorValue="color" title="Select a Theme Color" />')],-1))]),e("div",H,[o[20]||(o[20]=e("h3",null,"Color Picker Island Popup",-1)),o[21]||(o[21]=e("p",{class:"custom-guide"},[e("strong",null,"Component:"),n(),e("code",null,"<PPColorPickerIsland>")],-1)),e("div",z,[t(s(c),{onClick:o[5]||(o[5]=l=>i.value=!0)},{default:p(()=>[...o[19]||(o[19]=[n("Open Color Picker Island",-1)])]),_:1}),t(s(g),{modelValue:i.value,"onUpdate:modelValue":o[6]||(o[6]=l=>i.value=l),colorValue:r.value,"onUpdate:colorValue":o[7]||(o[7]=l=>r.value=l),title:"Select a Theme Color"},null,8,["modelValue","colorValue"])]),o[22]||(o[22]=e("pre",{class:"code-block"},[e("code",null,'<PPColorPickerIsland v-model="isOpen" v-model:colorValue="color" title="Select a Theme Color" />')],-1))]),e("div",E,[o[24]||(o[24]=e("h3",null,"Color Picker Alert",-1)),o[25]||(o[25]=e("p",{class:"custom-guide"},[e("strong",null,"Component:"),n(),e("code",null,"<PPColorPickerAlert>")],-1)),e("div",F,[t(s(c),{onClick:o[8]||(o[8]=l=>u.value=!0)},{default:p(()=>[...o[23]||(o[23]=[n("Open Color Alert",-1)])]),_:1}),t(s(k),{modelValue:u.value,"onUpdate:modelValue":o[9]||(o[9]=l=>u.value=l),colorValue:r.value,"onUpdate:colorValue":o[10]||(o[10]=l=>r.value=l),title:"Select a Theme Color"},null,8,["modelValue","colorValue"])]),o[26]||(o[26]=e("pre",{class:"code-block"},[e("code",null,'<PPColorPickerAlert v-model="isOpen" v-model:colorValue="color" title="Select a Theme Color" />')],-1))]),o[31]||(o[31]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[32]||(o[32]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Color Picker</h2>
    <p>A color picker component that allows users to select colors using HEX, RGB, or HSL.</p>

    <h3>Basic Usage</h3>
    <div class="demo-box">
      <PPColorPicker v-model="color" />
      <div style="margin-top: 16px;">
        Selected Color: <span :style="{ color: color, fontWeight: 'bold' }">{{ color }}</span>
      </div>
    </div>
    <pre class="code-block"><code>&lt;PPColorPicker v-model="color" /&gt;</code></pre>
    <div class="variant-group">
      <h3>Color Picker Sheet</h3>
      <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPColorPickerSheet&gt;</code></p>
      <div class="demo-box">
        <PPButton @click="showColorPickerSheet = true">Open Color Sheet</PPButton>
        <PPColorPickerSheet 
          v-model="showColorPickerSheet"
          v-model:colorValue="color"
          title="Select a Theme Color"
        />
      </div>
      <pre class="code-block"><code>&lt;PPColorPickerSheet v-model="isOpen" v-model:colorValue="color" title="Select a Theme Color" /&gt;</code></pre>
    </div>

    <div class="variant-group">
      <h3>Color Picker Island Popup</h3>
      <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPColorPickerIsland&gt;</code></p>
      <div class="demo-box">
        <PPButton @click="showColorPickerIsland = true">Open Color Picker Island</PPButton>
        <PPColorPickerIsland 
          v-model="showColorPickerIsland"
          v-model:colorValue="color"
          title="Select a Theme Color"
        />
      </div>
      <pre class="code-block"><code>&lt;PPColorPickerIsland v-model="isOpen" v-model:colorValue="color" title="Select a Theme Color" /&gt;</code></pre>
    </div>

    <div class="variant-group">
      <h3>Color Picker Alert</h3>
      <p class="custom-guide"><strong>Component:</strong> <code>&lt;PPColorPickerAlert&gt;</code></p>
      <div class="demo-box">
        <PPButton @click="showColorPickerAlert = true">Open Color Alert</PPButton>
        <PPColorPickerAlert 
          v-model="showColorPickerAlert"
          v-model:colorValue="color"
          title="Select a Theme Color"
        />
      </div>
      <pre class="code-block"><code>&lt;PPColorPickerAlert v-model="isOpen" v-model:colorValue="color" title="Select a Theme Color" /&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-calendar-btn-cancel-text: /* value */;
  --pp-calendar-btn-confirm-bg: /* value */;
  --pp-calendar-btn-confirm-text: /* value */;
  --pp-color-primary: /* value */;
  --pp-island-expanded-height: /* value */;
  --pp-island-expanded-radius: /* value */;
  --pp-island-expanded-width: /* value */;
  --pp-primary: /* value */;
  --pp-primary-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
const colorModel = ref(null);
import { PPColorPicker, PPButton, PPColorPickerSheet, PPColorPickerIsland, PPColorPickerAlert , PPColorPickerInput } from '@phanna/ui-framework';

const color = ref('#3880ff');
const showColorPickerSheet = ref(false);
const showColorPickerIsland = ref(false);
const showColorPickerAlert = ref(false);
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
</style>
`)])],-1))],64))}}),R=h(M,[["__scopeId","data-v-91c2950b"]]);export{R as C};
