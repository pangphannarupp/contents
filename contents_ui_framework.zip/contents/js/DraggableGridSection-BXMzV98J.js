import{d as f,o as d,j as l,l as e,F as p,z as y,y as s,A as m,V as h,a1 as D,a as S,w as g,D as C,u as k,p as c}from"../vendors/vendor-ah_eQdvw.js";import{au as w}from"./AccountCardSection-DXixqG3L.js";import{_ as I}from"./App-D7rwXoHs.js";const P={class:"component-section"},T={class:"demo-box draggable-demo-layout"},_={class:"external-source"},E={class:"external-items-list"},G=["onDragstart"],O={class:"item-icon"},z={class:"item-name"},j={class:"grid-destination"},$={class:"grid-controls"},A={class:"grid-card"},N={class:"card-header"},V={class:"card-icon"},U={class:"card-title"},J=["onClick"],M={class:"card-body"},R={style:{"margin-top":"24px",padding:"12px",background:"#f0f0f0","border-radius":"4px","font-size":"14px"}},B=f({__name:"DraggableGridSection",setup(F){const i=c(3),u=c([{id:"stat-1",name:"Revenue",icon:"💰"},{id:"stat-2",name:"Users",icon:"👥"},{id:"chart-1",name:"Analytics",icon:"📈"},{id:"list-1",name:"Recent Tasks",icon:"📋"},{id:"alert-1",name:"System Status",icon:"⚠️"}]),o=c([{id:"initial-1",name:"Welcome Panel",icon:"👋"}]),x=(r,t)=>{if(r.dataTransfer){r.dataTransfer.effectAllowed="copy";const a={...t,id:`${t.id}-${Math.random().toString(36).substr(2,9)}`};r.dataTransfer.setData("application/json",JSON.stringify(a))}},v=({item:r,index:t})=>{console.log(`External item ${r.name} dropped at index ${t}`)},b=r=>{o.value.splice(r,1)};return(r,t)=>(d(),l(p,null,[e("div",P,[t[9]||(t[9]=e("h2",null,"Draggable Grid",-1)),t[10]||(t[10]=e("p",null,"A CSS grid layout that supports drag-and-drop reordering, as well as accepting items from external drag sources.",-1)),e("div",T,[e("div",_,[t[2]||(t[2]=e("h3",null,"Components (Drag me!)",-1)),t[3]||(t[3]=e("p",{class:"helper-text"},"Drag these items into the grid on the right.",-1)),e("div",E,[(d(!0),l(p,null,y(u.value,a=>(d(),l("div",{key:a.id,class:"external-item",draggable:"true",onDragstart:n=>x(n,a)},[e("div",O,s(a.icon),1),e("div",z,s(a.name),1)],40,G))),128))])]),e("div",j,[t[7]||(t[7]=e("h3",null,"Dashboard Layout",-1)),t[8]||(t[8]=e("p",{class:"helper-text"},"Drag items here to add or rearrange.",-1)),e("div",$,[e("label",null,[t[4]||(t[4]=m("Columns: ",-1)),h(e("input",{type:"number","onUpdate:modelValue":t[0]||(t[0]=a=>i.value=a),min:"1",max:"6"},null,512),[[D,i.value]])])]),S(k(w),{modelValue:o.value,"onUpdate:modelValue":t[1]||(t[1]=a=>o.value=a),columns:i.value,gap:"16px",onDropExternal:v},{item:g(({item:a,index:n})=>[e("div",A,[e("div",N,[e("span",V,s(a.icon),1),e("span",U,s(a.name),1),e("button",{class:"remove-btn",onClick:C(L=>b(n),["stop"])},"✕",8,J)]),e("div",M," Placeholder content for "+s(a.name)+". ",1)])]),empty:g(()=>[...t[5]||(t[5]=[e("div",{class:"empty-state"},[e("div",{style:{"font-size":"24px","margin-bottom":"8px"}},"📥"),m(" Drop components here to build your dashboard ")],-1)])]),_:1},8,["modelValue","columns"]),e("div",R,[t[6]||(t[6]=e("strong",null,"Current Order:",-1)),m(" "+s(o.value.map(a=>a.name).join(" → ")||"Empty"),1)])])]),t[11]||(t[11]=e("pre",{class:"code-block"},[e("code",null,`<!-- The Grid -->
<PPDraggableGrid 
  v-model="gridItems" 
  :columns="3"
  gap="16px"
  @drop-external="onDropExternal"
>
  <template #item="{ item, index }">
    <div class="my-card">{{ item.name }}</div>
  </template>
</PPDraggableGrid>

<!-- External draggable source (make sure to set dataTransfer!) -->
<div 
  draggable="true" 
  @dragstart="(e) => {
    e.dataTransfer.setData('application/json', JSON.stringify(myObject));
  }"
>Drag me!</div>`)],-1)),t[12]||(t[12]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[13]||(t[13]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Draggable Grid</h2>
    <p>A CSS grid layout that supports drag-and-drop reordering, as well as accepting items from external drag sources.</p>

    <div class="demo-box draggable-demo-layout">
      <!-- External Draggable Items -->
      <div class="external-source">
        <h3>Components (Drag me!)</h3>
        <p class="helper-text">Drag these items into the grid on the right.</p>
        <div class="external-items-list">
          <div 
            v-for="item in availableItems" 
            :key="item.id"
            class="external-item"
            draggable="true"
            @dragstart="onExternalDragStart($event, item)"
          >
            <div class="item-icon">{{ item.icon }}</div>
            <div class="item-name">{{ item.name }}</div>
          </div>
        </div>
      </div>

      <!-- The Grid -->
      <div class="grid-destination">
        <h3>Dashboard Layout</h3>
        <p class="helper-text">Drag items here to add or rearrange.</p>
        
        <div class="grid-controls">
          <label>Columns: <input type="number" v-model="gridColumns" min="1" max="6"></label>
        </div>

        <PPDraggableGrid 
          v-model="gridItems" 
          :columns="gridColumns"
          gap="16px"
          @drop-external="onDropExternal"
        >
          <!-- Custom template for each item in the grid -->
          <template #item="{ item, index }">
            <div class="grid-card">
              <div class="card-header">
                <span class="card-icon">{{ item.icon }}</span>
                <span class="card-title">{{ item.name }}</span>
                <button class="remove-btn" @click.stop="removeItem(index)">✕</button>
              </div>
              <div class="card-body">
                Placeholder content for {{ item.name }}.
              </div>
            </div>
          </template>
          
          <!-- Custom template for empty state -->
          <template #empty>
            <div class="empty-state">
              <div style="font-size: 24px; margin-bottom: 8px;">📥</div>
              Drop components here to build your dashboard
            </div>
          </template>
        </PPDraggableGrid>
        
        <div style="margin-top: 24px; padding: 12px; background: #f0f0f0; border-radius: 4px; font-size: 14px;">
          <strong>Current Order:</strong> {{ gridItems.map(i => i.name).join(' → ') || 'Empty' }}
        </div>
      </div>
    </div>
    
    <pre class="code-block" v-pre><code>&lt;!-- The Grid --&gt;
&lt;PPDraggableGrid 
  v-model="gridItems" 
  :columns="3"
  gap="16px"
  @drop-external="onDropExternal"
&gt;
  &lt;template #item="{ item, index }"&gt;
    &lt;div class="my-card"&gt;{{ item.name }}&lt;/div&gt;
  &lt;/template&gt;
&lt;/PPDraggableGrid&gt;

&lt;!-- External draggable source (make sure to set dataTransfer!) --&gt;
&lt;div 
  draggable="true" 
  @dragstart="(e) =&gt; {
    e.dataTransfer.setData('application/json', JSON.stringify(myObject));
  }"
&gt;Drag me!&lt;/div&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPDraggableGrid } from '@phanna/ui-framework';

const gridColumns = ref(3);

const availableItems = ref([
  { id: 'stat-1', name: 'Revenue', icon: '💰' },
  { id: 'stat-2', name: 'Users', icon: '👥' },
  { id: 'chart-1', name: 'Analytics', icon: '📈' },
  { id: 'list-1', name: 'Recent Tasks', icon: '📋' },
  { id: 'alert-1', name: 'System Status', icon: '⚠️' }
]);

const gridItems = ref([
  { id: 'initial-1', name: 'Welcome Panel', icon: '👋' }
]);

const onExternalDragStart = (e: DragEvent, item: any) => {
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = 'copy';
    // Stringify the item and set it as JSON payload
    // We add a random suffix to ID so we can drop the same item multiple times
    const dropItem = { ...item, id: \`\${item.id}-\${Math.random().toString(36).substr(2, 9)}\` };
    e.dataTransfer.setData('application/json', JSON.stringify(dropItem));
  }
};

const onDropExternal = ({ item, index }: { item: any, index: number }) => {
  console.log(\`External item \${item.name} dropped at index \${index}\`);
};

const removeItem = (index: number) => {
  gridItems.value.splice(index, 1);
};
<\/script>

<style scoped>
.draggable-demo-layout {
  display: flex;
  gap: 24px;
  align-items: flex-start;
}

@media (max-width: 768px) {
  .draggable-demo-layout {
    flex-direction: column;
  }
}

.external-source {
  flex: 0 0 250px;
  background: #f8f9fa;
  border-radius: 8px;
  padding: 16px;
  border: 1px solid #e0e0e0;
}

.grid-destination {
  flex: 1;
  background: white;
  border-radius: 8px;
  padding: 16px;
  border: 1px solid #e0e0e0;
}

.helper-text {
  font-size: 13px;
  color: #666;
  margin-bottom: 16px;
}

.external-items-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.external-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: white;
  border: 1px solid #ddd;
  border-radius: 6px;
  cursor: grab;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}
.external-item:active {
  cursor: grabbing;
}

.item-icon {
  font-size: 20px;
}
.item-name {
  font-weight: 500;
  font-size: 14px;
}

.grid-controls {
  margin-bottom: 16px;
}

.grid-card {
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  height: 100%;
  display: flex;
  flex-direction: column;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.card-header {
  display: flex;
  align-items: center;
  padding: 12px;
  border-bottom: 1px solid #f0f0f0;
  background: #fafafa;
  border-radius: 8px 8px 0 0;
}

.card-icon {
  margin-right: 8px;
}

.card-title {
  font-weight: 600;
  flex: 1;
}

.remove-btn {
  background: none;
  border: none;
  color: #999;
  cursor: pointer;
  font-size: 14px;
  padding: 4px;
  border-radius: 4px;
}
.remove-btn:hover {
  background: #f0f0f0;
  color: #d32f2f;
}

.card-body {
  padding: 16px;
  font-size: 13px;
  color: #555;
  flex: 1;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  color: #666;
}
</style>
`)])],-1))],64))}}),H=I(B,[["__scopeId","data-v-35383e8e"]]);export{H as D};
