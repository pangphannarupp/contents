import{d as g,o as v,j as P,l as e,a as n,w as l,u as o,A as i,E as s,bg as f,S as b,bh as h,b7 as y,bi as x,a7 as O,aP as S,L as w,F as D}from"../vendors/vendor-ah_eQdvw.js";import{P as a,aI as r,aJ as u}from"./AccountCardSection-DXixqG3L.js";const B={class:"component-section"},T={style:{"margin-top":"32px"}},k={class:"demo-box",style:{display:"flex",gap:"32px","align-items":"center","justify-content":"center",height:"160px"}},I={style:{width:"40px",height:"40px","border-radius":"50%",background:"#e2e8f0",display:"flex","align-items":"center","justify-content":"center"}},C={style:{"margin-top":"32px"}},A={class:"demo-box",style:{display:"flex",gap:"48px","align-items":"center","justify-content":"center",height:"300px"}},V={style:{cursor:"pointer",padding:"8px","border-radius":"8px",background:"#f1f5f9"}},z=g({__name:"InteractiveOverlaysSection",setup(_){const d=[{label:"View Details",icon:h,value:"view"},{label:"Edit Document",icon:y,value:"edit"},{label:"Share",icon:x,value:"share",disabled:!0},{label:"Delete",icon:O,value:"delete",danger:!0}],m=[{label:"Option 1",value:1},{label:"Option 2",value:2},{label:"Option 3",value:3}],p=c=>{console.log("Selected:",c)};return(c,t)=>(v(),P(D,null,[e("div",B,[t[7]||(t[7]=e("h2",null,"Interactive Overlays",-1)),t[8]||(t[8]=e("p",null,"Contextual components that appear above the main content to provide extra information or actions.",-1)),e("div",T,[t[2]||(t[2]=e("h3",null,"Tooltip",-1)),t[3]||(t[3]=e("p",null,"A brief informative message that appears on hover.",-1)),e("div",k,[n(o(r),{content:"Top placement (Dark)"},{default:l(()=>[n(o(a),{variant:"outline"},{default:l(()=>[...t[0]||(t[0]=[i("Hover Top",-1)])]),_:1})]),_:1}),n(o(r),{content:"Bottom placement (Light)",placement:"bottom",theme:"light"},{default:l(()=>[n(o(a),{variant:"outline"},{default:l(()=>[...t[1]||(t[1]=[i("Hover Bottom",-1)])]),_:1})]),_:1}),n(o(r),{content:"Right placement",placement:"right"},{default:l(()=>[e("div",I,[n(o(s),{icon:o(f),style:{"font-size":"24px",color:"#64748b"}},null,8,["icon"])])]),_:1})])]),e("div",C,[t[5]||(t[5]=e("h3",null,"Dropdown",-1)),t[6]||(t[6]=e("p",null,"A contextual menu for displaying a list of actions.",-1)),e("div",A,[n(o(u),{items:d,onSelect:p},{trigger:l(()=>[n(o(a),null,{default:l(()=>[t[4]||(t[4]=i("Actions ",-1)),n(o(s),{icon:o(b),style:{"margin-left":"8px"}},null,8,["icon"])]),_:1})]),_:1}),n(o(u),{items:m,placement:"bottom-left",onSelect:p},{trigger:l(()=>[e("div",V,[n(o(s),{icon:o(S),style:{"font-size":"20px"}},null,8,["icon"])])]),_:1})])]),t[9]||(t[9]=w(`<div style="margin-top:40px;"><h3>Usage Example</h3><pre class="code-block" style="background:#f8fafc;padding:16px;border-radius:8px;overflow-x:auto;"><code>&lt;template&gt;
  &lt;PPTooltip content=&quot;Hover me!&quot; placement=&quot;top&quot;&gt;
    &lt;PPButton&gt;Action&lt;/PPButton&gt;
  &lt;/PPTooltip&gt;
  
  &lt;PPDropdown :items=&quot;menuItems&quot; @select=&quot;handleSelect&quot;&gt;
    &lt;template #trigger&gt;
      &lt;PPButton&gt;Menu&lt;/PPButton&gt;
    &lt;/template&gt;
  &lt;/PPDropdown&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPTooltip, PPDropdown, PPButton } from &#39;@phanna/ui-framework&#39;;
import { settingsOutline, logOutOutline } from &#39;ionicons/icons&#39;;

const menuItems = [
  { label: &#39;Settings&#39;, icon: settingsOutline },
  { label: &#39;Logout&#39;, icon: logOutOutline, danger: true }
];

const handleSelect = (item) =&gt; {
  console.log(&#39;Selected:&#39;, item.label);
};
&lt;/script&gt;</code></pre></div><div class="variant-group"><h3>Customizing CSS</h3><p class="custom-guide">You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),t[10]||(t[10]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="component-section">
    <h2>Interactive Overlays</h2>
    <p>Contextual components that appear above the main content to provide extra information or actions.</p>

    <!-- Tooltip -->
    <div style="margin-top: 32px;">
      <h3>Tooltip</h3>
      <p>A brief informative message that appears on hover.</p>
      
      <div class="demo-box" style="display: flex; gap: 32px; align-items: center; justify-content: center; height: 160px;">
        <PPTooltip content="Top placement (Dark)">
          <PPButton variant="outline">Hover Top</PPButton>
        </PPTooltip>

        <PPTooltip content="Bottom placement (Light)" placement="bottom" theme="light">
          <PPButton variant="outline">Hover Bottom</PPButton>
        </PPTooltip>

        <PPTooltip content="Right placement" placement="right">
          <div style="width: 40px; height: 40px; border-radius: 50%; background: #e2e8f0; display: flex; align-items: center; justify-content: center;">
            <ion-icon :icon="informationCircleOutline" style="font-size: 24px; color: #64748b;" />
          </div>
        </PPTooltip>
      </div>
    </div>

    <!-- Dropdown -->
    <div style="margin-top: 32px;">
      <h3>Dropdown</h3>
      <p>A contextual menu for displaying a list of actions.</p>
      
      <div class="demo-box" style="display: flex; gap: 48px; align-items: center; justify-content: center; height: 300px;">
        <PPDropdown :items="dropdownItems1" @select="handleSelect">
          <template #trigger>
            <PPButton>Actions <ion-icon :icon="chevronDownOutline" style="margin-left: 8px;" /></PPButton>
          </template>
        </PPDropdown>
        
        <PPDropdown :items="dropdownItems2" placement="bottom-left" @select="handleSelect">
          <template #trigger>
            <div style="cursor: pointer; padding: 8px; border-radius: 8px; background: #f1f5f9;">
              <ion-icon :icon="ellipsisVerticalOutline" style="font-size: 20px;" />
            </div>
          </template>
        </PPDropdown>
      </div>
    </div>

    <!-- Usage Section -->
    <div style="margin-top: 40px;">
      <h3>Usage Example</h3>
      <pre class="code-block" style="background: #f8fafc; padding: 16px; border-radius: 8px; overflow-x: auto;"><code>&lt;template&gt;
  &lt;PPTooltip content="Hover me!" placement="top"&gt;
    &lt;PPButton&gt;Action&lt;/PPButton&gt;
  &lt;/PPTooltip&gt;
  
  &lt;PPDropdown :items="menuItems" @select="handleSelect"&gt;
    &lt;template #trigger&gt;
      &lt;PPButton&gt;Menu&lt;/PPButton&gt;
    &lt;/template&gt;
  &lt;/PPDropdown&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { PPTooltip, PPDropdown, PPButton } from '@phanna/ui-framework';
import { settingsOutline, logOutOutline } from 'ionicons/icons';

const menuItems = [
  { label: 'Settings', icon: settingsOutline },
  { label: 'Logout', icon: logOutOutline, danger: true }
];

const handleSelect = (item) =&gt; {
  console.log('Selected:', item.label);
};
&lt;/script&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { informationCircleOutline, chevronDownOutline, ellipsisVerticalOutline, eyeOutline, createOutline, shareSocialOutline, trashOutline } from 'ionicons/icons';
import { PPTooltip, PPDropdown, PPButton } from '@phanna/ui-framework';
import { IonIcon } from '@ionic/vue';

const dropdownItems1 = [
  { label: 'View Details', icon: eyeOutline, value: 'view' },
  { label: 'Edit Document', icon: createOutline, value: 'edit' },
  { label: 'Share', icon: shareSocialOutline, value: 'share', disabled: true },
  { label: 'Delete', icon: trashOutline, value: 'delete', danger: true }
];

const dropdownItems2 = [
  { label: 'Option 1', value: 1 },
  { label: 'Option 2', value: 2 },
  { label: 'Option 3', value: 3 }
];

const handleSelect = (item: any) => {
  console.log('Selected:', item);
};
<\/script>
`)])],-1))],64))}});export{z as _};
