"use strict";(self["webpackChunkVue_Client"]=self["webpackChunkVue_Client"]||[]).push([[78],{78:function(e,t,n){n.r(t),n.d(t,{startStatusTap:function(){return i}});var r=n(65),s=n(74),o=n(587);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const i=()=>{const e=window;e.addEventListener("statusTap",(()=>{(0,r.wj)((()=>{const t=e.innerWidth,n=e.innerHeight,i=document.elementFromPoint(t/2,n/2);if(!i)return;const u=(0,s.a)(i);u&&new Promise((e=>(0,o.c)(u,e))).then((()=>{(0,r.Iu)((async()=>{u.style.setProperty("--overflow","hidden"),await(0,s.s)(u,300),u.style.removeProperty("--overflow")}))}))}))}))}}}]);
//# sourceMappingURL=78.41b5c941.js.map