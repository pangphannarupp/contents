import{aF as c}from"./AccountCardSection-DXixqG3L.js";import{d as n,o as r,j as t,l as e,a as i,u as d,k as m,F as u,p as g}from"../vendors/vendor-ah_eQdvw.js";import{_ as x}from"./App-D7rwXoHs.js";const v={class:"guide-section"},C={class:"demo-box"},b={key:0,style:{"margin-top":"20px"}},f=["src"],h=n({__name:"ImageCropperSection",setup(y){const a=g(""),p=s=>{a.value=s},l=()=>{alert("Crop cancelled")};return(s,o)=>(r(),t(u,null,[e("div",v,[o[1]||(o[1]=e("h2",null,"Image Cropper",-1)),o[2]||(o[2]=e("p",null,"A component that allows users to crop an image to a specific aspect ratio.",-1)),o[3]||(o[3]=e("h3",null,"Basic Usage",-1)),e("div",C,[i(d(c),{src:"https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&w=1000&q=80",aspectRatio:1,onCrop:p,onCancel:l}),a.value?(r(),t("div",b,[o[0]||(o[0]=e("h4",null,"Cropped Result:",-1)),e("img",{src:a.value,style:{"max-width":"200px","border-radius":"8px"}},null,8,f)])):m("",!0)]),o[4]||(o[4]=e("pre",{class:"code-block"},[e("code",null,'<PPImageCropper src="..." :aspectRatio="1" @crop="..." @cancel="..." />')],-1)),o[5]||(o[5]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-light: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[6]||(o[6]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
  <div class="guide-section">
    <h2>Image Cropper</h2>
    <p>A component that allows users to crop an image to a specific aspect ratio.</p>

    <h3>Basic Usage</h3>
    <div class="demo-box">
      <PPImageCropper 
        src="https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&w=1000&q=80"
        :aspectRatio="1"
        @crop="handleCrop"
        @cancel="handleCropCancel"
      />
      <div v-if="croppedImage" style="margin-top: 20px;">
        <h4>Cropped Result:</h4>
        <img :src="croppedImage" style="max-width: 200px; border-radius: 8px;" />
      </div>
    </div>
    <pre class="code-block"><code>&lt;PPImageCropper src="..." :aspectRatio="1" @crop="..." @cancel="..." /&gt;</code></pre>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-light: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPImageCropper } from '@phanna/ui-framework';

const croppedImage = ref('');

const handleCrop = (dataUrl: string) => {
  croppedImage.value = dataUrl;
};

const handleCropCancel = () => {
  alert('Crop cancelled');
};
<\/script>

<style scoped>
.guide-section { display: flex; flex-direction: column; gap: 24px; }
.demo-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; background: #f9fafb; }
.code-block {
  background: #1f2937;
  color: #e5e7eb;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  font-family: 'Fira Code', Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
  font-size: 14px;
  line-height: 1.5;
  margin: 0;
}
</style>
`)])],-1))],64))}}),w=x(h,[["__scopeId","data-v-52675787"]]);export{w as I};
