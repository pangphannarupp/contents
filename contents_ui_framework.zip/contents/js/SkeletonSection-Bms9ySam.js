import{bt as i,bu as s,bv as n,bw as r}from"./AccountCardSection-DXixqG3L.js";import{d,o as c,j as p,l as e,a as l,u as o,A as a,w as m,F as u}from"../vendors/vendor-ah_eQdvw.js";const v={class:"guide-section"},g={class:"variant-group"},P={class:"component-demo"},S={class:"variant-group",style:{"margin-top":"32px"}},k={class:"component-demo"},x={style:{display:"flex",gap:"16px","align-items":"center"}},y={style:{flex:"1",display:"flex","flex-direction":"column",gap:"8px"}},f={class:"variant-group",style:{"margin-top":"32px"}},h={class:"component-demo"},L=d({__name:"SkeletonSection",setup(b){return(w,t)=>(c(),p(u,null,[e("div",v,[t[7]||(t[7]=e("h2",null,"16. Skeleton Loading",-1)),t[8]||(t[8]=e("p",{class:"guide-desc"},"Beautiful loading placeholders for list and detail views.",-1)),e("div",g,[t[0]||(t[0]=e("h3",null,"List Skeleton",-1)),e("div",P,[l(o(i),{count:3,avatar:!0})]),t[1]||(t[1]=e("pre",{class:"code-block"},[e("code",null,'<PPSkeletonList :count="3" :avatar="true" />')],-1))]),e("div",S,[t[2]||(t[2]=e("h3",null,"Custom Template Skeleton",-1)),t[3]||(t[3]=e("p",{class:"custom-guide"},[a("Use "),e("code",null,"<PPSkeleton>"),a(" to create your own loading layouts")],-1)),e("div",k,[l(o(n),{loading:!0},{template:m(()=>[e("div",x,[l(o(s),{variant:"circle"}),e("div",y,[l(o(s),{variant:"text",width:"60%"}),l(o(s),{variant:"text",width:"80%"}),l(o(s),{variant:"text",width:"40%"})])])]),_:1})]),t[4]||(t[4]=e("pre",{class:"code-block"},[e("code",null,`<PPSkeleton :loading="true">
  <template #template>
    <div style="display: flex; gap: 16px; align-items: center;">
      <PPSkeletonItem variant="circle" />
      <div style="flex: 1; display: flex; flex-direction: column; gap: 8px;">
        <PPSkeletonItem variant="text" width="60%" />
        <PPSkeletonItem variant="text" width="80%" />
        <PPSkeletonItem variant="text" width="40%" />
      </div>
    </div>
  </template>
</PPSkeleton>`)],-1))]),e("div",f,[t[5]||(t[5]=e("h3",null,"Detail Skeleton",-1)),e("div",h,[l(o(r),{paragraphs:2})]),t[6]||(t[6]=e("pre",{class:"code-block"},[e("code",null,'<PPSkeletonDetail :paragraphs="2" />')],-1))]),t[9]||(t[9]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[10]||(t[10]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>16. Skeleton Loading</h2>
        <p class="guide-desc">Beautiful loading placeholders for list and detail views.</p>

        <div class="variant-group">
          <h3>List Skeleton</h3>
          <div class="component-demo">
            <PPSkeletonList :count="3" :avatar="true" />
          </div>
          <pre class="code-block"><code>&lt;PPSkeletonList :count="3" :avatar="true" /&gt;</code></pre>
        </div>

        <div class="variant-group" style="margin-top: 32px;">
          <h3>Custom Template Skeleton</h3>
          <p class="custom-guide">Use <code>&lt;PPSkeleton&gt;</code> to create your own loading layouts</p>
          <div class="component-demo">
            <PPSkeleton :loading="true">
              <template #template>
                <div style="display: flex; gap: 16px; align-items: center;">
                  <PPSkeletonItem variant="circle" />
                  <div style="flex: 1; display: flex; flex-direction: column; gap: 8px;">
                    <PPSkeletonItem variant="text" width="60%" />
                    <PPSkeletonItem variant="text" width="80%" />
                    <PPSkeletonItem variant="text" width="40%" />
                  </div>
                </div>
              </template>
            </PPSkeleton>
          </div>
          <pre class="code-block"><code>&lt;PPSkeleton :loading="true"&gt;
  &lt;template #template&gt;
    &lt;div style="display: flex; gap: 16px; align-items: center;"&gt;
      &lt;PPSkeletonItem variant="circle" /&gt;
      &lt;div style="flex: 1; display: flex; flex-direction: column; gap: 8px;"&gt;
        &lt;PPSkeletonItem variant="text" width="60%" /&gt;
        &lt;PPSkeletonItem variant="text" width="80%" /&gt;
        &lt;PPSkeletonItem variant="text" width="40%" /&gt;
      &lt;/div&gt;
    &lt;/div&gt;
  &lt;/template&gt;
&lt;/PPSkeleton&gt;</code></pre>
        </div>

        <div class="variant-group" style="margin-top: 32px;">
          <h3>Detail Skeleton</h3>
          <div class="component-demo">
            <PPSkeletonDetail :paragraphs="2" />
          </div>
          <pre class="code-block"><code>&lt;PPSkeletonDetail :paragraphs="2" /&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{L as _};
