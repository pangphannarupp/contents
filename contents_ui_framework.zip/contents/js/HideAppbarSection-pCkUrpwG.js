import{aE as r}from"./AccountCardSection-DXixqG3L.js";import{d as o,o as t,j as i,l as e,a as d,w as l,F as s,z as n,y as c,u}from"../vendors/vendor-ah_eQdvw.js";const g={class:"guide-section"},v={class:"variant-group"},m={class:"component-demo",style:{height:"400px",padding:"0"}},h={style:{padding:"16px",display:"flex","flex-direction":"column",gap:"16px"}},H=o({__name:"HideAppbarSection",setup(b){return(y,a)=>(t(),i(s,null,[e("div",g,[a[3]||(a[3]=e("h2",null,"Hide on Scroll App Bar",-1)),a[4]||(a[4]=e("p",{class:"guide-desc"},"A header that seamlessly hides when scrolling down, and reveals when scrolling up.",-1)),e("div",v,[a[1]||(a[1]=e("h3",null,"Interactive Demo",-1)),e("div",m,[d(u(r),{headerHeight:56},{header:l(()=>[...a[0]||(a[0]=[e("div",{style:{height:"100%",display:"flex","align-items":"center",padding:"0 16px",background:"var(--pp-primary-light, #3880ff)",color:"white"}},[e("h2",{style:{margin:"0","font-size":"18px"}},"My Hidden Header")],-1)])]),default:l(()=>[e("div",h,[(t(),i(s,null,n(20,p=>e("div",{key:p,style:{padding:"16px",background:"#fff","border-radius":"8px","box-shadow":"0 2px 4px rgba(0,0,0,0.05)"}}," Scroll me up and down! Item "+c(p),1)),64))])]),_:1})]),a[2]||(a[2]=e("pre",{class:"code-block"},[e("code",null,`<PPHideAppBar :headerHeight="56">
  <template #header>
    <div>My Header</div>
  </template>

  <!-- Scrollable content -->
  <div>...</div>
</PPHideAppBar>`)],-1))]),a[5]||(a[5]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-app-bar-bg: /* value */;
  --pp-app-bar-color: /* value */;
  --pp-app-bar-height: /* value */;
  --pp-app-bar-pb: /* value */;
  --pp-app-bar-pt: /* value */;
  --pp-app-bar-radius: /* value */;
  --pp-app-bar-title-size: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),a[6]||(a[6]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Hide on Scroll App Bar</h2>
        <p class="guide-desc">A header that seamlessly hides when scrolling down, and reveals when scrolling up.</p>

        <div class="variant-group">
          <h3>Interactive Demo</h3>
          <div class="component-demo" style="height: 400px; padding: 0;">
            <PPHideAppBar :headerHeight="56">
              <template #header>
                <div style="height: 100%; display: flex; align-items: center; padding: 0 16px; background: var(--pp-primary-light, #3880ff); color: white;">
                  <h2 style="margin: 0; font-size: 18px;">My Hidden Header</h2>
                </div>
              </template>
              
              <div style="padding: 16px; display: flex; flex-direction: column; gap: 16px;">
                <div v-for="i in 20" :key="i" style="padding: 16px; background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                  Scroll me up and down! Item {{ i }}
                </div>
              </div>
            </PPHideAppBar>
          </div>
          <pre class="code-block"><code>&lt;PPHideAppBar :headerHeight="56"&gt;
  &lt;template #header&gt;
    &lt;div&gt;My Header&lt;/div&gt;
  &lt;/template&gt;

  &lt;!-- Scrollable content --&gt;
  &lt;div&gt;...&lt;/div&gt;
&lt;/PPHideAppBar&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-app-bar-bg: /* value */;
  --pp-app-bar-color: /* value */;
  --pp-app-bar-height: /* value */;
  --pp-app-bar-pb: /* value */;
  --pp-app-bar-pt: /* value */;
  --pp-app-bar-radius: /* value */;
  --pp-app-bar-title-size: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

import { PPHideAppBar } from '@phanna/ui-framework';
<\/script>
`)])],-1))],64))}});export{H as _};
