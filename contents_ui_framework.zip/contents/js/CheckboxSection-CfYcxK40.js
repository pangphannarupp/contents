import{a4 as l,a5 as i}from"./AccountCardSection-DXixqG3L.js";import{d as c,o as u,j as d,l as e,a as t,u as a,w as p,y as m,F as h,p as s}from"../vendors/vendor-ah_eQdvw.js";const b={class:"guide-section"},v={class:"variant-group"},C={class:"component-demo"},k={class:"variant-group"},g={class:"component-demo"},S={style:{"margin-top":"10px","font-size":"14px"}},I=c({__name:"CheckboxSection",setup(f){const P=s(!1),n=s(["payment"]);return(x,o)=>(u(),d(h,null,[e("div",b,[o[7]||(o[7]=e("h2",null,"10. Checkboxes",-1)),e("div",v,[o[2]||(o[2]=e("h3",null,"Standard Checkbox",-1)),e("div",C,[t(a(l),{modelValue:P.value,"onUpdate:modelValue":o[0]||(o[0]=r=>P.value=r),label:"Hide deposit amounts"},null,8,["modelValue"])]),o[3]||(o[3]=e("pre",{class:"code-block"},[e("code",null,`<PPCheckbox 
  v-model="isChecked" 
  label="Hide deposit amounts" 
/>`)],-1))]),e("div",k,[o[4]||(o[4]=e("h3",null,"Checkbox Group",-1)),o[5]||(o[5]=e("p",{class:"custom-guide"},"Group multiple checkboxes bound to an array.",-1)),e("div",g,[t(a(i),{modelValue:n.value,"onUpdate:modelValue":o[1]||(o[1]=r=>n.value=r),vertical:""},{default:p(()=>[t(a(l),{value:"transfer",label:"Transfers"}),t(a(l),{value:"payment",label:"Bill Payments"}),t(a(l),{value:"topup",label:"Mobile Topup"})]),_:1},8,["modelValue"]),e("p",S,"Selected: "+m(n.value),1)]),o[6]||(o[6]=e("pre",{class:"code-block"},[e("code",null,`<PPCheckboxGroup v-model="features" vertical>
  <PPCheckbox value="transfer" label="Transfers" />
  <PPCheckbox value="payment" label="Payments" />
</PPCheckboxGroup>`)],-1))]),o[8]||(o[8]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),o[9]||(o[9]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>10. Checkboxes</h2>

        <div class="variant-group">
          <h3>Standard Checkbox</h3>
          <div class="component-demo">
            <PPCheckbox v-model="hideDeposit" label="Hide deposit amounts" />
          </div>
          <pre class="code-block"><code>&lt;PPCheckbox 
  v-model="isChecked" 
  label="Hide deposit amounts" 
/&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Checkbox Group</h3>
          <p class="custom-guide">Group multiple checkboxes bound to an array.</p>
          <div class="component-demo">
            <PPCheckboxGroup v-model="selectedFeatures" vertical>
              <PPCheckbox value="transfer" label="Transfers" />
              <PPCheckbox value="payment" label="Bill Payments" />
              <PPCheckbox value="topup" label="Mobile Topup" />
            </PPCheckboxGroup>
            <p style="margin-top: 10px; font-size: 14px;">Selected: {{ selectedFeatures }}</p>
          </div>
          <pre class="code-block"><code>&lt;PPCheckboxGroup v-model="features" vertical&gt;
  &lt;PPCheckbox value="transfer" label="Transfers" /&gt;
  &lt;PPCheckbox value="payment" label="Payments" /&gt;
&lt;/PPCheckboxGroup&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const hideDeposit = ref(false);

const selectedFeatures = ref(['payment']);



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{I as _};
