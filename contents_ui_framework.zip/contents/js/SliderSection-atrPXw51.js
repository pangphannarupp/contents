import{d as u,o as P,j as p,l,a as r,u as o,ba as m,cr as c,F as v,p as n}from"../vendors/vendor-ah_eQdvw.js";import{bx as i}from"./AccountCardSection-DXixqG3L.js";const g={class:"guide-section"},b={class:"variant-group"},S={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"24px"}},V={class:"variant-group"},h={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"24px"}},f={class:"variant-group"},k={class:"component-demo",style:{display:"flex","flex-direction":"column",gap:"24px"}},I=u({__name:"SliderSection",setup(y){const a=n(50),s=n({lower:20,upper:80}),d=n(30);return(C,e)=>(P(),p(v,null,[l("div",g,[e[13]||(e[13]=l("h2",null,"Sliders",-1)),e[14]||(e[14]=l("p",{class:"guide-desc"},"A highly customizable slider component supporting single values, ranges, steps, and pins.",-1)),l("div",b,[e[7]||(e[7]=l("h3",null,"Standard & Range",-1)),l("div",S,[r(o(i),{modelValue:a.value,"onUpdate:modelValue":e[0]||(e[0]=t=>a.value=t),label:"Standard",showValue:!0},null,8,["modelValue"]),r(o(i),{modelValue:s.value,"onUpdate:modelValue":e[1]||(e[1]=t=>s.value=t),label:"Dual Knobs (Range)",dualKnobs:!0,showValue:!0},null,8,["modelValue"])]),e[8]||(e[8]=l("pre",{class:"code-block"},[l("code",null,`<template>
  <PPSlider v-model="sliderVal1" label="Standard" :showValue="true" />
  <PPSlider v-model="sliderVal2" label="Dual Knobs (Range)" :dualKnobs="true" :showValue="true" />
</template>

<script setup>
import { ref } from 'vue';
const sliderVal1 = ref(50);
const sliderVal2 = ref({ lower: 20, upper: 80 });
<\/script>`)],-1))]),l("div",V,[e[9]||(e[9]=l("h3",null,"Snaps, Pins & Icons",-1)),l("div",h,[r(o(i),{modelValue:d.value,"onUpdate:modelValue":e[2]||(e[2]=t=>d.value=t),label:"Stepped with Pins",min:0,max:100,step:10,snaps:!0,pin:!0,ticks:!0},null,8,["modelValue"]),r(o(i),{modelValue:a.value,"onUpdate:modelValue":e[3]||(e[3]=t=>a.value=t),startIcon:o(c),endIcon:o(m),color:"secondary"},null,8,["modelValue","startIcon","endIcon"]),r(o(i),{modelValue:a.value,"onUpdate:modelValue":e[4]||(e[4]=t=>a.value=t),label:"Disabled Slider",disabled:!0},null,8,["modelValue"])]),e[10]||(e[10]=l("pre",{class:"code-block"},[l("code",null,`<template>
  <PPSlider v-model="sliderVal3" label="Stepped with Pins" :min="0" :max="100" :step="10" :snaps="true" :pin="true" :ticks="true" />
  <PPSlider v-model="sliderVal1" :startIcon="volumeLowOutline" :endIcon="volumeHighOutline" color="secondary" />
  <PPSlider v-model="sliderVal1" label="Disabled Slider" :disabled="true" />
</template>

<script setup>
import { ref } from 'vue';
import { volumeLowOutline, volumeHighOutline } from 'ionicons/icons';
const sliderVal1 = ref(50);
const sliderVal3 = ref(30);
<\/script>`)],-1))]),l("div",f,[e[11]||(e[11]=l("h3",null,"Material 3 Style",-1)),l("div",k,[r(o(i),{modelValue:a.value,"onUpdate:modelValue":e[5]||(e[5]=t=>a.value=t),label:"M3 Thick Track Slider",variant:"m3",showValue:!0},null,8,["modelValue"]),r(o(i),{modelValue:s.value,"onUpdate:modelValue":e[6]||(e[6]=t=>s.value=t),label:"M3 Range Slider",variant:"m3",dualKnobs:!0,showValue:!0},null,8,["modelValue"])]),e[12]||(e[12]=l("pre",{class:"code-block"},[l("code",null,`<template>
  <PPSlider v-model="sliderVal1" label="M3 Thick Track Slider" variant="m3" :showValue="true" />
  <PPSlider v-model="sliderVal2" label="M3 Range Slider" variant="m3" :dualKnobs="true" :showValue="true" />
</template>

<script setup>
import { ref } from 'vue';
const sliderVal1 = ref(50);
const sliderVal2 = ref({ lower: 20, upper: 80 });
<\/script>`)],-1))]),e[15]||(e[15]=l("div",{class:"variant-group"},[l("h3",null,"Customizing CSS"),l("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),l("pre",{class:"code-block"},[l("code",null,`/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-rgb: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[16]||(e[16]=l("div",{class:"variant-group",style:{"margin-top":"40px"}},[l("h3",null,"Full Page Source Code"),l("p",{class:"custom-guide"},"Complete source code for this section."),l("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[l("code",null,`<template>
<div class="guide-section">
        <h2>Sliders</h2>
        <p class="guide-desc">A highly customizable slider component supporting single values, ranges, steps, and pins.</p>

        <div class="variant-group">
          <h3>Standard & Range</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 24px;">
            <PPSlider v-model="sliderVal1" label="Standard" :showValue="true" />
            <PPSlider v-model="sliderVal2" label="Dual Knobs (Range)" :dualKnobs="true" :showValue="true" />
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPSlider v-model="sliderVal1" label="Standard" :showValue="true" /&gt;
  &lt;PPSlider v-model="sliderVal2" label="Dual Knobs (Range)" :dualKnobs="true" :showValue="true" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
const sliderVal1 = ref(50);
const sliderVal2 = ref({ lower: 20, upper: 80 });
&lt;/script&gt;</code></pre>
        </div>

        <div class="variant-group">
          <h3>Snaps, Pins & Icons</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 24px;">
            <PPSlider v-model="sliderVal3" label="Stepped with Pins" :min="0" :max="100" :step="10" :snaps="true" :pin="true" :ticks="true" />
            <PPSlider v-model="sliderVal1" :startIcon="volumeLowOutline" :endIcon="volumeHighOutline" color="secondary" />
            <PPSlider v-model="sliderVal1" label="Disabled Slider" :disabled="true" />
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPSlider v-model="sliderVal3" label="Stepped with Pins" :min="0" :max="100" :step="10" :snaps="true" :pin="true" :ticks="true" /&gt;
  &lt;PPSlider v-model="sliderVal1" :startIcon="volumeLowOutline" :endIcon="volumeHighOutline" color="secondary" /&gt;
  &lt;PPSlider v-model="sliderVal1" label="Disabled Slider" :disabled="true" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
import { volumeLowOutline, volumeHighOutline } from 'ionicons/icons';
const sliderVal1 = ref(50);
const sliderVal3 = ref(30);
&lt;/script&gt;</code></pre>
        </div>
        <div class="variant-group">
          <h3>Material 3 Style</h3>
          <div class="component-demo" style="display: flex; flex-direction: column; gap: 24px;">
            <PPSlider v-model="sliderVal1" label="M3 Thick Track Slider" variant="m3" :showValue="true" />
            <PPSlider v-model="sliderVal2" label="M3 Range Slider" variant="m3" :dualKnobs="true" :showValue="true" />
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPSlider v-model="sliderVal1" label="M3 Thick Track Slider" variant="m3" :showValue="true" /&gt;
  &lt;PPSlider v-model="sliderVal2" label="M3 Range Slider" variant="m3" :dualKnobs="true" :showValue="true" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
const sliderVal1 = ref(50);
const sliderVal2 = ref({ lower: 20, upper: 80 });
&lt;/script&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary: /* value */;
  --pp-primary-rgb: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const sliderVal1 = ref(50);

const sliderVal2 = ref({ lower: 20, upper: 80 });

const sliderVal3 = ref(30);



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{I as _};
