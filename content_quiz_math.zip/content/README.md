# OVERVIEW
A Simple Maths Quiz build purely on HTML, CSS and JavaScript. No API is used in generating question or Options.
All the questions are generated randomly. The same way are the options.

# TIMER
Timer feature is now added. Each question will have a time limit(10s here).
If the user is unable to pick the answer within that limit, next question will appear and scored for that question is counted zero.

# SCORING
Time based feature added. The scores now will be generated on the basis of how much of time was left for that particular question.
A simple linear function is used. (Ex : If the user finishes one question in 9s, the sore for that question will be 90%).

![image](https://user-images.githubusercontent.com/78557222/122156687-2022f200-ce87-11eb-952d-41f1c9ce44bc.png)
![image](https://user-images.githubusercontent.com/78557222/122156702-274a0000-ce87-11eb-86a4-7e6296c8d8bc.png)
