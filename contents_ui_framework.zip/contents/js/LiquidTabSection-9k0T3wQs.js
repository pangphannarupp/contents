import{d as r,Q as P,o as c,j as d,l as e,a as p,w as a,F as u,p as n,aB as m,bc as b,aD as h}from"../vendors/vendor-ah_eQdvw.js";const g={class:"guide-section"},v={class:"variant-group"},f={class:"component-demo",style:{position:"relative",height:"300px",background:"url('https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=1000&auto=format&fit=crop') center/cover","border-radius":"12px",overflow:"hidden"}},T=r({__name:"LiquidTabSection",setup(y){const o=n(0),i=n([{label:"Home",icon:m},{label:"History",icon:b},{label:"Profile",icon:h}]);return(C,t)=>{const l=P("PPAnimatedTabs");return c(),d(u,null,[e("div",g,[t[6]||(t[6]=e("h2",null,"Liquid Glass Tab Bar (iOS) & Animated Tabs",-1)),t[7]||(t[7]=e("p",{class:"guide-desc"},"A custom floating tab bar with an iOS-style liquid glass (frosted) effect that animates between tab content.",-1)),e("div",v,[t[4]||(t[4]=e("h3",null,"Interactive Demo",-1)),e("div",f,[p(l,{modelValue:o.value,"onUpdate:modelValue":t[0]||(t[0]=s=>o.value=s),tabs:i.value},{"tab-0":a(()=>[...t[1]||(t[1]=[e("div",{style:{padding:"24px",color:"white"}},[e("h3",{style:{color:"white","font-size":"24px"}},"Welcome Home"),e("p",null,"Slide transition applies smoothly across tabs.")],-1)])]),"tab-1":a(()=>[...t[2]||(t[2]=[e("div",{style:{padding:"24px",color:"white"}},[e("h3",{style:{color:"white","font-size":"24px"}},"Transaction History"),e("p",null,"All your recent transactions appear here.")],-1)])]),"tab-2":a(()=>[...t[3]||(t[3]=[e("div",{style:{padding:"24px",color:"white"}},[e("h3",{style:{color:"white","font-size":"24px"}},"Your Profile"),e("p",null,"Manage your account settings.")],-1)])]),_:1},8,["modelValue","tabs"])]),t[5]||(t[5]=e("pre",{class:"code-block"},[e("code",null,`<PPAnimatedTabs v-model="activeTab" :tabs="tabs">
  <template #tab-0>Content 1</template>
  <template #tab-1>Content 2</template>
</PPAnimatedTabs>`)],-1))]),t[8]||(t[8]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[9]||(t[9]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Liquid Glass Tab Bar (iOS) & Animated Tabs</h2>
        <p class="guide-desc">A custom floating tab bar with an iOS-style liquid glass (frosted) effect that animates between tab content.</p>

        <div class="variant-group">
          <h3>Interactive Demo</h3>
          <div class="component-demo" style="position: relative; height: 300px; background: url('https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=1000&auto=format&fit=crop') center/cover; border-radius: 12px; overflow: hidden;">
            <PPAnimatedTabs v-model="animatedTabVal" :tabs="animatedTabs">
              <template #tab-0>
                <div style="padding: 24px; color: white;">
                  <h3 style="color: white; font-size: 24px;">Welcome Home</h3>
                  <p>Slide transition applies smoothly across tabs.</p>
                </div>
              </template>
              <template #tab-1>
                <div style="padding: 24px; color: white;">
                  <h3 style="color: white; font-size: 24px;">Transaction History</h3>
                  <p>All your recent transactions appear here.</p>
                </div>
              </template>
              <template #tab-2>
                <div style="padding: 24px; color: white;">
                  <h3 style="color: white; font-size: 24px;">Your Profile</h3>
                  <p>Manage your account settings.</p>
                </div>
              </template>
            </PPAnimatedTabs>
          </div>
          <pre class="code-block"><code>&lt;PPAnimatedTabs v-model="activeTab" :tabs="tabs"&gt;
  &lt;template #tab-0&gt;Content 1&lt;/template&gt;
  &lt;template #tab-1&gt;Content 2&lt;/template&gt;
&lt;/PPAnimatedTabs&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const animatedTabVal = ref(0);

const animatedTabs = ref([
  { label: 'Home', icon: homeOutline },
  { label: 'History', icon: documentTextOutline },
  { label: 'Profile', icon: personOutline }
]);



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64)}}});export{T as _};
