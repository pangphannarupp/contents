import{bz as r}from"./AccountCardSection-DXixqG3L.js";import{d as a,o as P,j as i,l as e,a as l,u as s,y as c,F as u,p}from"../vendors/vendor-ah_eQdvw.js";const m={class:"guide-section"},d={class:"variant-group"},g={class:"component-demo"},h={style:{"margin-top":"10px"}},k=a({__name:"SpinnerSection",setup(v){const n=p(5);return(S,t)=>(P(),i(u,null,[e("div",m,[t[3]||(t[3]=e("h2",null,"Number Spinner",-1)),e("div",d,[t[1]||(t[1]=e("h3",null,"Min 0, Max 10, Step 1",-1)),e("div",g,[l(s(r),{modelValue:n.value,"onUpdate:modelValue":t[0]||(t[0]=o=>n.value=o),min:0,max:10,step:1},null,8,["modelValue"]),e("p",h,"Value: "+c(n.value),1)]),t[2]||(t[2]=e("pre",{class:"code-block"},[e("code",null,`<template>
  <PPNumberSpinner v-model="spinnerVal" :min="0" :max="10" :step="1" />
</template>

<script setup>
import { ref } from 'vue';
const spinnerVal = ref(5);
<\/script>`)],-1))]),t[4]||(t[4]=e("div",{class:"variant-group"},[e("h3",null,"Customizing CSS"),e("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),e("pre",{class:"code-block"},[e("code",null,`/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),t[5]||(t[5]=e("div",{class:"variant-group",style:{"margin-top":"40px"}},[e("h3",null,"Full Page Source Code"),e("p",{class:"custom-guide"},"Complete source code for this section."),e("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[e("code",null,`<template>
<div class="guide-section">
        <h2>Number Spinner</h2>
        <div class="variant-group">
          <h3>Min 0, Max 10, Step 1</h3>
          <div class="component-demo">
            <PPNumberSpinner v-model="spinnerVal" :min="0" :max="10" :step="1" />
            <p style="margin-top: 10px;">Value: {{ spinnerVal }}</p>
          </div>
          <pre class="code-block"><code>&lt;template&gt;
  &lt;PPNumberSpinner v-model="spinnerVal" :min="0" :max="10" :step="1" /&gt;
&lt;/template&gt;

&lt;script setup&gt;
import { ref } from 'vue';
const spinnerVal = ref(5);
&lt;/script&gt;</code></pre>
        </div>
      
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';

const spinnerVal = ref(5);



import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonTabButton, IonIcon, IonLabel } from '@ionic/vue';

import { addOutline, shareOutline, trashOutline, cardOutline, cashOutline, mapOutline, phonePortraitOutline, settingsOutline, homeOutline, home, documentTextOutline, documentText, personOutline, person, chatbubbleOutline, chatbubble, volumeLowOutline, volumeHighOutline, menuOutline, rocketOutline, cubeOutline, calendarOutline, compassOutline, chatbubbleEllipsesOutline, lockClosedOutline, barChartOutline, layersOutline, searchOutline } from 'ionicons/icons';

import { PPButton, PPButtonGroup, PPImageTransition, PPSwipeItem, PPSlider, PPSwitch, PPBarChart, PPLineChart, PPDonutChart, PPPieChart, PPRadarChart, PPProgressGauge, PPScatterChart, PPFunnelChart, PPSkeleton, PPSkeletonItem, PPSkeletonList, PPSkeletonDetail, PPHideAppBar, PPBottomNav, PPFab, PPFabList, PPFabAction, PPNumberSpinner, PPRadio, PPRadioGroup, PPRating, PPCollapsingToolbar, PPPullToRefresh, PPInput, PPTextField, PPSelect, PPTransferList, PPToggleButton, PPCheckbox, PPCheckboxGroup, PPPhoneInput, PPOtpInput, PPInfoCard, PPActionCard, PPAccountCard, PPSegment, PPSegmentButton, PPCompanySelector, PPScrollSegment, PPScrollSegmentButton, PPNotificationItem, PPPinDots, PPKeypad, PPSecureKeypad, PPSecureKeyboard, PPKhmerKeyboard, PPToast, PPConfirmSheet, PPReceiveAmountSheet, PPAccountSavingCard, PPReceivingAccountSheet, PPKhmerCalendar, PPKhmerCalendarSheet, PPKhmerCalendarAlert, PPKhmerCalendarIsland, PPCalendar, PPCalendarSheet, PPCalendarAlert, PPCalendarIsland, PPFileUpload, PPMonthPicker, PPMonthPickerSheet, PPMonthPickerAlert, PPMonthPickerIsland, PPYearPicker, PPYearPickerSheet, PPYearPickerAlert, PPYearPickerIsland, PPTimePicker, PPTimePickerSheet, PPTimePickerAlert, PPTimePickerIsland, PPAutocomplete, PPAccountListCard, PPAccountReorderList, PPColorPicker, PPColorPickerSheet, PPColorPickerAlert, PPColorPickerIsland, PPNavigationDrawer, PPNavigationRail, PPDynamicIsland, PPCollapse, PPCollapseItem } from '@phanna/ui-framework';

import { KhmerDate } from '@phanna/ui-framework/dist/KhmerDate';
<\/script>
`)])],-1))],64))}});export{k as _};
