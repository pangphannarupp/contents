import{aC as r}from"./AccountCardSection-DXixqG3L.js";import{d as F,o as b,j as h,l as t,a as p,u as d,y,L as P,F as w,p as c}from"../vendors/vendor-ah_eQdvw.js";import{_ as x}from"./App-D7rwXoHs.js";const I={class:"guide-section"},S={class:"demo-box"},U={class:"state-preview"},R={class:"demo-box"},k=F({__name:"FileUploadSection",setup(z){const a=c([]),s=c([]),m=o=>{a.value=o},u=o=>{const e=o.map(l=>({id:Date.now()+Math.random().toString(36).substring(2,9),name:l.name,size:l.size,progress:0,status:"uploading",file:l}));s.value=[...s.value,...e],e.forEach(l=>n(l.id))},g=o=>{s.value=s.value.filter(e=>e.id!==o)},f=o=>{const e=s.value.find(l=>l.id===o);e&&(e.status="uploading",e.progress=0,e.errorMessage=void 0,n(e.id))},n=o=>{let e=0;const l=setInterval(()=>{const i=s.value.find(v=>v.id===o);if(!i){clearInterval(l);return}e+=Math.random()*15+5,e>=100&&(e=100,clearInterval(l),Math.random()>.8?(i.status="error",i.errorMessage="Network error. Please try again."):i.status="success"),i.progress=e},300)};return(o,e)=>(b(),h(w,null,[t("div",I,[e[1]||(e[1]=t("h2",null,"File Upload (Dropzone)",-1)),e[2]||(e[2]=t("p",null,"A comprehensive drag-and-drop file upload area that shows upload progress, file previews, and handles multiple files elegantly.",-1)),e[3]||(e[3]=t("h3",null,"Basic Usage",-1)),e[4]||(e[4]=t("p",null,"A simple file upload component allowing users to click or drag-and-drop a file.",-1)),t("div",S,[p(d(r),{modelValue:a.value,"onUpdate:modelValue":e[0]||(e[0]=l=>a.value=l),onChange:m},null,8,["modelValue"]),t("div",U," Files selected: "+y(a.value.length),1)]),e[5]||(e[5]=t("div",{class:"usage-section"},[t("h4",null,"Usage"),t("pre",{class:"code-block"},[t("code",null,`<template>
  <PPFileUpload
    v-model="files"
    @change="onFileChange"
  />
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPFileUpload } from '@phanna/ui-framework';

const files = ref<File[]>([]);

const onFileChange = (newFiles: File[]) => {
  console.log('Selected files:', newFiles);
};
<\/script>`)])],-1)),e[6]||(e[6]=t("h3",null,"Upload with Progress Simulation",-1)),e[7]||(e[7]=t("p",null,"A complete implementation handling PPFileItem array to simulate an upload process.",-1)),t("div",R,[p(d(r),{files:s.value,multiple:"",accept:"image/png, image/jpeg, application/pdf","max-size":5*1024*1024,onSelect:u,onRemove:g,onRetry:f},null,8,["files"])]),e[8]||(e[8]=P(`<div class="usage-section" data-v-7f1bb5c8><h4 data-v-7f1bb5c8>Usage</h4><pre class="code-block" data-v-7f1bb5c8><code data-v-7f1bb5c8>&lt;template&gt;
  &lt;PPFileUpload
    :files=&quot;uploadFiles&quot;
    multiple
    accept=&quot;image/png, image/jpeg, application/pdf&quot;
    :max-size=&quot;5 * 1024 * 1024&quot;
    @select=&quot;onFileSelect&quot;
    @remove=&quot;onFileRemove&quot;
    @retry=&quot;onFileRetry&quot;
  /&gt;
&lt;/template&gt;

&lt;script setup lang=&quot;ts&quot;&gt;
import { ref } from &#39;vue&#39;;
import { PPFileUpload, PPFileItem } from &#39;@phanna/ui-framework&#39;;

const uploadFiles = ref&lt;PPFileItem[]&gt;([]);

const onFileSelect = (files: File[]) =&gt; {
  const newItems = files.map(f =&gt; ({
    id: Date.now() + Math.random().toString(),
    name: f.name,
    size: f.size,
    progress: 0,
    status: &#39;uploading&#39;,
    file: f
  }));
  
  uploadFiles.value.push(...newItems);
  
  // Example: simulate upload progress
  newItems.forEach(item =&gt; {
    let progress = 0;
    const interval = setInterval(() =&gt; {
      progress += 10;
      const fileRef = uploadFiles.value.find(f =&gt; f.id === item.id);
      if (fileRef) {
        fileRef.progress = progress;
        if (progress &gt;= 100) {
          fileRef.status = &#39;success&#39;;
          clearInterval(interval);
        }
      }
    }, 200);
  });
};

const onFileRemove = (id: string | number) =&gt; {
  uploadFiles.value = uploadFiles.value.filter(f =&gt; f.id !== id);
};

const onFileRetry = (id: string | number) =&gt; {
  // Reset and restart upload logic
};
&lt;/script&gt;</code></pre></div><div class="variant-group" data-v-7f1bb5c8><h3 data-v-7f1bb5c8>Customizing CSS</h3><p class="custom-guide" data-v-7f1bb5c8>You can override the component&#39;s appearance globally via CSS variables or by targeting its specific classes.</p><pre class="code-block" data-v-7f1bb5c8><code data-v-7f1bb5c8>/* Override globally */
:root {
  --pp-primary-light: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre></div>`,2))]),e[9]||(e[9]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="guide-section">
    <h2>File Upload (Dropzone)</h2>
    <p>A comprehensive drag-and-drop file upload area that shows upload progress, file previews, and handles multiple files elegantly.</p>

    <!-- Basic Upload -->
    <h3>Basic Usage</h3>
    <p>A simple file upload component allowing users to click or drag-and-drop a file.</p>
    <div class="demo-box">
      <PPFileUpload
        v-model="files1"
        @change="onFileChange"
      />
      <div class="state-preview">
        Files selected: {{ files1.length }}
      </div>
    </div>
    
    <div class="usage-section">
      <h4>Usage</h4>
      <pre class="code-block"><code>&lt;template&gt;
  &lt;PPFileUpload
    v-model="files"
    @change="onFileChange"
  /&gt;
&lt;/template&gt;

&lt;script setup lang="ts"&gt;
import { ref } from 'vue';
import { PPFileUpload } from '@phanna/ui-framework';

const files = ref&lt;File[]&gt;([]);

const onFileChange = (newFiles: File[]) =&gt; {
  console.log('Selected files:', newFiles);
};
&lt;/script&gt;</code></pre>
    </div>

    <h3>Upload with Progress Simulation</h3>
    <p>A complete implementation handling PPFileItem array to simulate an upload process.</p>
    <div class="demo-box">
      <PPFileUpload
        :files="uploadFiles"
        multiple
        accept="image/png, image/jpeg, application/pdf"
        :max-size="5 * 1024 * 1024"
        @select="onFileSelect"
        @remove="onFileRemove"
        @retry="onFileRetry"
      />
    </div>

    <div class="usage-section">
      <h4>Usage</h4>
      <pre class="code-block"><code>&lt;template&gt;
  &lt;PPFileUpload
    :files="uploadFiles"
    multiple
    accept="image/png, image/jpeg, application/pdf"
    :max-size="5 * 1024 * 1024"
    @select="onFileSelect"
    @remove="onFileRemove"
    @retry="onFileRetry"
  /&gt;
&lt;/template&gt;

&lt;script setup lang="ts"&gt;
import { ref } from 'vue';
import { PPFileUpload, PPFileItem } from '@phanna/ui-framework';

const uploadFiles = ref&lt;PPFileItem[]&gt;([]);

const onFileSelect = (files: File[]) =&gt; {
  const newItems = files.map(f =&gt; ({
    id: Date.now() + Math.random().toString(),
    name: f.name,
    size: f.size,
    progress: 0,
    status: 'uploading',
    file: f
  }));
  
  uploadFiles.value.push(...newItems);
  
  // Example: simulate upload progress
  newItems.forEach(item =&gt; {
    let progress = 0;
    const interval = setInterval(() =&gt; {
      progress += 10;
      const fileRef = uploadFiles.value.find(f =&gt; f.id === item.id);
      if (fileRef) {
        fileRef.progress = progress;
        if (progress &gt;= 100) {
          fileRef.status = 'success';
          clearInterval(interval);
        }
      }
    }, 200);
  });
};

const onFileRemove = (id: string | number) =&gt; {
  uploadFiles.value = uploadFiles.value.filter(f =&gt; f.id !== id);
};

const onFileRetry = (id: string | number) =&gt; {
  // Reset and restart upload logic
};
&lt;/script&gt;</code></pre>
    </div>

  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-primary-light: /* value */;
  --pp-primary-variant: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPFileUpload } from '@phanna/ui-framework';

type PPFileItem = any;

const files1 = ref<File[]>([]);
const uploadFiles = ref<PPFileItem[]>([]);

const onFileChange = (files: File[]) => {
  files1.value = files;
};

const onFileSelect = (files: File[]) => {
  // Convert standard files to PPFileItems
  const newItems: PPFileItem[] = files.map((f: any) => ({
    id: Date.now() + Math.random().toString(36).substring(2, 9),
    name: f.name,
    size: f.size,
    progress: 0,
    status: 'uploading',
    file: f
  }));
  
  uploadFiles.value = [...uploadFiles.value, ...newItems];
  
  // Simulate upload for each new file
  newItems.forEach((item: any) => simulateUpload(item.id));
};

const onFileRemove = (id: string | number) => {
  uploadFiles.value = uploadFiles.value.filter((f: any) => f.id !== id);
};

const onFileRetry = (id: string | number) => {
  const item = uploadFiles.value.find((f: any) => f.id === id);
  if (item) {
    item.status = 'uploading';
    item.progress = 0;
    item.errorMessage = undefined;
    simulateUpload(item.id);
  }
};

const simulateUpload = (id: string | number) => {
  let progress = 0;
  const interval = setInterval(() => {
    // Look up the item from the reactive array to ensure reactivity
    const item = uploadFiles.value.find((f: any) => f.id === id);
    if (!item) {
      clearInterval(interval);
      return;
    }
    
    progress += Math.random() * 15 + 5; // Add 5-20% randomly
    
    if (progress >= 100) {
      progress = 100;
      clearInterval(interval);
      
      // Randomly fail sometimes for demonstration
      if (Math.random() > 0.8) {
        item.status = 'error';
        item.errorMessage = 'Network error. Please try again.';
      } else {
        item.status = 'success';
      }
    }
    
    item.progress = progress;
  }, 300);
};
<\/script>

<style scoped>
.guide-section {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

h2 {
  margin: 0;
  font-size: 24px;
  color: #111827;
}

h3 {
  margin: 0;
  font-size: 18px;
  color: #374151;
  border-bottom: 1px solid #e5e7eb;
  padding-bottom: 8px;
}

p {
  margin: 0;
  color: #6b7280;
  line-height: 1.5;
}

.demo-box {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 24px;
  background: #f9fafb;
}

.state-preview {
  margin-top: 16px;
  padding: 12px;
  background: #f3f4f6;
  border-radius: 6px;
  font-family: monospace;
  font-size: 14px;
  color: #374151;
}

.usage-section {
  margin-top: 24px;
}

.usage-section h4 {
  margin: 0 0 12px 0;
  font-size: 16px;
  color: #4b5563;
}

.code-block {
  background: #1f2937;
  color: #e5e7eb;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  font-family: 'Fira Code', Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
  font-size: 14px;
  line-height: 1.5;
  margin: 0;
}
</style>
`)])],-1))],64))}}),A=x(k,[["__scopeId","data-v-7f1bb5c8"]]);export{A as F};
