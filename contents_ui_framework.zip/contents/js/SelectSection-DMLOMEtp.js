import{av as t}from"./AccountCardSection-DXixqG3L.js";import{d as m,o as f,j as b,l,a as s,u as n,F as S,p as i}from"../vendors/vendor-ah_eQdvw.js";import{_ as g}from"./App-D7rwXoHs.js";const P={class:"guide-section"},x={class:"variant-group"},y={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"24px"}},V={class:"variant-group"},h={class:"demo-box",style:{display:"flex","flex-direction":"column",gap:"24px"}},O=m({__name:"SelectSection",setup(F){const r=i(""),d=i(""),p=i(""),c=i(""),u=i(""),v=i(""),a=[{label:"Option 1",value:"opt1"},{label:"Option 2",value:"opt2"},{label:"Option 3",value:"opt3"}];return(C,e)=>(f(),b(S,null,[l("div",P,[e[9]||(e[9]=l("h2",null,"Select",-1)),e[10]||(e[10]=l("p",null,"A customizable dropdown select component for choosing from a list of options.",-1)),l("div",x,[e[6]||(e[6]=l("h3",null,"Variants",-1)),l("div",y,[s(n(t),{modelValue:r.value,"onUpdate:modelValue":e[0]||(e[0]=o=>r.value=o),options:a,label:"Outlined (Default)",placeholder:"Select an option"},null,8,["modelValue"]),s(n(t),{modelValue:d.value,"onUpdate:modelValue":e[1]||(e[1]=o=>d.value=o),options:a,variant:"filled",label:"Filled",placeholder:"Select an option"},null,8,["modelValue"]),s(n(t),{modelValue:p.value,"onUpdate:modelValue":e[2]||(e[2]=o=>p.value=o),options:a,variant:"flushed",label:"Flushed",placeholder:"Select an option"},null,8,["modelValue"]),s(n(t),{modelValue:c.value,"onUpdate:modelValue":e[3]||(e[3]=o=>c.value=o),options:a,variant:"soft",label:"Soft (Tonal)",placeholder:"Select an option"},null,8,["modelValue"])]),e[7]||(e[7]=l("pre",{class:"code-block"},[l("code",null,`<PPSelect variant="outlined" ... />
<PPSelect variant="filled" ... />
<PPSelect variant="flushed" ... />
<PPSelect variant="soft" ... />`)],-1))]),l("div",V,[e[8]||(e[8]=l("h3",null,"States & Validation",-1)),l("div",h,[s(n(t),{modelValue:u.value,"onUpdate:modelValue":e[4]||(e[4]=o=>u.value=o),options:a,label:"Error State",error:"Please select a valid option.",placeholder:"Invalid selection"},null,8,["modelValue"]),s(n(t),{modelValue:v.value,"onUpdate:modelValue":e[5]||(e[5]=o=>v.value=o),options:a,label:"Disabled State",disabled:"",placeholder:"Cannot select"},null,8,["modelValue"])])]),e[11]||(e[11]=l("div",{class:"variant-group"},[l("h3",null,"Customizing CSS"),l("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),l("pre",{class:"code-block"},[l("code",null,`/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
  --pp-text-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[12]||(e[12]=l("div",{class:"variant-group",style:{"margin-top":"40px"}},[l("h3",null,"Full Page Source Code"),l("p",{class:"custom-guide"},"Complete source code for this section."),l("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[l("code",null,`<template>
  <div class="guide-section">
    <h2>Select</h2>
    <p>A customizable dropdown select component for choosing from a list of options.</p>

    <div class="variant-group">
      <h3>Variants</h3>
      <div class="demo-box" style="display: flex; flex-direction: column; gap: 24px;">
        <PPSelect
          v-model="valOutlined"
          :options="options"
          label="Outlined (Default)"
          placeholder="Select an option"
        />
        <PPSelect
          v-model="valFilled"
          :options="options"
          variant="filled"
          label="Filled"
          placeholder="Select an option"
        />
        <PPSelect
          v-model="valFlushed"
          :options="options"
          variant="flushed"
          label="Flushed"
          placeholder="Select an option"
        />
        <PPSelect
          v-model="valSoft"
          :options="options"
          variant="soft"
          label="Soft (Tonal)"
          placeholder="Select an option"
        />
      </div>
      <pre class="code-block"><code>&lt;PPSelect variant="outlined" ... /&gt;
&lt;PPSelect variant="filled" ... /&gt;
&lt;PPSelect variant="flushed" ... /&gt;
&lt;PPSelect variant="soft" ... /&gt;</code></pre>
    </div>

    <div class="variant-group">
      <h3>States & Validation</h3>
      <div class="demo-box" style="display: flex; flex-direction: column; gap: 24px;">
        <PPSelect
          v-model="valError"
          :options="options"
          label="Error State"
          error="Please select a valid option."
          placeholder="Invalid selection"
        />
        <PPSelect
          v-model="valDisabled"
          :options="options"
          label="Disabled State"
          disabled
          placeholder="Cannot select"
        />
      </div>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  --pp-bg-color: /* value */;
  --pp-border-color: /* value */;
  --pp-primary-color: /* value */;
  --pp-primary-variant: /* value */;
  --pp-text-color: /* value */;
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PPSelect } from '@phanna/ui-framework';

const valOutlined = ref('');
const valFilled = ref('');
const valFlushed = ref('');
const valSoft = ref('');
const valError = ref('');
const valDisabled = ref('');

const options = [
  { label: 'Option 1', value: 'opt1' },
  { label: 'Option 2', value: 'opt2' },
  { label: 'Option 3', value: 'opt3' }
];
<\/script>

<style scoped>
.guide-section {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.demo-box {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 24px;
  background: #f9fafb;
}
</style>
`)])],-1))],64))}}),U=g(O,[["__scopeId","data-v-c8ce4e02"]]);export{U as S};
