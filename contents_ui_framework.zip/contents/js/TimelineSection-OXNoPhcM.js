import{bI as s,bJ as o}from"./AccountCardSection-DXixqG3L.js";import{d as r,o as m,j as p,l as t,a as l,w as i,u as n,A as a,F as d}from"../vendors/vendor-ah_eQdvw.js";import{_ as c}from"./App-D7rwXoHs.js";const P={class:"component-section"},u={class:"demo-box"},g={class:"demo-content"},v={class:"demo-content"},h={class:"demo-box"},T={class:"demo-content"},y={class:"demo-content"},f=r({__name:"TimelineSection",setup(b){return(I,e)=>(m(),p(d,null,[t("div",P,[e[24]||(e[24]=t("h2",null,"Timeline",-1)),e[25]||(e[25]=t("p",null,"A component for displaying a list of events in chronological order.",-1)),t("div",u,[e[6]||(e[6]=t("h3",null,"Vertical Timeline",-1)),t("div",g,[l(n(o),{direction:"vertical"},{default:i(()=>[l(n(s),{timestamp:"2023-04-12",timestampPlacement:"top",type:"primary"},{default:i(()=>[...e[0]||(e[0]=[t("h4",null,"Created",-1),t("p",null,"Order has been created successfully.",-1)])]),_:1}),l(n(s),{timestamp:"2023-04-13",type:"success",size:"large"},{default:i(()=>[...e[1]||(e[1]=[t("h4",null,"Processed",-1),t("p",null,"Order is being processed.",-1)])]),_:1}),l(n(s),{timestamp:"2023-04-14",type:"warning"},{default:i(()=>[...e[2]||(e[2]=[t("h4",null,"Shipped",-1),t("p",null,"Order has been shipped.",-1)])]),_:1})]),_:1})]),e[7]||(e[7]=t("pre",{class:"code-block"},[t("code",null,`<PPTimeline direction="vertical">
  <PPTimelineItem timestamp="2023-04-12" timestampPlacement="top" type="primary">
    <h4>Created</h4>
    <p>Order has been created successfully.</p>
  </PPTimelineItem>
</PPTimeline>`)],-1)),e[8]||(e[8]=t("h3",null,"Horizontal Timeline",-1)),t("div",v,[l(n(o),{direction:"horizontal"},{default:i(()=>[l(n(s),{timestamp:"Step 1",type:"success"},{default:i(()=>[...e[3]||(e[3]=[t("p",null,"Approval",-1)])]),_:1}),l(n(s),{timestamp:"Step 2",type:"primary"},{default:i(()=>[...e[4]||(e[4]=[t("p",null,"Processing",-1)])]),_:1}),l(n(s),{timestamp:"Step 3",type:"info"},{default:i(()=>[...e[5]||(e[5]=[t("p",null,"Done",-1)])]),_:1})]),_:1})]),e[9]||(e[9]=t("pre",{class:"code-block"},[t("code",null,`<PPTimeline direction="horizontal">
  <PPTimelineItem timestamp="Step 1" type="success">
    <p>Approval</p>
  </PPTimelineItem>
</PPTimeline>`)],-1))]),t("div",h,[e[18]||(e[18]=t("h3",null,"Alternate Layout & Hollow Nodes",-1)),e[19]||(e[19]=t("p",{class:"helper-text"},"Alternating sides with hollow variant and dashed lines for pending events. (Reload to see the animation)",-1)),t("div",T,[l(n(o),{direction:"vertical",align:"alternate",animated:""},{default:i(()=>[l(n(s),{timestamp:"2023-04-12",type:"primary",variant:"hollow"},{default:i(()=>[...e[10]||(e[10]=[t("h4",null,"Created",-1),t("p",null,"Order created successfully.",-1)])]),_:1}),l(n(s),{timestamp:"2023-04-13",type:"success",variant:"hollow"},{default:i(()=>[...e[11]||(e[11]=[t("h4",null,"Processed",-1),t("p",null,"Order is being processed.",-1)])]),_:1}),l(n(s),{timestamp:"2023-04-14",type:"warning",variant:"hollow",active:""},{default:i(()=>[...e[12]||(e[12]=[t("h4",null,"Shipped",-1),t("p",null,"Order has been shipped.",-1)])]),_:1}),l(n(s),{timestamp:"Pending",type:"info",variant:"hollow",dashed:""},{default:i(()=>[...e[13]||(e[13]=[t("h4",null,"Delivered",-1),t("p",null,"Awaiting delivery.",-1)])]),_:1})]),_:1})]),e[20]||(e[20]=t("pre",{class:"code-block"},[t("code",null,`<PPTimeline direction="vertical" align="alternate" animated>
  <PPTimelineItem variant="hollow">...</PPTimelineItem>
  <PPTimelineItem variant="hollow" active>...</PPTimelineItem>
  <PPTimelineItem variant="hollow" dashed>...</PPTimelineItem>
</PPTimeline>`)],-1)),e[21]||(e[21]=t("h3",null,"Custom Icon Timeline",-1)),e[22]||(e[22]=t("p",{class:"helper-text"},[a("Use the "),t("code",null,"#icon"),a(" slot to replace the standard dot.")],-1)),t("div",y,[l(n(o),{direction:"vertical"},{default:i(()=>[l(n(s),{type:"success",size:"large"},{icon:i(()=>[...e[14]||(e[14]=[t("div",{style:{background:"#4caf50","border-radius":"50%",width:"24px",height:"24px",display:"flex","align-items":"center","justify-content":"center",color:"white"}},"✓",-1)])]),default:i(()=>[e[15]||(e[15]=t("h4",null,"Step 1 Complete",-1))]),_:1}),l(n(s),{type:"primary",dashed:""},{icon:i(()=>[...e[16]||(e[16]=[t("div",{style:{background:"white",border:"2px solid #1a2a5e","border-radius":"50%",width:"20px",height:"20px",display:"flex","align-items":"center","justify-content":"center",color:"#1a2a5e","font-size":"12px","font-weight":"bold"}},"2",-1)])]),default:i(()=>[e[17]||(e[17]=t("h4",null,"Step 2 In Progress",-1))]),_:1})]),_:1})]),e[23]||(e[23]=t("pre",{class:"code-block"},[t("code",null,`<PPTimeline direction="vertical">
  <PPTimelineItem type="success" size="large">
    <template #icon>
      <div>✓</div>
    </template>
    <h4>Step 1 Complete</h4>
  </PPTimelineItem>
</PPTimeline>`)],-1))]),e[26]||(e[26]=t("div",{class:"variant-group"},[t("h3",null,"Customizing CSS"),t("p",{class:"custom-guide"},"You can override the component's appearance globally via CSS variables or by targeting its specific classes."),t("pre",{class:"code-block"},[t("code",null,`/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}`)])],-1))]),e[27]||(e[27]=t("div",{class:"variant-group",style:{"margin-top":"40px"}},[t("h3",null,"Full Page Source Code"),t("p",{class:"custom-guide"},"Complete source code for this section."),t("pre",{class:"code-block",style:{"max-height":"500px","overflow-y":"auto"}},[t("code",null,`<template>
  <div class="component-section">
    <h2>Timeline</h2>
    <p>A component for displaying a list of events in chronological order.</p>

    <div class="demo-box">
      <h3>Vertical Timeline</h3>
      <div class="demo-content">
        <PPTimeline direction="vertical">
          <PPTimelineItem 
            timestamp="2023-04-12" 
            timestampPlacement="top"
            type="primary"
          >
            <h4>Created</h4>
            <p>Order has been created successfully.</p>
          </PPTimelineItem>
          
          <PPTimelineItem 
            timestamp="2023-04-13" 
            type="success"
            size="large"
          >
            <h4>Processed</h4>
            <p>Order is being processed.</p>
          </PPTimelineItem>

          <PPTimelineItem 
            timestamp="2023-04-14" 
            type="warning"
          >
            <h4>Shipped</h4>
            <p>Order has been shipped.</p>
          </PPTimelineItem>
        </PPTimeline>
      </div>
      <pre class="code-block"><code>&lt;PPTimeline direction="vertical"&gt;
  &lt;PPTimelineItem timestamp="2023-04-12" timestampPlacement="top" type="primary"&gt;
    &lt;h4&gt;Created&lt;/h4&gt;
    &lt;p&gt;Order has been created successfully.&lt;/p&gt;
  &lt;/PPTimelineItem&gt;
&lt;/PPTimeline&gt;</code></pre>

      <h3>Horizontal Timeline</h3>
      <div class="demo-content">
        <PPTimeline direction="horizontal">
          <PPTimelineItem 
            timestamp="Step 1" 
            type="success"
          >
            <p>Approval</p>
          </PPTimelineItem>
          
          <PPTimelineItem 
            timestamp="Step 2" 
            type="primary"
          >
            <p>Processing</p>
          </PPTimelineItem>

          <PPTimelineItem 
            timestamp="Step 3" 
            type="info"
          >
            <p>Done</p>
          </PPTimelineItem>
        </PPTimeline>
      </div>
      <pre class="code-block"><code>&lt;PPTimeline direction="horizontal"&gt;
  &lt;PPTimelineItem timestamp="Step 1" type="success"&gt;
    &lt;p&gt;Approval&lt;/p&gt;
  &lt;/PPTimelineItem&gt;
&lt;/PPTimeline&gt;</code></pre>
    </div>

    <div class="demo-box">
      <h3>Alternate Layout & Hollow Nodes</h3>
      <p class="helper-text">Alternating sides with hollow variant and dashed lines for pending events. (Reload to see the animation)</p>
      <div class="demo-content">
        <PPTimeline direction="vertical" align="alternate" animated>
          <PPTimelineItem timestamp="2023-04-12" type="primary" variant="hollow">
            <h4>Created</h4>
            <p>Order created successfully.</p>
          </PPTimelineItem>
          
          <PPTimelineItem timestamp="2023-04-13" type="success" variant="hollow">
            <h4>Processed</h4>
            <p>Order is being processed.</p>
          </PPTimelineItem>

          <PPTimelineItem timestamp="2023-04-14" type="warning" variant="hollow" active>
            <h4>Shipped</h4>
            <p>Order has been shipped.</p>
          </PPTimelineItem>
          
          <PPTimelineItem timestamp="Pending" type="info" variant="hollow" dashed>
            <h4>Delivered</h4>
            <p>Awaiting delivery.</p>
          </PPTimelineItem>
        </PPTimeline>
      </div>
      <pre class="code-block"><code>&lt;PPTimeline direction="vertical" align="alternate" animated&gt;
  &lt;PPTimelineItem variant="hollow"&gt;...&lt;/PPTimelineItem&gt;
  &lt;PPTimelineItem variant="hollow" active&gt;...&lt;/PPTimelineItem&gt;
  &lt;PPTimelineItem variant="hollow" dashed&gt;...&lt;/PPTimelineItem&gt;
&lt;/PPTimeline&gt;</code></pre>

      <h3>Custom Icon Timeline</h3>
      <p class="helper-text">Use the <code>#icon</code> slot to replace the standard dot.</p>
      <div class="demo-content">
        <PPTimeline direction="vertical">
          <PPTimelineItem type="success" size="large">
            <template #icon>
              <div style="background: #4caf50; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; color: white;">✓</div>
            </template>
            <h4>Step 1 Complete</h4>
          </PPTimelineItem>
          <PPTimelineItem type="primary" dashed>
            <template #icon>
              <div style="background: white; border: 2px solid #1a2a5e; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; color: #1a2a5e; font-size: 12px; font-weight: bold;">2</div>
            </template>
            <h4>Step 2 In Progress</h4>
          </PPTimelineItem>
        </PPTimeline>
      </div>
      <pre class="code-block"><code>&lt;PPTimeline direction="vertical"&gt;
  &lt;PPTimelineItem type="success" size="large"&gt;
    &lt;template #icon&gt;
      &lt;div&gt;✓&lt;/div&gt;
    &lt;/template&gt;
    &lt;h4&gt;Step 1 Complete&lt;/h4&gt;
  &lt;/PPTimelineItem&gt;
&lt;/PPTimeline&gt;</code></pre>
    </div>
  
        <div class="variant-group">
          <h3>Customizing CSS</h3>
          <p class="custom-guide">You can override the component's appearance globally via CSS variables or by targeting its specific classes.</p>
          <pre class="code-block"><code>/* Override globally */
:root {
  /* This component does not use CSS variables directly. */
  /* Use custom classes to override styles. */
}

/* Or target specific instances using custom classes */
.my-custom-component {
  /* Add your custom styles */
}</code></pre>
        </div>
</div>
</template>

<script setup lang="ts">
import { PPTimeline, PPTimelineItem } from '@phanna/ui-framework';
<\/script>

<style scoped>
.demo-box {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 24px;
  margin-top: 16px;
  background: white;
}
.demo-content {
  margin-bottom: 24px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 4px;
}
h4 {
  margin: 0 0 4px 0;
  font-size: 14px;
  font-weight: 600;
  color: #1a2a5e;
}
p {
  margin: 0;
  color: #666;
  font-size: 13px;
}
</style>
`)])],-1))],64))}}),C=c(f,[["__scopeId","data-v-a69e3052"]]);export{C as T};
